--
-- PostgreSQL database dump
--

\restrict Uf3NgEgMYrR3V8mXZl5OuT5B3BeSUerHplKaPLB5vrvRooB4PIX3wWNK1O9mhIt

-- Dumped from database version 13.22 (Debian 13.22-1.pgdg13+1)
-- Dumped by pg_dump version 13.22 (Debian 13.22-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.user_roles DROP CONSTRAINT IF EXISTS user_roles_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_roles DROP CONSTRAINT IF EXISTS user_roles_role_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_permission_overrides DROP CONSTRAINT IF EXISTS user_permission_overrides_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_permission_overrides DROP CONSTRAINT IF EXISTS user_permission_overrides_permission_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_groups DROP CONSTRAINT IF EXISTS user_groups_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_groups DROP CONSTRAINT IF EXISTS user_groups_group_id_fkey;
ALTER TABLE IF EXISTS ONLY public.shows DROP CONSTRAINT IF EXISTS shows_organization_id_fkey;
ALTER TABLE IF EXISTS ONLY public.settings DROP CONSTRAINT IF EXISTS settings_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.segments DROP CONSTRAINT IF EXISTS segments_episode_id_fkey;
ALTER TABLE IF EXISTS ONLY public.seasons DROP CONSTRAINT IF EXISTS seasons_show_id_fkey;
ALTER TABLE IF EXISTS ONLY public.scripts DROP CONSTRAINT IF EXISTS scripts_segment_id_fkey;
ALTER TABLE IF EXISTS ONLY public.rundowns DROP CONSTRAINT IF EXISTS rundowns_episode_id_fkey;
ALTER TABLE IF EXISTS ONLY public.rundown_items DROP CONSTRAINT IF EXISTS rundown_items_segment_id_fkey;
ALTER TABLE IF EXISTS ONLY public.rundown_items DROP CONSTRAINT IF EXISTS rundown_items_rundown_id_fkey;
ALTER TABLE IF EXISTS ONLY public.roles DROP CONSTRAINT IF EXISTS roles_parent_role_id_fkey;
ALTER TABLE IF EXISTS ONLY public.roles DROP CONSTRAINT IF EXISTS roles_organization_id_fkey;
ALTER TABLE IF EXISTS ONLY public.role_permissions DROP CONSTRAINT IF EXISTS role_permissions_role_id_fkey;
ALTER TABLE IF EXISTS ONLY public.role_permissions DROP CONSTRAINT IF EXISTS role_permissions_permission_id_fkey;
ALTER TABLE IF EXISTS ONLY public.regions DROP CONSTRAINT IF EXISTS regions_rundown_id_fkey;
ALTER TABLE IF EXISTS ONLY public.rbac_audit_log DROP CONSTRAINT IF EXISTS rbac_audit_log_organization_id_fkey;
ALTER TABLE IF EXISTS ONLY public.groups DROP CONSTRAINT IF EXISTS groups_organization_id_fkey;
ALTER TABLE IF EXISTS ONLY public.group_roles DROP CONSTRAINT IF EXISTS group_roles_role_id_fkey;
ALTER TABLE IF EXISTS ONLY public.group_roles DROP CONSTRAINT IF EXISTS group_roles_group_id_fkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS fk_users_organization;
ALTER TABLE IF EXISTS ONLY public.episodes DROP CONSTRAINT IF EXISTS episodes_season_id_fkey;
ALTER TABLE IF EXISTS ONLY public.episode_templates DROP CONSTRAINT IF EXISTS episode_templates_template_id_fkey;
ALTER TABLE IF EXISTS ONLY public.episode_templates DROP CONSTRAINT IF EXISTS episode_templates_organization_id_fkey;
ALTER TABLE IF EXISTS ONLY public.episode_templates DROP CONSTRAINT IF EXISTS episode_templates_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.elements DROP CONSTRAINT IF EXISTS elements_segment_id_fkey;
ALTER TABLE IF EXISTS ONLY public.cues DROP CONSTRAINT IF EXISTS cues_segment_id_fkey;
ALTER TABLE IF EXISTS ONLY public.cues DROP CONSTRAINT IF EXISTS cues_element_id_fkey;
ALTER TABLE IF EXISTS ONLY public.cue_blocks DROP CONSTRAINT IF EXISTS cue_blocks_rundown_item_id_fkey;
ALTER TABLE IF EXISTS ONLY public.breaks DROP CONSTRAINT IF EXISTS breaks_episode_id_fkey;
ALTER TABLE IF EXISTS ONLY public.blueprints DROP CONSTRAINT IF EXISTS blueprints_template_id_fkey;
ALTER TABLE IF EXISTS ONLY public.blueprints DROP CONSTRAINT IF EXISTS blueprints_organization_id_fkey;
ALTER TABLE IF EXISTS ONLY public.blueprints DROP CONSTRAINT IF EXISTS blueprints_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.blueprint_nodes DROP CONSTRAINT IF EXISTS blueprint_nodes_template_id_fkey;
ALTER TABLE IF EXISTS ONLY public.blueprint_nodes DROP CONSTRAINT IF EXISTS blueprint_nodes_parent_id_fkey;
DROP INDEX IF EXISTS public.ix_users_username;
DROP INDEX IF EXISTS public.ix_users_id;
DROP INDEX IF EXISTS public.ix_user_sessions_username;
DROP INDEX IF EXISTS public.ix_user_sessions_session_token;
DROP INDEX IF EXISTS public.ix_user_sessions_id;
DROP INDEX IF EXISTS public.ix_user_permission_overrides_user_id;
DROP INDEX IF EXISTS public.ix_user_permission_overrides_permission_id;
DROP INDEX IF EXISTS public.ix_user_permission_overrides_id;
DROP INDEX IF EXISTS public.ix_shows_id;
DROP INDEX IF EXISTS public.ix_shows_asset_id;
DROP INDEX IF EXISTS public.ix_settings_key;
DROP INDEX IF EXISTS public.ix_settings_id;
DROP INDEX IF EXISTS public.ix_segments_slug;
DROP INDEX IF EXISTS public.ix_segments_id;
DROP INDEX IF EXISTS public.ix_segments_asset_id;
DROP INDEX IF EXISTS public.ix_seasons_id;
DROP INDEX IF EXISTS public.ix_seasons_asset_id;
DROP INDEX IF EXISTS public.ix_scripts_id;
DROP INDEX IF EXISTS public.ix_scripts_asset_id;
DROP INDEX IF EXISTS public.ix_rundowns_id;
DROP INDEX IF EXISTS public.ix_rundowns_asset_id;
DROP INDEX IF EXISTS public.ix_rundown_items_legacy_slug;
DROP INDEX IF EXISTS public.ix_rundown_items_legacy_id;
DROP INDEX IF EXISTS public.ix_rundown_items_legacy_asset_id;
DROP INDEX IF EXISTS public.ix_rundown_items_id;
DROP INDEX IF EXISTS public.ix_rundown_items_asset_id;
DROP INDEX IF EXISTS public.ix_roles_slug;
DROP INDEX IF EXISTS public.ix_roles_name;
DROP INDEX IF EXISTS public.ix_roles_id;
DROP INDEX IF EXISTS public.ix_regions_id;
DROP INDEX IF EXISTS public.ix_regions_asset_id;
DROP INDEX IF EXISTS public.ix_rbac_audit_log_id;
DROP INDEX IF EXISTS public.ix_rbac_audit_log_created_at;
DROP INDEX IF EXISTS public.ix_rbac_audit_log_action;
DROP INDEX IF EXISTS public.ix_processing_jobs_job_id;
DROP INDEX IF EXISTS public.ix_processing_jobs_id;
DROP INDEX IF EXISTS public.ix_permissions_resource;
DROP INDEX IF EXISTS public.ix_permissions_name;
DROP INDEX IF EXISTS public.ix_permissions_id;
DROP INDEX IF EXISTS public.ix_permissions_action;
DROP INDEX IF EXISTS public.ix_organizations_id;
DROP INDEX IF EXISTS public.ix_organizations_asset_id;
DROP INDEX IF EXISTS public.ix_groups_slug;
DROP INDEX IF EXISTS public.ix_groups_organization_id;
DROP INDEX IF EXISTS public.ix_groups_name;
DROP INDEX IF EXISTS public.ix_groups_id;
DROP INDEX IF EXISTS public.ix_extracted_quotes_slug;
DROP INDEX IF EXISTS public.ix_extracted_quotes_quote_id;
DROP INDEX IF EXISTS public.ix_extracted_quotes_id;
DROP INDEX IF EXISTS public.ix_episodes_id;
DROP INDEX IF EXISTS public.ix_episodes_asset_id;
DROP INDEX IF EXISTS public.ix_episode_templates_status;
DROP INDEX IF EXISTS public.ix_episode_templates_id;
DROP INDEX IF EXISTS public.ix_episode_templates_episode_number;
DROP INDEX IF EXISTS public.ix_elements_id;
DROP INDEX IF EXISTS public.ix_elements_asset_id;
DROP INDEX IF EXISTS public.ix_cues_id;
DROP INDEX IF EXISTS public.ix_cues_asset_id;
DROP INDEX IF EXISTS public.ix_cue_blocks_slug;
DROP INDEX IF EXISTS public.ix_cue_blocks_id;
DROP INDEX IF EXISTS public.ix_cue_blocks_asset_id;
DROP INDEX IF EXISTS public.ix_breaks_id;
DROP INDEX IF EXISTS public.ix_breaks_asset_id;
DROP INDEX IF EXISTS public.ix_blueprints_status;
DROP INDEX IF EXISTS public.ix_blueprints_id;
DROP INDEX IF EXISTS public.ix_blueprints_episode_number;
DROP INDEX IF EXISTS public.ix_blueprint_templates_template_type;
DROP INDEX IF EXISTS public.ix_blueprint_templates_name;
DROP INDEX IF EXISTS public.ix_blueprint_templates_id;
DROP INDEX IF EXISTS public.ix_blueprint_nodes_id;
DROP INDEX IF EXISTS public.ix_assets_slug;
DROP INDEX IF EXISTS public.ix_assets_id;
DROP INDEX IF EXISTS public.ix_assets_asset_id;
DROP INDEX IF EXISTS public.ix_asset_messages_id;
DROP INDEX IF EXISTS public.ix_asset_messages_asset_id;
DROP INDEX IF EXISTS public.ix_asset_links_target_asset_id;
DROP INDEX IF EXISTS public.ix_asset_links_source_asset_id;
DROP INDEX IF EXISTS public.ix_asset_links_id;
DROP INDEX IF EXISTS public.ix_asset_id_relationships_target_asset_id;
DROP INDEX IF EXISTS public.ix_asset_id_relationships_source_asset_id;
DROP INDEX IF EXISTS public.ix_asset_id_relationships_relationship_type;
DROP INDEX IF EXISTS public.ix_asset_id_relationships_id;
DROP INDEX IF EXISTS public.ix_asset_id_registry_id;
DROP INDEX IF EXISTS public.ix_asset_id_registry_entity_type;
DROP INDEX IF EXISTS public.ix_asset_id_registry_asset_id;
DROP INDEX IF EXISTS public.ix_asset_id_pending_messages_pending_asset_id;
DROP INDEX IF EXISTS public.ix_asset_id_pending_messages_id;
DROP INDEX IF EXISTS public.ix_api_keys_key_prefix;
DROP INDEX IF EXISTS public.ix_api_keys_key_hash;
DROP INDEX IF EXISTS public.ix_api_keys_id;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.user_sessions DROP CONSTRAINT IF EXISTS user_sessions_pkey;
ALTER TABLE IF EXISTS ONLY public.user_roles DROP CONSTRAINT IF EXISTS user_roles_pkey;
ALTER TABLE IF EXISTS ONLY public.user_permission_overrides DROP CONSTRAINT IF EXISTS user_permission_overrides_pkey;
ALTER TABLE IF EXISTS ONLY public.user_groups DROP CONSTRAINT IF EXISTS user_groups_pkey;
ALTER TABLE IF EXISTS ONLY public.shows DROP CONSTRAINT IF EXISTS shows_pkey;
ALTER TABLE IF EXISTS ONLY public.settings DROP CONSTRAINT IF EXISTS settings_pkey;
ALTER TABLE IF EXISTS ONLY public.segments DROP CONSTRAINT IF EXISTS segments_pkey;
ALTER TABLE IF EXISTS ONLY public.seasons DROP CONSTRAINT IF EXISTS seasons_pkey;
ALTER TABLE IF EXISTS ONLY public.scripts DROP CONSTRAINT IF EXISTS scripts_pkey;
ALTER TABLE IF EXISTS ONLY public.rundowns DROP CONSTRAINT IF EXISTS rundowns_pkey;
ALTER TABLE IF EXISTS ONLY public.rundown_items DROP CONSTRAINT IF EXISTS rundown_items_pkey;
ALTER TABLE IF EXISTS ONLY public.rundown_items_legacy DROP CONSTRAINT IF EXISTS rundown_items_legacy_pkey;
ALTER TABLE IF EXISTS ONLY public.roles DROP CONSTRAINT IF EXISTS roles_pkey;
ALTER TABLE IF EXISTS ONLY public.role_permissions DROP CONSTRAINT IF EXISTS role_permissions_pkey;
ALTER TABLE IF EXISTS ONLY public.regions DROP CONSTRAINT IF EXISTS regions_pkey;
ALTER TABLE IF EXISTS ONLY public.rbac_audit_log DROP CONSTRAINT IF EXISTS rbac_audit_log_pkey;
ALTER TABLE IF EXISTS ONLY public.processing_jobs DROP CONSTRAINT IF EXISTS processing_jobs_pkey;
ALTER TABLE IF EXISTS ONLY public.permissions DROP CONSTRAINT IF EXISTS permissions_pkey;
ALTER TABLE IF EXISTS ONLY public.organizations DROP CONSTRAINT IF EXISTS organizations_pkey;
ALTER TABLE IF EXISTS ONLY public.groups DROP CONSTRAINT IF EXISTS groups_pkey;
ALTER TABLE IF EXISTS ONLY public.group_roles DROP CONSTRAINT IF EXISTS group_roles_pkey;
ALTER TABLE IF EXISTS ONLY public.extracted_quotes DROP CONSTRAINT IF EXISTS extracted_quotes_pkey;
ALTER TABLE IF EXISTS ONLY public.episodes DROP CONSTRAINT IF EXISTS episodes_pkey;
ALTER TABLE IF EXISTS ONLY public.episode_templates DROP CONSTRAINT IF EXISTS episode_templates_pkey;
ALTER TABLE IF EXISTS ONLY public.elements DROP CONSTRAINT IF EXISTS elements_pkey;
ALTER TABLE IF EXISTS ONLY public.cues DROP CONSTRAINT IF EXISTS cues_pkey;
ALTER TABLE IF EXISTS ONLY public.cue_blocks DROP CONSTRAINT IF EXISTS cue_blocks_pkey;
ALTER TABLE IF EXISTS ONLY public.breaks DROP CONSTRAINT IF EXISTS breaks_pkey;
ALTER TABLE IF EXISTS ONLY public.blueprints DROP CONSTRAINT IF EXISTS blueprints_pkey;
ALTER TABLE IF EXISTS ONLY public.blueprint_templates DROP CONSTRAINT IF EXISTS blueprint_templates_pkey;
ALTER TABLE IF EXISTS ONLY public.blueprint_nodes DROP CONSTRAINT IF EXISTS blueprint_nodes_pkey;
ALTER TABLE IF EXISTS ONLY public.assets DROP CONSTRAINT IF EXISTS assets_pkey;
ALTER TABLE IF EXISTS ONLY public.asset_messages DROP CONSTRAINT IF EXISTS asset_messages_pkey;
ALTER TABLE IF EXISTS ONLY public.asset_links DROP CONSTRAINT IF EXISTS asset_links_pkey;
ALTER TABLE IF EXISTS ONLY public.asset_id_relationships DROP CONSTRAINT IF EXISTS asset_id_relationships_pkey;
ALTER TABLE IF EXISTS ONLY public.asset_id_registry DROP CONSTRAINT IF EXISTS asset_id_registry_pkey;
ALTER TABLE IF EXISTS ONLY public.asset_id_pending_messages DROP CONSTRAINT IF EXISTS asset_id_pending_messages_pkey;
ALTER TABLE IF EXISTS ONLY public.api_keys DROP CONSTRAINT IF EXISTS api_keys_pkey;
ALTER TABLE IF EXISTS ONLY public.alembic_version DROP CONSTRAINT IF EXISTS alembic_version_pkc;
ALTER TABLE IF EXISTS public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.user_sessions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.user_permission_overrides ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.shows ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.settings ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.segments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.seasons ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.scripts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.rundowns ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.rundown_items_legacy ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.rundown_items ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.roles ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.regions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.rbac_audit_log ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.processing_jobs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.permissions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.organizations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.groups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.extracted_quotes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.episodes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.episode_templates ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.elements ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.cues ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.cue_blocks ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.breaks ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.blueprints ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.blueprint_templates ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.blueprint_nodes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.assets ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.asset_messages ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.asset_links ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.asset_id_relationships ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.asset_id_registry ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.asset_id_pending_messages ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.api_keys ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.users_id_seq;
DROP TABLE IF EXISTS public.users;
DROP SEQUENCE IF EXISTS public.user_sessions_id_seq;
DROP TABLE IF EXISTS public.user_sessions;
DROP TABLE IF EXISTS public.user_roles;
DROP SEQUENCE IF EXISTS public.user_permission_overrides_id_seq;
DROP TABLE IF EXISTS public.user_permission_overrides;
DROP TABLE IF EXISTS public.user_groups;
DROP SEQUENCE IF EXISTS public.shows_id_seq;
DROP TABLE IF EXISTS public.shows;
DROP SEQUENCE IF EXISTS public.settings_id_seq;
DROP TABLE IF EXISTS public.settings;
DROP SEQUENCE IF EXISTS public.segments_id_seq;
DROP TABLE IF EXISTS public.segments;
DROP SEQUENCE IF EXISTS public.seasons_id_seq;
DROP TABLE IF EXISTS public.seasons;
DROP SEQUENCE IF EXISTS public.scripts_id_seq;
DROP TABLE IF EXISTS public.scripts;
DROP SEQUENCE IF EXISTS public.rundowns_id_seq;
DROP TABLE IF EXISTS public.rundowns;
DROP SEQUENCE IF EXISTS public.rundown_items_legacy_id_seq;
DROP TABLE IF EXISTS public.rundown_items_legacy;
DROP SEQUENCE IF EXISTS public.rundown_items_id_seq;
DROP TABLE IF EXISTS public.rundown_items;
DROP SEQUENCE IF EXISTS public.roles_id_seq;
DROP TABLE IF EXISTS public.roles;
DROP TABLE IF EXISTS public.role_permissions;
DROP SEQUENCE IF EXISTS public.regions_id_seq;
DROP TABLE IF EXISTS public.regions;
DROP SEQUENCE IF EXISTS public.rbac_audit_log_id_seq;
DROP TABLE IF EXISTS public.rbac_audit_log;
DROP SEQUENCE IF EXISTS public.processing_jobs_id_seq;
DROP TABLE IF EXISTS public.processing_jobs;
DROP SEQUENCE IF EXISTS public.permissions_id_seq;
DROP TABLE IF EXISTS public.permissions;
DROP SEQUENCE IF EXISTS public.organizations_id_seq;
DROP TABLE IF EXISTS public.organizations;
DROP SEQUENCE IF EXISTS public.groups_id_seq;
DROP TABLE IF EXISTS public.groups;
DROP TABLE IF EXISTS public.group_roles;
DROP SEQUENCE IF EXISTS public.extracted_quotes_id_seq;
DROP TABLE IF EXISTS public.extracted_quotes;
DROP SEQUENCE IF EXISTS public.episodes_id_seq;
DROP TABLE IF EXISTS public.episodes;
DROP SEQUENCE IF EXISTS public.episode_templates_id_seq;
DROP TABLE IF EXISTS public.episode_templates;
DROP SEQUENCE IF EXISTS public.elements_id_seq;
DROP TABLE IF EXISTS public.elements;
DROP SEQUENCE IF EXISTS public.cues_id_seq;
DROP TABLE IF EXISTS public.cues;
DROP SEQUENCE IF EXISTS public.cue_blocks_id_seq;
DROP TABLE IF EXISTS public.cue_blocks;
DROP SEQUENCE IF EXISTS public.breaks_id_seq;
DROP TABLE IF EXISTS public.breaks;
DROP SEQUENCE IF EXISTS public.blueprints_id_seq;
DROP TABLE IF EXISTS public.blueprints;
DROP SEQUENCE IF EXISTS public.blueprint_templates_id_seq;
DROP TABLE IF EXISTS public.blueprint_templates;
DROP SEQUENCE IF EXISTS public.blueprint_nodes_id_seq;
DROP TABLE IF EXISTS public.blueprint_nodes;
DROP SEQUENCE IF EXISTS public.assets_id_seq;
DROP TABLE IF EXISTS public.assets;
DROP SEQUENCE IF EXISTS public.asset_messages_id_seq;
DROP TABLE IF EXISTS public.asset_messages;
DROP SEQUENCE IF EXISTS public.asset_links_id_seq;
DROP TABLE IF EXISTS public.asset_links;
DROP SEQUENCE IF EXISTS public.asset_id_relationships_id_seq;
DROP TABLE IF EXISTS public.asset_id_relationships;
DROP SEQUENCE IF EXISTS public.asset_id_registry_id_seq;
DROP TABLE IF EXISTS public.asset_id_registry;
DROP SEQUENCE IF EXISTS public.asset_id_pending_messages_id_seq;
DROP TABLE IF EXISTS public.asset_id_pending_messages;
DROP SEQUENCE IF EXISTS public.api_keys_id_seq;
DROP TABLE IF EXISTS public.api_keys;
DROP TABLE IF EXISTS public.alembic_version;
DROP TYPE IF EXISTS public.rundownitemtype;
DROP TYPE IF EXISTS public.elementtype;
DROP TYPE IF EXISTS public.cuetype;
--
-- Name: cuetype; Type: TYPE; Schema: public; Owner: showbuild
--

CREATE TYPE public.cuetype AS ENUM (
    'MEDIA',
    'CAMERA',
    'AUDIO_MIC',
    'LIGHTING',
    'DIRECTOR',
    'TALENT'
);


ALTER TYPE public.cuetype OWNER TO showbuild;

--
-- Name: elementtype; Type: TYPE; Schema: public; Owner: showbuild
--

CREATE TYPE public.elementtype AS ENUM (
    'VIDEO',
    'AUDIO',
    'GRAPHIC',
    'ANIMATION',
    'LOWER_THIRD',
    'QUOTE'
);


ALTER TYPE public.elementtype OWNER TO showbuild;

--
-- Name: rundownitemtype; Type: TYPE; Schema: public; Owner: showbuild
--

CREATE TYPE public.rundownitemtype AS ENUM (
    'SEGMENT',
    'OPENING',
    'TEASER',
    'ADVERTISEMENT',
    'PROMO',
    'INTERVIEW',
    'PACKAGE',
    'TRANSITION',
    'STINGER',
    'REJOIN',
    'READER',
    'CLOSE',
    'BREAK'
);


ALTER TYPE public.rundownitemtype OWNER TO showbuild;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO showbuild;

--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.api_keys (
    id integer NOT NULL,
    key_hash character varying(255) NOT NULL,
    key_prefix character varying(8) NOT NULL,
    client_name character varying(100) NOT NULL,
    access_level character varying(20) NOT NULL,
    created_by_username character varying(50) NOT NULL,
    is_active boolean,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    last_used timestamp with time zone,
    expires_at timestamp with time zone,
    usage_count integer
);


ALTER TABLE public.api_keys OWNER TO showbuild;

--
-- Name: api_keys_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.api_keys_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.api_keys_id_seq OWNER TO showbuild;

--
-- Name: api_keys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.api_keys_id_seq OWNED BY public.api_keys.id;


--
-- Name: asset_id_pending_messages; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.asset_id_pending_messages (
    id integer NOT NULL,
    pending_asset_id character varying(50) NOT NULL,
    message_type character varying(50) NOT NULL,
    content text NOT NULL,
    priority integer,
    created_by character varying(255),
    created_at timestamp with time zone DEFAULT now(),
    delivered character varying(5),
    delivered_at timestamp without time zone,
    expires_at timestamp without time zone,
    context json
);


ALTER TABLE public.asset_id_pending_messages OWNER TO showbuild;

--
-- Name: asset_id_pending_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.asset_id_pending_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.asset_id_pending_messages_id_seq OWNER TO showbuild;

--
-- Name: asset_id_pending_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.asset_id_pending_messages_id_seq OWNED BY public.asset_id_pending_messages.id;


--
-- Name: asset_id_registry; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.asset_id_registry (
    id integer NOT NULL,
    asset_id character varying(50) NOT NULL,
    entity_type character varying(50) NOT NULL,
    entity_table character varying(100),
    entity_id integer,
    request_reason character varying(50) NOT NULL,
    request_context json,
    requested_by character varying(255),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    initial_links json,
    is_active character varying(20),
    meta_data json,
    notes text
);


ALTER TABLE public.asset_id_registry OWNER TO showbuild;

--
-- Name: asset_id_registry_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.asset_id_registry_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.asset_id_registry_id_seq OWNER TO showbuild;

--
-- Name: asset_id_registry_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.asset_id_registry_id_seq OWNED BY public.asset_id_registry.id;


--
-- Name: asset_id_relationships; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.asset_id_relationships (
    id integer NOT NULL,
    source_asset_id character varying(50) NOT NULL,
    target_asset_id character varying(50) NOT NULL,
    relationship_type character varying(50) NOT NULL,
    is_bidirectional character varying(5),
    strength integer,
    created_by character varying(255),
    created_at timestamp with time zone DEFAULT now(),
    context json,
    is_active character varying(20),
    notes text
);


ALTER TABLE public.asset_id_relationships OWNER TO showbuild;

--
-- Name: asset_id_relationships_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.asset_id_relationships_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.asset_id_relationships_id_seq OWNER TO showbuild;

--
-- Name: asset_id_relationships_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.asset_id_relationships_id_seq OWNED BY public.asset_id_relationships.id;


--
-- Name: asset_links; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.asset_links (
    id integer NOT NULL,
    source_asset_id character varying(50) NOT NULL,
    target_asset_id character varying(50) NOT NULL,
    link_type character varying(50) NOT NULL,
    meta_data json,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.asset_links OWNER TO showbuild;

--
-- Name: asset_links_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.asset_links_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.asset_links_id_seq OWNER TO showbuild;

--
-- Name: asset_links_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.asset_links_id_seq OWNED BY public.asset_links.id;


--
-- Name: asset_messages; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.asset_messages (
    id integer NOT NULL,
    asset_id character varying(50) NOT NULL,
    message_type character varying(50) NOT NULL,
    content text NOT NULL,
    user_id character varying(100),
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.asset_messages OWNER TO showbuild;

--
-- Name: asset_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.asset_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.asset_messages_id_seq OWNER TO showbuild;

--
-- Name: asset_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.asset_messages_id_seq OWNED BY public.asset_messages.id;


--
-- Name: assets; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.assets (
    id integer NOT NULL,
    episode_id integer NOT NULL,
    asset_id character varying(50) NOT NULL,
    slug character varying(100) NOT NULL,
    filename character varying(255) NOT NULL,
    asset_type character varying(20) NOT NULL,
    file_path character varying(500) NOT NULL,
    file_size integer,
    mime_type character varying(100),
    width integer,
    height integer,
    duration double precision,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    processed boolean,
    meta_data json,
    is_test_data boolean DEFAULT false NOT NULL
);


ALTER TABLE public.assets OWNER TO showbuild;

--
-- Name: assets_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.assets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.assets_id_seq OWNER TO showbuild;

--
-- Name: assets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.assets_id_seq OWNED BY public.assets.id;


--
-- Name: blueprint_nodes; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.blueprint_nodes (
    id integer NOT NULL,
    template_id integer NOT NULL,
    parent_id integer,
    node_type character varying(20) NOT NULL,
    name character varying(255) NOT NULL,
    content text,
    sort_order integer NOT NULL,
    is_required boolean NOT NULL
);


ALTER TABLE public.blueprint_nodes OWNER TO showbuild;

--
-- Name: blueprint_nodes_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.blueprint_nodes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.blueprint_nodes_id_seq OWNER TO showbuild;

--
-- Name: blueprint_nodes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.blueprint_nodes_id_seq OWNED BY public.blueprint_nodes.id;


--
-- Name: blueprint_templates; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.blueprint_templates (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    template_type character varying(50) NOT NULL,
    is_active boolean NOT NULL,
    is_default boolean NOT NULL,
    template_metadata json,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone
);


ALTER TABLE public.blueprint_templates OWNER TO showbuild;

--
-- Name: blueprint_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.blueprint_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.blueprint_templates_id_seq OWNER TO showbuild;

--
-- Name: blueprint_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.blueprint_templates_id_seq OWNED BY public.blueprint_templates.id;


--
-- Name: blueprints; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.blueprints (
    id integer NOT NULL,
    episode_number character varying(10) NOT NULL,
    title character varying(200),
    description text,
    episode_metadata json,
    template_id integer,
    status character varying(20) NOT NULL,
    created_by integer,
    organization_id integer,
    file_path character varying(500),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone
);


ALTER TABLE public.blueprints OWNER TO showbuild;

--
-- Name: blueprints_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.blueprints_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.blueprints_id_seq OWNER TO showbuild;

--
-- Name: blueprints_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.blueprints_id_seq OWNED BY public.blueprints.id;


--
-- Name: breaks; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.breaks (
    id integer NOT NULL,
    asset_id character varying(50) NOT NULL,
    episode_id integer NOT NULL,
    name character varying(50) NOT NULL,
    break_type character varying(50),
    order_in_episode integer NOT NULL,
    estimated_duration character varying(20),
    actual_duration character varying(20),
    description text,
    sponsor character varying(255),
    status character varying(50),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.breaks OWNER TO showbuild;

--
-- Name: breaks_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.breaks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.breaks_id_seq OWNER TO showbuild;

--
-- Name: breaks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.breaks_id_seq OWNED BY public.breaks.id;


--
-- Name: cue_blocks; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.cue_blocks (
    id integer NOT NULL,
    rundown_item_id integer NOT NULL,
    asset_id character varying(50) NOT NULL,
    slug character varying(100) NOT NULL,
    cue_type character varying(10) NOT NULL,
    "order" integer NOT NULL,
    quote_text text,
    attribution character varying(255),
    media_url character varying(500),
    transcription text,
    duration character varying(10),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    validated boolean,
    validation_errors json,
    meta_data json,
    is_test_data boolean DEFAULT false NOT NULL
);


ALTER TABLE public.cue_blocks OWNER TO showbuild;

--
-- Name: cue_blocks_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.cue_blocks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cue_blocks_id_seq OWNER TO showbuild;

--
-- Name: cue_blocks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.cue_blocks_id_seq OWNED BY public.cue_blocks.id;


--
-- Name: cues; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.cues (
    id integer NOT NULL,
    asset_id character varying(50) NOT NULL,
    segment_id integer NOT NULL,
    element_id integer,
    cue_type public.cuetype NOT NULL,
    name character varying(255) NOT NULL,
    time_offset double precision NOT NULL,
    duration double precision,
    parameters json,
    notes text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.cues OWNER TO showbuild;

--
-- Name: cues_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.cues_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cues_id_seq OWNER TO showbuild;

--
-- Name: cues_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.cues_id_seq OWNED BY public.cues.id;


--
-- Name: elements; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.elements (
    id integer NOT NULL,
    asset_id character varying(50) NOT NULL,
    segment_id integer NOT NULL,
    element_type public.elementtype NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(100) NOT NULL,
    file_path character varying(500),
    file_url character varying(500),
    modifications json,
    duration double precision,
    resolution character varying(50),
    file_size integer,
    quote_text text,
    attribution character varying(255),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.elements OWNER TO showbuild;

--
-- Name: elements_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.elements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.elements_id_seq OWNER TO showbuild;

--
-- Name: elements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.elements_id_seq OWNED BY public.elements.id;


--
-- Name: episode_templates; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.episode_templates (
    id integer NOT NULL,
    episode_number character varying(10) NOT NULL,
    title character varying(200),
    description text,
    episode_metadata json,
    template_id integer,
    status character varying(20) NOT NULL,
    created_by integer,
    organization_id integer,
    file_path character varying(500),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone
);


ALTER TABLE public.episode_templates OWNER TO showbuild;

--
-- Name: episode_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.episode_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.episode_templates_id_seq OWNER TO showbuild;

--
-- Name: episode_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.episode_templates_id_seq OWNED BY public.episode_templates.id;


--
-- Name: episodes; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.episodes (
    id integer NOT NULL,
    asset_id character varying(50) NOT NULL,
    season_id integer NOT NULL,
    episode_number integer,
    title character varying(255) NOT NULL,
    slug character varying(100) NOT NULL,
    publish_date timestamp without time zone,
    air_date timestamp without time zone,
    target_duration integer,
    actual_duration integer,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    status character varying(50),
    is_test_data boolean DEFAULT false NOT NULL,
    guest_name character varying(255),
    guest_bio text,
    guest_website character varying(500),
    template_type character varying(50),
    template_id character varying(50),
    template_name character varying(100),
    duration_formatted character varying(10)
);


ALTER TABLE public.episodes OWNER TO showbuild;

--
-- Name: episodes_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.episodes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.episodes_id_seq OWNER TO showbuild;

--
-- Name: episodes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.episodes_id_seq OWNED BY public.episodes.id;


--
-- Name: extracted_quotes; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.extracted_quotes (
    id integer NOT NULL,
    episode_id integer NOT NULL,
    quote_id character varying(50) NOT NULL,
    slug character varying(100) NOT NULL,
    text text NOT NULL,
    attribution character varying(255),
    context text,
    generated_image_path character varying(500),
    image_generated boolean,
    word_count integer,
    character_count integer,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    source_file character varying(500),
    source_line integer,
    is_test_data boolean DEFAULT false NOT NULL
);


ALTER TABLE public.extracted_quotes OWNER TO showbuild;

--
-- Name: extracted_quotes_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.extracted_quotes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.extracted_quotes_id_seq OWNER TO showbuild;

--
-- Name: extracted_quotes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.extracted_quotes_id_seq OWNED BY public.extracted_quotes.id;


--
-- Name: group_roles; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.group_roles (
    group_id integer NOT NULL,
    role_id integer NOT NULL,
    assigned_at timestamp with time zone DEFAULT now(),
    assigned_by character varying(50)
);


ALTER TABLE public.group_roles OWNER TO showbuild;

--
-- Name: groups; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.groups (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    description text,
    is_active boolean,
    color character varying(7),
    organization_id integer NOT NULL,
    auto_assign_new_users boolean,
    settings json,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    created_by character varying(50)
);


ALTER TABLE public.groups OWNER TO showbuild;

--
-- Name: groups_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.groups_id_seq OWNER TO showbuild;

--
-- Name: groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.groups_id_seq OWNED BY public.groups.id;


--
-- Name: organizations; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.organizations (
    id integer NOT NULL,
    asset_id character varying(50) NOT NULL,
    legal_name character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    settings json,
    name character varying(255),
    trade_name character varying(255),
    organization_type character varying(50),
    industry character varying(100),
    sector character varying(100),
    registration_number character varying(100),
    tax_id character varying(50),
    address_line1 character varying(255),
    address_line2 character varying(255),
    city character varying(100),
    state_province character varying(100),
    postal_code character varying(20),
    country character varying(100) DEFAULT 'United States'::character varying NOT NULL,
    phone character varying(30),
    email character varying(255),
    website character varying(255),
    founded_date timestamp with time zone,
    number_of_employees integer,
    annual_revenue bigint,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    created_by character varying(100),
    notes text,
    is_test_data boolean DEFAULT false NOT NULL
);


ALTER TABLE public.organizations OWNER TO showbuild;

--
-- Name: organizations_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.organizations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.organizations_id_seq OWNER TO showbuild;

--
-- Name: organizations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.organizations_id_seq OWNED BY public.organizations.id;


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.permissions (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    display_name character varying(255) NOT NULL,
    description text,
    resource character varying(50) NOT NULL,
    action character varying(50) NOT NULL,
    scope character varying(50) NOT NULL,
    is_system boolean,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    created_by character varying(50)
);


ALTER TABLE public.permissions OWNER TO showbuild;

--
-- Name: permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.permissions_id_seq OWNER TO showbuild;

--
-- Name: permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.permissions_id_seq OWNED BY public.permissions.id;


--
-- Name: processing_jobs; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.processing_jobs (
    id integer NOT NULL,
    episode_id integer NOT NULL,
    job_type character varying(50) NOT NULL,
    job_id character varying(100) NOT NULL,
    status character varying(20) NOT NULL,
    parameters json,
    result json,
    error_message text,
    progress integer NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    is_test_data boolean DEFAULT false NOT NULL
);


ALTER TABLE public.processing_jobs OWNER TO showbuild;

--
-- Name: processing_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.processing_jobs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.processing_jobs_id_seq OWNER TO showbuild;

--
-- Name: processing_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.processing_jobs_id_seq OWNED BY public.processing_jobs.id;


--
-- Name: rbac_audit_log; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.rbac_audit_log (
    id integer NOT NULL,
    action character varying(50) NOT NULL,
    resource_type character varying(50) NOT NULL,
    resource_id integer NOT NULL,
    actor_type character varying(20) NOT NULL,
    actor_id character varying(50) NOT NULL,
    organization_id integer,
    details json,
    ip_address character varying(45),
    user_agent text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.rbac_audit_log OWNER TO showbuild;

--
-- Name: rbac_audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.rbac_audit_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rbac_audit_log_id_seq OWNER TO showbuild;

--
-- Name: rbac_audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.rbac_audit_log_id_seq OWNED BY public.rbac_audit_log.id;


--
-- Name: regions; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.regions (
    id integer NOT NULL,
    asset_id character varying(50) NOT NULL,
    is_test_data boolean NOT NULL,
    rundown_id integer NOT NULL,
    region_type character varying(50) NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    order_in_rundown integer NOT NULL,
    estimated_duration character varying(20),
    actual_duration character varying(20),
    is_collapsible boolean,
    is_collapsed boolean,
    allow_reorder boolean,
    color_theme character varying(50),
    status character varying(50),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.regions OWNER TO showbuild;

--
-- Name: regions_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.regions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.regions_id_seq OWNER TO showbuild;

--
-- Name: regions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.regions_id_seq OWNED BY public.regions.id;


--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.role_permissions (
    role_id integer NOT NULL,
    permission_id integer NOT NULL,
    granted_at timestamp with time zone DEFAULT now(),
    granted_by character varying(50)
);


ALTER TABLE public.role_permissions OWNER TO showbuild;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    description text,
    parent_role_id integer,
    level integer,
    is_system boolean,
    is_active boolean,
    color character varying(7),
    organization_id integer,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    created_by character varying(50)
);


ALTER TABLE public.roles OWNER TO showbuild;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.roles_id_seq OWNER TO showbuild;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: rundown_items; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.rundown_items (
    id integer NOT NULL,
    asset_id character varying(50) NOT NULL,
    rundown_id integer NOT NULL,
    segment_id integer,
    item_type character varying(50) NOT NULL,
    title character varying(255) NOT NULL,
    slug character varying(100) NOT NULL,
    order_in_rundown integer NOT NULL,
    duration character varying(20),
    subtitle character varying(255),
    description text,
    airdate timestamp without time zone,
    guests character varying(500),
    resources text,
    tags character varying(500),
    server_message text,
    link character varying(500),
    priority character varying(50),
    message text,
    status character varying(50),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    is_test_data boolean DEFAULT false NOT NULL,
    script_content text
);


ALTER TABLE public.rundown_items OWNER TO showbuild;

--
-- Name: rundown_items_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.rundown_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rundown_items_id_seq OWNER TO showbuild;

--
-- Name: rundown_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.rundown_items_id_seq OWNED BY public.rundown_items.id;


--
-- Name: rundown_items_legacy; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.rundown_items_legacy (
    id integer NOT NULL,
    episode_id integer NOT NULL,
    asset_id character varying(50) NOT NULL,
    slug character varying(100) NOT NULL,
    type character varying(20) NOT NULL,
    "order" integer NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    duration character varying(10),
    priority character varying(20),
    status character varying(20) NOT NULL,
    script_content text,
    notes text,
    resources text,
    guests character varying(255),
    tags json,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    file_path character varying(500) NOT NULL,
    is_test_data boolean DEFAULT false NOT NULL
);


ALTER TABLE public.rundown_items_legacy OWNER TO showbuild;

--
-- Name: rundown_items_legacy_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.rundown_items_legacy_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rundown_items_legacy_id_seq OWNER TO showbuild;

--
-- Name: rundown_items_legacy_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.rundown_items_legacy_id_seq OWNED BY public.rundown_items_legacy.id;


--
-- Name: rundowns; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.rundowns (
    id integer NOT NULL,
    asset_id character varying(50) NOT NULL,
    episode_id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    order_in_episode integer,
    estimated_duration character varying(20),
    status character varying(50),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.rundowns OWNER TO showbuild;

--
-- Name: rundowns_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.rundowns_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rundowns_id_seq OWNER TO showbuild;

--
-- Name: rundowns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.rundowns_id_seq OWNED BY public.rundowns.id;


--
-- Name: scripts; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.scripts (
    id integer NOT NULL,
    asset_id character varying(50) NOT NULL,
    segment_id integer NOT NULL,
    role character varying(50) NOT NULL,
    content text NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.scripts OWNER TO showbuild;

--
-- Name: scripts_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.scripts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.scripts_id_seq OWNER TO showbuild;

--
-- Name: scripts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.scripts_id_seq OWNED BY public.scripts.id;


--
-- Name: seasons; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.seasons (
    id integer NOT NULL,
    asset_id character varying(50) NOT NULL,
    show_id integer NOT NULL,
    name character varying(255) NOT NULL,
    number integer,
    slug character varying(100) NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.seasons OWNER TO showbuild;

--
-- Name: seasons_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.seasons_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seasons_id_seq OWNER TO showbuild;

--
-- Name: seasons_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.seasons_id_seq OWNED BY public.seasons.id;


--
-- Name: segments; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.segments (
    id integer NOT NULL,
    asset_id character varying(50) NOT NULL,
    episode_id integer,
    rundown_type public.rundownitemtype NOT NULL,
    title character varying(255) NOT NULL,
    slug character varying(100) NOT NULL,
    "order" integer NOT NULL,
    description text,
    tags json,
    thumbnail_url character varying(500),
    estimated_duration integer NOT NULL,
    actual_duration integer,
    in_point double precision,
    out_point double precision,
    markers json,
    publishable boolean,
    published_platforms json,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.segments OWNER TO showbuild;

--
-- Name: segments_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.segments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.segments_id_seq OWNER TO showbuild;

--
-- Name: segments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.segments_id_seq OWNED BY public.segments.id;


--
-- Name: settings; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.settings (
    id integer NOT NULL,
    key character varying(100) NOT NULL,
    value json NOT NULL,
    category character varying(50),
    user_id integer,
    description text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.settings OWNER TO showbuild;

--
-- Name: settings_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.settings_id_seq OWNER TO showbuild;

--
-- Name: settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.settings_id_seq OWNED BY public.settings.id;


--
-- Name: shows; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.shows (
    id integer NOT NULL,
    asset_id character varying(50) NOT NULL,
    organization_id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    settings json,
    is_test_data boolean DEFAULT false NOT NULL
);


ALTER TABLE public.shows OWNER TO showbuild;

--
-- Name: shows_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.shows_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.shows_id_seq OWNER TO showbuild;

--
-- Name: shows_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.shows_id_seq OWNED BY public.shows.id;


--
-- Name: user_groups; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.user_groups (
    user_id integer NOT NULL,
    group_id integer NOT NULL,
    joined_at timestamp with time zone DEFAULT now(),
    added_by character varying(50)
);


ALTER TABLE public.user_groups OWNER TO showbuild;

--
-- Name: user_permission_overrides; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.user_permission_overrides (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL,
    is_granted boolean NOT NULL,
    resource_type character varying(50),
    resource_id character varying(50),
    granted_at timestamp with time zone DEFAULT now(),
    granted_by character varying(50) NOT NULL,
    expires_at timestamp with time zone,
    reason text
);


ALTER TABLE public.user_permission_overrides OWNER TO showbuild;

--
-- Name: user_permission_overrides_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.user_permission_overrides_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_permission_overrides_id_seq OWNER TO showbuild;

--
-- Name: user_permission_overrides_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.user_permission_overrides_id_seq OWNED BY public.user_permission_overrides.id;


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.user_roles (
    user_id integer NOT NULL,
    role_id integer NOT NULL,
    assigned_at timestamp with time zone DEFAULT now(),
    assigned_by character varying(50),
    expires_at timestamp with time zone
);


ALTER TABLE public.user_roles OWNER TO showbuild;

--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.user_sessions (
    id integer NOT NULL,
    session_token character varying(255) NOT NULL,
    username character varying(50) NOT NULL,
    ip_address character varying(45),
    user_agent text,
    created_at timestamp with time zone DEFAULT now(),
    expires_at timestamp with time zone NOT NULL,
    last_activity timestamp with time zone DEFAULT now(),
    is_active boolean
);


ALTER TABLE public.user_sessions OWNER TO showbuild;

--
-- Name: user_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.user_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_sessions_id_seq OWNER TO showbuild;

--
-- Name: user_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.user_sessions_id_seq OWNED BY public.user_sessions.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    hashed_password character varying(255) NOT NULL,
    access_level character varying(20) DEFAULT 'user'::character varying NOT NULL,
    first_name character varying(100),
    last_name character varying(100),
    email character varying(255),
    phone character varying(20),
    profile_picture character varying(500),
    is_active boolean DEFAULT true,
    is_verified boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    last_login timestamp with time zone,
    preferences json DEFAULT '{}'::json,
    organization_id integer,
    is_test_data boolean DEFAULT false NOT NULL
);


ALTER TABLE public.users OWNER TO showbuild;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO showbuild;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: api_keys id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.api_keys ALTER COLUMN id SET DEFAULT nextval('public.api_keys_id_seq'::regclass);


--
-- Name: asset_id_pending_messages id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.asset_id_pending_messages ALTER COLUMN id SET DEFAULT nextval('public.asset_id_pending_messages_id_seq'::regclass);


--
-- Name: asset_id_registry id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.asset_id_registry ALTER COLUMN id SET DEFAULT nextval('public.asset_id_registry_id_seq'::regclass);


--
-- Name: asset_id_relationships id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.asset_id_relationships ALTER COLUMN id SET DEFAULT nextval('public.asset_id_relationships_id_seq'::regclass);


--
-- Name: asset_links id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.asset_links ALTER COLUMN id SET DEFAULT nextval('public.asset_links_id_seq'::regclass);


--
-- Name: asset_messages id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.asset_messages ALTER COLUMN id SET DEFAULT nextval('public.asset_messages_id_seq'::regclass);


--
-- Name: assets id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.assets ALTER COLUMN id SET DEFAULT nextval('public.assets_id_seq'::regclass);


--
-- Name: blueprint_nodes id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.blueprint_nodes ALTER COLUMN id SET DEFAULT nextval('public.blueprint_nodes_id_seq'::regclass);


--
-- Name: blueprint_templates id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.blueprint_templates ALTER COLUMN id SET DEFAULT nextval('public.blueprint_templates_id_seq'::regclass);


--
-- Name: blueprints id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.blueprints ALTER COLUMN id SET DEFAULT nextval('public.blueprints_id_seq'::regclass);


--
-- Name: breaks id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.breaks ALTER COLUMN id SET DEFAULT nextval('public.breaks_id_seq'::regclass);


--
-- Name: cue_blocks id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.cue_blocks ALTER COLUMN id SET DEFAULT nextval('public.cue_blocks_id_seq'::regclass);


--
-- Name: cues id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.cues ALTER COLUMN id SET DEFAULT nextval('public.cues_id_seq'::regclass);


--
-- Name: elements id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.elements ALTER COLUMN id SET DEFAULT nextval('public.elements_id_seq'::regclass);


--
-- Name: episode_templates id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.episode_templates ALTER COLUMN id SET DEFAULT nextval('public.episode_templates_id_seq'::regclass);


--
-- Name: episodes id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.episodes ALTER COLUMN id SET DEFAULT nextval('public.episodes_id_seq'::regclass);


--
-- Name: extracted_quotes id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.extracted_quotes ALTER COLUMN id SET DEFAULT nextval('public.extracted_quotes_id_seq'::regclass);


--
-- Name: groups id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.groups ALTER COLUMN id SET DEFAULT nextval('public.groups_id_seq'::regclass);


--
-- Name: organizations id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.organizations ALTER COLUMN id SET DEFAULT nextval('public.organizations_id_seq'::regclass);


--
-- Name: permissions id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.permissions ALTER COLUMN id SET DEFAULT nextval('public.permissions_id_seq'::regclass);


--
-- Name: processing_jobs id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.processing_jobs ALTER COLUMN id SET DEFAULT nextval('public.processing_jobs_id_seq'::regclass);


--
-- Name: rbac_audit_log id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.rbac_audit_log ALTER COLUMN id SET DEFAULT nextval('public.rbac_audit_log_id_seq'::regclass);


--
-- Name: regions id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.regions ALTER COLUMN id SET DEFAULT nextval('public.regions_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: rundown_items id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.rundown_items ALTER COLUMN id SET DEFAULT nextval('public.rundown_items_id_seq'::regclass);


--
-- Name: rundown_items_legacy id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.rundown_items_legacy ALTER COLUMN id SET DEFAULT nextval('public.rundown_items_legacy_id_seq'::regclass);


--
-- Name: rundowns id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.rundowns ALTER COLUMN id SET DEFAULT nextval('public.rundowns_id_seq'::regclass);


--
-- Name: scripts id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.scripts ALTER COLUMN id SET DEFAULT nextval('public.scripts_id_seq'::regclass);


--
-- Name: seasons id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.seasons ALTER COLUMN id SET DEFAULT nextval('public.seasons_id_seq'::regclass);


--
-- Name: segments id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.segments ALTER COLUMN id SET DEFAULT nextval('public.segments_id_seq'::regclass);


--
-- Name: settings id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.settings ALTER COLUMN id SET DEFAULT nextval('public.settings_id_seq'::regclass);


--
-- Name: shows id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.shows ALTER COLUMN id SET DEFAULT nextval('public.shows_id_seq'::regclass);


--
-- Name: user_permission_overrides id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.user_permission_overrides ALTER COLUMN id SET DEFAULT nextval('public.user_permission_overrides_id_seq'::regclass);


--
-- Name: user_sessions id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.user_sessions ALTER COLUMN id SET DEFAULT nextval('public.user_sessions_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.alembic_version (version_num) FROM stdin;
b3e162fbdbed
\.


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.api_keys (id, key_hash, key_prefix, client_name, access_level, created_by_username, is_active, created_at, updated_at, last_used, expires_at, usage_count) FROM stdin;
6	thkYqftnji5NZC4w8htatupxJAVII5XKOSgc09Mjgh0	thkYqftn	rbac-test	admin	system	t	2025-08-30 06:22:36.39964+00	2025-08-30 06:23:24.590227+00	2025-08-30 06:23:24.59094+00	\N	2
1	MMRwCQVY8JoK5Z0KlCV7gL30oSEHTb6rOUx5kdlPIXI	MMRwCQVY	rbac-test	admin	system	t	2025-08-13 12:59:51.692531+00	2025-08-13 13:00:39.753136+00	2025-08-13 13:00:39.753443+00	\N	8
2	qguC1QhH2b75BJsrWcdoq8Iks0aYBF9RAWKDF4_oPrw	qguC1QhH	rbac-test	admin	system	t	2025-08-16 15:36:44.8043+00	2025-08-16 15:41:40.806279+00	2025-08-16 15:41:40.806708+00	\N	5
7	yf3QE6TPhIp5iecAJ13j0BmLYx3dxBgnfdGvkXu2Gh4	yf3QE6TP	rbac-test	admin	system	t	2025-08-30 12:22:43.139324+00	2025-08-30 12:40:28.159783+00	2025-08-30 12:40:28.160218+00	\N	10
8	nSudN-zXynaRm04RXTJJBeZi0OZNGMf9dtxlm1fKLNY	nSudN-zX	content-editor	service	dev	t	2025-08-30 14:11:28.440056+00	2025-09-27 01:30:26.942081+00	2025-09-27 01:30:26.942313+00	\N	1067
4	eSrLKf90bDdXpNGSPo7rgh_J0vawzIob2eR4xlGjl74	eSrLKf90	rbac-test	admin	system	t	2025-08-23 20:09:53.380378+00	2025-08-23 20:09:58.31753+00	2025-08-23 20:09:58.317936+00	\N	1
9	wwmh8gaDpVDuc9Zn4NPgiZDOuwfxTKFOGU1kU2Jp8GQ	wwmh8gaD	rbac-test	admin	system	t	2025-09-02 07:36:37.861985+00	2025-09-02 10:00:36.433215+00	2025-09-02 10:00:36.43377+00	\N	7
5	_gJC_OcJvWVbEINXBBHf_Fs5PmBe4aWUEGTOGoXUePM	_gJC_OcJ	rbac-test	admin	system	t	2025-08-29 23:32:33.912908+00	\N	\N	\N	0
3	jWKdST7VA59rdKqPeAO6E0Zjqc5f4HqeemsM11YG5JQ	jWKdST7V	rbac-test	admin	system	t	2025-08-16 16:30:22.771685+00	2025-08-30 01:36:05.870897+00	2025-08-30 01:36:05.876263+00	\N	119
\.


--
-- Data for Name: asset_id_pending_messages; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.asset_id_pending_messages (id, pending_asset_id, message_type, content, priority, created_by, created_at, delivered, delivered_at, expires_at, context) FROM stdin;
\.


--
-- Data for Name: asset_id_registry; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.asset_id_registry (id, asset_id, entity_type, entity_table, entity_id, request_reason, request_context, requested_by, created_at, initial_links, is_active, meta_data, notes) FROM stdin;
1	EPSMEEFA0DTJNAYVN	episode	\N	\N	create	{"slug": "test-episode", "cue_type": null, "episode_number": 123, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 15:39:10.67386+00	[]	active	{}	\N
2	SEGMEEFAFL4C5RT2B	segment	\N	\N	create	{"slug": "test-segment", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 15:39:30.280946+00	[{"asset_id": "EPSMEEFA0DTJNAYVN", "link_type": "parent_child"}]	active	{}	\N
3	CUEMEEFALU37XGFSZ	cue	\N	\N	create	{"slug": "sot-cue-1", "cue_type": "SOT", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 15:39:38.380119+00	[{"asset_id": "SEGMEEFAFL4C5RT2B", "link_type": "parent_child"}]	active	{}	\N
4	CUEMEEFBKP63U781E	cue	\N	\N	create	{"slug": "test-gfx-cue", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 15:40:23.563499+00	[{"asset_id": "SEGMEEFAFL4C5RT2B", "link_type": "parent_child"}]	active	{}	\N
5	ASTMEEFD8AX520WY1	ad	\N	\N	create	{"slug": "sponsor-message-1", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 15:41:40.810334+00	[]	active	{}	\N
6	CUEMEEH6LU3HLV29L	cue	\N	\N	create	{"slug": "test", "cue_type": "test", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 16:32:30.987611+00	[]	active	{}	\N
8	EPSMEEJ32D9UFK5BU	episode	\N	\N	create	{"slug": "", "cue_type": null, "episode_number": 236, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:25:45.106883+00	[]	active	{}	\N
9	SEGMEEJ3TNWZ5IUEO	segment	\N	\N	create	{"slug": "news updates", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:26:20.397103+00	[]	active	{}	\N
10	SEGMEEJ3YD0OKZM7D	segment	\N	\N	create	{"slug": "Biltong", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:26:26.486972+00	[]	active	{}	\N
11	SEGMEEJ44L61P9LZV	segment	\N	\N	create	{"slug": "man up", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:26:34.556472+00	[]	active	{}	\N
12	SEGMEEJ4JNYVA02T4	segment	\N	\N	create	{"slug": "Support our work", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:26:54.096722+00	[]	active	{}	\N
13	SEGMEEJ56401DC7UN	segment	\N	\N	create	{"slug": "borderline wild", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:27:23.186441+00	[]	active	{}	\N
14	SEGMEEJ5H1D9I4K1D	segment	\N	\N	create	{"slug": "potpourri", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:27:37.347295+00	[]	active	{}	\N
15	CUEMEEJFS6N0Y6BVP	cue	\N	\N	create	{"slug": "vigilante-tube", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:35:38.353619+00	[{"asset_id": "SEGMEEJ3TNWZ5IUEO", "link_type": "parent_child"}]	active	{}	\N
16	CUEMEEJFW5OXH49CV	cue	\N	\N	create	{"slug": "a group of", "cue_type": "FSQ", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:35:43.502736+00	[{"asset_id": "SEGMEEJ3TNWZ5IUEO", "link_type": "parent_child"}]	active	{}	\N
17	CUEMEEJFZ1B48GJAV	cue	\N	\N	create	{"slug": "the clip shows", "cue_type": "FSQ", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:35:47.233777+00	[{"asset_id": "SEGMEEJ3TNWZ5IUEO", "link_type": "parent_child"}]	active	{}	\N
18	CUEMEEJG1BTTZ9RKK	cue	\N	\N	create	{"slug": "The BTP are", "cue_type": "FSQ", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:35:50.203806+00	[{"asset_id": "SEGMEEJ3TNWZ5IUEO", "link_type": "parent_child"}]	active	{}	\N
19	CUEMEEJG43IE9XE52	cue	\N	\N	create	{"slug": "holly-pictures", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:35:53.792435+00	[{"asset_id": "SEGMEEJ3TNWZ5IUEO", "link_type": "parent_child"}]	active	{}	\N
20	CUEMEEJG6CVN16KFJ	cue	\N	\N	create	{"slug": "cincy-black-leaders", "cue_type": "SOT", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:35:56.721694+00	[{"asset_id": "SEGMEEJ3TNWZ5IUEO", "link_type": "parent_child"}]	active	{}	\N
21	CUEMEEJG9AV3QQNDK	cue	\N	\N	create	{"slug": "walter-tweet", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:36:00.53746+00	[{"asset_id": "SEGMEEJ3TNWZ5IUEO", "link_type": "parent_child"}]	active	{}	\N
22	CUEMEEJGLF9OYQXZC	cue	\N	\N	create	{"slug": "male-cheerleaders", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:36:16.247519+00	[{"asset_id": "SEGMEEJ44L61P9LZV", "link_type": "parent_child"}]	active	{}	\N
23	CUEMEEJGNHIAMNDQO	cue	\N	\N	create	{"slug": "dance-like-girl", "cue_type": "SOT", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:36:18.920579+00	[{"asset_id": "SEGMEEJ44L61P9LZV", "link_type": "parent_child"}]	active	{}	\N
24	CUEMEEJGPMGOLLC0T	cue	\N	\N	create	{"slug": "colin-wright-poll", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:36:21.690777+00	[{"asset_id": "SEGMEEJ44L61P9LZV", "link_type": "parent_child"}]	active	{}	\N
25	CUEMEEJGRSTM36X2K	cue	\N	\N	create	{"slug": "billboard-chris-tweet", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:36:24.511574+00	[{"asset_id": "SEGMEEJ44L61P9LZV", "link_type": "parent_child"}]	active	{}	\N
26	CUEMEEJGUC9SV6YC8	cue	\N	\N	create	{"slug": "john-connor-tweet", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:36:27.804037+00	[{"asset_id": "SEGMEEJ44L61P9LZV", "link_type": "parent_child"}]	active	{}	\N
27	CUEMEEJGWBU9O8PJZ	cue	\N	\N	create	{"slug": "brad-polumbo", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:36:30.380586+00	[{"asset_id": "SEGMEEJ44L61P9LZV", "link_type": "parent_child"}]	active	{}	\N
28	CUEMEEJGZ5BR5TNAN	cue	\N	\N	create	{"slug": "prisha-mosley", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:36:34.033802+00	[{"asset_id": "SEGMEEJ44L61P9LZV", "link_type": "parent_child"}]	active	{}	\N
29	CUEMEEJH18K27GCUJ	cue	\N	\N	create	{"slug": "what-youre-saying", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:36:36.74315+00	[{"asset_id": "SEGMEEJ44L61P9LZV", "link_type": "parent_child"}]	active	{}	\N
30	CUEMEEJH39UTHDQPZ	cue	\N	\N	create	{"slug": "when-you-start", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:36:39.380936+00	[{"asset_id": "SEGMEEJ44L61P9LZV", "link_type": "parent_child"}]	active	{}	\N
31	CUEMEEJH5L5EJ0QLB	cue	\N	\N	create	{"slug": "i-couldnt-disagree", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:36:42.379902+00	[{"asset_id": "SEGMEEJ44L61P9LZV", "link_type": "parent_child"}]	active	{}	\N
291	ASTMFT48660I4ZUKA	break	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:06:03.958468+00	[]	active	{}	\N
292	ASTMFT4866JZS6SZA	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:06:03.971127+00	[]	active	{}	\N
32	CUEMEEJH851KUTI9Z	cue	\N	\N	create	{"slug": "this-way-of-thinking", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:36:45.688006+00	[{"asset_id": "SEGMEEJ44L61P9LZV", "link_type": "parent_child"}]	active	{}	\N
33	CUEMEEJHAGOJO5MHZ	cue	\N	\N	create	{"slug": "why-not", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:36:48.698898+00	[{"asset_id": "SEGMEEJ44L61P9LZV", "link_type": "parent_child"}]	active	{}	\N
34	CUEMEEJHCIJ9X84QX	cue	\N	\N	create	{"slug": "i-kept-seeing", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:36:51.35736+00	[{"asset_id": "SEGMEEJ44L61P9LZV", "link_type": "parent_child"}]	active	{}	\N
35	CUEMEEJHEY901HMCU	cue	\N	\N	create	{"slug": "when-you-were", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:36:54.515804+00	[{"asset_id": "SEGMEEJ44L61P9LZV", "link_type": "parent_child"}]	active	{}	\N
36	CUEMEEJHIMKMC68FC	cue	\N	\N	create	{"slug": "if-it-was", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:36:59.278997+00	[{"asset_id": "SEGMEEJ44L61P9LZV", "link_type": "parent_child"}]	active	{}	\N
37	CUEMEEJHWMROXL1L8	cue	\N	\N	create	{"slug": "pdx-real", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:37:17.429394+00	[{"asset_id": "SEGMEEJ56401DC7UN", "link_type": "parent_child"}]	active	{}	\N
38	CUEMEEJHZTQUO2VE3	cue	\N	\N	create	{"slug": "karen-denver", "cue_type": "SOT", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:37:21.567228+00	[{"asset_id": "SEGMEEJ56401DC7UN", "link_type": "parent_child"}]	active	{}	\N
39	CUEMEEJJ87VW7XCBR	cue	\N	\N	create	{"slug": "cookie-dough", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:38:19.10189+00	[{"asset_id": "SEGMEEJ5H1D9I4K1D", "link_type": "parent_child"}]	active	{}	\N
40	SEGMEENCPXQ375N35	segment	\N	\N	create	{"slug": "slocum consulting", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 19:25:14.018786+00	[]	active	{}	\N
41	CUEMEEND27OHTCFXG	cue	\N	\N	create	{"slug": "Support Disaffected.com", "cue_type": "ADLIB", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 19:25:29.845127+00	[{"asset_id": "SEGMEENCPXQ375N35", "link_type": "parent_child"}]	active	{}	\N
42	CUEMEENDH3XSJ7GMN	cue	\N	\N	create	{"slug": "Support Disaffected.com", "cue_type": "ADLIB", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 19:25:49.151458+00	[{"asset_id": "SEGMEEJ4JNYVA02T4", "link_type": "parent_child"}]	active	{}	\N
43	CUEMEENDM8FGBUPV8	cue	\N	\N	create	{"slug": "biltong adlib", "cue_type": "ADLIB", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 19:25:55.794044+00	[{"asset_id": "SEGMEEJ3YD0OKZM7D", "link_type": "parent_child"}]	active	{}	\N
44	ASTMEEOASULAQYTLJ	promo	\N	\N	create	{"slug": "promo", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 19:51:44.01617+00	[{"asset_id": "EPSMEEJ32D9UFK5BU", "link_type": "parent_child"}]	active	{}	\N
45	SEGMEEOBAPUJXSG4D	segment	\N	\N	create	{"slug": "type: promo", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 19:52:07.171126+00	[]	active	{}	\N
46	CUEMEEPQ1XNB587ME	cue	\N	\N	create	{"slug": "retarded-neighbors", "cue_type": "SOT", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 20:31:35.245573+00	[{"asset_id": "SEGMEEJ5H1D9I4K1D", "link_type": "parent_child"}]	active	{}	\N
47	CUEMEEQS4B424DL1B	cue	\N	\N	create	{"slug": "chris-elston", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 21:01:11.248743+00	[{"asset_id": "SEGMEEJ3TNWZ5IUEO", "link_type": "parent_child"}]	active	{}	\N
48	SEGMEEUGQPOVKPL0G	segment	\N	\N	create	{"slug": null, "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 22:44:18.876763+00	[]	active	{}	\N
49	CUEMEF0GG3OT4EV9G	cue	\N	\N	create	{"slug": "Josh talk", "cue_type": "adlib", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-17 01:32:02.822842+00	[]	active	{}	\N
50	CUEMEF1M0VOTMXHR0	cue	\N	\N	create	{"slug": "a-group-of", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-17 02:04:22.646487+00	[{"asset_id": "SEGMEEJ3TNWZ5IUEO", "link_type": "parent_child"}]	active	{}	\N
51	CUEMEF1MMCNHQ2B7J	cue	\N	\N	create	{"slug": "agrou-of-pt", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-17 02:04:50.473946+00	[{"asset_id": "SEGMEEJ3TNWZ5IUEO", "link_type": "parent_child"}]	active	{}	\N
52	CUEMEF1NP7R2S32UR	cue	\N	\N	create	{"slug": "the-clip-shows", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-17 02:05:40.842083+00	[{"asset_id": "SEGMEEJ3TNWZ5IUEO", "link_type": "parent_child"}]	active	{}	\N
53	CUEMEF1W0XP0Q5PKX	cue	\N	\N	create	{"slug": "btp", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-17 02:12:09.280027+00	[{"asset_id": "SEGMEEJ3TNWZ5IUEO", "link_type": "parent_child"}]	active	{}	\N
54	CUEMEF22TNG6F7ZS8	cue	\N	\N	create	{"slug": "a-group-of", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-17 02:17:26.429128+00	[{"asset_id": "SEGMEEJ3TNWZ5IUEO", "link_type": "parent_child"}]	active	{}	\N
55	CUEMEF23DJ45GABLZ	cue	\N	\N	create	{"slug": "a-group-of-part", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-17 02:17:52.195024+00	[{"asset_id": "SEGMEEJ3TNWZ5IUEO", "link_type": "parent_child"}]	active	{}	\N
56	CUEMEF23VI6WIQ8SW	cue	\N	\N	create	{"slug": "an-off-duty", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-17 02:18:15.489116+00	[{"asset_id": "SEGMEEJ3TNWZ5IUEO", "link_type": "parent_child"}]	active	{}	\N
57	CUEMEF24QS9R6YDTF	cue	\N	\N	create	{"slug": "spokesperson", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-17 02:18:56.025718+00	[{"asset_id": "SEGMEEJ3TNWZ5IUEO", "link_type": "parent_child"}]	active	{}	\N
58	CUEMEF2AE2W19MGZT	cue	\N	\N	create	{"slug": "the-clip", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-17 02:23:19.499039+00	[{"asset_id": "SEGMEEJ3TNWZ5IUEO", "link_type": "parent_child"}]	active	{}	\N
59	SEGMENI0G7NHDS95Y	segment	\N	\N	create	{"slug": "segment", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 00:05:38.965545+00	[]	active	{}	\N
60	CUEMENIEHR7MIKVGP	cue	\N	\N	create	{"slug": "old-cuntry", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 00:16:34.149324+00	[{"asset_id": "slug:", "link_type": "parent_child"}]	active	{}	\N
61	CUEMENIJTO5C5B6VO	cue	\N	\N	create	{"slug": "old-cracker-barrel", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 00:20:42.871436+00	[{"asset_id": "slug:", "link_type": "parent_child"}]	active	{}	\N
62	CUEMENIK9AF8ZAMJJ	cue	\N	\N	create	{"slug": "new-cracker-barrel", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 00:21:03.113902+00	[{"asset_id": "slug:", "link_type": "parent_child"}]	active	{}	\N
63	CUEMENILDKHRC2TKM	cue	\N	\N	create	{"slug": "lgbt-cracker-barrel", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 00:21:55.316206+00	[{"asset_id": "slug:", "link_type": "parent_child"}]	active	{}	\N
64	CUEMENILXIWG7QRQ7	cue	\N	\N	create	{"slug": "black-supremacy-cracker-barrel", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 00:22:21.178816+00	[{"asset_id": "slug:", "link_type": "parent_child"}]	active	{}	\N
65	CUEMENIMRMCYQWKEI	cue	\N	\N	create	{"slug": "neurodiverse-cracker-barrel", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 00:23:00.182543+00	[{"asset_id": "slug:", "link_type": "parent_child"}]	active	{}	\N
66	CUEMENIRGZ906SNAR	cue	\N	\N	create	{"slug": "un-women-journalists", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 00:26:39.669717+00	[{"asset_id": "slug:", "link_type": "parent_child"}]	active	{}	\N
67	CUEMENIS44YIBI1Q7	cue	\N	\N	create	{"slug": "un-women-journalist", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 00:27:09.683049+00	[{"asset_id": "slug:", "link_type": "parent_child"}]	active	{}	\N
68	CUEMENIUDD21M7S2X	cue	\N	\N	create	{"slug": "pamela-tweet", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 00:28:54.953047+00	[{"asset_id": "slug:", "link_type": "parent_child"}]	active	{}	\N
69	CUEMENIWAI54O2R24	cue	\N	\N	create	{"slug": "pam-dr-janja-laich-national-cult-minorities", "cue_type": "sot", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 00:30:24.559332+00	[{"asset_id": "slug:", "link_type": "parent_child"}]	active	{}	\N
70	CUEMENIZ7HH2OW09M	cue	\N	\N	create	{"slug": "assault-ice-officer", "cue_type": "sot", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 00:32:40.616157+00	[{"asset_id": "slug:", "link_type": "parent_child"}]	active	{}	\N
71	CUEMENJ1R1M5WVTRP	cue	\N	\N	create	{"slug": "taylor-swift-whore", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 00:34:39.276316+00	[{"asset_id": "slug:", "link_type": "parent_child"}]	active	{}	\N
72	CUEMENJH97NHXBN4P	cue	\N	\N	create	{"slug": "ozempic-vag", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 00:46:42.661809+00	[{"asset_id": "slug:", "link_type": "parent_child"}]	active	{}	\N
73	CUEMENJIUTTLKPHDF	cue	\N	\N	create	{"slug": "cher-believe", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 00:47:57.332069+00	[{"asset_id": "slug:", "link_type": "parent_child"}]	active	{}	\N
74	CUEMENJJDS312LZRG	cue	\N	\N	create	{"slug": "response-to-cher-believe", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 00:48:21.894202+00	[{"asset_id": "slug:", "link_type": "parent_child"}]	active	{}	\N
75	SEGMENJX099GXB5YW	segment	\N	\N	create	{"slug": "segment", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 00:58:57.549931+00	[]	active	{}	\N
76	CUEMENM36688GBOIO	cue	\N	\N	create	{"slug": "first-ag-vid", "cue_type": "sot", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 01:59:44.386314+00	[{"asset_id": "LOCAL-RD-menkaa03-ma8qf", "link_type": "parent_child"}]	active	{}	\N
77	CUEMENMPWWR6J4IP4	cue	\N	\N	create	{"slug": "shoot-maga", "cue_type": "sot", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 02:17:25.469464+00	[{"asset_id": "LOCAL-RD-menkaa03-ma8qf", "link_type": "parent_child"}]	active	{}	\N
78	CUEMENMRO3E5UHGQO	cue	\N	\N	create	{"slug": "pamela-tweet", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 02:18:47.356425+00	[{"asset_id": "LOCAL-RD-menkaa03-ma8qf", "link_type": "parent_child"}]	active	{}	\N
79	CUEMENMSMYX79Z3L4	cue	\N	\N	create	{"slug": "pam-dr-janja", "cue_type": "sot", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 02:19:32.556155+00	[{"asset_id": "LOCAL-RD-menkaa03-ma8qf", "link_type": "parent_child"}]	active	{}	\N
80	CUEMENMUQO30DJWZ6	cue	\N	\N	create	{"slug": "assault-ice-officer", "cue_type": "sot", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 02:21:10.660382+00	[{"asset_id": "LOCAL-RD-menkaa03-ma8qf", "link_type": "parent_child"}]	active	{}	\N
81	ASTMENN08JNRJDC0G	ad	\N	\N	create	{"slug": "ad", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 02:25:27.109253+00	[]	active	{}	\N
82	SEGMENN1KTT4WZ9IA	segment	\N	\N	create	{"slug": "segment", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 02:26:29.683264+00	[]	active	{}	\N
83	CUEMENN9OHORZFJJL	cue	\N	\N	create	{"slug": "covid-lockdowns", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 02:32:47.678517+00	[{"asset_id": "SEGMEEJ3TNWZ5IUEO", "link_type": "parent_child"}]	active	{}	\N
84	CUEMENNBL547W2F07	cue	\N	\N	create	{"slug": "young-adults-chart", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 02:34:16.650666+00	[{"asset_id": "SEGMEEJ3TNWZ5IUEO", "link_type": "parent_child"}]	active	{}	\N
85	ASTMENNENQDGGNHMO	ad	\N	\N	create	{"slug": "ad", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 02:36:39.976161+00	[]	active	{}	\N
86	ASTMENNGGSESOGQAU	ad	\N	\N	create	{"slug": "ad", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 02:38:04.28881+00	[]	active	{}	\N
87	SEGMENNHZMNHN1OLZ	segment	\N	\N	create	{"slug": "segment", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 02:39:15.361445+00	[]	active	{}	\N
88	CUEMENNQEK7IBMNV5	cue	\N	\N	create	{"slug": "red-mcdonalds", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 02:45:47.961449+00	[{"asset_id": "slug: 60 Cracker Barrel", "link_type": "parent_child"}]	active	{}	\N
89	CUEMENNRBBBQIXF7I	cue	\N	\N	create	{"slug": "new-mdcdonalds", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 02:46:30.407515+00	[{"asset_id": "slug: 60 Cracker Barrel", "link_type": "parent_child"}]	active	{}	\N
90	CUEMENNSC98CS9ZZU	cue	\N	\N	create	{"slug": "old-cracker-barrel", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 02:47:18.287016+00	[{"asset_id": "slug: 60 Cracker Barrel", "link_type": "parent_child"}]	active	{}	\N
91	CUEMENNSXUZ1JDLZ7	cue	\N	\N	create	{"slug": "new-cracker-barrel", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 02:47:46.286321+00	[{"asset_id": "slug: 60 Cracker Barrel", "link_type": "parent_child"}]	active	{}	\N
180	ASTMFMGIV8TOXYGSJ	rundown_item	\N	\N	segment_mirror	{"filename": "Segment.md", "episode_number": "0238", "title": "Segment"}	segment_mirror_script	2025-09-16 11:15:55.173805+00	[]	active	{}	\N
92	CUEMENNVF3E2C7XIL	cue	\N	\N	create	{"slug": "inside-cracker-barrel", "cue_type": "sot", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 02:49:41.932756+00	[{"asset_id": "slug: 60 Cracker Barrel", "link_type": "parent_child"}]	active	{}	\N
93	SEGMENNWG7MZFJ7T4	segment	\N	\N	create	{"slug": "segment", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 02:50:30.037126+00	[]	active	{}	\N
94	SEGMENO45GP697XFT	segment	\N	\N	create	{"slug": "female narcissism", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 02:56:29.356168+00	[]	active	{}	\N
95	SEGMENO4J9M1S526M	segment	\N	\N	create	{"slug": "segment", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 02:56:47.244429+00	[]	active	{}	\N
96	CUEMENOBAE6S4NZSE	cue	\N	\N	create	{"slug": "taylor-swift", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 03:02:02.336303+00	[{"asset_id": "slug: taylor swift", "link_type": "parent_child"}]	active	{}	\N
97	SEGMEOFKUYOZE0Y76	segment	\N	\N	create	{"slug": "type: coldopen", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 15:45:18.530697+00	[]	active	{}	\N
98	SEGMEOIYLBRXWRRFC	segment	\N	\N	create	{"slug": "segment", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 17:19:58.07409+00	[]	active	{}	\N
99	SEGMEOIZJ66BP0L2S	segment	\N	\N	create	{"slug": "type: segment", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 17:20:41.936397+00	[]	active	{}	\N
100	SEGMEOJ3IIYIR5I9H	segment	\N	\N	create	{"slug": "60 Cracker Barrel", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 17:23:47.7244+00	[]	active	{}	\N
101	SEGMEOJ449DRJ4QTV	segment	\N	\N	create	{"slug": "taylor swift", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 17:24:15.889617+00	[]	active	{}	\N
102	SEGMEOJ4VJG38C2GD	segment	\N	\N	create	{"slug": "segment", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 17:24:51.246417+00	[]	active	{}	\N
103	SEGMEOJ57H90X3NHF	segment	\N	\N	create	{"slug": "type: segment", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 17:25:06.719982+00	[]	active	{}	\N
104	SEGMEOJK6D4V67EAJ	segment	\N	\N	create	{"slug": "Slocum Consulting", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 17:36:45.11452+00	[]	active	{}	\N
105	CUEMEOJRS925MMOI8	cue	\N	\N	create	{"slug": "first-ag-vid", "cue_type": "SOT", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 17:42:40.072706+00	[{"asset_id": "SEGMENO45GP697XFT", "link_type": "parent_child"}]	active	{}	\N
106	CUEMEOMV84ZZEZVMG	cue	\N	\N	create	{"slug": "assault-ice-officer", "cue_type": "SOT", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 19:09:19.475796+00	[{"asset_id": "SEGMENO45GP697XFT", "link_type": "parent_child"}]	active	{}	\N
107	CUEMEOMVCAIQ2MDV7	cue	\N	\N	create	{"slug": "shoot-maga", "cue_type": "SOT", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 19:09:24.858709+00	[{"asset_id": "SEGMENO45GP697XFT", "link_type": "parent_child"}]	active	{}	\N
108	CUEMEOMVM8C1BJ23P	cue	\N	\N	create	{"slug": "pamela-tweet", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 19:09:37.740926+00	[{"asset_id": "SEGMENO45GP697XFT", "link_type": "parent_child"}]	active	{}	\N
109	CUEMEOMVPPIAIQMD7	cue	\N	\N	create	{"slug": "pam-dr-janja", "cue_type": "SOT", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 19:09:42.249196+00	[{"asset_id": "SEGMENO45GP697XFT", "link_type": "parent_child"}]	active	{}	\N
110	CUEMEOMVWA97O7H4A	cue	\N	\N	create	{"slug": "un-women-journalists", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 19:09:50.769973+00	[{"asset_id": "SEGMENO45GP697XFT", "link_type": "parent_child"}]	active	{}	\N
111	CUEMEOMVZ52ZIS1IR	cue	\N	\N	create	{"slug": "un-women-journalist", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 19:09:54.470773+00	[{"asset_id": "SEGMENO45GP697XFT", "link_type": "parent_child"}]	active	{}	\N
112	SEGMEOOMWQVHLKPE7	segment	\N	\N	create	{"slug": null, "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 19:58:50.698165+00	[]	active	{}	\N
113	CUEMEOPLOWFSWFCUJ	cue	\N	\N	create	{"slug": "ceo-cracker-barrel", "cue_type": "sot", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 20:25:53.489662+00	[{"asset_id": "SEGMEOOMWQVHLKPE7", "link_type": "parent_child"}]	active	{}	\N
114	CUEMEOPR27Q8GRQ0Z	cue	\N	\N	create	{"slug": "inside-cracker-barrel", "cue_type": "SOT", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 20:30:04.024575+00	[{"asset_id": "SEGMEOOMWQVHLKPE7", "link_type": "parent_child"}]	active	{}	\N
115	CUEMEOPR5F8O373KC	cue	\N	\N	create	{"slug": "new-cracker-barrel", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 20:30:08.180858+00	[{"asset_id": "SEGMEOOMWQVHLKPE7", "link_type": "parent_child"}]	active	{}	\N
116	CUEMEOPR9VVUNF1I6	cue	\N	\N	create	{"slug": "old-cracker-barrel", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 20:30:13.964273+00	[{"asset_id": "SEGMEOOMWQVHLKPE7", "link_type": "parent_child"}]	active	{}	\N
117	CUEMEOPRCZZB1GX3E	cue	\N	\N	create	{"slug": "new-mdcdonalds", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 20:30:18.001871+00	[{"asset_id": "SEGMEOOMWQVHLKPE7", "link_type": "parent_child"}]	active	{}	\N
118	CUEMEOPRF6G39VFYE	cue	\N	\N	create	{"slug": "red-mcdonalds", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 20:30:20.826999+00	[{"asset_id": "SEGMEOOMWQVHLKPE7", "link_type": "parent_child"}]	active	{}	\N
119	CUEMEOSWI106C2RU2	cue	\N	\N	create	{"slug": "shogirl-whore", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 21:58:16.646977+00	[{"asset_id": "SEGMEOJ449DRJ4QTV", "link_type": "parent_child"}]	active	{}	\N
120	CUEMEOSWMBZ8DISGQ	cue	\N	\N	create	{"slug": "response-to-cher-believe", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 21:58:22.224229+00	[{"asset_id": "SEGMEOJ449DRJ4QTV", "link_type": "parent_child"}]	active	{}	\N
121	CUEMEOSWQW1HZZOM9	cue	\N	\N	create	{"slug": "cher-believe", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 21:58:28.129622+00	[{"asset_id": "SEGMEOJ449DRJ4QTV", "link_type": "parent_child"}]	active	{}	\N
122	EPSMETSMHDWCRS8XH	episode	\N	\N	episode_scaffold_create	{"episode_number": "0238", "template_id": 1, "template_name": "Sunday Show", "title": "Cracker Barrel", "source": "episode_scaffold_service", "blueprint_template_type": "episode"}	1	2025-08-27 09:49:20.128738+00	[]	active	{}	\N
250	ASTMFSR6T3UWIHYHD	coldopen	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-20 21:01:05.363729+00	[]	active	{}	\N
123	EPSMEXH8GS6XXHO2F	episode	\N	\N	episode_scaffold_create	{"episode_number": "0238", "template_id": 1, "template_name": "Sunday Show", "title": null, "source": "episode_scaffold_service", "blueprint_template_type": "episode"}	1	2025-08-29 23:41:35.093242+00	[]	active	{}	\N
124	EPSMEXINEQGJ2NU4R	episode	\N	\N	episode_scaffold_create	{"episode_number": "0238", "template_id": 1, "template_name": "Sunday Show", "title": null, "source": "episode_scaffold_service", "blueprint_template_type": "episode"}	1	2025-08-30 00:21:11.895642+00	[]	active	{}	\N
126	SEGMEXLBQBFLD4KQB	segment	\N	\N	create	{"slug": "type: coldopen", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-30 01:36:05.885029+00	[]	active	{}	\N
127	SEGMEXVKAYJRS3HGE	segment	\N	\N	rundown_item_creation	{"slug": "test-server-assetid", "title": "Test Item with Server AssetID", "episode_number": "0237", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	rbac-test	2025-08-30 06:22:42.137555+00	[]	active	{}	\N
128	SEGMEXVL7SLOYOE5V	segment	\N	\N	rundown_item_creation	{"slug": "test-server-assetid", "title": "Test Item with Server AssetID", "episode_number": "0237", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	rbac-test	2025-08-30 06:23:24.698581+00	[]	active	{}	\N
129	ASTMEY3H4JETER0HD	promo	\N	\N	rundown_item_creation	{"slug": "promo", "title": "Promo", "episode_number": "0238", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-08-30 10:04:10.684475+00	[]	active	{}	\N
130	EPSMEY8EVJQRZK24K	episode	\N	\N	episode_scaffold_create	{"episode_number": "0001", "template_id": 1, "template_name": "Sunday Show", "title": null, "source": "episode_scaffold_service", "blueprint_template_type": "episode"}	1	2025-08-30 12:22:23.791988+00	[]	active	{}	\N
131	ASTMEY8F52UKZ8UCD	coldopen	\N	\N	rundown_item_creation	{"slug": "show-cold-open", "title": "Cold Open", "episode_number": "0001", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-08-30 12:22:36.152871+00	[]	active	{}	\N
132	ASTMEY8F888WE9R21	tease	\N	\N	rundown_item_creation	{"slug": "", "title": "", "episode_number": "0001", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-08-30 12:22:40.235122+00	[]	active	{}	\N
133	SEGMEY8FBXICD5NYV	segment	\N	\N	rundown_item_creation	{"slug": "segment", "title": "Segment", "episode_number": "0001", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-08-30 12:22:45.03225+00	[]	active	{}	\N
134	SEGMEY8FDNA1AI2RL	segment	\N	\N	rundown_item_creation	{"slug": "segment", "title": "Segment", "episode_number": "0001", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-08-30 12:22:47.256895+00	[]	active	{}	\N
135	EPSMEY8MLPMRH71P7	episode	\N	\N	episode_scaffold_create	{"episode_number": "0900", "template_id": 1, "template_name": "Sunday Show", "title": "Test Episode 0900 from Scaffold", "source": "episode_scaffold_service", "blueprint_template_type": "episode"}	episode_scaffold_service	2025-08-30 12:28:24.295833+00	[]	active	{}	\N
136	ASTMEY9GMJYCYF0HJ	promo	\N	\N	rundown_item_creation	{"slug": "promo", "title": "Promo", "episode_number": "0001", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-08-30 12:51:45.07224+00	[]	active	{}	\N
137	ASTMEY9HFAGHSKEEQ	ad	\N	\N	rundown_item_creation	{"slug": "advertisement", "title": "Advertisement", "episode_number": "0001", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-08-30 12:52:22.314804+00	[]	active	{}	\N
138	ASTMEY9IOUFCRJENC	reader	\N	\N	rundown_item_creation	{"slug": "reader", "title": "Reader", "episode_number": "0001", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-08-30 12:53:21.35344+00	[]	active	{}	\N
139	ASTMEY9KJJIWV1DD7	break	\N	\N	rundown_item_creation	{"slug": "break", "title": "Break", "episode_number": "0001", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-08-30 12:54:47.792315+00	[]	active	{}	\N
140	ASTMEYC4SM4C7FIXP	break	\N	\N	rundown_item_creation	{"slug": "break", "title": "Break", "episode_number": "0001", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-08-30 14:06:31.902969+00	[]	active	{}	\N
141	EPSMEYLG3N3WWCLAJ	episode	\N	\N	episode_scaffold_create	{"episode_number": "0238", "template_id": 1, "template_name": "Sunday Show", "title": null, "source": "episode_scaffold_service", "blueprint_template_type": "episode"}	1	2025-08-30 18:27:15.943893+00	[]	active	{}	\N
142	ASTMEYLH24D8CRUIN	coldopen	\N	\N	rundown_item_creation	{"slug": "show-cold-open", "title": "Cold Open", "episode_number": "0238", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-08-30 18:28:00.639739+00	[]	active	{}	\N
143	SEGMEYLHB64D1HSOB	segment	\N	\N	rundown_item_creation	{"slug": "segment", "title": "Segment", "episode_number": "0238", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-08-30 18:28:12.366315+00	[]	active	{}	\N
144	ASTMF0PED3L07CS5Z	coldopen	\N	\N	rundown_item_creation	{"slug": "show-cold-open", "title": "Cold Open", "episode_number": "0001", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-01 05:53:25.720143+00	[]	active	{}	\N
145	EPSMF27X37QW1N671	episode	\N	\N	episode_scaffold_create	{"episode_number": "0239", "template_id": 1, "template_name": "Sunday Show", "title": "TBD", "source": "episode_scaffold_service", "blueprint_template_type": "episode"}	1	2025-09-02 07:19:38.622866+00	[]	active	{}	\N
146	ASTMF27XAO8R383HX	coldopen	\N	\N	rundown_item_creation	{"slug": "show-cold-open", "title": "Cold Open", "episode_number": "0239", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-02 07:19:48.298226+00	[]	active	{}	\N
147	ASTMF27XDEOOHVTN0	tease	\N	\N	rundown_item_creation	{"slug": "", "title": "", "episode_number": "0239", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-02 07:19:51.84239+00	[]	active	{}	\N
148	SEGMF27XFJ3JHJVFO	segment	\N	\N	rundown_item_creation	{"slug": "segment", "title": "Segment", "episode_number": "0239", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-02 07:19:54.594068+00	[]	active	{}	\N
149	SEGMF27XGVMCVX1O0	segment	\N	\N	rundown_item_creation	{"slug": "segment", "title": "Segment", "episode_number": "0239", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-02 07:19:56.338806+00	[]	active	{}	\N
150	ASTMF27XJHSIE28AQ	reader	\N	\N	rundown_item_creation	{"slug": "reader", "title": "Reader", "episode_number": "0239", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-02 07:19:59.730899+00	[]	active	{}	\N
287	ASTMFT4829QP1W3O5	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:05:58.908403+00	[]	active	{}	\N
289	ASTMFT482ADDM9PIR	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:05:58.928531+00	[]	active	{}	\N
290	ASTMFT4865N792ZN9	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:06:03.935265+00	[]	active	{}	\N
151	SEGMF27XLOFZ0XJXF	segment	\N	\N	rundown_item_creation	{"slug": "segment", "title": "Segment", "episode_number": "0239", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-02 07:20:02.561988+00	[]	active	{}	\N
152	ASTMF280OENKFAIDI	tease	\N	\N	rundown_item_creation	{"slug": "", "title": "", "episode_number": "0239", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-02 07:22:26.063885+00	[]	active	{}	\N
153	ASTMF28JF748LB5DD	coldopen	\N	\N	rundown_item_creation	{"slug": "show-cold-open", "title": "Test Cold Open", "episode_number": "0238", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	rbac-test	2025-09-02 07:37:00.685906+00	[]	active	{}	\N
154	SEGMF28JSPA3LJ9HU	segment	\N	\N	rundown_item_creation	{"slug": "test-segment", "title": "Test Segment", "episode_number": "0238", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	rbac-test	2025-09-02 07:37:18.094864+00	[]	active	{}	\N
155	SEGMF28K7VQEMC4OW	segment	\N	\N	rundown_item_creation	{"slug": "middle-segment", "title": "Middle Segment", "episode_number": "0238", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	rbac-test	2025-09-02 07:37:37.767087+00	[]	active	{}	\N
156	ASTMF2DXJOA201GWI	promo	\N	\N	rundown_item_creation	{"slug": "promo", "title": "Promo", "episode_number": "0239", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-02 10:07:57.662086+00	[]	active	{}	\N
157	ASTMF2E67ZC9GYV7Q	break	\N	\N	rundown_item_creation	{"slug": "break", "title": "Break", "episode_number": "0239", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-02 10:14:42.408813+00	[]	active	{}	\N
158	SEGMF2GLEDCHVANLV	segment	\N	\N	rundown_item_creation	{"slug": "segment", "title": "Segment", "episode_number": "0239", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-02 11:22:29.767392+00	[]	active	{}	\N
159	EPSMF8MT17N6UZ5FT	episode	\N	\N	episode_scaffold_create	{"episode_number": "0239", "template_id": 1, "template_name": "Sunday Show", "title": "The Princess and the Pea", "source": "episode_scaffold_service", "blueprint_template_type": "episode"}	1	2025-09-06 19:03:00.706171+00	[]	active	{}	\N
160	SEGMF8MUZZPXDQZB1	segment	\N	\N	rundown_item_creation	{"slug": "segment", "title": "Segment", "episode_number": "0239", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-06 19:04:32.440154+00	[]	active	{}	\N
161	EPSMFJRNMJLTMEDTX	episode	\N	\N	episode_scaffold_create	{"episode_number": "0240", "template_id": 1, "template_name": "Sunday Show", "title": "The Turning Point", "source": "episode_scaffold_service", "blueprint_template_type": "episode"}	1	2025-09-14 14:04:14.432264+00	[]	active	{}	\N
162	ASTMFJRV616ICH14B	coldopen	\N	\N	rundown_item_creation	{"slug": "show-cold-open", "title": "Cold Open", "episode_number": "0240", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-14 14:10:06.284667+00	[]	active	{}	\N
163	ASTMFJRXGRKM7U803	tease	\N	\N	rundown_item_creation	{"slug": "", "title": "", "episode_number": "0240", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-14 14:11:53.506763+00	[]	active	{}	\N
164	ASTMFJRXLJJFR9CD6	break	\N	\N	rundown_item_creation	{"slug": "break", "title": "Break", "episode_number": "0240", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-14 14:11:59.698097+00	[]	active	{}	\N
165	ASTMFJSG4BT913KEO	break	\N	\N	rundown_item_creation	{"slug": "break", "title": "Break", "episode_number": "0240", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-14 14:26:23.851293+00	[]	active	{}	\N
166	ASTMFJSIFMFRY2KJB	tease	\N	\N	rundown_item_creation	{"slug": "", "title": "", "episode_number": "0240", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-14 14:28:11.801297+00	[]	active	{}	\N
167	ASTMFJXNEKU7DJLZP	tease	\N	\N	rundown_item_creation	{"slug": "", "title": "", "episode_number": "0240", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-14 16:52:01.808253+00	[]	active	{}	\N
168	ASTMFJXRAJL9DB85K	tease	\N	\N	rundown_item_creation	{"slug": "", "title": "", "episode_number": "0240", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-14 16:55:03.20411+00	[]	active	{}	\N
169	ASTMFJZBY9ZAIA7F8	reader	\N	\N	rundown_item_creation	{"slug": "reader", "title": "Reader", "episode_number": "0240", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-14 17:39:06.698045+00	[]	active	{}	\N
170	ASTMFJZE3OJ9BKXJ6	break	\N	\N	rundown_item_creation	{"slug": "break", "title": "Break", "episode_number": "0240", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-14 17:40:47.013218+00	[]	active	{}	\N
171	ASTMFJZF6Z67H8XAD	tease	\N	\N	rundown_item_creation	{"slug": "", "title": "", "episode_number": "0240", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-14 17:41:37.940481+00	[]	active	{}	\N
172	ASTMFK0RNJH2GH0RW	break	\N	\N	rundown_item_creation	{"slug": "break", "title": "Break", "episode_number": "0240", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-14 18:19:18.895226+00	[]	active	{}	\N
173	ASTMFK659V5Z6YPQJ	promo	\N	\N	rundown_item_creation	{"slug": "promo", "title": "Promo", "episode_number": "0240", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-14 20:49:52.435596+00	[]	active	{}	\N
174	EPSMFM60A0IWPUX9Z	episode	\N	\N	episode_scaffold_create	{"episode_number": "0241", "template_id": 1, "template_name": "Sunday Show", "title": null, "source": "episode_scaffold_service", "blueprint_template_type": "episode"}	1	2025-09-16 06:21:31.691291+00	[]	active	{}	\N
175	EPSMFMCUHX8G7QS6G	episode	\N	\N	episode_scaffold_create	{"episode_number": "0241", "template_id": 1, "template_name": "Sunday Show", "title": null, "source": "episode_scaffold_service", "blueprint_template_type": "episode"}	1	2025-09-16 09:32:59.322298+00	[]	active	{}	\N
176	EPSMFMGBVGXZ495AY	episode	\N	\N	filesystem_mirror	{"episode_number": "0239", "title": "The Princess and the Pea", "source": "filesystem_migration"}	episode_mirror_script	2025-09-16 11:10:28.875364+00	[]	active	{}	\N
177	ASTMFMGHUWAOTYMOG	rundown	\N	\N	segment_mirror	{"episode_number": "0238", "episode_title": "Episode 238 - Keri Smith", "source": "filesystem_segment_migration"}	segment_mirror_script	2025-09-16 11:15:08.06684+00	[]	active	{}	\N
179	ASTMFMGIV8BZF5SF8	rundown	\N	\N	segment_mirror	{"episode_number": "0238", "episode_title": "Episode 238 - Keri Smith", "source": "filesystem_segment_migration"}	segment_mirror_script	2025-09-16 11:15:55.155656+00	[]	active	{}	\N
288	ASTMFT4829Y3FOX43	break	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:05:58.916803+00	[]	active	{}	\N
181	ASTMFMGIV960OJRIF	rundown	\N	\N	segment_mirror	{"episode_number": "0239", "episode_title": "The Princess and the Pea", "source": "filesystem_segment_migration"}	segment_mirror_script	2025-09-16 11:15:55.189103+00	[]	active	{}	\N
182	ASTMFMGOB0NQGJIMX	rundown	\N	\N	segment_mirror	{"episode_number": "0236", "episode_title": "Episode 236", "source": "filesystem_migration"}	mirror_all_script	2025-09-16 11:20:08.895772+00	[]	active	{}	\N
184	EPSMFMGRRW3D4U04V	episode	\N	\N	filesystem_mirror	{"episode_number": "0240", "title": "The Turning Point", "source": "filesystem_migration"}	mirror_remaining_script	2025-09-16 11:22:50.734329+00	[]	active	{}	\N
185	ASTMFMGRRWF7TC15C	rundown	\N	\N	segment_mirror	{"episode_number": "0240", "episode_title": "The Turning Point"}	mirror_remaining_script	2025-09-16 11:22:50.74959+00	[]	active	{}	\N
186	ASTMFMGRRWO0XMK4R	rundown_item	\N	\N	segment_mirror	{"filename": "040-segment-charlie-kirk.md", "episode_number": "0240"}	mirror_remaining_script	2025-09-16 11:22:50.755516+00	[]	active	{}	\N
187	ASTMFMGRRWVUYHVKA	rundown_item	\N	\N	segment_mirror	{"filename": "070-segment-mommy.md", "episode_number": "0240"}	mirror_remaining_script	2025-09-16 11:22:50.764656+00	[]	active	{}	\N
188	ASTMFMGRRX2989JL4	rundown_item	\N	\N	segment_mirror	{"filename": "110-break-support.md", "episode_number": "0240"}	mirror_remaining_script	2025-09-16 11:22:50.771113+00	[]	active	{}	\N
189	ASTMFMGRRX6OW4SYP	rundown_item	\N	\N	segment_mirror	{"filename": "120-segment-iryna-zarutska.md", "episode_number": "0240"}	mirror_remaining_script	2025-09-16 11:22:50.777421+00	[]	active	{}	\N
190	EPSMFMGRRXCVUILZ5	episode	\N	\N	filesystem_mirror	{"episode_number": "0242", "title": "Episode 0242", "source": "filesystem_migration"}	mirror_remaining_script	2025-09-16 11:22:50.784607+00	[]	active	{}	\N
191	ASTMFMGTPCAQMTXD1	rundown	\N	\N	segment_mirror	{"episode_number": "0236", "episode_title": "Episode 236"}	mirror_236_script	2025-09-16 11:24:20.740432+00	[]	active	{}	\N
192	ASTMFMGUC93N0ERT1	rundown	\N	\N	segment_mirror	{"episode_number": "0236", "episode_title": "Episode 236"}	mirror_236_script	2025-09-16 11:24:50.433052+00	[]	active	{}	\N
193	ASTMFMGUNIY1T7V0J	rundown	\N	\N	segment_mirror	{"episode_number": "0236", "episode_title": "Episode 236"}	mirror_236_script	2025-09-16 11:25:05.044782+00	[]	active	{}	\N
194	ASTMFMGUNJ9DWHECM	rundown_item	\N	\N	segment_mirror	{"filename": "25 break.md", "episode_number": "0236"}	mirror_236_script	2025-09-16 11:25:05.057383+00	[]	active	{}	\N
195	ASTMFMGUNJI53Q3M9	rundown_item	\N	\N	segment_mirror	{"filename": "45 break.md", "episode_number": "0236"}	mirror_236_script	2025-09-16 11:25:05.066923+00	[]	active	{}	\N
196	EPSMFMM55FM1YT93W	episode	\N	\N	episode_scaffold_create	{"episode_number": "0241", "template_id": 1, "template_name": "Sunday Show", "title": null, "source": "episode_scaffold_service", "blueprint_template_type": "episode"}	1	2025-09-16 13:53:12.897683+00	[]	active	{}	\N
197	EPSMFMMGLVFSQL61S	episode	\N	\N	episode_scaffold_create	{"episode_number": "0241", "template_id": 1, "template_name": "Sunday Show", "title": null, "source": "episode_scaffold_service", "blueprint_template_type": "episode"}	1	2025-09-16 14:02:07.413151+00	[]	active	{}	\N
198	EPSMFMPEPUSI2Y6WI	episode	\N	\N	episode_scaffold_create	{"episode_number": "0241", "template_id": 1, "template_name": "Sunday Show", "title": null, "source": "episode_scaffold_service", "blueprint_template_type": "episode"}	1	2025-09-16 15:24:38.114996+00	[]	active	{}	\N
199	ASTMFMPUT79QI14W6	coldopen	\N	\N	rundown_item_creation	{"slug": "show-cold-open", "title": "Cold Open", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 15:37:08.95073+00	[]	active	{}	\N
200	ASTMFMQEH3QSS6PQH	coldopen	\N	\N	rundown_item_creation	{"slug": "show-cold-open", "title": "Cold Open", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 15:52:26.392507+00	[]	active	{}	\N
201	ASTMFMSMEKK4DD327	coldopen	\N	\N	rundown_item_creation	{"slug": "show-cold-open", "title": "Cold Open", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 16:54:35.590498+00	[]	active	{}	\N
202	SEGMFMSNZA2JBEEYO	segment	\N	\N	rundown_item_creation	{"slug": "segment", "title": "Segment", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 16:55:49.084878+00	[]	active	{}	\N
203	SEGMFMSO3IYYMDFD5	segment	\N	\N	rundown_item_creation	{"slug": "segment", "title": "Segment", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 16:55:54.58851+00	[]	active	{}	\N
204	ASTMFMSO5J5X2TCLG	tease	\N	\N	rundown_item_creation	{"slug": "", "title": "", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 16:55:57.188125+00	[]	active	{}	\N
205	ASTMFMTH1LHOEEMLZ	coldopen	\N	\N	rundown_item_creation	{"slug": "show-cold-open", "title": "Cold Open", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:18:25.113146+00	[]	active	{}	\N
206	ASTMFMTJBNVNUW4UC	coldopen	\N	\N	rundown_item_creation	{"slug": "show-cold-open", "title": "Cold Open", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:20:11.474584+00	[]	active	{}	\N
207	ASTMFMTK6QJIKFGMM	tease	\N	\N	rundown_item_creation	{"slug": "", "title": "", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:20:51.741614+00	[]	active	{}	\N
208	ASTMFMTKEEQ3NSWR4	reader	\N	\N	rundown_item_creation	{"slug": "reader", "title": "Reader", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:21:01.683294+00	[]	active	{}	\N
209	SEGMFMTKGQAROORCS	segment	\N	\N	rundown_item_creation	{"slug": "segment", "title": "Segment", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:21:04.691383+00	[]	active	{}	\N
210	SEGMFMTKIMEEEEDLG	segment	\N	\N	rundown_item_creation	{"slug": "segment", "title": "Segment", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:21:07.145001+00	[]	active	{}	\N
211	ASTMFMTKM0MC22VRA	tease	\N	\N	rundown_item_creation	{"slug": "", "title": "", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:21:11.544981+00	[]	active	{}	\N
212	ASTMFMTL9WJR2UAD0	break	\N	\N	rundown_item_creation	{"slug": "break", "title": "Break", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:21:42.501597+00	[]	active	{}	\N
213	ASTMFMTLJBHS1C3OX	break	\N	\N	rundown_item_creation	{"slug": "break", "title": "Break", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:21:54.704049+00	[]	active	{}	\N
214	ASTMFMTOJL7M0OXEQ	coldopen	\N	\N	rundown_item_creation	{"slug": "show-cold-open", "title": "Cold Open", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:24:15.027002+00	[]	active	{}	\N
215	ASTMFMTOMX7IEHLCO	tease	\N	\N	rundown_item_creation	{"slug": "", "title": "", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:24:19.341998+00	[]	active	{}	\N
216	SEGMFMTOP9I3N9WEC	segment	\N	\N	rundown_item_creation	{"slug": "segment", "title": "Segment", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:24:22.376278+00	[]	active	{}	\N
217	SEGMFMTOSTUUD3ADJ	segment	\N	\N	rundown_item_creation	{"slug": "segment", "title": "Segment", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:24:26.99678+00	[]	active	{}	\N
218	ASTMFMTPMGXOM4Q0M	rundown	\N	\N	episode_rundown_creation	{"episode_number": "0241"}	system	2025-09-16 17:25:05.404251+00	[{"asset_id": "EPSMFMPEPUSI2Y6WI", "link_type": "belongs_to"}]	active	{}	\N
219	ASTMFMTVDHY2S68UE	coldopen	\N	\N	rundown_item_creation	{"slug": "show-cold-open", "title": "Cold Open", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:29:33.725681+00	[]	active	{}	\N
220	ASTMFMTVIDTIC6KWR	coldopen	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-16 17:29:40.047865+00	[]	active	{}	\N
221	ASTMFMTVIJNWDL5X6	coldopen	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-16 17:29:40.25602+00	[]	active	{}	\N
222	ASTMFMTX41GYR6IBK	coldopen	\N	\N	rundown_item_creation	{"slug": "show-cold-open", "title": "Cold Open", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:30:54.779843+00	[]	active	{}	\N
223	ASTMFMTXABD7G9S4Q	coldopen	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-16 17:31:02.904056+00	[]	active	{}	\N
224	ASTMFMU031DNZA55L	tease	\N	\N	rundown_item_creation	{"slug": "", "title": "", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:33:13.443959+00	[]	active	{}	\N
225	ASTMFMU12HWIPAMR0	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-16 17:33:59.390177+00	[]	active	{}	\N
226	SEGMFMU2RTBAU9XQQ	segment	\N	\N	rundown_item_creation	{"slug": "segment", "title": "Segment", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:35:18.865274+00	[]	active	{}	\N
227	SEGMFMU2TCWTCTOSN	segment	\N	\N	rundown_item_creation	{"slug": "segment", "title": "Segment", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:35:20.864652+00	[]	active	{}	\N
228	ASTMFMU2VF3TL7YIK	promo	\N	\N	rundown_item_creation	{"slug": "promo", "title": "Promo", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:35:23.537365+00	[]	active	{}	\N
229	ASTMFMU2YUEAC4RQB	interview	\N	\N	rundown_item_creation	{"slug": "interview", "title": "Interview", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:35:27.976896+00	[]	active	{}	\N
230	ASTMFMU32AMUH5M0D	break	\N	\N	rundown_item_creation	{"slug": "break", "title": "Break", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:35:32.44854+00	[]	active	{}	\N
231	ASTMFMU4O85DBSE8T	promo	\N	\N	rundown_item_creation	{"slug": "promo", "title": "Promo", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:36:47.527659+00	[]	active	{}	\N
232	SEGMFMU4QN1SGX692	segment	\N	\N	rundown_item_creation	{"slug": "segment", "title": "Segment", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:36:50.655379+00	[]	active	{}	\N
233	SEGMFMU4S4FMKDMSA	segment	\N	\N	rundown_item_creation	{"slug": "segment", "title": "Segment", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:36:52.577394+00	[]	active	{}	\N
234	ASTMFMU4ULWAKD6AT	reader	\N	\N	rundown_item_creation	{"slug": "reader", "title": "Reader", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:36:55.798699+00	[]	active	{}	\N
235	ASTMFMU4Y6DNZ5B1X	break	\N	\N	rundown_item_creation	{"slug": "break", "title": "Break", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:37:00.423813+00	[]	active	{}	\N
236	ASTMFMU4ZJK14NIL2	promo	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-16 17:37:02.191462+00	[]	active	{}	\N
237	SEGMFMU4ZJNL0MLVK	segment	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-16 17:37:02.195374+00	[]	active	{}	\N
238	SEGMFMU4ZJR2I1UDY	segment	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-16 17:37:02.198805+00	[]	active	{}	\N
239	ASTMFMU4ZJTFQAJFI	reader	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-16 17:37:02.201616+00	[]	active	{}	\N
240	ASTMFMU4ZJX3YYL3X	break	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-16 17:37:02.204971+00	[]	active	{}	\N
241	ASTMFMU5G6O4UPP9B	promo	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-16 17:37:23.751681+00	[]	active	{}	\N
242	SEGMFMU5G712N56VK	segment	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-16 17:37:23.771612+00	[]	active	{}	\N
243	SEGMFMU5G7C7A889V	segment	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-16 17:37:23.782996+00	[]	active	{}	\N
244	ASTMFMU5G7PQOE30E	reader	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-16 17:37:23.795251+00	[]	active	{}	\N
245	ASTMFMU5G80JM8UT4	break	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-16 17:37:23.806381+00	[]	active	{}	\N
246	EPSMFSR3W9KUCTLRM	episode	\N	\N	episode_scaffold_create	{"episode_number": "0241", "template_id": 1, "template_name": "Sunday Show", "title": "Manson Family Values", "source": "episode_scaffold_service", "blueprint_template_type": "episode"}	1	2025-09-20 20:58:49.495614+00	[]	active	{}	\N
247	ASTMFSR4ECMMLM34Y	coldopen	\N	\N	rundown_item_creation	{"slug": "show-cold-open", "title": "Cold Open", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-20 20:59:12.937178+00	[]	active	{}	\N
248	ASTMFSR4IARNH4LRN	tease	\N	\N	rundown_item_creation	{"slug": "", "title": "", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-20 20:59:18.053438+00	[]	active	{}	\N
249	ASTMFSR6T37QO5C5V	rundown	\N	\N	episode_rundown_creation	{"episode_number": "0241"}	system	2025-09-20 21:01:05.343761+00	[{"asset_id": "EPSMFSR3W9KUCTLRM", "link_type": "belongs_to"}]	active	{}	\N
251	ASTMFSR6T43X378M1	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-20 21:01:05.377988+00	[]	active	{}	\N
252	SEGMFSTCOJSAQNNAF	segment	\N	\N	rundown_item_creation	{"slug": "segment", "title": "Segment", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-20 22:01:38.63452+00	[]	active	{}	\N
253	SEGMFSTDTKWZK9ADY	segment	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-20 22:02:31.800699+00	[]	active	{}	\N
254	SEGMFT39C7Q8V9TWE	segment	\N	\N	create	{"slug": "we're all manson girl", "cue_type": null, "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:58.839544+00	[]	active	{}	\N
255	ASTMFT39C85NHP49A	gfx	\N	\N	create	{"slug": "tyler-robinson", "cue_type": "GFX", "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:58.853843+00	[]	active	{}	\N
256	ASTMFT39C8C7NK3Y9	gfx	\N	\N	create	{"slug": "lance-twiggs", "cue_type": "GFX", "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:58.861198+00	[]	active	{}	\N
257	ASTMFT39C8J9XHMST	gfx	\N	\N	create	{"slug": "lance-doggy", "cue_type": "GFX", "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:58.867951+00	[]	active	{}	\N
258	ASTMFT39C8QEPNBQH	gfx	\N	\N	create	{"slug": "keyboard-note", "cue_type": "GFX", "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:58.874861+00	[]	active	{}	\N
259	ASTMFT39C8XYANWUO	gfx	\N	\N	create	{"slug": "why-did-i", "cue_type": "GFX", "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:58.881774+00	[]	active	{}	\N
260	ASTMFT39C942OE6ZU	sot	\N	\N	create	{"slug": "abc-touching-shooter", "cue_type": "SOT", "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:58.888611+00	[]	active	{}	\N
261	ASTMFT39C9BIHDDA2	sot	\N	\N	create	{"slug": "touching-intimate-portrait", "cue_type": "SOT", "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:58.895821+00	[]	active	{}	\N
262	ASTMFT39C9XCYUL42	sot	\N	\N	create	{"slug": "montel-williams", "cue_type": "SOT", "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:58.919781+00	[]	active	{}	\N
263	ASTMFT39CANMRT24I	gfx	\N	\N	create	{"slug": "manson-girls-kneel", "cue_type": "GFX", "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:58.94575+00	[]	active	{}	\N
264	ASTMFT39CBDW0BE1X	sot	\N	\N	create	{"slug": "manson-girls-singing", "cue_type": "SOT", "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:58.971308+00	[]	active	{}	\N
265	ASTMFT39CC3XVAFFE	sot	\N	\N	create	{"slug": "manson-speaks", "cue_type": "SOT", "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:58.997289+00	[]	active	{}	\N
266	ASTMFT39CCTV6A883	gfx	\N	\N	create	{"slug": "luigi-mangione", "cue_type": "GFX", "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:59.023092+00	[]	active	{}	\N
267	ASTMFT39CDJ8I2TAZ	gfx	\N	\N	create	{"slug": "by-the-numbers", "cue_type": "GFX", "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:59.049892+00	[]	active	{}	\N
268	ASTMFT39CE8FBYXHA	sot	\N	\N	create	{"slug": "married-luigi-mangioni", "cue_type": "SOT", "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:59.074118+00	[]	active	{}	\N
269	ASTMFT39CELCZPRZT	sot	\N	\N	create	{"slug": "cheer-for-luigi", "cue_type": "SOT", "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:59.086654+00	[]	active	{}	\N
270	SEGMFT39CEVMP5WD9	segment	\N	\N	create	{"slug": "cancel culture", "cue_type": null, "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:59.096505+00	[]	active	{}	\N
271	ASTMFT39CF6PENLRD	sot	\N	\N	create	{"slug": "nurse-fired", "cue_type": "SOT", "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:59.107004+00	[]	active	{}	\N
272	ASTMFT39CFDJ3EFG3	gfx	\N	\N	create	{"slug": "weird-how-people", "cue_type": "GFX", "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:59.113784+00	[]	active	{}	\N
273	ASTMFT39CFJMPTI97	sot	\N	\N	create	{"slug": "fuck-fired-charlie", "cue_type": "SOT", "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:59.120295+00	[]	active	{}	\N
274	ASTMFT39CFQ6LJEJJ	sot	\N	\N	create	{"slug": "girls-destroy-memorial", "cue_type": "SOT", "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:59.127069+00	[]	active	{}	\N
275	SEGMFT39CFXRU8V4P	segment	\N	\N	create	{"slug": "family insane", "cue_type": null, "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:59.13373+00	[]	active	{}	\N
276	SEGMFT39CG6TYWMQB	segment	\N	\N	create	{"slug": "Potpourri du Moquerie", "cue_type": null, "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:59.14257+00	[]	active	{}	\N
277	ASTMFT39CGFV9VMRR	sot	\N	\N	create	{"slug": "meow-girl", "cue_type": "SOT", "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:59.151963+00	[]	active	{}	\N
278	ASTMFT39CGMD4TDX4	sot	\N	\N	create	{"slug": "look-what-i-can", "cue_type": "SOT", "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:59.158468+00	[]	active	{}	\N
279	ASTMFT39CGSWS1B57	sot	\N	\N	create	{"slug": "mom-got-deported", "cue_type": "SOT", "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:59.164979+00	[]	active	{}	\N
280	ASTMFT39CGZUYJYDF	sot	\N	\N	create	{"slug": "trump-to-bitches", "cue_type": "SOT", "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:59.171688+00	[]	active	{}	\N
281	ASTMFT47H1MIIKAED	break	\N	\N	rundown_item_creation	{"slug": "break", "title": "Break", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-21 03:05:31.402896+00	[]	active	{}	\N
282	ASTMFT47KJ236CTET	break	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:05:35.916209+00	[]	active	{}	\N
283	ASTMFT47NE3NLNFKO	tease	\N	\N	rundown_item_creation	{"slug": "", "title": "", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-21 03:05:39.62775+00	[]	active	{}	\N
284	ASTMFT47PJRWCW1L6	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:05:42.42123+00	[]	active	{}	\N
285	ASTMFT47PJV63KQGL	break	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:05:42.427363+00	[]	active	{}	\N
286	ASTMFT47YHJF30UD5	tease	\N	\N	rundown_item_creation	{"slug": "", "title": "", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-21 03:05:54.008459+00	[]	active	{}	\N
293	ASTMFT489JFTYJMBH	break	\N	\N	rundown_item_creation	{"slug": "break", "title": "Break", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-21 03:06:08.331771+00	[]	active	{}	\N
295	ASTMFT48DAZ8ELDHA	break	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:06:13.211197+00	[]	active	{}	\N
297	ASTMFT48DBOZ0ZMRB	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:06:13.231481+00	[]	active	{}	\N
298	ASTMFT48FTXG0F142	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:06:16.483347+00	[]	active	{}	\N
300	ASTMFT48FU47D4STP	break	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:06:16.4914+00	[]	active	{}	\N
294	ASTMFT48DAWO64O1H	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:06:13.206175+00	[]	active	{}	\N
296	ASTMFT48DB8JN3YZW	break	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:06:13.216092+00	[]	active	{}	\N
299	ASTMFT48FU051EH6E	break	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:06:16.487886+00	[]	active	{}	\N
301	ASTMFT48FU75NOAZ9	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:06:16.494777+00	[]	active	{}	\N
302	ASTMFT4E8X3V8O3ZY	break	\N	\N	rundown_item_creation	{"slug": "break", "title": "Break", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-21 03:10:47.469517+00	[]	active	{}	\N
303	ASTMFT4EBIYCN7VQ2	break	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:10:50.840233+00	[]	active	{}	\N
304	ASTMFT4ED4UA5XMA7	break	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:10:52.924175+00	[]	active	{}	\N
305	ASTMFT4EFUFOUVBU8	tease	\N	\N	rundown_item_creation	{"slug": "", "title": "", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-21 03:10:56.441491+00	[]	active	{}	\N
306	ASTMFT4EJWJORECBB	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:11:01.686787+00	[]	active	{}	\N
307	ASTMFT4EJWWCR4IX8	break	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:11:01.71088+00	[]	active	{}	\N
308	ASTMFT4EOZS8VQLDP	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:11:08.283793+00	[]	active	{}	\N
309	ASTMFT4EP05DDKDK5	break	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:11:08.307634+00	[]	active	{}	\N
310	ASTMFT4EXLWR8EL5Z	tease	\N	\N	rundown_item_creation	{"slug": "", "title": "", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-21 03:11:19.463061+00	[]	active	{}	\N
311	ASTMFT4EZNIDADW8M	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:11:22.099184+00	[]	active	{}	\N
312	ASTMFT4EZNVJP29TJ	break	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:11:22.12145+00	[]	active	{}	\N
313	ASTMFT4EZOAVKLAQ6	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:11:22.133397+00	[]	active	{}	\N
314	ASTMFT4F9RCQ7IUMF	break	\N	\N	rundown_item_creation	{"slug": "break", "title": "Break", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-21 03:11:35.210285+00	[]	active	{}	\N
315	ASTMFT4FGIAMIZSG9	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:11:43.952395+00	[]	active	{}	\N
316	ASTMFT4FGIEGN5J3Y	break	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:11:43.95838+00	[]	active	{}	\N
317	ASTMFT4FGIHRQPOYD	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:11:43.960895+00	[]	active	{}	\N
318	ASTMFT4FGIMH92KEQ	break	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:11:43.965411+00	[]	active	{}	\N
319	ASTMFT4FHYJ3UBZTK	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:11:45.832955+00	[]	active	{}	\N
320	ASTMFT4FHYM9JXL13	break	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:11:45.838254+00	[]	active	{}	\N
321	ASTMFT4FHYQD8MPKG	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:11:45.840785+00	[]	active	{}	\N
322	ASTMFT4FHYUBFM0E1	break	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:11:45.846181+00	[]	active	{}	\N
323	ASTMFT4LF14DHTFTF	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:16:21.973384+00	[]	active	{}	\N
324	ASTMFT4LF1AZJ2WZQ	break	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:16:21.980997+00	[]	active	{}	\N
325	ASTMFT4LF1SEZZQPY	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:16:21.995919+00	[]	active	{}	\N
326	ASTMFT4LF244VX02X	break	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:16:22.011132+00	[]	active	{}	\N
327	ASTMFT4M01YEWJD5R	reader	\N	\N	rundown_item_creation	{"slug": "reader", "title": "Reader", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-21 03:16:49.222509+00	[]	active	{}	\N
328	ASTMFT4WAYXN4LAVJ	tease	\N	\N	rundown_item_creation	{"slug": "", "title": "", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-21 03:24:49.934946+00	[]	active	{}	\N
329	ASTMFT4WDF4UZQUUJ	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:24:53.10355+00	[]	active	{}	\N
330	ASTMFT4WMIWTZH4XX	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:25:04.902941+00	[]	active	{}	\N
331	ASTMFT4WR5538OV9I	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:25:10.877314+00	[]	active	{}	\N
332	ASTMFT4WTFOWLZC7J	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:25:13.857819+00	[]	active	{}	\N
333	ASTMFT4Z0U5GZZ3RE	break	\N	\N	rundown_item_creation	{"slug": "break", "title": "Break", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-21 03:26:56.76719+00	[]	active	{}	\N
334	ASTMFT4Z3IX239XGC	break	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:27:00.247839+00	[]	active	{}	\N
335	ASTMFT5139ND2XSZF	break	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:28:33.223738+00	[]	active	{}	\N
336	ASTMFT51R0Q4ETKQZ	tease	\N	\N	rundown_item_creation	{"slug": "", "title": "", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-21 03:29:04.01092+00	[]	active	{}	\N
337	ASTMFT51TF3GVSA2G	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:29:07.11672+00	[]	active	{}	\N
338	ASTMFT51VJ4LRT1AC	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:29:09.844266+00	[]	active	{}	\N
339	ASTMFT58YHT8KUWXZ	reader	\N	\N	rundown_item_creation	{"slug": "reader", "title": "Reader", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-21 03:34:40.292133+00	[]	active	{}	\N
340	ASTMFT595RIZ1I35H	reader	\N	\N	rundown_item_creation	{"slug": "reader", "title": "Reader", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-21 03:34:49.713067+00	[]	active	{}	\N
341	EPSMG001SVZY8YW7C	episode	\N	\N	episode_scaffold_create	{"episode_number": "0242", "template_id": 1, "template_name": "Sunday Show", "title": "Forgiveness Discourse", "source": "episode_scaffold_service", "blueprint_template_type": "episode"}	1	2025-09-25 22:43:31.581899+00	[]	active	{}	\N
342	ASTMG0028V6G7EZIV	coldopen	\N	\N	rundown_item_creation	{"slug": "show-cold-open", "title": "Cold Open", "episode_number": "0242", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-25 22:43:52.293111+00	[]	active	{}	\N
343	ASTMG002D69CQKWL8	coldopen	\N	\N	rundown_item_creation	{"slug": "show-cold-open", "title": "Cold Open", "episode_number": "0242", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-25 22:43:57.876006+00	[]	active	{}	\N
344	ASTMG009VUZ4HFPFK	coldopen	\N	\N	rundown_item_creation	{"slug": "show-cold-open", "title": "Cold Open", "episode_number": "0242", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-25 22:49:48.685745+00	[]	active	{}	\N
345	ASTMG01RTKS9TT1BF	coldopen	\N	\N	rundown_item_creation	{"slug": "show-cold-open", "title": "Cold Open", "episode_number": "0242", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-25 23:31:45.14893+00	[]	active	{}	\N
346	ASTMG04EIM1ZYAW35	coldopen	\N	\N	rundown_item_creation	{"slug": "show-cold-open", "title": "Cold Open", "episode_number": "0242", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-26 00:45:23.259228+00	[]	active	{}	\N
347	ASTMG05Z04SIH84VY	coldopen	\N	\N	rundown_item_creation	{"slug": "show-cold-open", "title": "Cold Open", "episode_number": "0242", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-26 01:29:18.701327+00	[]	active	{}	\N
348	ASTMG061CV1JSC2SY	coldopen	\N	\N	rundown_item_creation	{"slug": "show-cold-open", "title": "Cold Open", "episode_number": "0242", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-26 01:31:08.511762+00	[]	active	{}	\N
349	ASTMG061HW3BKFT9O	coldopen	\N	\N	rundown_item_creation	{"slug": "show-cold-open", "title": "Cold Open", "episode_number": "0242", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-26 01:31:15.029404+00	[]	active	{}	\N
350	ASTMG063O1XSUTRW7	coldopen	\N	\N	rundown_item_creation	{"slug": "show-cold-open", "title": "Cold Open", "episode_number": "0242", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-26 01:32:56.327171+00	[]	active	{}	\N
351	ASTMG063SL5K7XCXY	coldopen	\N	\N	rundown_item_creation	{"slug": "show-cold-open", "title": "Cold Open", "episode_number": "0242", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-26 01:33:02.203759+00	[]	active	{}	\N
352	EPSMG1FO7YJDBU685	episode	\N	\N	episode_scaffold_create	{"episode_number": "0243", "template_id": 1, "template_name": "Sunday Show", "title": null, "source": "episode_scaffold_service", "blueprint_template_type": "episode"}	1	2025-09-26 22:48:37.96228+00	[]	active	{}	\N
\.


--
-- Data for Name: asset_id_relationships; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.asset_id_relationships (id, source_asset_id, target_asset_id, relationship_type, is_bidirectional, strength, created_by, created_at, context, is_active, notes) FROM stdin;
1	SEGMEEFAFL4C5RT2B	EPSMEEFA0DTJNAYVN	parent_child	false	1	rbac-test	2025-08-16 15:39:30.280946+00	{"initial_link": true}	active	\N
2	CUEMEEFALU37XGFSZ	SEGMEEFAFL4C5RT2B	parent_child	false	1	rbac-test	2025-08-16 15:39:38.380119+00	{"initial_link": true}	active	\N
3	CUEMEEFBKP63U781E	SEGMEEFAFL4C5RT2B	parent_child	false	1	rbac-test	2025-08-16 15:40:23.563499+00	{"initial_link": true}	active	\N
4	CUEMEEJFS6N0Y6BVP	SEGMEEJ3TNWZ5IUEO	parent_child	false	1	rbac-test	2025-08-16 17:35:38.353619+00	{"initial_link": true}	active	\N
5	CUEMEEJFW5OXH49CV	SEGMEEJ3TNWZ5IUEO	parent_child	false	1	rbac-test	2025-08-16 17:35:43.502736+00	{"initial_link": true}	active	\N
6	CUEMEEJFZ1B48GJAV	SEGMEEJ3TNWZ5IUEO	parent_child	false	1	rbac-test	2025-08-16 17:35:47.233777+00	{"initial_link": true}	active	\N
7	CUEMEEJG1BTTZ9RKK	SEGMEEJ3TNWZ5IUEO	parent_child	false	1	rbac-test	2025-08-16 17:35:50.203806+00	{"initial_link": true}	active	\N
8	CUEMEEJG43IE9XE52	SEGMEEJ3TNWZ5IUEO	parent_child	false	1	rbac-test	2025-08-16 17:35:53.792435+00	{"initial_link": true}	active	\N
9	CUEMEEJG6CVN16KFJ	SEGMEEJ3TNWZ5IUEO	parent_child	false	1	rbac-test	2025-08-16 17:35:56.721694+00	{"initial_link": true}	active	\N
10	CUEMEEJG9AV3QQNDK	SEGMEEJ3TNWZ5IUEO	parent_child	false	1	rbac-test	2025-08-16 17:36:00.53746+00	{"initial_link": true}	active	\N
11	CUEMEEJGLF9OYQXZC	SEGMEEJ44L61P9LZV	parent_child	false	1	rbac-test	2025-08-16 17:36:16.247519+00	{"initial_link": true}	active	\N
12	CUEMEEJGNHIAMNDQO	SEGMEEJ44L61P9LZV	parent_child	false	1	rbac-test	2025-08-16 17:36:18.920579+00	{"initial_link": true}	active	\N
13	CUEMEEJGPMGOLLC0T	SEGMEEJ44L61P9LZV	parent_child	false	1	rbac-test	2025-08-16 17:36:21.690777+00	{"initial_link": true}	active	\N
14	CUEMEEJGRSTM36X2K	SEGMEEJ44L61P9LZV	parent_child	false	1	rbac-test	2025-08-16 17:36:24.511574+00	{"initial_link": true}	active	\N
15	CUEMEEJGUC9SV6YC8	SEGMEEJ44L61P9LZV	parent_child	false	1	rbac-test	2025-08-16 17:36:27.804037+00	{"initial_link": true}	active	\N
16	CUEMEEJGWBU9O8PJZ	SEGMEEJ44L61P9LZV	parent_child	false	1	rbac-test	2025-08-16 17:36:30.380586+00	{"initial_link": true}	active	\N
17	CUEMEEJGZ5BR5TNAN	SEGMEEJ44L61P9LZV	parent_child	false	1	rbac-test	2025-08-16 17:36:34.033802+00	{"initial_link": true}	active	\N
18	CUEMEEJH18K27GCUJ	SEGMEEJ44L61P9LZV	parent_child	false	1	rbac-test	2025-08-16 17:36:36.74315+00	{"initial_link": true}	active	\N
19	CUEMEEJH39UTHDQPZ	SEGMEEJ44L61P9LZV	parent_child	false	1	rbac-test	2025-08-16 17:36:39.380936+00	{"initial_link": true}	active	\N
20	CUEMEEJH5L5EJ0QLB	SEGMEEJ44L61P9LZV	parent_child	false	1	rbac-test	2025-08-16 17:36:42.379902+00	{"initial_link": true}	active	\N
21	CUEMEEJH851KUTI9Z	SEGMEEJ44L61P9LZV	parent_child	false	1	rbac-test	2025-08-16 17:36:45.688006+00	{"initial_link": true}	active	\N
22	CUEMEEJHAGOJO5MHZ	SEGMEEJ44L61P9LZV	parent_child	false	1	rbac-test	2025-08-16 17:36:48.698898+00	{"initial_link": true}	active	\N
23	CUEMEEJHCIJ9X84QX	SEGMEEJ44L61P9LZV	parent_child	false	1	rbac-test	2025-08-16 17:36:51.35736+00	{"initial_link": true}	active	\N
24	CUEMEEJHEY901HMCU	SEGMEEJ44L61P9LZV	parent_child	false	1	rbac-test	2025-08-16 17:36:54.515804+00	{"initial_link": true}	active	\N
25	CUEMEEJHIMKMC68FC	SEGMEEJ44L61P9LZV	parent_child	false	1	rbac-test	2025-08-16 17:36:59.278997+00	{"initial_link": true}	active	\N
26	CUEMEEJHWMROXL1L8	SEGMEEJ56401DC7UN	parent_child	false	1	rbac-test	2025-08-16 17:37:17.429394+00	{"initial_link": true}	active	\N
27	CUEMEEJHZTQUO2VE3	SEGMEEJ56401DC7UN	parent_child	false	1	rbac-test	2025-08-16 17:37:21.567228+00	{"initial_link": true}	active	\N
28	CUEMEEJJ87VW7XCBR	SEGMEEJ5H1D9I4K1D	parent_child	false	1	rbac-test	2025-08-16 17:38:19.10189+00	{"initial_link": true}	active	\N
29	CUEMEEND27OHTCFXG	SEGMEENCPXQ375N35	parent_child	false	1	rbac-test	2025-08-16 19:25:29.845127+00	{"initial_link": true}	active	\N
30	CUEMEENDH3XSJ7GMN	SEGMEEJ4JNYVA02T4	parent_child	false	1	rbac-test	2025-08-16 19:25:49.151458+00	{"initial_link": true}	active	\N
31	CUEMEENDM8FGBUPV8	SEGMEEJ3YD0OKZM7D	parent_child	false	1	rbac-test	2025-08-16 19:25:55.794044+00	{"initial_link": true}	active	\N
32	ASTMEEOASULAQYTLJ	EPSMEEJ32D9UFK5BU	parent_child	false	1	rbac-test	2025-08-16 19:51:44.01617+00	{"initial_link": true}	active	\N
33	CUEMEEPQ1XNB587ME	SEGMEEJ5H1D9I4K1D	parent_child	false	1	rbac-test	2025-08-16 20:31:35.245573+00	{"initial_link": true}	active	\N
34	CUEMEEQS4B424DL1B	SEGMEEJ3TNWZ5IUEO	parent_child	false	1	rbac-test	2025-08-16 21:01:11.248743+00	{"initial_link": true}	active	\N
35	CUEMEF1M0VOTMXHR0	SEGMEEJ3TNWZ5IUEO	parent_child	false	1	rbac-test	2025-08-17 02:04:22.646487+00	{"initial_link": true}	active	\N
36	CUEMEF1MMCNHQ2B7J	SEGMEEJ3TNWZ5IUEO	parent_child	false	1	rbac-test	2025-08-17 02:04:50.473946+00	{"initial_link": true}	active	\N
37	CUEMEF1NP7R2S32UR	SEGMEEJ3TNWZ5IUEO	parent_child	false	1	rbac-test	2025-08-17 02:05:40.842083+00	{"initial_link": true}	active	\N
38	CUEMEF1W0XP0Q5PKX	SEGMEEJ3TNWZ5IUEO	parent_child	false	1	rbac-test	2025-08-17 02:12:09.280027+00	{"initial_link": true}	active	\N
39	CUEMEF22TNG6F7ZS8	SEGMEEJ3TNWZ5IUEO	parent_child	false	1	rbac-test	2025-08-17 02:17:26.429128+00	{"initial_link": true}	active	\N
40	CUEMEF23DJ45GABLZ	SEGMEEJ3TNWZ5IUEO	parent_child	false	1	rbac-test	2025-08-17 02:17:52.195024+00	{"initial_link": true}	active	\N
41	CUEMEF23VI6WIQ8SW	SEGMEEJ3TNWZ5IUEO	parent_child	false	1	rbac-test	2025-08-17 02:18:15.489116+00	{"initial_link": true}	active	\N
42	CUEMEF24QS9R6YDTF	SEGMEEJ3TNWZ5IUEO	parent_child	false	1	rbac-test	2025-08-17 02:18:56.025718+00	{"initial_link": true}	active	\N
43	CUEMEF2AE2W19MGZT	SEGMEEJ3TNWZ5IUEO	parent_child	false	1	rbac-test	2025-08-17 02:23:19.499039+00	{"initial_link": true}	active	\N
44	CUEMENIEHR7MIKVGP	slug:	parent_child	false	1	rbac-test	2025-08-23 00:16:34.149324+00	{"initial_link": true}	active	\N
45	CUEMENIJTO5C5B6VO	slug:	parent_child	false	1	rbac-test	2025-08-23 00:20:42.871436+00	{"initial_link": true}	active	\N
46	CUEMENIK9AF8ZAMJJ	slug:	parent_child	false	1	rbac-test	2025-08-23 00:21:03.113902+00	{"initial_link": true}	active	\N
47	CUEMENILDKHRC2TKM	slug:	parent_child	false	1	rbac-test	2025-08-23 00:21:55.316206+00	{"initial_link": true}	active	\N
48	CUEMENILXIWG7QRQ7	slug:	parent_child	false	1	rbac-test	2025-08-23 00:22:21.178816+00	{"initial_link": true}	active	\N
49	CUEMENIMRMCYQWKEI	slug:	parent_child	false	1	rbac-test	2025-08-23 00:23:00.182543+00	{"initial_link": true}	active	\N
50	CUEMENIRGZ906SNAR	slug:	parent_child	false	1	rbac-test	2025-08-23 00:26:39.669717+00	{"initial_link": true}	active	\N
51	CUEMENIS44YIBI1Q7	slug:	parent_child	false	1	rbac-test	2025-08-23 00:27:09.683049+00	{"initial_link": true}	active	\N
52	CUEMENIUDD21M7S2X	slug:	parent_child	false	1	rbac-test	2025-08-23 00:28:54.953047+00	{"initial_link": true}	active	\N
53	CUEMENIWAI54O2R24	slug:	parent_child	false	1	rbac-test	2025-08-23 00:30:24.559332+00	{"initial_link": true}	active	\N
54	CUEMENIZ7HH2OW09M	slug:	parent_child	false	1	rbac-test	2025-08-23 00:32:40.616157+00	{"initial_link": true}	active	\N
55	CUEMENJ1R1M5WVTRP	slug:	parent_child	false	1	rbac-test	2025-08-23 00:34:39.276316+00	{"initial_link": true}	active	\N
56	CUEMENJH97NHXBN4P	slug:	parent_child	false	1	rbac-test	2025-08-23 00:46:42.661809+00	{"initial_link": true}	active	\N
57	CUEMENJIUTTLKPHDF	slug:	parent_child	false	1	rbac-test	2025-08-23 00:47:57.332069+00	{"initial_link": true}	active	\N
58	CUEMENJJDS312LZRG	slug:	parent_child	false	1	rbac-test	2025-08-23 00:48:21.894202+00	{"initial_link": true}	active	\N
59	CUEMENM36688GBOIO	LOCAL-RD-menkaa03-ma8qf	parent_child	false	1	rbac-test	2025-08-23 01:59:44.386314+00	{"initial_link": true}	active	\N
60	CUEMENMPWWR6J4IP4	LOCAL-RD-menkaa03-ma8qf	parent_child	false	1	rbac-test	2025-08-23 02:17:25.469464+00	{"initial_link": true}	active	\N
61	CUEMENMRO3E5UHGQO	LOCAL-RD-menkaa03-ma8qf	parent_child	false	1	rbac-test	2025-08-23 02:18:47.356425+00	{"initial_link": true}	active	\N
62	CUEMENMSMYX79Z3L4	LOCAL-RD-menkaa03-ma8qf	parent_child	false	1	rbac-test	2025-08-23 02:19:32.556155+00	{"initial_link": true}	active	\N
63	CUEMENMUQO30DJWZ6	LOCAL-RD-menkaa03-ma8qf	parent_child	false	1	rbac-test	2025-08-23 02:21:10.660382+00	{"initial_link": true}	active	\N
64	CUEMENN9OHORZFJJL	SEGMEEJ3TNWZ5IUEO	parent_child	false	1	rbac-test	2025-08-23 02:32:47.678517+00	{"initial_link": true}	active	\N
65	CUEMENNBL547W2F07	SEGMEEJ3TNWZ5IUEO	parent_child	false	1	rbac-test	2025-08-23 02:34:16.650666+00	{"initial_link": true}	active	\N
66	CUEMENNQEK7IBMNV5	slug: 60 Cracker Barrel	parent_child	false	1	rbac-test	2025-08-23 02:45:47.961449+00	{"initial_link": true}	active	\N
67	CUEMENNRBBBQIXF7I	slug: 60 Cracker Barrel	parent_child	false	1	rbac-test	2025-08-23 02:46:30.407515+00	{"initial_link": true}	active	\N
68	CUEMENNSC98CS9ZZU	slug: 60 Cracker Barrel	parent_child	false	1	rbac-test	2025-08-23 02:47:18.287016+00	{"initial_link": true}	active	\N
69	CUEMENNSXUZ1JDLZ7	slug: 60 Cracker Barrel	parent_child	false	1	rbac-test	2025-08-23 02:47:46.286321+00	{"initial_link": true}	active	\N
70	CUEMENNVF3E2C7XIL	slug: 60 Cracker Barrel	parent_child	false	1	rbac-test	2025-08-23 02:49:41.932756+00	{"initial_link": true}	active	\N
71	CUEMENOBAE6S4NZSE	slug: taylor swift	parent_child	false	1	rbac-test	2025-08-23 03:02:02.336303+00	{"initial_link": true}	active	\N
72	CUEMEOJRS925MMOI8	SEGMENO45GP697XFT	parent_child	false	1	rbac-test	2025-08-23 17:42:40.072706+00	{"initial_link": true}	active	\N
73	CUEMEOMV84ZZEZVMG	SEGMENO45GP697XFT	parent_child	false	1	rbac-test	2025-08-23 19:09:19.475796+00	{"initial_link": true}	active	\N
74	CUEMEOMVCAIQ2MDV7	SEGMENO45GP697XFT	parent_child	false	1	rbac-test	2025-08-23 19:09:24.858709+00	{"initial_link": true}	active	\N
75	CUEMEOMVM8C1BJ23P	SEGMENO45GP697XFT	parent_child	false	1	rbac-test	2025-08-23 19:09:37.740926+00	{"initial_link": true}	active	\N
76	CUEMEOMVPPIAIQMD7	SEGMENO45GP697XFT	parent_child	false	1	rbac-test	2025-08-23 19:09:42.249196+00	{"initial_link": true}	active	\N
77	CUEMEOMVWA97O7H4A	SEGMENO45GP697XFT	parent_child	false	1	rbac-test	2025-08-23 19:09:50.769973+00	{"initial_link": true}	active	\N
78	CUEMEOMVZ52ZIS1IR	SEGMENO45GP697XFT	parent_child	false	1	rbac-test	2025-08-23 19:09:54.470773+00	{"initial_link": true}	active	\N
79	CUEMEOPLOWFSWFCUJ	SEGMEOOMWQVHLKPE7	parent_child	false	1	rbac-test	2025-08-23 20:25:53.489662+00	{"initial_link": true}	active	\N
80	CUEMEOPR27Q8GRQ0Z	SEGMEOOMWQVHLKPE7	parent_child	false	1	rbac-test	2025-08-23 20:30:04.024575+00	{"initial_link": true}	active	\N
81	CUEMEOPR5F8O373KC	SEGMEOOMWQVHLKPE7	parent_child	false	1	rbac-test	2025-08-23 20:30:08.180858+00	{"initial_link": true}	active	\N
82	CUEMEOPR9VVUNF1I6	SEGMEOOMWQVHLKPE7	parent_child	false	1	rbac-test	2025-08-23 20:30:13.964273+00	{"initial_link": true}	active	\N
83	CUEMEOPRCZZB1GX3E	SEGMEOOMWQVHLKPE7	parent_child	false	1	rbac-test	2025-08-23 20:30:18.001871+00	{"initial_link": true}	active	\N
84	CUEMEOPRF6G39VFYE	SEGMEOOMWQVHLKPE7	parent_child	false	1	rbac-test	2025-08-23 20:30:20.826999+00	{"initial_link": true}	active	\N
85	CUEMEOSWI106C2RU2	SEGMEOJ449DRJ4QTV	parent_child	false	1	rbac-test	2025-08-23 21:58:16.646977+00	{"initial_link": true}	active	\N
86	CUEMEOSWMBZ8DISGQ	SEGMEOJ449DRJ4QTV	parent_child	false	1	rbac-test	2025-08-23 21:58:22.224229+00	{"initial_link": true}	active	\N
87	CUEMEOSWQW1HZZOM9	SEGMEOJ449DRJ4QTV	parent_child	false	1	rbac-test	2025-08-23 21:58:28.129622+00	{"initial_link": true}	active	\N
88	ASTMFMTPMGXOM4Q0M	EPSMFMPEPUSI2Y6WI	belongs_to	false	1	system	2025-09-16 17:25:05.404251+00	{"initial_link": true}	active	\N
89	ASTMFSR6T37QO5C5V	EPSMFSR3W9KUCTLRM	belongs_to	false	1	system	2025-09-20 21:01:05.343761+00	{"initial_link": true}	active	\N
\.


--
-- Data for Name: asset_links; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.asset_links (id, source_asset_id, target_asset_id, link_type, meta_data, created_at) FROM stdin;
1	EPSMEEFA0DTJNAYVN	SEGMEEFAFL4C5RT2B	parent_child	{"child_type": "segment", "relationship": "parent_to_child"}	2025-08-16 15:39:30.287115+00
2	SEGMEEFAFL4C5RT2B	CUEMEEFALU37XGFSZ	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 15:39:38.383655+00
3	SEGMEEFAFL4C5RT2B	CUEMEEFBKP63U781E	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 15:40:23.56598+00
4	SEGMEEJ3TNWZ5IUEO	CUEMEEJFS6N0Y6BVP	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 17:35:38.36818+00
5	SEGMEEJ3TNWZ5IUEO	CUEMEEJFW5OXH49CV	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 17:35:43.512048+00
6	SEGMEEJ3TNWZ5IUEO	CUEMEEJFZ1B48GJAV	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 17:35:47.241977+00
7	SEGMEEJ3TNWZ5IUEO	CUEMEEJG1BTTZ9RKK	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 17:35:50.213026+00
8	SEGMEEJ3TNWZ5IUEO	CUEMEEJG43IE9XE52	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 17:35:53.801346+00
9	SEGMEEJ3TNWZ5IUEO	CUEMEEJG6CVN16KFJ	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 17:35:56.73086+00
10	SEGMEEJ3TNWZ5IUEO	CUEMEEJG9AV3QQNDK	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 17:36:00.543013+00
11	SEGMEEJ44L61P9LZV	CUEMEEJGLF9OYQXZC	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 17:36:16.257623+00
12	SEGMEEJ44L61P9LZV	CUEMEEJGNHIAMNDQO	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 17:36:18.924443+00
13	SEGMEEJ44L61P9LZV	CUEMEEJGPMGOLLC0T	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 17:36:21.696744+00
14	SEGMEEJ44L61P9LZV	CUEMEEJGRSTM36X2K	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 17:36:24.520699+00
15	SEGMEEJ44L61P9LZV	CUEMEEJGUC9SV6YC8	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 17:36:27.813382+00
16	SEGMEEJ44L61P9LZV	CUEMEEJGWBU9O8PJZ	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 17:36:30.388339+00
17	SEGMEEJ44L61P9LZV	CUEMEEJGZ5BR5TNAN	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 17:36:34.042022+00
18	SEGMEEJ44L61P9LZV	CUEMEEJH18K27GCUJ	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 17:36:36.752045+00
19	SEGMEEJ44L61P9LZV	CUEMEEJH39UTHDQPZ	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 17:36:39.390158+00
20	SEGMEEJ44L61P9LZV	CUEMEEJH5L5EJ0QLB	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 17:36:42.385812+00
21	SEGMEEJ44L61P9LZV	CUEMEEJH851KUTI9Z	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 17:36:45.693497+00
22	SEGMEEJ44L61P9LZV	CUEMEEJHAGOJO5MHZ	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 17:36:48.708642+00
23	SEGMEEJ44L61P9LZV	CUEMEEJHCIJ9X84QX	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 17:36:51.365654+00
24	SEGMEEJ44L61P9LZV	CUEMEEJHEY901HMCU	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 17:36:54.525608+00
25	SEGMEEJ44L61P9LZV	CUEMEEJHIMKMC68FC	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 17:36:59.288465+00
26	SEGMEEJ56401DC7UN	CUEMEEJHWMROXL1L8	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 17:37:17.439289+00
27	SEGMEEJ56401DC7UN	CUEMEEJHZTQUO2VE3	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 17:37:21.570439+00
28	SEGMEEJ5H1D9I4K1D	CUEMEEJJ87VW7XCBR	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 17:38:19.111696+00
29	SEGMEENCPXQ375N35	CUEMEEND27OHTCFXG	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 19:25:29.849579+00
30	SEGMEEJ4JNYVA02T4	CUEMEENDH3XSJ7GMN	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 19:25:49.15971+00
31	SEGMEEJ3YD0OKZM7D	CUEMEENDM8FGBUPV8	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 19:25:55.802584+00
32	EPSMEEJ32D9UFK5BU	ASTMEEOASULAQYTLJ	parent_child	{"child_type": "promo", "relationship": "parent_to_child"}	2025-08-16 19:51:44.029508+00
33	SEGMEEJ5H1D9I4K1D	CUEMEEPQ1XNB587ME	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 20:31:35.25587+00
34	SEGMEEJ3TNWZ5IUEO	CUEMEEQS4B424DL1B	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 21:01:11.252206+00
35	SEGMEEJ3TNWZ5IUEO	CUEMEF1M0VOTMXHR0	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-17 02:04:22.656584+00
36	SEGMEEJ3TNWZ5IUEO	CUEMEF1MMCNHQ2B7J	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-17 02:04:50.482495+00
37	SEGMEEJ3TNWZ5IUEO	CUEMEF1NP7R2S32UR	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-17 02:05:40.850609+00
38	SEGMEEJ3TNWZ5IUEO	CUEMEF1W0XP0Q5PKX	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-17 02:12:09.289389+00
39	SEGMEEJ3TNWZ5IUEO	CUEMEF22TNG6F7ZS8	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-17 02:17:26.432519+00
40	SEGMEEJ3TNWZ5IUEO	CUEMEF23DJ45GABLZ	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-17 02:17:52.203757+00
41	SEGMEEJ3TNWZ5IUEO	CUEMEF23VI6WIQ8SW	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-17 02:18:15.497874+00
42	SEGMEEJ3TNWZ5IUEO	CUEMEF24QS9R6YDTF	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-17 02:18:56.029171+00
43	SEGMEEJ3TNWZ5IUEO	CUEMEF2AE2W19MGZT	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-17 02:23:19.508915+00
44	SEGMEEJ3TNWZ5IUEO	CUEMENN9OHORZFJJL	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-23 02:32:47.687958+00
45	SEGMEEJ3TNWZ5IUEO	CUEMENNBL547W2F07	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-23 02:34:16.660557+00
46	SEGMENO45GP697XFT	CUEMEOJRS925MMOI8	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-23 17:42:40.08211+00
47	SEGMENO45GP697XFT	CUEMEOMV84ZZEZVMG	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-23 19:09:19.479716+00
48	SEGMENO45GP697XFT	CUEMEOMVCAIQ2MDV7	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-23 19:09:24.862531+00
49	SEGMENO45GP697XFT	CUEMEOMVM8C1BJ23P	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-23 19:09:37.74293+00
50	SEGMENO45GP697XFT	CUEMEOMVPPIAIQMD7	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-23 19:09:42.258051+00
51	SEGMENO45GP697XFT	CUEMEOMVWA97O7H4A	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-23 19:09:50.772378+00
52	SEGMENO45GP697XFT	CUEMEOMVZ52ZIS1IR	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-23 19:09:54.474113+00
53	SEGMEOOMWQVHLKPE7	CUEMEOPLOWFSWFCUJ	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-23 20:25:53.500521+00
54	SEGMEOOMWQVHLKPE7	CUEMEOPR27Q8GRQ0Z	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-23 20:30:04.033827+00
55	SEGMEOOMWQVHLKPE7	CUEMEOPR5F8O373KC	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-23 20:30:08.185553+00
56	SEGMEOOMWQVHLKPE7	CUEMEOPR9VVUNF1I6	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-23 20:30:13.967925+00
57	SEGMEOOMWQVHLKPE7	CUEMEOPRCZZB1GX3E	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-23 20:30:18.010294+00
58	SEGMEOOMWQVHLKPE7	CUEMEOPRF6G39VFYE	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-23 20:30:20.835361+00
59	SEGMEOJ449DRJ4QTV	CUEMEOSWI106C2RU2	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-23 21:58:16.656421+00
60	SEGMEOJ449DRJ4QTV	CUEMEOSWMBZ8DISGQ	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-23 21:58:22.227933+00
61	SEGMEOJ449DRJ4QTV	CUEMEOSWQW1HZZOM9	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-23 21:58:28.13219+00
\.


--
-- Data for Name: asset_messages; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.asset_messages (id, asset_id, message_type, content, user_id, created_at) FROM stdin;
\.


--
-- Data for Name: assets; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.assets (id, episode_id, asset_id, slug, filename, asset_type, file_path, file_size, mime_type, width, height, duration, created_at, updated_at, processed, meta_data, is_test_data) FROM stdin;
\.


--
-- Data for Name: blueprint_nodes; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.blueprint_nodes (id, template_id, parent_id, node_type, name, content, sort_order, is_required) FROM stdin;
2	1	\N	directory	assets	\N	1	t
3	1	\N	directory	rundown	\N	2	t
4	1	\N	directory	exports	\N	3	t
5	1	\N	directory	distribute	\N	4	t
6	1	2	directory	audio	\N	1	t
7	1	2	directory	video	\N	2	t
8	1	2	directory	graphics	\N	3	t
9	1	2	directory	images	\N	4	t
10	1	2	directory	quotes	\N	5	t
11	2	\N	directory	assets	\N	1	t
12	2	\N	directory	rundown	\N	2	t
13	2	\N	directory	exports	\N	3	t
14	2	\N	directory	distribute	\N	4	t
15	2	11	directory	audio	\N	1	t
16	2	11	directory	video	\N	2	t
17	2	11	directory	graphics	\N	3	t
18	2	11	directory	images	\N	4	t
19	2	11	directory	quotes	\N	5	t
20	3	\N	directory	assets	\N	1	t
21	3	\N	directory	rundown	\N	2	t
22	3	\N	directory	exports	\N	3	t
23	3	\N	directory	distribute	\N	4	t
24	3	20	directory	audio	\N	1	t
25	3	20	directory	video	\N	2	t
26	3	20	directory	graphics	\N	3	t
27	3	20	directory	images	\N	4	t
28	3	20	directory	quotes	\N	5	t
34	1	\N	directory	scripts	\N	5	t
46	2	\N	directory	scripts	\N	5	t
58	3	\N	directory	scripts	\N	5	t
\.


--
-- Data for Name: blueprint_templates; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.blueprint_templates (id, name, description, template_type, is_active, is_default, template_metadata, created_at, updated_at) FROM stdin;
1	Sunday Show	Standard Sunday show template with segments and breaks	episode	t	t	{"status": "draft", "duration": "01:00:00"}	2025-08-27 08:41:52.640741+00	\N
2	Full Show	Complete show template with all segments	episode	t	f	{"status": "draft", "duration": "02:00:00"}	2025-08-27 08:41:52.640741+00	\N
3	Interview	Interview-focused template	episode	t	f	{"status": "draft", "duration": "00:30:00"}	2025-08-27 08:41:52.640741+00	\N
\.


--
-- Data for Name: blueprints; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.blueprints (id, episode_number, title, description, episode_metadata, template_id, status, created_by, organization_id, file_path, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: breaks; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.breaks (id, asset_id, episode_id, name, break_type, order_in_episode, estimated_duration, actual_duration, description, sponsor, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: cue_blocks; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.cue_blocks (id, rundown_item_id, asset_id, slug, cue_type, "order", quote_text, attribution, media_url, transcription, duration, created_at, updated_at, validated, validation_errors, meta_data, is_test_data) FROM stdin;
\.


--
-- Data for Name: cues; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.cues (id, asset_id, segment_id, element_id, cue_type, name, time_offset, duration, parameters, notes, created_at, updated_at) FROM stdin;
1	CUEMEEFALU37XGFSZ	1	\N	MEDIA	sot-cue-1	0	\N	{"original_cue_type": "SOT", "slug": "sot-cue-1"}	\N	2025-08-16 15:39:38.383655+00	\N
2	CUEMEEFBKP63U781E	1	\N	MEDIA	test-gfx-cue	0	\N	{"original_cue_type": "GFX", "slug": "test-gfx-cue"}	\N	2025-08-16 15:40:23.56598+00	\N
3	CUEMEEJFS6N0Y6BVP	2	\N	MEDIA	vigilante-tube	0	\N	{"original_cue_type": "GFX", "slug": "vigilante-tube"}	\N	2025-08-16 17:35:38.36818+00	\N
4	CUEMEEJFW5OXH49CV	2	\N	MEDIA	a group of	0	\N	{"original_cue_type": "FSQ", "slug": "a group of"}	\N	2025-08-16 17:35:43.512048+00	\N
5	CUEMEEJFZ1B48GJAV	2	\N	MEDIA	the clip shows	0	\N	{"original_cue_type": "FSQ", "slug": "the clip shows"}	\N	2025-08-16 17:35:47.241977+00	\N
6	CUEMEEJG1BTTZ9RKK	2	\N	MEDIA	The BTP are	0	\N	{"original_cue_type": "FSQ", "slug": "The BTP are"}	\N	2025-08-16 17:35:50.213026+00	\N
7	CUEMEEJG43IE9XE52	2	\N	MEDIA	holly-pictures	0	\N	{"original_cue_type": "GFX", "slug": "holly-pictures"}	\N	2025-08-16 17:35:53.801346+00	\N
8	CUEMEEJG6CVN16KFJ	2	\N	MEDIA	cincy-black-leaders	0	\N	{"original_cue_type": "SOT", "slug": "cincy-black-leaders"}	\N	2025-08-16 17:35:56.73086+00	\N
9	CUEMEEJG9AV3QQNDK	2	\N	MEDIA	walter-tweet	0	\N	{"original_cue_type": "GFX", "slug": "walter-tweet"}	\N	2025-08-16 17:36:00.543013+00	\N
10	CUEMEEJGLF9OYQXZC	4	\N	MEDIA	male-cheerleaders	0	\N	{"original_cue_type": "GFX", "slug": "male-cheerleaders"}	\N	2025-08-16 17:36:16.257623+00	\N
11	CUEMEEJGNHIAMNDQO	4	\N	MEDIA	dance-like-girl	0	\N	{"original_cue_type": "SOT", "slug": "dance-like-girl"}	\N	2025-08-16 17:36:18.924443+00	\N
12	CUEMEEJGPMGOLLC0T	4	\N	MEDIA	colin-wright-poll	0	\N	{"original_cue_type": "GFX", "slug": "colin-wright-poll"}	\N	2025-08-16 17:36:21.696744+00	\N
13	CUEMEEJGRSTM36X2K	4	\N	MEDIA	billboard-chris-tweet	0	\N	{"original_cue_type": "GFX", "slug": "billboard-chris-tweet"}	\N	2025-08-16 17:36:24.520699+00	\N
14	CUEMEEJGUC9SV6YC8	4	\N	MEDIA	john-connor-tweet	0	\N	{"original_cue_type": "GFX", "slug": "john-connor-tweet"}	\N	2025-08-16 17:36:27.813382+00	\N
15	CUEMEEJGWBU9O8PJZ	4	\N	MEDIA	brad-polumbo	0	\N	{"original_cue_type": "GFX", "slug": "brad-polumbo"}	\N	2025-08-16 17:36:30.388339+00	\N
16	CUEMEEJGZ5BR5TNAN	4	\N	MEDIA	prisha-mosley	0	\N	{"original_cue_type": "GFX", "slug": "prisha-mosley"}	\N	2025-08-16 17:36:34.042022+00	\N
17	CUEMEEJH18K27GCUJ	4	\N	MEDIA	what-youre-saying	0	\N	{"original_cue_type": "GFX", "slug": "what-youre-saying"}	\N	2025-08-16 17:36:36.752045+00	\N
18	CUEMEEJH39UTHDQPZ	4	\N	MEDIA	when-you-start	0	\N	{"original_cue_type": "GFX", "slug": "when-you-start"}	\N	2025-08-16 17:36:39.390158+00	\N
19	CUEMEEJH5L5EJ0QLB	4	\N	MEDIA	i-couldnt-disagree	0	\N	{"original_cue_type": "GFX", "slug": "i-couldnt-disagree"}	\N	2025-08-16 17:36:42.385812+00	\N
20	CUEMEEJH851KUTI9Z	4	\N	MEDIA	this-way-of-thinking	0	\N	{"original_cue_type": "GFX", "slug": "this-way-of-thinking"}	\N	2025-08-16 17:36:45.693497+00	\N
21	CUEMEEJHAGOJO5MHZ	4	\N	MEDIA	why-not	0	\N	{"original_cue_type": "GFX", "slug": "why-not"}	\N	2025-08-16 17:36:48.708642+00	\N
22	CUEMEEJHCIJ9X84QX	4	\N	MEDIA	i-kept-seeing	0	\N	{"original_cue_type": "GFX", "slug": "i-kept-seeing"}	\N	2025-08-16 17:36:51.365654+00	\N
23	CUEMEEJHEY901HMCU	4	\N	MEDIA	when-you-were	0	\N	{"original_cue_type": "GFX", "slug": "when-you-were"}	\N	2025-08-16 17:36:54.525608+00	\N
24	CUEMEEJHIMKMC68FC	4	\N	MEDIA	if-it-was	0	\N	{"original_cue_type": "GFX", "slug": "if-it-was"}	\N	2025-08-16 17:36:59.288465+00	\N
25	CUEMEEJHWMROXL1L8	6	\N	MEDIA	pdx-real	0	\N	{"original_cue_type": "GFX", "slug": "pdx-real"}	\N	2025-08-16 17:37:17.439289+00	\N
26	CUEMEEJHZTQUO2VE3	6	\N	MEDIA	karen-denver	0	\N	{"original_cue_type": "SOT", "slug": "karen-denver"}	\N	2025-08-16 17:37:21.570439+00	\N
27	CUEMEEJJ87VW7XCBR	7	\N	MEDIA	cookie-dough	0	\N	{"original_cue_type": "GFX", "slug": "cookie-dough"}	\N	2025-08-16 17:38:19.111696+00	\N
28	CUEMEEND27OHTCFXG	8	\N	MEDIA	Support Disaffected.com	0	\N	{"original_cue_type": "ADLIB", "slug": "Support Disaffected.com"}	\N	2025-08-16 19:25:29.849579+00	\N
29	CUEMEENDH3XSJ7GMN	5	\N	MEDIA	Support Disaffected.com	0	\N	{"original_cue_type": "ADLIB", "slug": "Support Disaffected.com"}	\N	2025-08-16 19:25:49.15971+00	\N
30	CUEMEENDM8FGBUPV8	3	\N	MEDIA	biltong adlib	0	\N	{"original_cue_type": "ADLIB", "slug": "biltong adlib"}	\N	2025-08-16 19:25:55.802584+00	\N
31	CUEMEEPQ1XNB587ME	7	\N	MEDIA	retarded-neighbors	0	\N	{"original_cue_type": "SOT", "slug": "retarded-neighbors"}	\N	2025-08-16 20:31:35.25587+00	\N
32	CUEMEEQS4B424DL1B	2	\N	MEDIA	chris-elston	0	\N	{"original_cue_type": "GFX", "slug": "chris-elston"}	\N	2025-08-16 21:01:11.252206+00	\N
33	CUEMEF1M0VOTMXHR0	2	\N	MEDIA	a-group-of	0	\N	{"original_cue_type": "gfx", "slug": "a-group-of"}	\N	2025-08-17 02:04:22.656584+00	\N
34	CUEMEF1MMCNHQ2B7J	2	\N	MEDIA	agrou-of-pt	0	\N	{"original_cue_type": "gfx", "slug": "agrou-of-pt"}	\N	2025-08-17 02:04:50.482495+00	\N
35	CUEMEF1NP7R2S32UR	2	\N	MEDIA	the-clip-shows	0	\N	{"original_cue_type": "gfx", "slug": "the-clip-shows"}	\N	2025-08-17 02:05:40.850609+00	\N
36	CUEMEF1W0XP0Q5PKX	2	\N	MEDIA	btp	0	\N	{"original_cue_type": "gfx", "slug": "btp"}	\N	2025-08-17 02:12:09.289389+00	\N
37	CUEMEF22TNG6F7ZS8	2	\N	MEDIA	a-group-of	0	\N	{"original_cue_type": "gfx", "slug": "a-group-of"}	\N	2025-08-17 02:17:26.432519+00	\N
38	CUEMEF23DJ45GABLZ	2	\N	MEDIA	a-group-of-part	0	\N	{"original_cue_type": "gfx", "slug": "a-group-of-part"}	\N	2025-08-17 02:17:52.203757+00	\N
39	CUEMEF23VI6WIQ8SW	2	\N	MEDIA	an-off-duty	0	\N	{"original_cue_type": "gfx", "slug": "an-off-duty"}	\N	2025-08-17 02:18:15.497874+00	\N
40	CUEMEF24QS9R6YDTF	2	\N	MEDIA	spokesperson	0	\N	{"original_cue_type": "gfx", "slug": "spokesperson"}	\N	2025-08-17 02:18:56.029171+00	\N
41	CUEMEF2AE2W19MGZT	2	\N	MEDIA	the-clip	0	\N	{"original_cue_type": "gfx", "slug": "the-clip"}	\N	2025-08-17 02:23:19.508915+00	\N
42	CUEMENN9OHORZFJJL	2	\N	MEDIA	covid-lockdowns	0	\N	{"original_cue_type": "gfx", "slug": "covid-lockdowns"}	\N	2025-08-23 02:32:47.687958+00	\N
43	CUEMENNBL547W2F07	2	\N	MEDIA	young-adults-chart	0	\N	{"original_cue_type": "gfx", "slug": "young-adults-chart"}	\N	2025-08-23 02:34:16.660557+00	\N
44	CUEMEOJRS925MMOI8	16	\N	MEDIA	first-ag-vid	0	\N	{"original_cue_type": "SOT", "slug": "first-ag-vid"}	\N	2025-08-23 17:42:40.08211+00	\N
45	CUEMEOMV84ZZEZVMG	16	\N	MEDIA	assault-ice-officer	0	\N	{"original_cue_type": "SOT", "slug": "assault-ice-officer"}	\N	2025-08-23 19:09:19.479716+00	\N
46	CUEMEOMVCAIQ2MDV7	16	\N	MEDIA	shoot-maga	0	\N	{"original_cue_type": "SOT", "slug": "shoot-maga"}	\N	2025-08-23 19:09:24.862531+00	\N
47	CUEMEOMVM8C1BJ23P	16	\N	MEDIA	pamela-tweet	0	\N	{"original_cue_type": "GFX", "slug": "pamela-tweet"}	\N	2025-08-23 19:09:37.74293+00	\N
48	CUEMEOMVPPIAIQMD7	16	\N	MEDIA	pam-dr-janja	0	\N	{"original_cue_type": "SOT", "slug": "pam-dr-janja"}	\N	2025-08-23 19:09:42.258051+00	\N
49	CUEMEOMVWA97O7H4A	16	\N	MEDIA	un-women-journalists	0	\N	{"original_cue_type": "GFX", "slug": "un-women-journalists"}	\N	2025-08-23 19:09:50.772378+00	\N
50	CUEMEOMVZ52ZIS1IR	16	\N	MEDIA	un-women-journalist	0	\N	{"original_cue_type": "GFX", "slug": "un-women-journalist"}	\N	2025-08-23 19:09:54.474113+00	\N
51	CUEMEOPLOWFSWFCUJ	26	\N	MEDIA	ceo-cracker-barrel	0	\N	{"original_cue_type": "sot", "slug": "ceo-cracker-barrel"}	\N	2025-08-23 20:25:53.500521+00	\N
52	CUEMEOPR27Q8GRQ0Z	26	\N	MEDIA	inside-cracker-barrel	0	\N	{"original_cue_type": "SOT", "slug": "inside-cracker-barrel"}	\N	2025-08-23 20:30:04.033827+00	\N
53	CUEMEOPR5F8O373KC	26	\N	MEDIA	new-cracker-barrel	0	\N	{"original_cue_type": "GFX", "slug": "new-cracker-barrel"}	\N	2025-08-23 20:30:08.185553+00	\N
54	CUEMEOPR9VVUNF1I6	26	\N	MEDIA	old-cracker-barrel	0	\N	{"original_cue_type": "GFX", "slug": "old-cracker-barrel"}	\N	2025-08-23 20:30:13.967925+00	\N
55	CUEMEOPRCZZB1GX3E	26	\N	MEDIA	new-mdcdonalds	0	\N	{"original_cue_type": "GFX", "slug": "new-mdcdonalds"}	\N	2025-08-23 20:30:18.010294+00	\N
56	CUEMEOPRF6G39VFYE	26	\N	MEDIA	red-mcdonalds	0	\N	{"original_cue_type": "GFX", "slug": "red-mcdonalds"}	\N	2025-08-23 20:30:20.835361+00	\N
57	CUEMEOSWI106C2RU2	22	\N	MEDIA	shogirl-whore	0	\N	{"original_cue_type": "gfx", "slug": "shogirl-whore"}	\N	2025-08-23 21:58:16.656421+00	\N
58	CUEMEOSWMBZ8DISGQ	22	\N	MEDIA	response-to-cher-believe	0	\N	{"original_cue_type": "GFX", "slug": "response-to-cher-believe"}	\N	2025-08-23 21:58:22.227933+00	\N
59	CUEMEOSWQW1HZZOM9	22	\N	MEDIA	cher-believe	0	\N	{"original_cue_type": "GFX", "slug": "cher-believe"}	\N	2025-08-23 21:58:28.13219+00	\N
\.


--
-- Data for Name: elements; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.elements (id, asset_id, segment_id, element_type, name, slug, file_path, file_url, modifications, duration, resolution, file_size, quote_text, attribution, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: episode_templates; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.episode_templates (id, episode_number, title, description, episode_metadata, template_id, status, created_by, organization_id, file_path, created_at, updated_at) FROM stdin;
6	0001	\N	\N	{"airdate": "2025-08-31", "status": "draft", "duration": "00:00:00", "template_type": "sunday_show", "asset_id": "EPSMEY8EVJQRZK24K", "episode_number": "0001", "template_id": 1, "template_name": "Sunday Show"}	1	draft	1	\N	/home/episodes/0001	2025-08-30 12:22:23.822887+00	\N
8	0238	\N	\N	{"airdate": "2025-08-31", "status": "draft", "duration": "00:00:00", "template_type": "sunday_show", "asset_id": "EPSMEYLG3N3WWCLAJ", "episode_number": "0238", "template_id": 1, "template_name": "Sunday Show"}	1	draft	1	\N	/home/episodes/0238	2025-08-30 18:27:15.960536+00	\N
11	0240	The Turning Point	\N	{"airdate": "2025-09-14", "status": "draft", "duration": "00:00:00", "template_type": "sunday_show", "asset_id": "EPSMFJRNMJLTMEDTX", "episode_number": "0240", "template_id": 1, "template_name": "Sunday Show"}	1	draft	1	\N	/home/episodes/0240	2025-09-14 14:04:14.438412+00	\N
12	0241	\N	\N	{"airdate": "2025-09-21", "status": "draft", "duration": "00:00:00", "template_type": "sunday_show", "asset_id": "EPSMFM60A0IWPUX9Z", "episode_number": "0241", "template_id": 1, "template_name": "Sunday Show"}	1	draft	1	\N	/home/episodes/0241	2025-09-16 06:21:31.707446+00	\N
\.


--
-- Data for Name: episodes; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.episodes (id, asset_id, season_id, episode_number, title, slug, publish_date, air_date, target_duration, actual_duration, created_at, updated_at, status, is_test_data, guest_name, guest_bio, guest_website, template_type, template_id, template_name, duration_formatted) FROM stdin;
1	EPSMEEFA0DTJNAYVN	1	123	test-episode	test-episode	\N	\N	\N	\N	2025-08-16 15:39:10.681475+00	\N	draft	f	\N	\N	\N	\N	\N	\N	\N
3	EPSMEEJ32D9UFK5BU	1	236	Episode 236	episode-236	\N	\N	\N	\N	2025-08-16 17:25:45.111232+00	\N	draft	f	\N	\N	\N	\N	\N	\N	\N
6	EPSMEYLG3N3WWCLAJ	1	238	Episode 238 - Keri Smith	episode-238	2025-08-31 00:00:00	2025-08-31 00:00:00	\N	\N	2025-09-16 09:48:26.547467+00	\N	draft	f	Keri Smith	Host of Deprogrammed with Keri Smith	https://www.kerismith.net/	sunday_show	1	Sunday Show	00:00:00
7	EPSMFMGBVGXZ495AY	1	239	The Princess and the Pea	episode-0239	2025-09-07 00:00:00	2025-09-07 00:00:00	2700	\N	2025-09-16 11:10:28.889091+00	\N	published	f				sunday_show		Sunday Show	00:45:00
8	EPSMFMGRRW3D4U04V	1	240	The Turning Point	episode-0240	2025-09-14 00:00:00	2025-09-14 00:00:00	\N	\N	2025-09-16 11:22:50.74959+00	\N	published	f		\N	\N	sunday_show	\N		01:00:00
22	EPSMG001SVZY8YW7C	1	242	Forgiveness Discourse	episode-0242	\N	2025-09-28 00:00:00	\N	\N	2025-09-25 22:43:31.59806+00	2025-09-26 20:25:01.707343+00	draft	f	\N	\N	\N	episode	\N	Sunday Show	00:00:00
21	EP0241	1	241	Manson Family Values	manson-family-values	\N	\N	\N	\N	2025-09-21 03:43:06.658199+00	2025-09-21 03:44:11.163803+00	draft	f	\N	\N	\N	\N	\N	\N	01:00:00
23	EPSMG1FO7YJDBU685	1	243	Episode 0243	episode-0243	\N	2025-10-05 00:00:00	\N	\N	2025-09-26 22:48:37.97165+00	2025-09-27 01:30:26.905589+00	draft	f	\N	\N	\N	episode	\N	Sunday Show	00:00:00
\.


--
-- Data for Name: extracted_quotes; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.extracted_quotes (id, episode_id, quote_id, slug, text, attribution, context, generated_image_path, image_generated, word_count, character_count, created_at, updated_at, source_file, source_line, is_test_data) FROM stdin;
3	5	westman_001	to-my-mother-westman_001	To my mother and father, I am sorry I didn't turn out as you had hoped. You did not fail me, you gave me so much. I truly appreciate the love you have given me. I feel I was raised to be a good person. I've kept those traits of empahty, self-sacrifice, and good character	Robert "Robin" Westman's suicide note	{"category": "FS Quote/to my mother", "tags": ["family", "apology", "character", "self-reflection"], "content_warning": "suicide", "priority": "high", "source_type": "suicide_note", "metadata": {"source": "westman_suicide_note", "date_processed": "2025-08-30", "content_type": "sensitive", "requires_review": true, "broadcast_ready": false}}	\N	f	55	271	2025-08-30 18:50:36.795564+00	\N	/app/quotes_input.json	\N	t
4	5	westman_002	i-have-wanted-westman_002	I have wanted this for so long. I am not well. I am not right. I am a sad person, hautned by those things that do not go away. I know this is wrong but I can't seem to stop myself. I am severely depressed and have been suicidal for years. Only recently have I lost all hope and decided to perform my fainal action against this world. I don't want to kneel down for the injustices of this world. I want to die. I'd rather die on my feet than live on my knees, constantly in pain.	Robert "Robin" Westman's suicide note	{"category": "FS Quote/I have wanted", "tags": ["depression", "suicide", "mental_health", "pain", "desperation"], "content_warning": "suicide, mental_health", "priority": "high", "source_type": "suicide_note", "metadata": {"source": "westman_suicide_note", "date_processed": "2025-08-30", "content_type": "sensitive", "requires_review": true, "broadcast_ready": false}}	\N	f	98	478	2025-08-30 18:50:36.795564+00	\N	/app/quotes_input.json	\N	t
\.


--
-- Data for Name: group_roles; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.group_roles (group_id, role_id, assigned_at, assigned_by) FROM stdin;
\.


--
-- Data for Name: groups; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.groups (id, name, slug, description, is_active, color, organization_id, auto_assign_new_users, settings, created_at, updated_at, created_by) FROM stdin;
\.


--
-- Data for Name: organizations; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.organizations (id, asset_id, legal_name, created_at, updated_at, settings, name, trade_name, organization_type, industry, sector, registration_number, tax_id, address_line1, address_line2, city, state_province, postal_code, country, phone, email, website, founded_date, number_of_employees, annual_revenue, status, created_by, notes, is_test_data) FROM stdin;
2	ORGH5ZI5TKE88NN	TechCorp Solutions LLC	2025-08-10 06:40:03.81508+00	\N	\N	TechCorp	\N	\N	Technology	\N	\N	\N	\N	\N	San Francisco	CA	\N	United States	\N	\N	\N	\N	\N	\N	active	system	\N	f
3	ORGCIDYCO7JX9EZ	Green Valley Media Inc	2025-08-10 06:40:03.820306+00	\N	\N	Green Valley	\N	\N	Media	\N	\N	\N	\N	\N	Portland	OR	\N	United States	\N	\N	\N	\N	\N	\N	active	system	\N	f
4	ORGQ2GL520UIANC	Midwest Manufacturing Corp	2025-08-10 06:40:03.82063+00	\N	\N	Midwest Mfg	\N	\N	Manufacturing	\N	\N	\N	\N	\N	Detroit	MI	\N	United States	\N	\N	\N	\N	\N	\N	active	system	\N	f
5	ORGE1AWSKKPSNZ7	Coastal Services Group	2025-08-10 06:40:03.821015+00	\N	\N	Coastal Services	\N	\N	Professional Services	\N	\N	\N	\N	\N	Miami	FL	\N	United States	\N	\N	\N	\N	\N	\N	active	system	\N	f
6	ORGWHPND5I9HDZ9	Mountain Peak Ventures LLC	2025-08-10 06:40:03.821322+00	\N	\N	Mountain Peak	\N	\N	Investment	\N	\N	\N	\N	\N	Denver	CO	\N	United States	\N	\N	\N	\N	\N	\N	active	system	\N	f
1	ORGME59KA79S92XIP	Polaris Broadcasting LLC	2025-08-10 05:49:16.613655+00	2025-08-10 06:35:26.55891+00	{"migrated_from_settings": true}	Polaris Mediaworks	Polaris Media	LLC	Broadcasting	Media & Entertainment	124456465	54564579686	190 Main St.	\N	Ravena	NY	12143	United States	(518) 605-6460	info@polarisbroadcasting.com	https://polarisbroadcasting.com	2025-01-15 00:00:00+00	1	250000000	active	kevin	Regional broadcasting company focused on local news and community content	f
7	ORGA0DTJNAYVN	Default Organization	2025-08-16 15:39:10.681475+00	\N	{}	Default Organization	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	United States	\N	\N	\N	\N	\N	\N	active	\N	\N	f
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.permissions (id, name, display_name, description, resource, action, scope, is_system, created_at, updated_at, created_by) FROM stdin;
1	users.create	Create Users	\N	users	create	global	t	2025-08-13 12:59:32.624322+00	\N	system
2	users.read	View Users	\N	users	read	organization	t	2025-08-13 12:59:32.624322+00	\N	system
3	users.update	Update Users	\N	users	update	organization	t	2025-08-13 12:59:32.624322+00	\N	system
4	users.delete	Delete Users	\N	users	delete	organization	t	2025-08-13 12:59:32.624322+00	\N	system
5	organizations.create	Create Organizations	\N	organizations	create	global	t	2025-08-13 12:59:32.624322+00	\N	system
6	organizations.read	View Organizations	\N	organizations	read	own	t	2025-08-13 12:59:32.624322+00	\N	system
7	organizations.update	Update Organizations	\N	organizations	update	own	t	2025-08-13 12:59:32.624322+00	\N	system
8	organizations.delete	Delete Organizations	\N	organizations	delete	global	t	2025-08-13 12:59:32.624322+00	\N	system
9	shows.create	Create Shows	\N	shows	create	organization	t	2025-08-13 12:59:32.624322+00	\N	system
10	shows.read	View Shows	\N	shows	read	organization	t	2025-08-13 12:59:32.624322+00	\N	system
11	shows.update	Update Shows	\N	shows	update	organization	t	2025-08-13 12:59:32.624322+00	\N	system
12	shows.delete	Delete Shows	\N	shows	delete	organization	t	2025-08-13 12:59:32.624322+00	\N	system
13	episodes.create	Create Episodes	\N	episodes	create	organization	t	2025-08-13 12:59:32.624322+00	\N	system
14	episodes.read	View Episodes	\N	episodes	read	organization	t	2025-08-13 12:59:32.624322+00	\N	system
15	episodes.update	Update Episodes	\N	episodes	update	organization	t	2025-08-13 12:59:32.624322+00	\N	system
16	episodes.delete	Delete Episodes	\N	episodes	delete	organization	t	2025-08-13 12:59:32.624322+00	\N	system
17	episodes.publish	Publish Episodes	\N	episodes	publish	organization	t	2025-08-13 12:59:32.624322+00	\N	system
18	content.create	Create Content	\N	content	create	organization	t	2025-08-13 12:59:32.624322+00	\N	system
19	content.read	View Content	\N	content	read	organization	t	2025-08-13 12:59:32.624322+00	\N	system
20	content.update	Update Content	\N	content	update	organization	t	2025-08-13 12:59:32.624322+00	\N	system
21	content.delete	Delete Content	\N	content	delete	organization	t	2025-08-13 12:59:32.624322+00	\N	system
22	rbac.manage	Manage Roles & Permissions	\N	rbac	manage	organization	t	2025-08-13 12:59:32.624322+00	\N	system
23	rbac.assign	Assign Roles	\N	rbac	assign	organization	t	2025-08-13 12:59:32.624322+00	\N	system
24	rbac.audit	View Audit Logs	\N	rbac	audit	organization	t	2025-08-13 12:59:32.624322+00	\N	system
25	admin.all	Full System Access	\N	admin	all	global	t	2025-08-13 12:59:32.624322+00	\N	system
\.


--
-- Data for Name: processing_jobs; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.processing_jobs (id, episode_id, job_type, job_id, status, parameters, result, error_message, progress, created_at, started_at, completed_at, is_test_data) FROM stdin;
\.


--
-- Data for Name: rbac_audit_log; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.rbac_audit_log (id, action, resource_type, resource_id, actor_type, actor_id, organization_id, details, ip_address, user_agent, created_at) FROM stdin;
1	role_assigned	user	1	user	rbac-test	1	{"role_id": 5, "role_name": "Viewer"}	\N	\N	2025-08-13 13:00:27.045792+00
\.


--
-- Data for Name: regions; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.regions (id, asset_id, is_test_data, rundown_id, region_type, name, description, order_in_rundown, estimated_duration, actual_duration, is_collapsible, is_collapsed, allow_reorder, color_theme, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.role_permissions (role_id, permission_id, granted_at, granted_by) FROM stdin;
1	25	2025-08-13 12:59:32.624322+00	\N
2	14	2025-08-13 12:59:32.624322+00	\N
2	19	2025-08-13 12:59:32.624322+00	\N
2	11	2025-08-13 12:59:32.624322+00	\N
2	9	2025-08-13 12:59:32.624322+00	\N
2	3	2025-08-13 12:59:32.624322+00	\N
2	10	2025-08-13 12:59:32.624322+00	\N
2	7	2025-08-13 12:59:32.624322+00	\N
2	2	2025-08-13 12:59:32.624322+00	\N
2	18	2025-08-13 12:59:32.624322+00	\N
2	1	2025-08-13 12:59:32.624322+00	\N
2	16	2025-08-13 12:59:32.624322+00	\N
2	20	2025-08-13 12:59:32.624322+00	\N
2	13	2025-08-13 12:59:32.624322+00	\N
2	15	2025-08-13 12:59:32.624322+00	\N
2	6	2025-08-13 12:59:32.624322+00	\N
2	4	2025-08-13 12:59:32.624322+00	\N
2	23	2025-08-13 12:59:32.624322+00	\N
2	21	2025-08-13 12:59:32.624322+00	\N
2	12	2025-08-13 12:59:32.624322+00	\N
2	22	2025-08-13 12:59:32.624322+00	\N
2	24	2025-08-13 12:59:32.624322+00	\N
2	17	2025-08-13 12:59:32.624322+00	\N
3	11	2025-08-13 12:59:32.624322+00	\N
3	17	2025-08-13 12:59:32.624322+00	\N
3	13	2025-08-13 12:59:32.624322+00	\N
3	20	2025-08-13 12:59:32.624322+00	\N
3	19	2025-08-13 12:59:32.624322+00	\N
3	10	2025-08-13 12:59:32.624322+00	\N
3	21	2025-08-13 12:59:32.624322+00	\N
3	15	2025-08-13 12:59:32.624322+00	\N
3	16	2025-08-13 12:59:32.624322+00	\N
3	14	2025-08-13 12:59:32.624322+00	\N
3	18	2025-08-13 12:59:32.624322+00	\N
3	9	2025-08-13 12:59:32.624322+00	\N
4	19	2025-08-13 12:59:32.624322+00	\N
4	18	2025-08-13 12:59:32.624322+00	\N
4	21	2025-08-13 12:59:32.624322+00	\N
4	14	2025-08-13 12:59:32.624322+00	\N
4	15	2025-08-13 12:59:32.624322+00	\N
4	20	2025-08-13 12:59:32.624322+00	\N
5	10	2025-08-13 12:59:32.624322+00	\N
5	14	2025-08-13 12:59:32.624322+00	\N
5	19	2025-08-13 12:59:32.624322+00	\N
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.roles (id, name, slug, description, parent_role_id, level, is_system, is_active, color, organization_id, created_at, updated_at, created_by) FROM stdin;
1	Super Admin	super-admin	Full system administrator	\N	0	t	t	\N	\N	2025-08-13 12:59:32.624322+00	\N	system
2	Organization Admin	org-admin	Organization administrator	\N	1	t	t	\N	\N	2025-08-13 12:59:32.624322+00	\N	system
3	Content Manager	content-manager	Manages shows and episodes	\N	2	t	t	\N	\N	2025-08-13 12:59:32.624322+00	\N	system
4	Content Editor	content-editor	Edits content and rundowns	\N	3	t	t	\N	\N	2025-08-13 12:59:32.624322+00	\N	system
5	Viewer	viewer	Read-only access	\N	4	t	t	\N	\N	2025-08-13 12:59:32.624322+00	\N	system
\.


--
-- Data for Name: rundown_items; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.rundown_items (id, asset_id, rundown_id, segment_id, item_type, title, slug, order_in_rundown, duration, subtitle, description, airdate, guests, resources, tags, server_message, link, priority, message, status, created_at, updated_at, is_test_data, script_content) FROM stdin;
1	ASTMEEFD8AX520WY1	1	\N	advertisement	sponsor-message-1	sponsor-message-1	1	00:00:30	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	draft	2025-08-16 15:41:40.813318+00	\N	f	\N
158	SEGMG1FRQHM2U8QNM	20	\N	tease	Untitled		20	00:00:00:00			\N		\N		\N	\N		\N	draft	2025-09-26 22:51:21.946809+00	2025-09-27 01:30:26.94579+00	f	
3	ASTMENN08JNRJDC0G	1	\N	advertisement	ad	ad	1	00:00:30	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	draft	2025-08-23 02:25:27.117073+00	\N	f	\N
4	ASTMENNENQDGGNHMO	1	\N	advertisement	ad	ad	1	00:00:30	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	draft	2025-08-23 02:36:39.983838+00	\N	f	\N
5	ASTMENNGGSESOGQAU	1	\N	advertisement	ad	ad	1	00:00:30	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	draft	2025-08-23 02:38:04.296152+00	\N	f	\N
165	placeholder_1758936099954_eflmvwob1	20	\N	ad	New Break 3 (Click to edit)	new-break-placeholder	60	00:01:00			\N		\N		\N	\N	normal	\N	draft	2025-09-27 01:21:50.669063+00	2025-09-27 01:30:26.947393+00	f	
166	placeholder_1758936103266_htzpl1iac	20	\N	segment	New Block A (Click to edit)	new-block-placeholder	70	00:01:00			\N		\N		\N	\N	normal	\N	draft	2025-09-27 01:21:50.669578+00	2025-09-27 01:30:26.947765+00	f	
167	placeholder_1758936107138_wqvil0jj3	20	\N	segment	New Block A (Click to edit)	new-block-placeholder	80	00:01:00			\N		\N		\N	\N	normal	\N	draft	2025-09-27 01:21:50.670102+00	2025-09-27 01:30:26.948136+00	f	
9	SEGMF28JSPA3LJ9HU	3	\N	segment	Test Segment	test-segment	60	00:00:00		## Notes\n\n## Description\n\n## Script	\N				2025-09-02T07:37:18.094364: Generated server AssetID SEGMF28JSPA3LJ9HU via rundown item creation	\N		\N	draft	2025-09-16 11:15:55.189103+00	2025-09-16 11:40:41.270744+00	f	## Notes\n\n## Description\n\n## Script
6	SEGMF28K7VQEMC4OW	3	\N	segment	Middle Segment	middle-segment	40	00:00:00		## Notes\n\n## Description\n\n## Script	\N				2025-09-02T07:37:37.766587: Generated server AssetID SEGMF28K7VQEMC4OW via rundown item creation	\N		\N	draft	2025-09-16 11:15:55.173805+00	2025-09-16 11:40:41.270744+00	f	## Notes\n\n## Description\n\n## Script
21	ASTMFMGRRWO0XMK4R	6	\N	segment	Block A - Charlie Kirk	charlie-kirk	40	00:25:00	None	# Charlie Kirk\n\n**Facts:**\n\nCharlie Kirk was the founder of Turning Point USA, a group dedicated to mobilizing the young conservative vote. Charlie was killed at 31 years old. He leaves behind his wife Erika, and two small children, at least one of whom watched her father's carotid artery explode from an assassin's bullet the morning of Wednesday, Sept 10, 2025. \n\nCharlie was speaking on the campus of Utah Valley University. The suspect in custody now is 22-year-old Tyler Robinson. We'll have more on Robinson below. Much more. \n\nThis clip is a good example of who Charlie Kirk was and how he operated. He was a consummate gentleman, not a provocateur, impossibly gracious. He invited young leftist students to come up to the microphone to debate, and he took the most vile abuse from them without ever returning it in kind. \n\nTake a look:\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: charlie-in-action]\n[Description: ]\n[MediaURL: ../assets/video/charlie-in-action.mp4]\n[Duration: 00:00:57:09]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nCharlie turned the other cheek just like so many Christians want everyone to do. He wasn't foul-mouthed, mean, provocative, outrageous, or any of the other adjectives applied to firebrand commentators, applied to me though I'm small potatoes. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-E16387628722]\n[Slug: charlie-family]\n[Description: ]\n[MediaURL: ../assets/graphics/charlie-family.png]\n<img src="../assets/graphics/charlie-family.png" width="200" />\n<!-- End Cue -->\n\nAnd he was murdered anyway. Here it is:\n\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: alternate-charlie-kirk-shooting]\n[Description: ]\n[MediaURL: ../assets/video/alternate-charlie-kirk-shooting.mp4]\n[Duration: Pending...]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nHere it is from the front:\n\n\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: charlie-kirk-shooting]\n[Description: ]\n[MediaURL: ../assets/video/charlie-kirk-shooting.mp4]\n[Duration: Pending...]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\n## What we know about the shooter\n\nEverything is provisional. The story has changed several times as I've watched in real time. This is what I think I know as of Saturday, September 13. Everything is subject to change. \n\nThe police have arrested 22-year-old Tyler Robinson. He apparently spent one semester in college and dropped out. He comes from a Republican family with a mother and father still married, and two brothers. His father is a countertop installer and his mother apparently a social worker. More on the family in a few minutes. \n\nRobinson appears to have gotten on a rooftop and shot Charlie from a few hundred yards. \n\nWe're just learning from Fox News that Tyler Robinson had a boyfriend who calls himself a trans woman. All claims so far point to Tyler being the lone leftist liberal in conservative family. It appears, so far, that he became radicalized by spending way too much time online. Also more on this in a few minutes. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-E16387628722]\n[Slug: tyler-mask]\n[Description: ]\n[MediaURL: ../assets/graphics/tyler-mask.png]\n<img src="../assets/graphics/tyler-mask.png" width="200" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-E16387628722]\n[Slug: tyler-bedroom]\n[Description: ]\n[MediaURL: ../assets/graphics/tyler-bedroom.png]\n<img src="../assets/graphics/tyler-bedroom.png" width="200" />\n<!-- End Cue -->\n\nFrom Fox News:\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-E16387628722]\n[Slug: exclusive-charlie-tweet]\n[Description: ]\n[MediaURL: ../assets/graphics/exclusive-charlie-tweet.png]\n<img src="../assets/graphics/exclusive-charlie-tweet.png" width="200" />\n<!-- End Cue -->\n\n{GFX/the last question}\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-E16387628722]\n[Slug: the-last-question]\n[Description: ]\n[MediaURL: ../assets/graphics/the-last-question.png]\n<img src="../assets/graphics/the-last-question.png" width="200" />\n<!-- End Cue -->\n\nHere's what Utah Governor Spencer Cox had to say after Tyler was caught. Pay attention to what Cox says about what Tyler engraved on the bullets. He wrote antifa slogans, and also what appears to be a reference to transgender/furry culture. You'll hear Cox refer to a family member who turned Tyler in to the police. That family member was Tyler's father Matt. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: ut-gov-announcement]\n[Description: ]\n[MediaURL: ../assets/video/ut-gov-announcement.mp4]\n[Duration: 00:02:43:19]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\n-"Notices bulges"-furry trans reference\n\n-As I said, it appears that Tyler's father Matt turned his son in after getting a family preacher to convince Tyler not to kill himself and to take accountability for his actions. \n\n-Everyone around the family so far has described them as conservative, religious, and that Tyler was the only leftist, and that he had gotten increasinbly radical over time. It's  not clear to me if the family were practicing mormons, or some other religion or denomination. I'm seeing conflicting reports. \n\n## Media reaction\n\nFor years on this show we've talked about the socially acceptable open glee the mainstream left takes in violence against conservatives. How it goes all the way to the top. How President Joe Biden stood in front of a blood red background and screamed at half the country and called them enemies and killers because they wouldn't take a fucking shot in their arm over a fucking cold virus. \n\nHere's a clip from last year after the first ass. attempt against pres Trump. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: disaffected-clip]\n[Description: ]\n[MediaURL: ../assets/video/disaffected-clip.mp4]\n[Duration: 00:00:31:10]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {"credit1":"Joshua Slocum"}]\n<!-- End Cue -->\n\nPeople around the country this week are learning that their brothers, sisters, mothers, fathers, friends, bosses, and teachers would see them dead. They know this because their loved ones are delighting in Charlie Kirk's murder, and these people had thoughts that aligned with Charlie. \n\nYes, that's right. Your own family many of you wants you dead, or would happily see you dead without lifting a finger to stop it. They might even helpfully point to you so the killer can find you. I put friends out of my life over this during the past five years becasue I think they would see me dead too. After all, I'm a moral contaminant. And so are you to your leftist family. \n\nWe need our noses rubbed in this shit until it is smeared up our nostrils and we can't pretend any longer that we don't have feces in our face. So let's go. \n\nHere's a video montage from Virginia's Lt. Gov, Winsome Sears, a conservative. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: winsome-sears-fascism]\n[Description: ]\n[MediaURL: ../assets/video/winsome-sears-fascism.mp4]\n[Duration: 00:02:24:01]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nPsychopathic moral reversals. The murderers are telling us we're the murderers. \n\nHere's MSNBC reacting to Kirk's murder. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: msnbc-trump-justify-charlie]\n[Description: ]\n[MediaURL: ../assets/video/msnbc-trump-justify-charlie.mp4]\n[Duration: 00:00:36:22]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nDid you catch her lie? \nShe said a DOGE employee was "allegedly attacked." \nThere's nothing alleged about it and she knows it. She's lying consciously. Here's what that attack looked like:\n\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: big-balls-attacked]\n[Description: ]\n[MediaURL: ../assets/video/big-balls-attacked.mp4]\n[Duration: 00:01:56:24]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nHere's more from MSNBC\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: msnbc-divisive-charlie]\n[Description: ]\n[MediaURL: ../assets/video/msnbc-divisive-charlie.mp4]\n[Duration: 00:01:17:19]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nAnd here's more from MSNBC\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: msnbc-unfortunate]\n[Description: ]\n[MediaURL: ../assets/video/msnbc-unfortunate.mp4]\n[Duration: 00:00:25:10]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\n-Charlie deserved it, see? You say awful things like I care about the Constitution, and so you get awful things. Including having your carotid artery shot out in front of your fucking children.\n\nHere's the US House of Representives refusing to keep silent for a one-minute prayer for Charlie:\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: house-dems-boo-kirk]\n[Description: ]\n[MediaURL: ../assets/video/house-dems-boo-kirk.mp4]\n[Duration: 00:00:55:22]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nLet's look at the reactions from the public. Do not lie to yourself and people around you saying "this is just a few loons on social media." No it's not. And the fact that these people are comfortable saying this in public is a REAL LIFE REAL WORLD EMERGENCY. \n\nThere will be no "you're just cherry picking extremists." If that's your line, I know who you side with and you are my enemy and I will keep you in line of sight and never turn my back on you. I suggest all of you adopt my stance. The shushers will get you killed. \n\nThere were thousands of these reactions online. What you're gonna see is just a tiny fraction. Thousands and thousands and thousands of these. \n\nHere's intensive care Cleveland clinic nurse Andrew Corbit/Stiltner:  \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-E16387628722]\n[Slug: andrew-corbit]\n[Description: ]\n[MediaURL: ../assets/graphics/andrew-corbit.png]\n<img src="../assets/graphics/andrew-corbit.png" width="200" />\n<!-- End Cue -->\n\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-E16387628722]\n[Slug: andrew-thread]\n[Description: ]\n[MediaURL: ../assets/graphics/andrew-thread.png]\n<img src="../assets/graphics/andrew-thread.png" width="200" />\n<!-- End Cue -->\n\n-There was no old him. That's who he's always been. \n\n-Fire him. Pull his nursing license. \n\nHere's Heather Harvey, staffer for Democrat Rep. Andre Carson of Illinois. On Instagram she calls herself the smartass staffer\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-E16387628722]\n[Slug: smart-ass-staffer]\n[Description: ]\n[MediaURL: ../assets/graphics/smart-ass-staffer.png]\n<img src="../assets/graphics/smart-ass-staffer.png" width="200" />\n<!-- End Cue -->\n\n-Fire her. Blacklist in all party politics. \n\nThe TeleTeeShirt company had a hot new product for a few hours until someone noticed their psychopathy:\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-E16387628722]\n[Slug: tele-teeshirt]\n[Description: ]\n[MediaURL: ../assets/graphics/tele-teeshirt.png]\n<img src="../assets/graphics/tele-teeshirt.png" width="200" />\n<!-- End Cue -->\n\nHere's another nurse. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: medical-worker-charlie]\n[Description: ]\n[MediaURL: ../assets/video/medical-worker-charlie.mp4]\n[Duration: 00:00:36:22]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nHere's Lisa Damato, a former contestant on America's Next Top Model:\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: lisa-damato-charlie]\n[Description: ]\n[MediaURL: ../assets/video/lisa-damato-charlie.mp4]\n[Duration: 00:00:21:26]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nCharlie knew what was coming to America. Here's what he tweeted on April 7. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-E16387628722]\n[Slug: assassination-culture]\n[Description: ]\n[MediaURL: ../assets/graphics/assassination-culture.png]\n<img src="../assets/graphics/assassination-culture.png" width="200" />\n<!-- End Cue -->\n\nLet's check in with the borderline personality set. All of these appear to have comorbid pyschopathy. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: nose-ring-girl-charlie]\n[Description: ]\n[MediaURL: ../assets/video/nose-ring-girl-charlie.mp4]\n[Duration: 00:01:07:15]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nHere's more. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: charlie-in-the-neck]\n[Description: ]\n[MediaURL: ../assets/video/charlie-in-the-neck.mp4]\n[Duration: 00:00:30:09]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nHere's a TikTok compilation. See if you can identify any patterns about these people:\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: tiktok-celebration]\n[Description: ]\n[MediaURL: ../assets/video/tiktok-celebration.mp4]\n[Duration: 00:00:38:02]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nHere's a commenter named Amanda Seales. She would like you to know that she just chillin' and having her snacks about it. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: amanda-seales-charlie]\n[Description: ]\n[MediaURL: ../assets/video/amanda-seales-charlie.mp4]\n[Duration: 00:02:41:05]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nHere's a delightful and sweet girl:\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: the-best-part-a]\n[Description: ]\n[MediaURL: ../assets/video/the-best-part-a.mp4]\n[Duration: 00:00:17:18]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->	\N	None	None	None	None	\N	None	\N	production	2025-09-16 11:22:50.764656+00	2025-09-16 11:40:41.295386+00	f	# Charlie Kirk\n\n**Facts:**\n\nCharlie Kirk was the founder of Turning Point USA, a group dedicated to mobilizing the young conservative vote. Charlie was killed at 31 years old. He leaves behind his wife Erika, and two small children, at least one of whom watched her father's carotid artery explode from an assassin's bullet the morning of Wednesday, Sept 10, 2025. \n\nCharlie was speaking on the campus of Utah Valley University. The suspect in custody now is 22-year-old Tyler Robinson. We'll have more on Robinson below. Much more. \n\nThis clip is a good example of who Charlie Kirk was and how he operated. He was a consummate gentleman, not a provocateur, impossibly gracious. He invited young leftist students to come up to the microphone to debate, and he took the most vile abuse from them without ever returning it in kind. \n\nTake a look:\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: charlie-in-action]\n[Description: ]\n[MediaURL: ../assets/video/charlie-in-action.mp4]\n[Duration: 00:00:57:09]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nCharlie turned the other cheek just like so many Christians want everyone to do. He wasn't foul-mouthed, mean, provocative, outrageous, or any of the other adjectives applied to firebrand commentators, applied to me though I'm small potatoes. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-E16387628722]\n[Slug: charlie-family]\n[Description: ]\n[MediaURL: ../assets/graphics/charlie-family.png]\n<img src="../assets/graphics/charlie-family.png" width="200" />\n<!-- End Cue -->\n\nAnd he was murdered anyway. Here it is:\n\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: alternate-charlie-kirk-shooting]\n[Description: ]\n[MediaURL: ../assets/video/alternate-charlie-kirk-shooting.mp4]\n[Duration: Pending...]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nHere it is from the front:\n\n\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: charlie-kirk-shooting]\n[Description: ]\n[MediaURL: ../assets/video/charlie-kirk-shooting.mp4]\n[Duration: Pending...]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\n## What we know about the shooter\n\nEverything is provisional. The story has changed several times as I've watched in real time. This is what I think I know as of Saturday, September 13. Everything is subject to change. \n\nThe police have arrested 22-year-old Tyler Robinson. He apparently spent one semester in college and dropped out. He comes from a Republican family with a mother and father still married, and two brothers. His father is a countertop installer and his mother apparently a social worker. More on the family in a few minutes. \n\nRobinson appears to have gotten on a rooftop and shot Charlie from a few hundred yards. \n\nWe're just learning from Fox News that Tyler Robinson had a boyfriend who calls himself a trans woman. All claims so far point to Tyler being the lone leftist liberal in conservative family. It appears, so far, that he became radicalized by spending way too much time online. Also more on this in a few minutes. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-E16387628722]\n[Slug: tyler-mask]\n[Description: ]\n[MediaURL: ../assets/graphics/tyler-mask.png]\n<img src="../assets/graphics/tyler-mask.png" width="200" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-E16387628722]\n[Slug: tyler-bedroom]\n[Description: ]\n[MediaURL: ../assets/graphics/tyler-bedroom.png]\n<img src="../assets/graphics/tyler-bedroom.png" width="200" />\n<!-- End Cue -->\n\nFrom Fox News:\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-E16387628722]\n[Slug: exclusive-charlie-tweet]\n[Description: ]\n[MediaURL: ../assets/graphics/exclusive-charlie-tweet.png]\n<img src="../assets/graphics/exclusive-charlie-tweet.png" width="200" />\n<!-- End Cue -->\n\n{GFX/the last question}\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-E16387628722]\n[Slug: the-last-question]\n[Description: ]\n[MediaURL: ../assets/graphics/the-last-question.png]\n<img src="../assets/graphics/the-last-question.png" width="200" />\n<!-- End Cue -->\n\nHere's what Utah Governor Spencer Cox had to say after Tyler was caught. Pay attention to what Cox says about what Tyler engraved on the bullets. He wrote antifa slogans, and also what appears to be a reference to transgender/furry culture. You'll hear Cox refer to a family member who turned Tyler in to the police. That family member was Tyler's father Matt. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: ut-gov-announcement]\n[Description: ]\n[MediaURL: ../assets/video/ut-gov-announcement.mp4]\n[Duration: 00:02:43:19]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\n-"Notices bulges"-furry trans reference\n\n-As I said, it appears that Tyler's father Matt turned his son in after getting a family preacher to convince Tyler not to kill himself and to take accountability for his actions. \n\n-Everyone around the family so far has described them as conservative, religious, and that Tyler was the only leftist, and that he had gotten increasinbly radical over time. It's  not clear to me if the family were practicing mormons, or some other religion or denomination. I'm seeing conflicting reports. \n\n## Media reaction\n\nFor years on this show we've talked about the socially acceptable open glee the mainstream left takes in violence against conservatives. How it goes all the way to the top. How President Joe Biden stood in front of a blood red background and screamed at half the country and called them enemies and killers because they wouldn't take a fucking shot in their arm over a fucking cold virus. \n\nHere's a clip from last year after the first ass. attempt against pres Trump. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: disaffected-clip]\n[Description: ]\n[MediaURL: ../assets/video/disaffected-clip.mp4]\n[Duration: 00:00:31:10]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {"credit1":"Joshua Slocum"}]\n<!-- End Cue -->\n\nPeople around the country this week are learning that their brothers, sisters, mothers, fathers, friends, bosses, and teachers would see them dead. They know this because their loved ones are delighting in Charlie Kirk's murder, and these people had thoughts that aligned with Charlie. \n\nYes, that's right. Your own family many of you wants you dead, or would happily see you dead without lifting a finger to stop it. They might even helpfully point to you so the killer can find you. I put friends out of my life over this during the past five years becasue I think they would see me dead too. After all, I'm a moral contaminant. And so are you to your leftist family. \n\nWe need our noses rubbed in this shit until it is smeared up our nostrils and we can't pretend any longer that we don't have feces in our face. So let's go. \n\nHere's a video montage from Virginia's Lt. Gov, Winsome Sears, a conservative. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: winsome-sears-fascism]\n[Description: ]\n[MediaURL: ../assets/video/winsome-sears-fascism.mp4]\n[Duration: 00:02:24:01]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nPsychopathic moral reversals. The murderers are telling us we're the murderers. \n\nHere's MSNBC reacting to Kirk's murder. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: msnbc-trump-justify-charlie]\n[Description: ]\n[MediaURL: ../assets/video/msnbc-trump-justify-charlie.mp4]\n[Duration: 00:00:36:22]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nDid you catch her lie? \nShe said a DOGE employee was "allegedly attacked." \nThere's nothing alleged about it and she knows it. She's lying consciously. Here's what that attack looked like:\n\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: big-balls-attacked]\n[Description: ]\n[MediaURL: ../assets/video/big-balls-attacked.mp4]\n[Duration: 00:01:56:24]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nHere's more from MSNBC\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: msnbc-divisive-charlie]\n[Description: ]\n[MediaURL: ../assets/video/msnbc-divisive-charlie.mp4]\n[Duration: 00:01:17:19]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nAnd here's more from MSNBC\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: msnbc-unfortunate]\n[Description: ]\n[MediaURL: ../assets/video/msnbc-unfortunate.mp4]\n[Duration: 00:00:25:10]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\n-Charlie deserved it, see? You say awful things like I care about the Constitution, and so you get awful things. Including having your carotid artery shot out in front of your fucking children.\n\nHere's the US House of Representives refusing to keep silent for a one-minute prayer for Charlie:\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: house-dems-boo-kirk]\n[Description: ]\n[MediaURL: ../assets/video/house-dems-boo-kirk.mp4]\n[Duration: 00:00:55:22]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nLet's look at the reactions from the public. Do not lie to yourself and people around you saying "this is just a few loons on social media." No it's not. And the fact that these people are comfortable saying this in public is a REAL LIFE REAL WORLD EMERGENCY. \n\nThere will be no "you're just cherry picking extremists." If that's your line, I know who you side with and you are my enemy and I will keep you in line of sight and never turn my back on you. I suggest all of you adopt my stance. The shushers will get you killed. \n\nThere were thousands of these reactions online. What you're gonna see is just a tiny fraction. Thousands and thousands and thousands of these. \n\nHere's intensive care Cleveland clinic nurse Andrew Corbit/Stiltner:  \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-E16387628722]\n[Slug: andrew-corbit]\n[Description: ]\n[MediaURL: ../assets/graphics/andrew-corbit.png]\n<img src="../assets/graphics/andrew-corbit.png" width="200" />\n<!-- End Cue -->\n\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-E16387628722]\n[Slug: andrew-thread]\n[Description: ]\n[MediaURL: ../assets/graphics/andrew-thread.png]\n<img src="../assets/graphics/andrew-thread.png" width="200" />\n<!-- End Cue -->\n\n-There was no old him. That's who he's always been. \n\n-Fire him. Pull his nursing license. \n\nHere's Heather Harvey, staffer for Democrat Rep. Andre Carson of Illinois. On Instagram she calls herself the smartass staffer\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-E16387628722]\n[Slug: smart-ass-staffer]\n[Description: ]\n[MediaURL: ../assets/graphics/smart-ass-staffer.png]\n<img src="../assets/graphics/smart-ass-staffer.png" width="200" />\n<!-- End Cue -->\n\n-Fire her. Blacklist in all party politics. \n\nThe TeleTeeShirt company had a hot new product for a few hours until someone noticed their psychopathy:\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-E16387628722]\n[Slug: tele-teeshirt]\n[Description: ]\n[MediaURL: ../assets/graphics/tele-teeshirt.png]\n<img src="../assets/graphics/tele-teeshirt.png" width="200" />\n<!-- End Cue -->\n\nHere's another nurse. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: medical-worker-charlie]\n[Description: ]\n[MediaURL: ../assets/video/medical-worker-charlie.mp4]\n[Duration: 00:00:36:22]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nHere's Lisa Damato, a former contestant on America's Next Top Model:\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: lisa-damato-charlie]\n[Description: ]\n[MediaURL: ../assets/video/lisa-damato-charlie.mp4]\n[Duration: 00:00:21:26]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nCharlie knew what was coming to America. Here's what he tweeted on April 7. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-E16387628722]\n[Slug: assassination-culture]\n[Description: ]\n[MediaURL: ../assets/graphics/assassination-culture.png]\n<img src="../assets/graphics/assassination-culture.png" width="200" />\n<!-- End Cue -->\n\nLet's check in with the borderline personality set. All of these appear to have comorbid pyschopathy. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: nose-ring-girl-charlie]\n[Description: ]\n[MediaURL: ../assets/video/nose-ring-girl-charlie.mp4]\n[Duration: 00:01:07:15]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nHere's more. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: charlie-in-the-neck]\n[Description: ]\n[MediaURL: ../assets/video/charlie-in-the-neck.mp4]\n[Duration: 00:00:30:09]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nHere's a TikTok compilation. See if you can identify any patterns about these people:\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: tiktok-celebration]\n[Description: ]\n[MediaURL: ../assets/video/tiktok-celebration.mp4]\n[Duration: 00:00:38:02]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nHere's a commenter named Amanda Seales. She would like you to know that she just chillin' and having her snacks about it. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: amanda-seales-charlie]\n[Description: ]\n[MediaURL: ../assets/video/amanda-seales-charlie.mp4]\n[Duration: 00:02:41:05]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nHere's a delightful and sweet girl:\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: the-best-part-a]\n[Description: ]\n[MediaURL: ../assets/video/the-best-part-a.mp4]\n[Duration: 00:00:17:18]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->
29	ASTMFMGRRX6OW4SYP	6	\N	segment	Block B - Iryna Zarutska	iryna-zarutska	120	00:18:00	None	# Block B - Iryna Zarutska\n\nThe murder of Iryna Zarutska was going to be the lead story on this episode until the assassination of Charlie Kirk. It's all part of the same horror. \n\nWe're lucky we even know that this poor girl was murdered. It happened on August 22, and it was only because somebody got ahold of the CCTV camera footage on the train that we know about it. The media sure wasn't going to go there willingly. \n\nWhy? Because an American black man with at least 14 arrests knifed a beautiful young blonde European white girl, and we don't have sympathy for beautiful young, European white people. \n\nWe only have sympathy for criminal psychopath blacks. That's the United STates of Fucking America in 2025. The blacks want the whites dead, and at least half the whites want themselves or other whites dead too. It's the sickest sexual perversion I've ever seen, and that's exactly what it is. Psychosexual masochism. White liberals, you're shot through with it. You're disgusting and dangerous. \n\nOn August 22, 2025, a 24-year-old woman named Iryna Zarutska clocked out of a job at a pizza parlor and rode the train home from work. She was an actual refugee from Ukraine who had only arrived in the US recently to escape the war. She's dead now. \n\nHere she is in a picture with her father from her obituary:\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-60042039024A]\n[Slug: iryna-zarutska]\n[Description: ]\n[MediaURL: ../assets/graphics/iryna-zarutska.png]\n<img src="../assets/graphics/iryna-zarutska.png" width="200" />\n<!-- End Cue -->\n\nThis is your warning to turn away. We're going to play the entire murder, and her death, on video. That's starting right now. \n\nI want you to listen to what her killer, DeCarlos Brown says as he walked away. \n\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-AD401C8015AA]\n[Slug: iryna-murder]\n[Description: ]\n[MediaURL: ../assets/video/iryna-murder.mp4]\n[Duration: 00:00:48:17]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\n-Did you hear it? \n\n-Got that white girl. Got that white girl. \n\n-You see Iryna realize that she has been fatally wounded. She puts her head and cries because she's knows she's dying. And she's dying alone with no one to hold her. \n\nThis is when she realized. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-60042039024A]\n[Slug: iryna-scared]\n[Description: ]\n[MediaURL: ../assets/graphics/iryna-scared.png]\n<img src="../assets/graphics/iryna-scared.png" width="200" />\n<!-- End Cue -->\n\nIt's not about race, says everyone on the left. Don't say it's about race. It can't be about race. Even though proportionally far more black people kill white people than white people kill black people. Uh uh, the fact that most murders are race on same race does not change that. Even accounting for that, black people kill whites at a far higher rate proportion to their population than whites kill blacks. \n\nBy at least an order of magnitude. \n\nCNN political personality Van Jones had this to say:\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-AD401C8015AA]\n[Slug: van-jones]\n[Description: ]\n[MediaURL: ../assets/video/van-jones.mp4]\n[Duration: 00:00:12:14]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\n-The way this man was hurting. \n\n-Hurt people hurt people. \n\n-Did Iryna hurt DeCarlos?\n\n-Got that white girl. Go that white girl. \n\nVan Jones you are a motherfucker. \n\nHere's what the organization Black Lives Matter posted on social media on learning about this race based murder. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-AD401C8015AA]\n[Slug: blm-iryna-murder]\n[Description: ]\n[MediaURL: ../assets/video/blm-iryna-murder.mp4]\n[Duration: 00:00:14:25]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nI don't know who this guy is, but he's one of hundreds, probably thousands posting sentiments just like this. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-AD401C8015AA]\n[Slug: liberation-in-blood]\n[Description: ]\n[MediaURL: ../assets/video/liberation-in-blood.mp4]\n[Duration: 00:00:25:11]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nWho is the murderer DeCarlos Brown? Just another black brotha who been done wrong and need second chance. \n\nFourteen second chances. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-60042039024A]\n[Slug: breaking-it-has-been]\n[Description: ]\n[MediaURL: ../assets/graphics/breaking-it-has-been.png]\n<img src="../assets/graphics/breaking-it-has-been.png" width="200" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-60042039024A]\n[Slug: decarlos-arrest]\n[Description: ]\n[MediaURL: ../assets/graphics/decarlos-arrest.png]\n<img src="../assets/graphics/decarlos-arrest.png" width="200" />\n<!-- End Cue -->\n\nWho kept releasing him? The latest was magistrate judge Teresa Stokes:\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-60042039024A]\n[Slug: teresa-stokes]\n[Description: ]\n[MediaURL: ../assets/graphics/teresa-stokes.png]\n<img src="../assets/graphics/teresa-stokes.png" width="200" />\n<!-- End Cue -->\n\nFrom Newsweek:\n\nhttps://www.newsweek.com/teresa-stokes-charlotte-judge-decarlos-brown-jr-2126808\n\n\n\n\n{FS Quote/records show that}\n"Records show that Brown has been arrested 14 times in over a decade and was diagnosed with schizophrenia.He has previously been convicted of felony larceny, robbery with a dangerous weapon and communicating threats, leading to a six-year prison sentence in 2015 for incidents dating to 2013 and 2014. He was released in 2020; then, months later, he was charged with assaulting his sister."  \n—Newsweek\n\n{FS Quote/  \nStokes is a magistrate judge for the Charlotte District in Mecklenburg County Court, North Carolina. She has also been linked to a charity that provides mental health and addiction support by social media users, though Newsweek was unable to verify these claims."  \n—Newsweek\n\n-I've seen several claims that judge Teresa Stokes is not even an attorney and never passed the bar exam. I can't confirm or deny this, but it wouldn't surprise me. And if North Carolina or any other state allows the appointment of non lawyers like this then we can expect more of this. \n\nAs fellow Vermont podcaster Styxenhammer said:\n\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-60042039024A]\n[Slug: styxhenhammer]\n[Description: ]\n[MediaURL: ../assets/graphics/styxhenhammer.png]\n<img src="../assets/graphics/styxhenhammer.png" width="200" />\n<!-- End Cue -->	\N	None	None	None	None	\N	None	\N	production	2025-09-16 11:22:50.781401+00	2025-09-16 11:40:41.295386+00	f	# Block B - Iryna Zarutska\n\nThe murder of Iryna Zarutska was going to be the lead story on this episode until the assassination of Charlie Kirk. It's all part of the same horror. \n\nWe're lucky we even know that this poor girl was murdered. It happened on August 22, and it was only because somebody got ahold of the CCTV camera footage on the train that we know about it. The media sure wasn't going to go there willingly. \n\nWhy? Because an American black man with at least 14 arrests knifed a beautiful young blonde European white girl, and we don't have sympathy for beautiful young, European white people. \n\nWe only have sympathy for criminal psychopath blacks. That's the United STates of Fucking America in 2025. The blacks want the whites dead, and at least half the whites want themselves or other whites dead too. It's the sickest sexual perversion I've ever seen, and that's exactly what it is. Psychosexual masochism. White liberals, you're shot through with it. You're disgusting and dangerous. \n\nOn August 22, 2025, a 24-year-old woman named Iryna Zarutska clocked out of a job at a pizza parlor and rode the train home from work. She was an actual refugee from Ukraine who had only arrived in the US recently to escape the war. She's dead now. \n\nHere she is in a picture with her father from her obituary:\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-60042039024A]\n[Slug: iryna-zarutska]\n[Description: ]\n[MediaURL: ../assets/graphics/iryna-zarutska.png]\n<img src="../assets/graphics/iryna-zarutska.png" width="200" />\n<!-- End Cue -->\n\nThis is your warning to turn away. We're going to play the entire murder, and her death, on video. That's starting right now. \n\nI want you to listen to what her killer, DeCarlos Brown says as he walked away. \n\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-AD401C8015AA]\n[Slug: iryna-murder]\n[Description: ]\n[MediaURL: ../assets/video/iryna-murder.mp4]\n[Duration: 00:00:48:17]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\n-Did you hear it? \n\n-Got that white girl. Got that white girl. \n\n-You see Iryna realize that she has been fatally wounded. She puts her head and cries because she's knows she's dying. And she's dying alone with no one to hold her. \n\nThis is when she realized. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-60042039024A]\n[Slug: iryna-scared]\n[Description: ]\n[MediaURL: ../assets/graphics/iryna-scared.png]\n<img src="../assets/graphics/iryna-scared.png" width="200" />\n<!-- End Cue -->\n\nIt's not about race, says everyone on the left. Don't say it's about race. It can't be about race. Even though proportionally far more black people kill white people than white people kill black people. Uh uh, the fact that most murders are race on same race does not change that. Even accounting for that, black people kill whites at a far higher rate proportion to their population than whites kill blacks. \n\nBy at least an order of magnitude. \n\nCNN political personality Van Jones had this to say:\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-AD401C8015AA]\n[Slug: van-jones]\n[Description: ]\n[MediaURL: ../assets/video/van-jones.mp4]\n[Duration: 00:00:12:14]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\n-The way this man was hurting. \n\n-Hurt people hurt people. \n\n-Did Iryna hurt DeCarlos?\n\n-Got that white girl. Go that white girl. \n\nVan Jones you are a motherfucker. \n\nHere's what the organization Black Lives Matter posted on social media on learning about this race based murder. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-AD401C8015AA]\n[Slug: blm-iryna-murder]\n[Description: ]\n[MediaURL: ../assets/video/blm-iryna-murder.mp4]\n[Duration: 00:00:14:25]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nI don't know who this guy is, but he's one of hundreds, probably thousands posting sentiments just like this. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-AD401C8015AA]\n[Slug: liberation-in-blood]\n[Description: ]\n[MediaURL: ../assets/video/liberation-in-blood.mp4]\n[Duration: 00:00:25:11]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nWho is the murderer DeCarlos Brown? Just another black brotha who been done wrong and need second chance. \n\nFourteen second chances. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-60042039024A]\n[Slug: breaking-it-has-been]\n[Description: ]\n[MediaURL: ../assets/graphics/breaking-it-has-been.png]\n<img src="../assets/graphics/breaking-it-has-been.png" width="200" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-60042039024A]\n[Slug: decarlos-arrest]\n[Description: ]\n[MediaURL: ../assets/graphics/decarlos-arrest.png]\n<img src="../assets/graphics/decarlos-arrest.png" width="200" />\n<!-- End Cue -->\n\nWho kept releasing him? The latest was magistrate judge Teresa Stokes:\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-60042039024A]\n[Slug: teresa-stokes]\n[Description: ]\n[MediaURL: ../assets/graphics/teresa-stokes.png]\n<img src="../assets/graphics/teresa-stokes.png" width="200" />\n<!-- End Cue -->\n\nFrom Newsweek:\n\nhttps://www.newsweek.com/teresa-stokes-charlotte-judge-decarlos-brown-jr-2126808\n\n\n\n\n{FS Quote/records show that}\n"Records show that Brown has been arrested 14 times in over a decade and was diagnosed with schizophrenia.He has previously been convicted of felony larceny, robbery with a dangerous weapon and communicating threats, leading to a six-year prison sentence in 2015 for incidents dating to 2013 and 2014. He was released in 2020; then, months later, he was charged with assaulting his sister."  \n—Newsweek\n\n{FS Quote/  \nStokes is a magistrate judge for the Charlotte District in Mecklenburg County Court, North Carolina. She has also been linked to a charity that provides mental health and addiction support by social media users, though Newsweek was unable to verify these claims."  \n—Newsweek\n\n-I've seen several claims that judge Teresa Stokes is not even an attorney and never passed the bar exam. I can't confirm or deny this, but it wouldn't surprise me. And if North Carolina or any other state allows the appointment of non lawyers like this then we can expect more of this. \n\nAs fellow Vermont podcaster Styxenhammer said:\n\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-60042039024A]\n[Slug: styxhenhammer]\n[Description: ]\n[MediaURL: ../assets/graphics/styxhenhammer.png]\n<img src="../assets/graphics/styxhenhammer.png" width="200" />\n<!-- End Cue -->
25	ASTMFJZBY9ZAIA7F8	6	\N	segment	Reader	reader	100	00:00:00		## Notes\n\n## Description\n\n## Script\n\n[BILTONG ADLIB]	\N				2025-09-14T17:39:06.695870: Generated server AssetID ASTMFJZBY9ZAIA7F8 via rundown item creation	\N		\N	production	2025-09-16 11:22:50.771113+00	2025-09-16 11:40:41.295386+00	f	## Notes\n\n## Description\n\n## Script\n\n[BILTONG ADLIB]
20	ASTMFJRXLJJFR9CD6	6	\N	break	Break	break	60	00:00:00		## Notes\n\n## Description\n\n## Script\n\n<!-- Begin Cue -->\n[Type: BREAK]\n[Slug: break]\n[AssetID: ASTMFJRXLJJFR9CD6]\n<!-- End Cue -->	\N				2025-09-14T14:11:59.695948: Generated server AssetID ASTMFJRXLJJFR9CD6 via rundown item creation	\N		\N	production	2025-09-16 11:22:50.755516+00	2025-09-16 11:40:41.295386+00	f	## Notes\n\n## Description\n\n## Script\n\n<!-- Begin Cue -->\n[Type: BREAK]\n[Slug: break]\n[AssetID: ASTMFJRXLJJFR9CD6]\n<!-- End Cue -->
130	ASTMFT51TF3GVSA2G	18	\N	tease	Untitled	cancel culture tease	40	00:00:00:00			\N		\N		\N	\N		\N	draft	2025-09-21 03:44:11.202212+00	2025-09-21 03:58:11.850584+00	f	Come back on the other side to indulge in some schadenfreude as we watch modern day 
131	ASTMFT4Z3IX239XGC	18	\N	break	Break	break	50	00:00:00:00			\N		\N		\N	\N		\N	production	2025-09-21 03:44:11.202775+00	2025-09-21 03:58:11.851067+00	f	
132	ASTMFT51VJ4LRT1AC	18	\N	tease	Untitled	family insane tease	70	00:00:00:00			\N		\N		\N	\N		\N	production	2025-09-21 03:44:11.203949+00	2025-09-21 03:58:11.85211+00	f	Come back after the break to talk about what I'm hearing from my coaching and consulting clients on this topic. Many of them are afraid of, or should be afraid, of the people who live in the same house they do. Also, we'll have little bit of fun to close the show out. Don't you need a laugh? I do.
133	ASTMFT5139ND2XSZF	18	\N	break	Break	break	80	00:00:00:00			\N		\N		\N	\N		\N	production	2025-09-21 03:44:11.204486+00	2025-09-21 03:58:11.852569+00	f	
145	SEGMG0VU7HUK0A9VQ	19	\N	tease	Untitled		20	00:00:00:00			\N		\N		\N	\N		\N	draft	2025-09-26 13:33:24.97819+00	2025-09-26 20:42:27.638308+00	f	
146	SEGMG0VUC7GK67XG5	19	\N	segment	Segment	segment	70	00:00:00:00			\N		\N		\N	\N		\N	draft	2025-09-26 13:33:31.084899+00	2025-09-26 20:42:27.640426+00	f	
152	SEGMG10DYNGAK9T5P	19	\N	tease	Untitled		60	00:00:00:00			\N		\N		\N	\N		\N	draft	2025-09-26 15:40:45.100543+00	2025-09-26 20:42:27.640005+00	f	
33	ASTMFMGUNJ9DWHECM	9	\N	break	25 Break	25-break	25	00:05:00	None	<!-- Begin Cue -->\n[Type: Break]\n[AssetID: BREAK25001]\n[Slug: break]\n<!-- End Cue -->	\N	None	None	None	None	\N	None	\N	production	2025-09-16 11:25:05.066923+00	2025-09-16 11:40:41.244694+00	f	<!-- Begin Cue -->\n[Type: Break]\n[AssetID: BREAK25001]\n[Slug: break]\n<!-- End Cue -->
38	SEGMEEJ56401DC7UN	9	\N	segment	Borderlines in the Wild	borderline wild	50	02:31	None	## Notes\n\n## Description\n\n## Script\n\nYou're about to see the most Karen borderline meltdown of them all. It happened in Portland, naturally. And let's go out of order so we make sure this woman is publicly identified. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJHWMROXL1L8]\n[Slug: pdx-real]\n[Description: ]\n[MediaURL: ../assets/graphics/pdx-real.png]\n<img src="../assets/graphics/pdx-real.png" width="200" />\n<!-- End Cue -->\n\nClassic borderline. "Clicks. That's all I am to you." Why won't you see me as a damsel in distress? \n\nWanna see the video?\n\n-This is borderline psychosis\n\n-She would have been in an asylum in any other era. \n\nHere's one from downtown Denver. This shit is happening in the real world. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: CUEMEEJHZTQUO2VE3]\n[Slug: karen-denver]\n[Description: ]\n[MediaURL: ../assets/video/karen-denver.mp4]\n[Duration: 00:01:39:23]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\n-She diagnoses Trump "Pedophilic Disorder" from the Diagnostic and Statistical Manual. You do understand that these women are psycho-sexually disturbed? That their triggered state at masculinity, and their allegations of rape and pedophilia, are a form of their own sexual fantasies? It's true.	2025-08-17 00:00:00	None	None	None	None	\N	None	\N	production	2025-09-16 11:25:05.073322+00	2025-09-16 11:40:41.244694+00	f	## Notes\n\n## Description\n\n## Script\n\nYou're about to see the most Karen borderline meltdown of them all. It happened in Portland, naturally. And let's go out of order so we make sure this woman is publicly identified. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJHWMROXL1L8]\n[Slug: pdx-real]\n[Description: ]\n[MediaURL: ../assets/graphics/pdx-real.png]\n<img src="../assets/graphics/pdx-real.png" width="200" />\n<!-- End Cue -->\n\nClassic borderline. "Clicks. That's all I am to you." Why won't you see me as a damsel in distress? \n\nWanna see the video?\n\n-This is borderline psychosis\n\n-She would have been in an asylum in any other era. \n\nHere's one from downtown Denver. This shit is happening in the real world. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: CUEMEEJHZTQUO2VE3]\n[Slug: karen-denver]\n[Description: ]\n[MediaURL: ../assets/video/karen-denver.mp4]\n[Duration: 00:01:39:23]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\n-She diagnoses Trump "Pedophilic Disorder" from the Diagnostic and Statistical Manual. You do understand that these women are psycho-sexually disturbed? That their triggered state at masculinity, and their allegations of rape and pedophilia, are a form of their own sexual fantasies? It's true.
31	SEGMEEJ3TNWZ5IUEO	9	\N	segment	News Roundup and Updates	10-news-roundup-and-updates	10	06:27	None	## Notes\n\n## Description\n\n## Script\n\nWelcome to Disaffected. It's August 17, 2025 and this is the show where we talk about politics, culture, and relationships through a psychological lens. I'm Joshua Slocum. \n\nThe big focus tonight will be on the return of men and masculinity, and how feminists, women, and gays don't have to like it. We're going to look at the astonishing, but predictable, social media pile-on  that happened to none other than BillBoard Chris. Chris Elston\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEQS4B424DL1B]\n[Slug: chris-elston]\n[Description: ]\n[MediaURL: ../assets/graphics/chris-elston.png]\n<img src="../assets/graphics/chris-elston.png" width="200" />\n<!-- End Cue -->\n\nis someone you know as a Canadian father who travels the world to stop child gender mutilation. No single person man or woman has done as much or put his own safety on the line to stop this butchery than Chris. He's been assaulted countless times, and has had his arm broken by violent gender lunatics for wearing a sandwich board in public that decries the child abuse  we call "gender affirming care."\n\nAll hell broke loose online when he commented on the sissification of cheerleading in American football. Chris had the temerity to say that putting twinky gay men on cheerleading teams for NFL was, well, kind of faggy and off-putting. Suddenly, hundreds, maybe thousands of people--mainly women, but quite a few men--turned on him. They called him one of the reasons that children feel the need to transition. His homophobic, bigoted hate, they say, is why mommies are taking their little boys to get their peepees cut off. \n\nIt's a disgusting spectacle, and it's Cluster B to the core. And, it's not just some online fight on Twitter. It's the exposed edge of a conversation that has been waiting to happen for years, and we're going to have it tonight. The Western world has been so thoroughly feminized that women, gays, and suckered men move heaven and earth to teach boys to shake pom poms and live their best fabulous lives, and go apeshit berserk when men and fathers say, "Boys need to learn to be manly."\n\nWe're going to pick that scab right off and letting the bleeding begin. As the very kind of fey, artistiic sissy boy myself that these mother hens think they're protecting, you may be surprised to learn that I'm 100 percent on team Man Up, and foursquare behind men and fathers reasserting what it means to be a man. \n\nBut first, we have some updates on topics we've covered on the show in recent weeks. \n\nYou recall the video last week showing a black African on the London Underground train. He was standing there with his pants down showing his cock and balls off to everyone on the train. A couple of normal white English guys told him to cover it up or get off the train. \n\nNaturally, he chimped out and started screaming FUCK YOU FUCK YOU. Meanwhile, the normal men were saying, 'There's fookin kids about, mate." Those men took care of business. They beat some sense into him, and then they bodily through him off the train. As it should be. As a cop should have done. As no one would ever have had to do before our governments in the West deliberately brought in third world savages to destroy white Western culture. \n\nWell,  you know what's happened now, don't you? Don't you? \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJFS6N0Y6BVP]\n[Slug: vigilante-tube]\n[Description: ]\n[MediaURL: ../assets/graphics/vigilante-tube.png]\n<img src="../assets/graphics/vigilante-tube.png" width="800" />\n<!-- End Cue -->\n\nOriginally from The Independent:\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEF22TNG6F7ZS8]\n[Slug: a-group-of]\n[Description: ]\n[MediaURL: ../assets/graphics/a-group-of.png]\n<img src="../assets/graphics/a-group-of.png" width="800" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEF23DJ45GABLZ]\n[Slug: a-group-of-part]\n[Description: ]\n[MediaURL: ../assets/graphics/a-group-of-part.png]\n<img src="../assets/graphics/a-group-of-part.png" width="800" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEF23VI6WIQ8SW]\n[Slug: an-off-duty]\n[Description: ]\n[MediaURL: ../assets/graphics/an-off-duty.png]\n<img src="../assets/graphics/an-off-duty.png" width="800" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEF24QS9R6YDTF]\n[Slug: spokesperson]\n[Description: ]\n[MediaURL: ../assets/graphics/spokesperson.png]\n<img src="../assets/graphics/spokesperson.png" width="800" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEF2AE2W19MGZT]\n[Slug: the-clip]\n[Description: ]\n[MediaURL: ../assets/graphics/the-clip.png]\n<img src="../assets/graphics/the-clip.png" width="200" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: ADLIB]\n[AssetID: LOCAL-ADLIB-20250816-213201]\n[Slug: Josh talk]\n[Duration: 000100]\n<!-- End Cue -->\n\nAnd you remember how we told you about Holly, the middle-aged mom beaten almost to death by a black mob in Cincinnati at a music festival. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJG43IE9XE52]\n[Slug: holly-pictures]\n[Description: ]\n[MediaURL: ../assets/graphics/holly-pictures.png]\n<img src="../assets/graphics/holly-pictures.png" width="200" />\n<!-- End Cue -->\n\nThere are, naturally, more calls from Cincinnati's finest black leadership to. . . . prosecute the other victim.  A white man. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: CUEMEEJG6CVN16KFJ]\n[Slug: cincy-black-leaders]\n[Description: ]\n[MediaURL: ../assets/video/cincy-black-leaders.mp4]\n[Duration: 00:00:27:05]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nAs Walter remarked on Twitter:\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJG9AV3QQNDK]\n[Slug: walter-tweet]\n[Description: ]\n[MediaURL: ../assets/graphics/walter-tweet.png]\n<img src="../assets/graphics/walter-tweet.png" width="200" />\n<!-- End Cue -->\n\n-Riff a bit on waking up to the truth about race. \n\n-We're going to talk the truth about sexuality and sex roles, or "gender" if you will in the next block. \n\nEND OF BLOCK A	2025-08-17 00:00:00	None	None	None	None	\N	None	\N	production	2025-09-16 11:25:05.057383+00	2025-09-16 11:40:41.244694+00	f	## Notes\n\n## Description\n\n## Script\n\nWelcome to Disaffected. It's August 17, 2025 and this is the show where we talk about politics, culture, and relationships through a psychological lens. I'm Joshua Slocum. \n\nThe big focus tonight will be on the return of men and masculinity, and how feminists, women, and gays don't have to like it. We're going to look at the astonishing, but predictable, social media pile-on  that happened to none other than BillBoard Chris. Chris Elston\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEQS4B424DL1B]\n[Slug: chris-elston]\n[Description: ]\n[MediaURL: ../assets/graphics/chris-elston.png]\n<img src="../assets/graphics/chris-elston.png" width="200" />\n<!-- End Cue -->\n\nis someone you know as a Canadian father who travels the world to stop child gender mutilation. No single person man or woman has done as much or put his own safety on the line to stop this butchery than Chris. He's been assaulted countless times, and has had his arm broken by violent gender lunatics for wearing a sandwich board in public that decries the child abuse  we call "gender affirming care."\n\nAll hell broke loose online when he commented on the sissification of cheerleading in American football. Chris had the temerity to say that putting twinky gay men on cheerleading teams for NFL was, well, kind of faggy and off-putting. Suddenly, hundreds, maybe thousands of people--mainly women, but quite a few men--turned on him. They called him one of the reasons that children feel the need to transition. His homophobic, bigoted hate, they say, is why mommies are taking their little boys to get their peepees cut off. \n\nIt's a disgusting spectacle, and it's Cluster B to the core. And, it's not just some online fight on Twitter. It's the exposed edge of a conversation that has been waiting to happen for years, and we're going to have it tonight. The Western world has been so thoroughly feminized that women, gays, and suckered men move heaven and earth to teach boys to shake pom poms and live their best fabulous lives, and go apeshit berserk when men and fathers say, "Boys need to learn to be manly."\n\nWe're going to pick that scab right off and letting the bleeding begin. As the very kind of fey, artistiic sissy boy myself that these mother hens think they're protecting, you may be surprised to learn that I'm 100 percent on team Man Up, and foursquare behind men and fathers reasserting what it means to be a man. \n\nBut first, we have some updates on topics we've covered on the show in recent weeks. \n\nYou recall the video last week showing a black African on the London Underground train. He was standing there with his pants down showing his cock and balls off to everyone on the train. A couple of normal white English guys told him to cover it up or get off the train. \n\nNaturally, he chimped out and started screaming FUCK YOU FUCK YOU. Meanwhile, the normal men were saying, 'There's fookin kids about, mate." Those men took care of business. They beat some sense into him, and then they bodily through him off the train. As it should be. As a cop should have done. As no one would ever have had to do before our governments in the West deliberately brought in third world savages to destroy white Western culture. \n\nWell,  you know what's happened now, don't you? Don't you? \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJFS6N0Y6BVP]\n[Slug: vigilante-tube]\n[Description: ]\n[MediaURL: ../assets/graphics/vigilante-tube.png]\n<img src="../assets/graphics/vigilante-tube.png" width="800" />\n<!-- End Cue -->\n\nOriginally from The Independent:\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEF22TNG6F7ZS8]\n[Slug: a-group-of]\n[Description: ]\n[MediaURL: ../assets/graphics/a-group-of.png]\n<img src="../assets/graphics/a-group-of.png" width="800" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEF23DJ45GABLZ]\n[Slug: a-group-of-part]\n[Description: ]\n[MediaURL: ../assets/graphics/a-group-of-part.png]\n<img src="../assets/graphics/a-group-of-part.png" width="800" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEF23VI6WIQ8SW]\n[Slug: an-off-duty]\n[Description: ]\n[MediaURL: ../assets/graphics/an-off-duty.png]\n<img src="../assets/graphics/an-off-duty.png" width="800" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEF24QS9R6YDTF]\n[Slug: spokesperson]\n[Description: ]\n[MediaURL: ../assets/graphics/spokesperson.png]\n<img src="../assets/graphics/spokesperson.png" width="800" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEF2AE2W19MGZT]\n[Slug: the-clip]\n[Description: ]\n[MediaURL: ../assets/graphics/the-clip.png]\n<img src="../assets/graphics/the-clip.png" width="200" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: ADLIB]\n[AssetID: LOCAL-ADLIB-20250816-213201]\n[Slug: Josh talk]\n[Duration: 000100]\n<!-- End Cue -->\n\nAnd you remember how we told you about Holly, the middle-aged mom beaten almost to death by a black mob in Cincinnati at a music festival. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJG43IE9XE52]\n[Slug: holly-pictures]\n[Description: ]\n[MediaURL: ../assets/graphics/holly-pictures.png]\n<img src="../assets/graphics/holly-pictures.png" width="200" />\n<!-- End Cue -->\n\nThere are, naturally, more calls from Cincinnati's finest black leadership to. . . . prosecute the other victim.  A white man. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: CUEMEEJG6CVN16KFJ]\n[Slug: cincy-black-leaders]\n[Description: ]\n[MediaURL: ../assets/video/cincy-black-leaders.mp4]\n[Duration: 00:00:27:05]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nAs Walter remarked on Twitter:\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJG9AV3QQNDK]\n[Slug: walter-tweet]\n[Description: ]\n[MediaURL: ../assets/graphics/walter-tweet.png]\n<img src="../assets/graphics/walter-tweet.png" width="200" />\n<!-- End Cue -->\n\n-Riff a bit on waking up to the truth about race. \n\n-We're going to talk the truth about sexuality and sex roles, or "gender" if you will in the next block. \n\nEND OF BLOCK A
34	SEGMEEJ44L61P9LZV	9	\N	segment	Man Up	Man Up	30	1081	None	## Notes\n\n## Description\n\n## Script\n\nSociety is finally starting to wake up to the trans delusion. The Trump administration is going after hospitals that maim children with what they call "gender affirming care." More than half the states have outlawed it. The Supreme Court upheld a Tennessee law banning it as an act of child abuse. \n\nFinally, we're able to say out loud that poisoning children with hormones isn't healthful. We're now allowed to say that it's evil and insane to cut the breasts off little girls and the scrotums off little boys. We're finally able to say it's ludicrous to let fetishistic men in dresses go into the women's bathroom or play on girls' sports teams. \n\nBut there's something we're still not allowed to say. The Gender Criticals won't allow it. The Terfs won't allow it. Because feminism won't allow it. And feminism doesn't  just include those women who explicitly identify this way. It includes almost all of society, because almost everyone has imbibed feminism at a core level. That's why we can have women claiming to live in a patriarchy when it's transparently obvious that we're living in a feminized gynocracy. \n\nDo you know what we're still not allowed to say? That masculinity is good. That boys can be and should be masculine. That's not allowed. That's "homophobic" because it says something not nice about effeminate boys. That's bigoted, because it says there's a "right way to be a boy or a girl." And that can only be bigoted. \n\nGirls can do anything. They can be President. An astronaut. A girl boss.Meanwhile, boys are drugged for ADHD because feminized school systems want them to sit quietly. Men are terrified to approach young women for fear of being called "creepy." Male suicide is many times higher than for women, and white men are a lot of that. But that doesn't matter because it's men, and men are bad, and if they're lonely, maybe they should like, go therapy. Maybe they should be more like women? And then when I find I'm not turned on by sissy men I'll tell them they don't live up to my standards? \n\nBut even hint that boys and young men should develop manly qualities and the feminists and your next door neighbors start shrieking. And then they turn on good men and start abusing him. Calling him the evil one who's making little boys feel like they have to transition. Because the demand for boys to be masculine is so overwhelmingly dominant that boys are falling off the ladder left and right? \n\nNo, it isn't. And hasn't been my entire life and I'm 50. The only things encouraged in boys are feminine things. Stop being angry. Be more empathetic. Talk about your feelings more, until that gives your girl the ick, then don't do that anymore. Do more chores around the house, but also be my knight in shining armor and bring home more money from your outside job. \n\nMen have been mocked, derided, and called toxic at the cultural level  for most of my life. And it's become clear how much feminists, and many women, really do dislike or outright hate boys and masculinity. \n\nThat became clear in the reaction online to Chris Elston. You know him as Billboard Chris, the guy who travels the world where a sandwich board sign to protest the medical transing of children. He's a married father, and he's put his life on the line, and been beaten up mulitple times to do this. \n\nWell, now the very TERFs that liked him are accusing him of being a force for evil. Of spreading attitudes that make young boys want to become girls. That's right, they're pulling an abusive, Cluster B reversal and it's sick-making. \n\nAnd it's all over this. The Minnesota Vikings Football team has two new male cheerleaders the squad. Their names simply must be Lance and Bryden. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJGLF9OYQXZC]\n[Slug: male-cheerleaders]\n[Description: ]\n[MediaURL: ../assets/graphics/male-cheerleaders.png]\n<img src="../assets/graphics/male-cheerleaders.png" width="200" />\n<!-- End Cue -->\n\n. In this video, he's bouncing around in what can only be described as girlish moves. Stay with me, don't get emotional, you don't know where I'm going yet. Just take a look. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: CUEMEEJGNHIAMNDQO]\n[Slug: dance-like-girl]\n[Description: ]\n[MediaURL: ../assets/video/dance-like-girl.mp4]\n[Duration: 00:00:21:13]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nBiologist Colin Wright put up a Twitter poll:\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJGPMGOLLC0T]\n[Slug: colin-wright-poll]\n[Description: ]\n[MediaURL: ../assets/graphics/colin-wright-poll.png]\n<img src="../assets/graphics/colin-wright-poll.png" width="200" />\n<!-- End Cue -->\n\n-A tendentiously put question full of buried assumptions. The biggest one is that OK to be means "everyone must approve and those who don't approve are bigots and their lack of approval means we're not letting boys be cheerleaders." I don't think Colin and the majority of people taking his position is even dimly aware of the smuggled assumptions they operate under. And they object mightilty when that' spointed out. \n\nHere's what Billboard Chris had to say:\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJGRSTM36X2K]\n[Slug: billboard-chris-tweet]\n[Description: ]\n[MediaURL: ../assets/graphics/billboard-chris-tweet.png]\n<img src="../assets/graphics/billboard-chris-tweet.png" width="200" />\n<!-- End Cue -->\n\n-All holy hell broke loose. Hundreds of people swarmed. Some of them are people I'm friendly with on Twitter. They accused him of bigotry, of being a gender essentialist, of "not letting boys express themselves," and being one of the major reasons why boys feel they need to transition. That's right. These people turned on Chris Elston and said HE is the reason why young boys want to get their dicks chopped off. It's revolting. \n\nYou know why? Because it's not allowed to tell boys to be masculine. That is "coded" as the kids say, as "homophobic abuse," and outmoded thinking. Meanwhile, no one, no man is allowed to say "boys need to man up." The very state of masculinity is itself considered poison. Why do you think women have been feminizing boys and men for decades in the school system? I want you to really see how normal male masculinity, and no other trait, is seen as so evil and obviously so, that people don't even hear themselves. \n\nThey suddenly don't see the Munchy moms, the personality disordered bitches who medicalize their own sons. Nope. That's not the reason boys transition cough Jazz Jennings, it's men like Chris. It's men like many others online who are football fans and who don't want to ogle a mincing faggot sticking his ass up in the air on the cheer team during gay time. Women and leftie men shocked and appalled! Haters! Troglodytes. \n\nDo you see how disfavored being  a man is? Do you see how much normal, normative boyhood and manhood is called unacceptable? Are you beginning to understand, just a little tiny bit, what my alleged "issue with women" is? \n\nLet's take a tour of the online responses. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJGUC9SV6YC8]\n[Slug: john-connor-tweet]\n[Description: ]\n[MediaURL: ../assets/graphics/john-connor-tweet.png]\n<img src="../assets/graphics/john-connor-tweet.png" width="200" />\n<!-- End Cue -->\n\nGay conservative Brad Polumbo whines. Notice throughout these the smuggled assumption. Liking or advocating for masculinity in boys is bigotry. Advocating for feminity is fine. Notice this double standard throughtout. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJGWBU9O8PJZ]\n[Slug: brad-polumbo]\n[Description: ]\n[MediaURL: ../assets/graphics/brad-polumbo.png]\n<img src="../assets/graphics/brad-polumbo.png" width="200" />\n<!-- End Cue -->\n\nDetransitioner Prisha Mosley, who proceeded to totally borderline out on me as well and accuse me of "harassing women":\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJGZ5BR5TNAN]\n[Slug: prisha-mosley]\n[Description: ]\n[MediaURL: ../assets/graphics/prisha-mosley.png]\n<img src="../assets/graphics/prisha-mosley.png" width="200" />\n<!-- End Cue -->\n\nNotice in this one the other: "Let them be feminine men." It's screamed, demanded. The implication is that these poor boys are prevented from being who they are because other men say they don't like their affect. Or their theatricality. The lie is that Chris saying anything is an act against these poor boys who have NO ability to be feminine without the left protecting them. Meanwhile in the real world there is ONLY space for feminized men. It's all a reversal. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJH18K27GCUJ]\n[Slug: what-youre-saying]\n[Description: ]\n[MediaURL: ../assets/graphics/what-youre-saying.png]\n<img src="../assets/graphics/what-youre-saying.png" width="200" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJH39UTHDQPZ]\n[Slug: when-you-start]\n[Description: ]\n[MediaURL: ../assets/graphics/when-you-start.png]\n<img src="../assets/graphics/when-you-start.png" width="200" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJH5L5EJ0QLB]\n[Slug: i-couldnt-disagree]\n[Description: ]\n[MediaURL: ../assets/graphics/i-couldnt-disagree.png]\n<img src="../assets/graphics/i-couldnt-disagree.png" width="200" />\n<!-- End Cue -->\n\nIt goes on and on. Notice what they're saying. They are denying that sex roles exist. What they call gender roles are just old fashioned sex roles. The gender criticals, the gays, the feminists, they really do think we can abolish sex role expectations. It's lunatic. No society on earth made up of humans does not have sex roles. What do you think "gender critical meant." Did you forget to take it at its word? They mean it. They think they can, and should, get rid of any expecations or associations of behavior with sex. All of them. \n\nIt will never happen, but this is why the left is insane. And not just the left. When it comes to seeing masculinity as suspect, the right is just as bad. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJH851KUTI9Z]\n[Slug: this-way-of-thinking]\n[Description: ]\n[MediaURL: ../assets/graphics/this-way-of-thinking.png]\n<img src="../assets/graphics/this-way-of-thinking.png" width="200" />\n<!-- End Cue -->\n\nDawn here is typical. She's pretending to be obtuse. "What does it mean to dance like a girl." Dawn you're lying. You're not asking a question. You're making a statement: You're a bad bigoted patriarch for noticing that there are feminine and masculine behaviors." \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJHAGOJO5MHZ]\n[Slug: why-not]\n[Description: ]\n[MediaURL: ../assets/graphics/why-not.png]\n<img src="../assets/graphics/why-not.png" width="200" />\n<!-- End Cue -->\n\n"Don't ruin your fight with this" "Lol" Shame on you. Shame on you awful people for throwing Chris' good work out, more than you've done, because you hate men. And you hate boys. And you hate everything that is natural to them. Meanwhile you crave us. You crave our masculinity. You desire it sexually. Women--sort your borderline selves out. \n\nHere's another feminist bitch with the typical female monitoring of Not a good look. Pretty weird. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJHCIJ9X84QX]\n[Slug: i-kept-seeing]\n[Description: ]\n[MediaURL: ../assets/graphics/i-kept-seeing.png]\n<img src="../assets/graphics/i-kept-seeing.png" width="200" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJHEY901HMCU]\n[Slug: when-you-were]\n[Description: ]\n[MediaURL: ../assets/graphics/when-you-were.png]\n<img src="../assets/graphics/when-you-were.png" width="200" />\n<!-- End Cue -->\n\nIt goes on like this endlessly. I'm sorry to say I saw some show viewers playing this nasty game too. \n\nI jumped in to defend Chris, and, naturally, was called the same sort of bigoted but also mentally ill male oppressor. I won't bore you with it, but it included the usual accusations of internalized homophobia, misogyny, and becoming the very thing I hated. I'm a monster, like all men, really. \n\nHatred of men, boys, and masculinity bubbles along underneath everything in this culture and I'm past the point of bearing it. One man, one father, advocates for manly and masculine behavior in boys. \n\nFury erupts. Decent people, some of whom are my Twitter "friends" go apeshit. They scold him. They accuse him of causing children to trans. They throw ever dirty feminist, manipulative trick at him. \n\nThen some of them turn it on me. \n\nAll of this because *a man dared to express that he doesn't approve of sissy behavior in boys*. He might even actually care that this kind of feminization does those boys no favors. \n\nBut no. That can't be spoken. All these women and feminists and homos get to shout all goddamned day long for decades about how we have to "make space" for your stupid antics, but one man says "no, masculinity," and you lose your shit. \n\nThere has been nothing but space--all of it, everywhere, all the time--for feminized boys. Gay boys and sissies are a goddamned protected class in this country. Regular boys? Masculine boys? Straight boys? Gay boys who don't mince? There is zero space for them culturally. And it's your fault, mothers, feminists, and absent, gelded fathers.\n\nThis topic exercises me; it’s pretty much a new frontier in the change of public discourse: that masculinity is almost universally “recognized” as a state of sin, a state of innate hostility and danger. Almost everyone believes this, even when they say and believe that they don’t believe it.\n\nThey do. The _merest_ mention of the ideas “boys ought not dance like girls on the Minnesota Vikings cheerleading squad” is met with shock and abuse. Accusations of “misogyny,” of “homophobia,” of “attitudes like yours are why these kids think they need to trans.” Men are not allowed, ever, under any circumstances, to ever object to sissying up boys. Why, that’s abusive. We have to make _even more space for sissy boys, encourage more sissiness and faggotry, because that means we reaaa-weeeee wuv them.”  \n  \n*Meanwhile society has space for no men who aren’t sissies. And this isn’t about gay or straight—none of us men who talk like men and insist on _being* men, however we may fail in the ways we do—we all get called toxic. Misogynist. Why trans kids happened.  \n  \nUngrateful. Abusive\n\nIt is loathsome, and it’s common. I’m seeing people online I like and respect and my eyes are goggling. \n\nAs a boy, I had no father. Mine left my mother before I was born.\n\nAt three years old, she hooked up with my stepfather, then married him. He was a violent abuser. He concussed me, beat me, beat my mother, and molested his own daughter, my sister.\n\nAgainst this backdrop was my abusive mother, the woman with borderline and narcissistic personality disorders. She vacillated between mocking and humiliating me for "being soft; no girl will ever want you, and you're going to turn out like every other piece of shit man like your father" and treating me like a golden prince, "You're so handsome all the girls will go for you."\n\nI didn't know if I was coming or going.\n\nHaving no father, I never learned to fight. I didn't learn how to defend myself. I didn't even learn how to walk like a man, talk like a man, or take responsibility for myself like a man.\n\nInstead, I learned to cry. To panic. To dissolve in tears of frustration, and then to scream to get my way. I learned to be a feminine borderline, like my mother.\n\nEvery normal, masculine man or boy I met I feared. I believed men were born innately evil and abusive (think how that affects a boy child's view of himself). When I did get pushed around or picked on for being a homo, I was terrified. And I exaggerated the bullying to a hysterical degree.\n\nBut most normal boys rejected me because, well, normal people can smell the freak on you (you may call it ‘trauma’ if that’s more palatable) and they could smell it on me. I had almost no friends until middle school when I suddenly “became funny” and found some popularity or acceptance for the first time in my life.\n\nI became a histrionic. An entertainer. I had a power no one else did. I couldn’t throw a football, but I could cast a spell on a room. Hey, it does me pretty well today to keep people entertained. But it’s definitively an adaptive behavior as a response to abuse. I would have been better off at least learning to throw the football, too.\n\nIf I'd known how to hold my own and throw the punches back, I would have been even better off.\n\nUntil my 40s, I thought I wasn't part of the male sex, not really. All straight men hated sissies like me, I thought, and would kill me if they could. It's deranged, but this is the mindset of so many guys like me.\n\nWhat I needed was a male role model. I needed to learn to be a man. That didn't need to mean I'd turn into a football jock. Society has always had a place for bookish, intellectual men--and that's a path I could have taken respectably. It didn't have to mean being a feminized, histrionic mess.\n\nBut I didn't have that. Millions of boys don't.\n\nAnd I removed myself from the society of men, not realizing that I was part of them. That most of them didn't hate me. That they, and I, all being men, could be friends and share men's business.\n\nAs gay rights became "the thing," society hug-boxed me. Women especially. I "leaned in" to being a victim, into seeking out maternal love and approval from women friends, into performing "gay best friend" for them.\n\nI turned into a stereoptypical pocket pansy.\n\nI’m not a “gay man” anymore. Not in any way that’s fundamental to who I am. Not in the way you inevitably hear when a guy describes himself that way. I am a man, and I am also a homosexual. Yeah, I’m shaped by my past and I’m definitely “gay” in that way. I like to put on camp humor. I’m a 20th century gay, and it’s fun. But I’m not a sissy, not anymore. And there is no dignity in sissyhood. That’s why it’s a popular BDSM fetish for God’s sake.\n\nDo you want this for your sons? For your neighbors' sons? For the boys you claim to care about?\n\nHave you ever thought about this?\n\nDon’t mistake me please; I’m not asking for your sympathy. I’m not wallowing in victimhood, or presenting myself to you as a victim. I’m trying to tell you a truth that pertains to many more gay men than me personally. I hope you’ll want to understand that point of view.\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJHIMKMC68FC]\n[Slug: if-it-was]\n[Description: ]\n[MediaURL: ../assets/graphics/if-it-was.png]\n<img src="../assets/graphics/if-it-was.png" width="200" />\n<!-- End Cue -->	2025-08-17 00:00:00	None	None	None	None	\N	None	\N	production	2025-09-16 11:25:05.066923+00	2025-09-16 11:40:41.244694+00	f	## Notes\n\n## Description\n\n## Script\n\nSociety is finally starting to wake up to the trans delusion. The Trump administration is going after hospitals that maim children with what they call "gender affirming care." More than half the states have outlawed it. The Supreme Court upheld a Tennessee law banning it as an act of child abuse. \n\nFinally, we're able to say out loud that poisoning children with hormones isn't healthful. We're now allowed to say that it's evil and insane to cut the breasts off little girls and the scrotums off little boys. We're finally able to say it's ludicrous to let fetishistic men in dresses go into the women's bathroom or play on girls' sports teams. \n\nBut there's something we're still not allowed to say. The Gender Criticals won't allow it. The Terfs won't allow it. Because feminism won't allow it. And feminism doesn't  just include those women who explicitly identify this way. It includes almost all of society, because almost everyone has imbibed feminism at a core level. That's why we can have women claiming to live in a patriarchy when it's transparently obvious that we're living in a feminized gynocracy. \n\nDo you know what we're still not allowed to say? That masculinity is good. That boys can be and should be masculine. That's not allowed. That's "homophobic" because it says something not nice about effeminate boys. That's bigoted, because it says there's a "right way to be a boy or a girl." And that can only be bigoted. \n\nGirls can do anything. They can be President. An astronaut. A girl boss.Meanwhile, boys are drugged for ADHD because feminized school systems want them to sit quietly. Men are terrified to approach young women for fear of being called "creepy." Male suicide is many times higher than for women, and white men are a lot of that. But that doesn't matter because it's men, and men are bad, and if they're lonely, maybe they should like, go therapy. Maybe they should be more like women? And then when I find I'm not turned on by sissy men I'll tell them they don't live up to my standards? \n\nBut even hint that boys and young men should develop manly qualities and the feminists and your next door neighbors start shrieking. And then they turn on good men and start abusing him. Calling him the evil one who's making little boys feel like they have to transition. Because the demand for boys to be masculine is so overwhelmingly dominant that boys are falling off the ladder left and right? \n\nNo, it isn't. And hasn't been my entire life and I'm 50. The only things encouraged in boys are feminine things. Stop being angry. Be more empathetic. Talk about your feelings more, until that gives your girl the ick, then don't do that anymore. Do more chores around the house, but also be my knight in shining armor and bring home more money from your outside job. \n\nMen have been mocked, derided, and called toxic at the cultural level  for most of my life. And it's become clear how much feminists, and many women, really do dislike or outright hate boys and masculinity. \n\nThat became clear in the reaction online to Chris Elston. You know him as Billboard Chris, the guy who travels the world where a sandwich board sign to protest the medical transing of children. He's a married father, and he's put his life on the line, and been beaten up mulitple times to do this. \n\nWell, now the very TERFs that liked him are accusing him of being a force for evil. Of spreading attitudes that make young boys want to become girls. That's right, they're pulling an abusive, Cluster B reversal and it's sick-making. \n\nAnd it's all over this. The Minnesota Vikings Football team has two new male cheerleaders the squad. Their names simply must be Lance and Bryden. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJGLF9OYQXZC]\n[Slug: male-cheerleaders]\n[Description: ]\n[MediaURL: ../assets/graphics/male-cheerleaders.png]\n<img src="../assets/graphics/male-cheerleaders.png" width="200" />\n<!-- End Cue -->\n\n. In this video, he's bouncing around in what can only be described as girlish moves. Stay with me, don't get emotional, you don't know where I'm going yet. Just take a look. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: CUEMEEJGNHIAMNDQO]\n[Slug: dance-like-girl]\n[Description: ]\n[MediaURL: ../assets/video/dance-like-girl.mp4]\n[Duration: 00:00:21:13]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nBiologist Colin Wright put up a Twitter poll:\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJGPMGOLLC0T]\n[Slug: colin-wright-poll]\n[Description: ]\n[MediaURL: ../assets/graphics/colin-wright-poll.png]\n<img src="../assets/graphics/colin-wright-poll.png" width="200" />\n<!-- End Cue -->\n\n-A tendentiously put question full of buried assumptions. The biggest one is that OK to be means "everyone must approve and those who don't approve are bigots and their lack of approval means we're not letting boys be cheerleaders." I don't think Colin and the majority of people taking his position is even dimly aware of the smuggled assumptions they operate under. And they object mightilty when that' spointed out. \n\nHere's what Billboard Chris had to say:\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJGRSTM36X2K]\n[Slug: billboard-chris-tweet]\n[Description: ]\n[MediaURL: ../assets/graphics/billboard-chris-tweet.png]\n<img src="../assets/graphics/billboard-chris-tweet.png" width="200" />\n<!-- End Cue -->\n\n-All holy hell broke loose. Hundreds of people swarmed. Some of them are people I'm friendly with on Twitter. They accused him of bigotry, of being a gender essentialist, of "not letting boys express themselves," and being one of the major reasons why boys feel they need to transition. That's right. These people turned on Chris Elston and said HE is the reason why young boys want to get their dicks chopped off. It's revolting. \n\nYou know why? Because it's not allowed to tell boys to be masculine. That is "coded" as the kids say, as "homophobic abuse," and outmoded thinking. Meanwhile, no one, no man is allowed to say "boys need to man up." The very state of masculinity is itself considered poison. Why do you think women have been feminizing boys and men for decades in the school system? I want you to really see how normal male masculinity, and no other trait, is seen as so evil and obviously so, that people don't even hear themselves. \n\nThey suddenly don't see the Munchy moms, the personality disordered bitches who medicalize their own sons. Nope. That's not the reason boys transition cough Jazz Jennings, it's men like Chris. It's men like many others online who are football fans and who don't want to ogle a mincing faggot sticking his ass up in the air on the cheer team during gay time. Women and leftie men shocked and appalled! Haters! Troglodytes. \n\nDo you see how disfavored being  a man is? Do you see how much normal, normative boyhood and manhood is called unacceptable? Are you beginning to understand, just a little tiny bit, what my alleged "issue with women" is? \n\nLet's take a tour of the online responses. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJGUC9SV6YC8]\n[Slug: john-connor-tweet]\n[Description: ]\n[MediaURL: ../assets/graphics/john-connor-tweet.png]\n<img src="../assets/graphics/john-connor-tweet.png" width="200" />\n<!-- End Cue -->\n\nGay conservative Brad Polumbo whines. Notice throughout these the smuggled assumption. Liking or advocating for masculinity in boys is bigotry. Advocating for feminity is fine. Notice this double standard throughtout. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJGWBU9O8PJZ]\n[Slug: brad-polumbo]\n[Description: ]\n[MediaURL: ../assets/graphics/brad-polumbo.png]\n<img src="../assets/graphics/brad-polumbo.png" width="200" />\n<!-- End Cue -->\n\nDetransitioner Prisha Mosley, who proceeded to totally borderline out on me as well and accuse me of "harassing women":\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJGZ5BR5TNAN]\n[Slug: prisha-mosley]\n[Description: ]\n[MediaURL: ../assets/graphics/prisha-mosley.png]\n<img src="../assets/graphics/prisha-mosley.png" width="200" />\n<!-- End Cue -->\n\nNotice in this one the other: "Let them be feminine men." It's screamed, demanded. The implication is that these poor boys are prevented from being who they are because other men say they don't like their affect. Or their theatricality. The lie is that Chris saying anything is an act against these poor boys who have NO ability to be feminine without the left protecting them. Meanwhile in the real world there is ONLY space for feminized men. It's all a reversal. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJH18K27GCUJ]\n[Slug: what-youre-saying]\n[Description: ]\n[MediaURL: ../assets/graphics/what-youre-saying.png]\n<img src="../assets/graphics/what-youre-saying.png" width="200" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJH39UTHDQPZ]\n[Slug: when-you-start]\n[Description: ]\n[MediaURL: ../assets/graphics/when-you-start.png]\n<img src="../assets/graphics/when-you-start.png" width="200" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJH5L5EJ0QLB]\n[Slug: i-couldnt-disagree]\n[Description: ]\n[MediaURL: ../assets/graphics/i-couldnt-disagree.png]\n<img src="../assets/graphics/i-couldnt-disagree.png" width="200" />\n<!-- End Cue -->\n\nIt goes on and on. Notice what they're saying. They are denying that sex roles exist. What they call gender roles are just old fashioned sex roles. The gender criticals, the gays, the feminists, they really do think we can abolish sex role expectations. It's lunatic. No society on earth made up of humans does not have sex roles. What do you think "gender critical meant." Did you forget to take it at its word? They mean it. They think they can, and should, get rid of any expecations or associations of behavior with sex. All of them. \n\nIt will never happen, but this is why the left is insane. And not just the left. When it comes to seeing masculinity as suspect, the right is just as bad. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJH851KUTI9Z]\n[Slug: this-way-of-thinking]\n[Description: ]\n[MediaURL: ../assets/graphics/this-way-of-thinking.png]\n<img src="../assets/graphics/this-way-of-thinking.png" width="200" />\n<!-- End Cue -->\n\nDawn here is typical. She's pretending to be obtuse. "What does it mean to dance like a girl." Dawn you're lying. You're not asking a question. You're making a statement: You're a bad bigoted patriarch for noticing that there are feminine and masculine behaviors." \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJHAGOJO5MHZ]\n[Slug: why-not]\n[Description: ]\n[MediaURL: ../assets/graphics/why-not.png]\n<img src="../assets/graphics/why-not.png" width="200" />\n<!-- End Cue -->\n\n"Don't ruin your fight with this" "Lol" Shame on you. Shame on you awful people for throwing Chris' good work out, more than you've done, because you hate men. And you hate boys. And you hate everything that is natural to them. Meanwhile you crave us. You crave our masculinity. You desire it sexually. Women--sort your borderline selves out. \n\nHere's another feminist bitch with the typical female monitoring of Not a good look. Pretty weird. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJHCIJ9X84QX]\n[Slug: i-kept-seeing]\n[Description: ]\n[MediaURL: ../assets/graphics/i-kept-seeing.png]\n<img src="../assets/graphics/i-kept-seeing.png" width="200" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJHEY901HMCU]\n[Slug: when-you-were]\n[Description: ]\n[MediaURL: ../assets/graphics/when-you-were.png]\n<img src="../assets/graphics/when-you-were.png" width="200" />\n<!-- End Cue -->\n\nIt goes on like this endlessly. I'm sorry to say I saw some show viewers playing this nasty game too. \n\nI jumped in to defend Chris, and, naturally, was called the same sort of bigoted but also mentally ill male oppressor. I won't bore you with it, but it included the usual accusations of internalized homophobia, misogyny, and becoming the very thing I hated. I'm a monster, like all men, really. \n\nHatred of men, boys, and masculinity bubbles along underneath everything in this culture and I'm past the point of bearing it. One man, one father, advocates for manly and masculine behavior in boys. \n\nFury erupts. Decent people, some of whom are my Twitter "friends" go apeshit. They scold him. They accuse him of causing children to trans. They throw ever dirty feminist, manipulative trick at him. \n\nThen some of them turn it on me. \n\nAll of this because *a man dared to express that he doesn't approve of sissy behavior in boys*. He might even actually care that this kind of feminization does those boys no favors. \n\nBut no. That can't be spoken. All these women and feminists and homos get to shout all goddamned day long for decades about how we have to "make space" for your stupid antics, but one man says "no, masculinity," and you lose your shit. \n\nThere has been nothing but space--all of it, everywhere, all the time--for feminized boys. Gay boys and sissies are a goddamned protected class in this country. Regular boys? Masculine boys? Straight boys? Gay boys who don't mince? There is zero space for them culturally. And it's your fault, mothers, feminists, and absent, gelded fathers.\n\nThis topic exercises me; it’s pretty much a new frontier in the change of public discourse: that masculinity is almost universally “recognized” as a state of sin, a state of innate hostility and danger. Almost everyone believes this, even when they say and believe that they don’t believe it.\n\nThey do. The _merest_ mention of the ideas “boys ought not dance like girls on the Minnesota Vikings cheerleading squad” is met with shock and abuse. Accusations of “misogyny,” of “homophobia,” of “attitudes like yours are why these kids think they need to trans.” Men are not allowed, ever, under any circumstances, to ever object to sissying up boys. Why, that’s abusive. We have to make _even more space for sissy boys, encourage more sissiness and faggotry, because that means we reaaa-weeeee wuv them.”  \n  \n*Meanwhile society has space for no men who aren’t sissies. And this isn’t about gay or straight—none of us men who talk like men and insist on _being* men, however we may fail in the ways we do—we all get called toxic. Misogynist. Why trans kids happened.  \n  \nUngrateful. Abusive\n\nIt is loathsome, and it’s common. I’m seeing people online I like and respect and my eyes are goggling. \n\nAs a boy, I had no father. Mine left my mother before I was born.\n\nAt three years old, she hooked up with my stepfather, then married him. He was a violent abuser. He concussed me, beat me, beat my mother, and molested his own daughter, my sister.\n\nAgainst this backdrop was my abusive mother, the woman with borderline and narcissistic personality disorders. She vacillated between mocking and humiliating me for "being soft; no girl will ever want you, and you're going to turn out like every other piece of shit man like your father" and treating me like a golden prince, "You're so handsome all the girls will go for you."\n\nI didn't know if I was coming or going.\n\nHaving no father, I never learned to fight. I didn't learn how to defend myself. I didn't even learn how to walk like a man, talk like a man, or take responsibility for myself like a man.\n\nInstead, I learned to cry. To panic. To dissolve in tears of frustration, and then to scream to get my way. I learned to be a feminine borderline, like my mother.\n\nEvery normal, masculine man or boy I met I feared. I believed men were born innately evil and abusive (think how that affects a boy child's view of himself). When I did get pushed around or picked on for being a homo, I was terrified. And I exaggerated the bullying to a hysterical degree.\n\nBut most normal boys rejected me because, well, normal people can smell the freak on you (you may call it ‘trauma’ if that’s more palatable) and they could smell it on me. I had almost no friends until middle school when I suddenly “became funny” and found some popularity or acceptance for the first time in my life.\n\nI became a histrionic. An entertainer. I had a power no one else did. I couldn’t throw a football, but I could cast a spell on a room. Hey, it does me pretty well today to keep people entertained. But it’s definitively an adaptive behavior as a response to abuse. I would have been better off at least learning to throw the football, too.\n\nIf I'd known how to hold my own and throw the punches back, I would have been even better off.\n\nUntil my 40s, I thought I wasn't part of the male sex, not really. All straight men hated sissies like me, I thought, and would kill me if they could. It's deranged, but this is the mindset of so many guys like me.\n\nWhat I needed was a male role model. I needed to learn to be a man. That didn't need to mean I'd turn into a football jock. Society has always had a place for bookish, intellectual men--and that's a path I could have taken respectably. It didn't have to mean being a feminized, histrionic mess.\n\nBut I didn't have that. Millions of boys don't.\n\nAnd I removed myself from the society of men, not realizing that I was part of them. That most of them didn't hate me. That they, and I, all being men, could be friends and share men's business.\n\nAs gay rights became "the thing," society hug-boxed me. Women especially. I "leaned in" to being a victim, into seeking out maternal love and approval from women friends, into performing "gay best friend" for them.\n\nI turned into a stereoptypical pocket pansy.\n\nI’m not a “gay man” anymore. Not in any way that’s fundamental to who I am. Not in the way you inevitably hear when a guy describes himself that way. I am a man, and I am also a homosexual. Yeah, I’m shaped by my past and I’m definitely “gay” in that way. I like to put on camp humor. I’m a 20th century gay, and it’s fun. But I’m not a sissy, not anymore. And there is no dignity in sissyhood. That’s why it’s a popular BDSM fetish for God’s sake.\n\nDo you want this for your sons? For your neighbors' sons? For the boys you claim to care about?\n\nHave you ever thought about this?\n\nDon’t mistake me please; I’m not asking for your sympathy. I’m not wallowing in victimhood, or presenting myself to you as a victim. I’m trying to tell you a truth that pertains to many more gay men than me personally. I hope you’ll want to understand that point of view.\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJHIMKMC68FC]\n[Slug: if-it-was]\n[Description: ]\n[MediaURL: ../assets/graphics/if-it-was.png]\n<img src="../assets/graphics/if-it-was.png" width="200" />\n<!-- End Cue -->
35	SEGMEEOBAPUJXSG4D	9	\N	advertisement	Disaffected.com One-time Dono	40-support-disaffected.com	40	00:01:00	None	<!-- Begin Cue -->\n[Type: ADLIB]\n[AssetID: CUEMEENDH3XSJ7GMN]\n[Slug: Support Disaffected.com]\n[Duration: 00:01:00 ]\n<!-- End Cue -->\n\n[^1]:	\N	None	None	None	None	\N	medium	\N	production	2025-09-16 11:25:05.066923+00	2025-09-16 11:40:41.244694+00	f	<!-- Begin Cue -->\n[Type: ADLIB]\n[AssetID: CUEMEENDH3XSJ7GMN]\n[Slug: Support Disaffected.com]\n[Duration: 00:01:00 ]\n<!-- End Cue -->\n\n[^1]:
136	SEGMG07QPJATJFWKM	19	\N	segment	Segment	segment	80	00:00:00:00			\N		\N		\N	\N		\N	draft	2025-09-26 02:18:50.950701+00	2025-09-26 20:42:27.640878+00	f	
144	SEGMG0VFQLOBDBV09	19	\N	ad	Advertisement	advertisement	40	00:00:00:00			\N		\N		\N	\N		\N	draft	2025-09-26 13:22:09.900888+00	2025-09-26 20:42:27.639172+00	f	
147	SEGMG0WEIKVI08246	19	\N	segment	Segment	segment	120	00:00:00:00			\N		\N		\N	\N		\N	draft	2025-09-26 13:49:12.463852+00	2025-09-26 20:42:27.642577+00	f	
14	SEGMF8N5M6S8UWA0E	4	\N	segment	Beatrix Potter Fantasy	beatrix-potter	40	00:08:00	Childrens literature analysis	## Notes\nCultural commentary on children's literature and its role in identity formation and fantasy development.\n\n## Description\nAnalysis of Beatrix Potter's work and its cultural significance in childhood development and identity formation.\n\n## Script  \n**Media Elements Referenced:**\n- {GFX/toads} → 1 toads.png\n- {SOT/frog-song} → frog song.mp4\n\n**Script Content:**\nMoving into our Beatrix Potter fantasy segment, we explore how children's literature shapes identity and provides frameworks for understanding the world.\n\nThe anthropomorphic characters in Potter's work - Peter Rabbit, Jemima Puddle-Duck, Mrs. Tiggy-Winkle - offer children models for behavior, consequence, and moral development.\n\n[Full segment content from original script lines 163-178]	2025-09-07 00:00:00		Beatrix Potter works, children literature analysis	beatrix potter, children, literature, fantasy, identity	Generated for episode 0239 segmentation	\N	medium	\N	draft	2025-09-16 11:15:55.200852+00	2025-09-16 17:32:25.484368+00	f	## Notes\nCultural commentary on children's literature and its role in identity formation and fantasy development.\n\n## Description\nAnalysis of Beatrix Potter's work and its cultural significance in childhood development and identity formation.\n\n## Script  \n**Media Elements Referenced:**\n- {GFX/toads} → 1 toads.png\n- {SOT/frog-song} → frog song.mp4\n\n**Script Content:**\nMoving into our Beatrix Potter fantasy segment, we explore how children's literature shapes identity and provides frameworks for understanding the world.\n\nThe anthropomorphic characters in Potter's work - Peter Rabbit, Jemima Puddle-Duck, Mrs. Tiggy-Winkle - offer children models for behavior, consequence, and moral development.\n\n[Full segment content from original script lines 163-178]
19	ASTMFJZF6Z67H8XAD	6	\N	segment	071 Tease	intro tease	20	00:00:00		## Notes\n\n## Description\n\n## Script\n\nTonight's show is heavy and graphic. We are not censoring video footage of murders; You're going to see Charlie Kirk murdered, and you're going to see Iryna Zarutska murdered. \n\nThey did not "pass," as too many conservative millennials like to say. They were brutally murdered and blood gushed out of them so fast that they had only seconds of consciousness left. America needs to see the truth of what's happening. I want you to know what you're going to see if you stay with us.\n\nThis episode is one I don't want to make but that we have to make. The murders of Ukrainian refugee Iryna Zarutska by a black man who boasted about getting the white girl, and the murder of a truly godly man named Charlie Kirk by a lunatic leftist with a transgender "partner" do constitute an actual turning point. \n\nIt wasn't these brutal murders that demonstrate that turning point. It was the reaction of the left, the media, and much of the public that made this a turning point. The demonic gloating, the joy, the erotic frisson, the grave dancing in public–all of these are more sick-making than the murders themselves because they make the soul despair. We need to face this Satanic ugliness straight on and we're going to do it tonight. \n\nMany Americans realized this week for the first time who their friends, families, and coworkers really are. They should have realized it during the alleged pandemic. They should have realized it when their wives and husbands celebrated the assassination attempts on President Trump last year. \n\nBut they didn't. They continued their denial until this week. Now they know, now maybe you know, that their own families would happily see them dead. \n\nWelcome to being a Democrat and a liberal in 2025. Yes. A liberal. No, I won't stop saying liberal. I won't qualify it. I won't say "leftist, not liberal. \n\nNo, audience. No. This is liberalism. Pre-emptively: shut up if you're getting twisted about it. Shut up. Direct your anger at the devils around you, not at me. They're the ones who will see you dead. Not me. \n\nYou go out and rebuild your reputation and rebuild the respectability aroudn the word liberal. It's not my job and you had better not try to make it my job. \n\nAnd yeah, we are going to talk about the shooter's parents. That includes his mother. We are going to identify patterns, speculate, and raise serious questions. That conversation is going to happen. \n\nI'm sick in my soul this week. This episode is harder than any I've done yet. \n\nI'm Joshua Slocum and this is Disaffected.  The show that ....  \n\nWhen we come back after the break, its going to be dark.  Its going to be graphic.  Tonight, I'm not going to spare you.  \n\nThis has been your warning.	\N				2025-09-14T17:41:37.938343: Generated server AssetID ASTMFJZF6Z67H8XAD via rundown item creation	\N		\N	production	2025-09-16 11:22:50.755516+00	2025-09-16 11:40:41.295386+00	f	## Notes\n\n## Description\n\n## Script\n\nTonight's show is heavy and graphic. We are not censoring video footage of murders; You're going to see Charlie Kirk murdered, and you're going to see Iryna Zarutska murdered. \n\nThey did not "pass," as too many conservative millennials like to say. They were brutally murdered and blood gushed out of them so fast that they had only seconds of consciousness left. America needs to see the truth of what's happening. I want you to know what you're going to see if you stay with us.\n\nThis episode is one I don't want to make but that we have to make. The murders of Ukrainian refugee Iryna Zarutska by a black man who boasted about getting the white girl, and the murder of a truly godly man named Charlie Kirk by a lunatic leftist with a transgender "partner" do constitute an actual turning point. \n\nIt wasn't these brutal murders that demonstrate that turning point. It was the reaction of the left, the media, and much of the public that made this a turning point. The demonic gloating, the joy, the erotic frisson, the grave dancing in public–all of these are more sick-making than the murders themselves because they make the soul despair. We need to face this Satanic ugliness straight on and we're going to do it tonight. \n\nMany Americans realized this week for the first time who their friends, families, and coworkers really are. They should have realized it during the alleged pandemic. They should have realized it when their wives and husbands celebrated the assassination attempts on President Trump last year. \n\nBut they didn't. They continued their denial until this week. Now they know, now maybe you know, that their own families would happily see them dead. \n\nWelcome to being a Democrat and a liberal in 2025. Yes. A liberal. No, I won't stop saying liberal. I won't qualify it. I won't say "leftist, not liberal. \n\nNo, audience. No. This is liberalism. Pre-emptively: shut up if you're getting twisted about it. Shut up. Direct your anger at the devils around you, not at me. They're the ones who will see you dead. Not me. \n\nYou go out and rebuild your reputation and rebuild the respectability aroudn the word liberal. It's not my job and you had better not try to make it my job. \n\nAnd yeah, we are going to talk about the shooter's parents. That includes his mother. We are going to identify patterns, speculate, and raise serious questions. That conversation is going to happen. \n\nI'm sick in my soul this week. This episode is harder than any I've done yet. \n\nI'm Joshua Slocum and this is Disaffected.  The show that ....  \n\nWhen we come back after the break, its going to be dark.  Its going to be graphic.  Tonight, I'm not going to spare you.  \n\nThis has been your warning.
23	ASTMFJSG4BT913KEO	6	\N	break	Break	break	90	00:00:00		## Notes\n\n## Description\n\n## Script\n\n<!-- Begin Cue -->\n[Type: BREAK]\n[Slug: break]\n[AssetID: ASTMFJSG4BT913KEO]\n<!-- End Cue -->	\N				2025-09-14T14:26:23.849066: Generated server AssetID ASTMFJSG4BT913KEO via rundown item creation	\N		\N	production	2025-09-16 11:22:50.764656+00	2025-09-16 11:40:41.295386+00	f	## Notes\n\n## Description\n\n## Script\n\n<!-- Begin Cue -->\n[Type: BREAK]\n[Slug: break]\n[AssetID: ASTMFJSG4BT913KEO]\n<!-- End Cue -->
135	SEGMG07QKGSJDXE0C	19	\N	tease	Untitled		140	00:00:00:00			\N		\N		\N	\N		\N	draft	2025-09-26 02:18:44.380672+00	2025-09-26 20:42:27.643489+00	f	
148	SEGMG0WF4HYVUR6S2	19	\N	cta	Call to Action	call-to-action	150	00:00:00:00			\N		\N		\N	\N		\N	draft	2025-09-26 13:49:40.870684+00	2025-09-26 20:42:27.643949+00	f	
137	SEGMG0QGHBVTJ0XXX	19	\N	promo	Promo	promo	100	00:00:00:00			\N		\N		\N	\N		\N	draft	2025-09-26 11:02:46.459376+00	2025-09-26 20:42:27.641745+00	f	
141	SEGMG0U4SD873S87L	19	\N	ad	Advertisement	advertisement	160	00:00:00:00			\N		\N		\N	\N		\N	draft	2025-09-26 12:45:39.356426+00	2025-09-26 20:42:27.644409+00	f	
39	SEGMEEJ5H1D9I4K1D	9	\N	segment	Potpourri Du Moquerie	60-potpourri-du-moquerie	60	00:12	None	## Notes\n\n## Description\n\n## Script\n\nRetards\n\nLet's go back to a public service announcement from 1980. Hey Gen Z---get your anxiety fidget toys. The olds are gonna say bad things? \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: CUEMEEPQ1XNB587ME]\n[Slug: retarded-neighbors]\n[Description: ]\n[MediaURL: ../assets/video/retarded-neighbors.mp4]\n[Duration: 00:00:20:17]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJJ87VW7XCBR]\n[Slug: cookie-dough]\n[Description: ]\n[MediaURL: ../assets/graphics/cookie-dough.png]\n<img src="../assets/graphics/cookie-dough.png" width="200" />\n<!-- End Cue -->\n\nThat's the show-goodnight!	2025-08-17 00:00:00	None	None	None	None	\N	None	\N	production	2025-09-16 11:25:05.073322+00	2025-09-16 11:40:41.244694+00	f	## Notes\n\n## Description\n\n## Script\n\nRetards\n\nLet's go back to a public service announcement from 1980. Hey Gen Z---get your anxiety fidget toys. The olds are gonna say bad things? \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: CUEMEEPQ1XNB587ME]\n[Slug: retarded-neighbors]\n[Description: ]\n[MediaURL: ../assets/video/retarded-neighbors.mp4]\n[Duration: 00:00:20:17]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJJ87VW7XCBR]\n[Slug: cookie-dough]\n[Description: ]\n[MediaURL: ../assets/graphics/cookie-dough.png]\n<img src="../assets/graphics/cookie-dough.png" width="200" />\n<!-- End Cue -->\n\nThat's the show-goodnight!
37	ASTMFMGUNJI53Q3M9	9	\N	break	45 Break	45-break	45	00:05:00	None	<!-- Begin Cue -->\n[Type: Break]\n[AssetID: BREAK45001]\n[Slug: break]\n<!-- End Cue -->	\N	None	None	None	None	\N	None	\N	production	2025-09-16 11:25:05.073322+00	2025-09-16 11:40:41.244694+00	f	<!-- Begin Cue -->\n[Type: Break]\n[AssetID: BREAK45001]\n[Slug: break]\n<!-- End Cue -->
36	SEGMEENCPXQ375N35	9	\N	segment	Slocum Consulting	41-slocum-consulting	41	01:00	None	<!-- Begin Cue -->\n[Type: ADLIB]\n[AssetID: CUEMEEND27OHTCFXG]\n[Slug: Support Disaffected.com]\n[Duration: 00:01:00 ]\n<!-- End Cue -->	\N	None	None	None	None	\N	None	\N	production	2025-09-16 11:25:05.066923+00	2025-09-16 11:40:41.244694+00	f	<!-- Begin Cue -->\n[Type: ADLIB]\n[AssetID: CUEMEEND27OHTCFXG]\n[Slug: Support Disaffected.com]\n[Duration: 00:01:00 ]\n<!-- End Cue -->
32	SEGMEEJ3YD0OKZM7D	9	\N	advertisement	20 Biltong	20-biltong	20	00:30	None	<!-- Begin Cue -->\n[Type: ADLIB]\n[AssetID: CUEMEENDM8FGBUPV8]\n[Slug: biltong adlib]\n[Duration: 00:00:30 ]\n<!-- End Cue -->	\N	None	None	None	None	\N	None	\N	production	2025-09-16 11:25:05.057383+00	2025-09-16 11:40:41.244694+00	f	<!-- Begin Cue -->\n[Type: ADLIB]\n[AssetID: CUEMEENDM8FGBUPV8]\n[Slug: biltong adlib]\n[Duration: 00:00:30 ]\n<!-- End Cue -->
13	BRKM8N4L5R7TZV9D	4	\N	break	Support Break	support-promo	30	00:03:00	Support and consulting promos	## Notes\nMid-show break featuring support promos and advertisements.\n\n## Description\nBreak segment featuring Biltong promotion and Slocum Consulting advertisement.\n\n## Script\n**BILTONG WITHIN BLOCK TO TAKE US OUT TO BREAK**\n\n**BREAK**\n—Support Us\n—Slocum Consulting\n\n[Break content from original script lines 154-160]	2025-09-07 00:00:00		Biltong promo, Slocum Consulting promo	break, promo, support, consulting, biltong	Generated for episode 0239 segmentation	\N	medium	\N	draft	2025-09-16 11:15:55.200852+00	2025-09-16 17:32:25.481758+00	f	## Notes\nMid-show break featuring support promos and advertisements.\n\n## Description\nBreak segment featuring Biltong promotion and Slocum Consulting advertisement.\n\n## Script\n**BILTONG WITHIN BLOCK TO TAKE US OUT TO BREAK**\n\n**BREAK**\n—Support Us\n—Slocum Consulting\n\n[Break content from original script lines 154-160]
18	ASTMFJRV616ICH14B	6	\N	coldopen	Cold Open	show-cold-open	10	00:00:45		## Notes\n\n## Description\n\n## Script	\N				2025-09-14T14:10:06.282534: Generated server AssetID ASTMFJRV616ICH14B via rundown item creation	\N		\N	draft	2025-09-16 11:22:50.755516+00	2025-09-16 11:40:41.295386+00	f	## Notes\n\n## Description\n\n## Script
22	ASTMFJSIFMFRY2KJB	6	\N	segment	041 Tease	050-tease-041-tease	50	00:00:00		## Notes\n\n## Description\n\n## Script\n\nWhen we come back we're going to go even further through the looking glass.\n\nWe're going to take an uncomfortably close look at the relationship between the assassin - and his mother.  \n\nPut you predictions on a postcard.. \n\nwe'll be right back.	\N				2025-09-14T14:28:11.799145: Generated server AssetID ASTMFJSIFMFRY2KJB via rundown item creation	\N		\N	production	2025-09-16 11:22:50.764656+00	2025-09-16 11:40:41.295386+00	f	## Notes\n\n## Description\n\n## Script\n\nWhen we come back we're going to go even further through the looking glass.\n\nWe're going to take an uncomfortably close look at the relationship between the assassin - and his mother.  \n\nPut you predictions on a postcard.. \n\nwe'll be right back.
163	SEGMG1J0M92S7I9D1	20	\N	promo	Promo	promo	30	00:01:00:00			\N		\N		\N	\N		\N	draft	2025-09-27 00:22:15.206092+00	2025-09-27 01:30:26.946206+00	f	
161	SEGMG1J05PI6VUEMD	20	\N	promo	Promo	promo	40	00:00:00:00			\N		\N		\N	\N		\N	draft	2025-09-27 00:21:53.766269+00	2025-09-27 01:30:26.94661+00	f	
162	SEGMG1J0A95GXWEQG	20	\N	ad	Advertisement	advertisement	10	00:00:00:00			\N		\N		\N	\N		\N	draft	2025-09-27 00:21:59.657659+00	2025-09-27 01:30:26.945383+00	f	
24	ASTMFMGRRWVUYHVKA	6	\N	segment	Mommy - Pattern Recognition	mommy	70	00:15:00	None	# Mommy - Pattern Recognition\n\nNow we have to talk about the part no one wants to talk about, and that will get me accused of hating women, jumping to conclusions, and being a hysterical misogynist. To those read to make those accusations, I'll pray that you see the light before it's too late for you and yours. You don't have to like this, and you don't have to like me. But I'm recognizing something real, my pattern spotting is very good, and I have lived this. You scorn me and you only hurt you and yours. Those of us who can see this, and who tell you, are not your enemies. We're not hateful. We're telling the truth as an act of love. \n\nA longtime show viewer and supporter rounded these up. She's a good woman, and she too grew up in a Cluster B household.\n\nAmber Jones Robinson is shooter suspect Tyler Robinson's mother. She's a social worker. You've heard that the family is intact and conservative. For many that means they think they know it was a good family. They've already decided that. And they're upset that people like me are going to probe a little deeper. Being upset about this is only hurting them and their. It's not making me stop saying it. I will never stop saying it. \n\nThis is speculation; that's all it can be. I do not claim to have first person insight into this family. But I don't need to. There are patterns here to recognize. They exist in the real world, it's not Josh Slocum imaginging them for personal reasons. \n\nAnd yes, it is not appropriate to ask these questions and point out these patterns, it is absolutely necessary. Oh I know. A lot of people want to stop at "it's SSRIs." They want to stop at "he was radicallized online." They want to stop at "it was the guns." \n\nNo. We're gonna look at the pattern. And the pattern appears be to a mother who comports herself just like a mother with borderline personality disorder. An emotionally enmeshed, performative, uncomfortably close to her sons mother. \n\nLet's take a look at years of Facebook postings by mother Amber Jones Robinson. Even if you hate that I'm doing this, try to let your eyes show you what you're able to see when your emotional disinclination isn't stopping you from seeing it. \n\nThe friend of the show who rounded these posts up gos by Nua Peasant:\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: tylers-mom-fb]\n[Description: ]\n[MediaURL: ../assets/graphics/tylers-mom-fb.png]\n<img src="../assets/graphics/tylers-mom-fb.png" width="200" />\n<!-- End Cue -->\n\nCan you handle this? Can you commit to trying it on without reacting against it reflexively? Let's try. \n\nHere's a post from 12 years ago when shooter suspect Tyler Robinson was just a boy. It's about how he's got all the computers he wants now so he doesn't have to interact with the family. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: almost-forgot-tyler]\n[Description: ]\n[MediaURL: ../assets/graphics/almost-forgot-tyler.png]\n<img src="../assets/graphics/almost-forgot-tyler.png" width="200" />\n<!-- End Cue -->\n\n"He was radicalized online!"\n\nOK. How did that happen? How was it faciliated? By whom?\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: posting-tylers-scores]\n[Description: ]\n[MediaURL: ../assets/graphics/posting-tylers-scores.png]\n<img src="../assets/graphics/posting-tylers-scores.png" width="200" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: man-child-of-mine]\n[Description: ]\n[MediaURL: ../assets/graphics/man-child-of-mine.png]\n<img src="../assets/graphics/man-child-of-mine.png" width="200" />\n<!-- End Cue -->\n\n-Date. Stay close to momma. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: two-posts-so-far]\n[Description: ]\n[MediaURL: ../assets/graphics/two-posts-so-far.png]\n<img src="../assets/graphics/two-posts-so-far.png" width="200" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: back-to-school-date]\n[Description: ]\n[MediaURL: ../assets/graphics/back-to-school-date.png]\n<img src="../assets/graphics/back-to-school-date.png" width="200" />\n<!-- End Cue -->\n\nSo she dates both her sons. And she jokes about murdering them. \n\nHere's another date, this time with Tyler:\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: again-this-is]\n[Description: ]\n[MediaURL: ../assets/graphics/again-this-is.png]\n<img src="../assets/graphics/again-this-is.png" width="200" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: back-to-school]\n[Description: ]\n[MediaURL: ../assets/graphics/back-to-school.png]\n<img src="../assets/graphics/back-to-school.png" width="200" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: you-may-think]\n[Description: ]\n[MediaURL: ../assets/graphics/you-may-think.png]\n<img src="../assets/graphics/you-may-think.png" width="200" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: since-austin-is]\n[Description: ]\n[MediaURL: ../assets/graphics/since-austin-is.png]\n<img src="../assets/graphics/since-austin-is.png" width="200" />\n<!-- End Cue -->\n\nAnother murder joke:\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: another-murder-joke]\n[Description: ]\n[MediaURL: ../assets/graphics/another-murder-joke.png]\n<img src="../assets/graphics/another-murder-joke.png" width="200" />\n<!-- End Cue -->\n\nMommy is so close to her little boys. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: grad-picture]\n[Description: ]\n[MediaURL: ../assets/graphics/grad-picture.png]\n<img src="../assets/graphics/grad-picture.png" width="200" />\n<!-- End Cue -->\n\n-I know. You've decided I've gone off the rails and i'm just making normal maternal love sound prurient. Are you sure? \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: LOCAL-GFX-20250914-164813]\n[Slug: tit-jut]\n[Description: ]\n[MediaURL: ../assets/graphics/tit-jut.png]\n<img src="../assets/graphics/tit-jut.png" width="200" />\n<!-- End Cue -->\n\nAmber's a hot mommy. I know you see this. \n\nI've talked about emotional incest between mothers and sons many times. I've told you about how my mother would coo at me for being so handsome, so brilliant, how all the girls were gonna want me. Do you know what else was going on that no one could see? Walking around naked when I was too old to see it? In adolescene, making "hilarious jokes" about how she refused to wear a bra in public, along with flapping her boob and laughing hysterically? Or how about swishing her skirt because she was having a hot flash, and making sure I knew she wasn't wearing panties. \n\nBut that's just my mom though. I'm crazy, and she's uniquely crazy, and I'm just projecting. Nothing to see here. What pattern?\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: happy-birthday-to]\n[Description: ]\n[MediaURL: ../assets/graphics/happy-birthday-to.png]\n<img src="../assets/graphics/happy-birthday-to.png" width="200" />\n<!-- End Cue -->\n\nAre you sure that there's nothing to see, here? In the car at age 45 to 50, with her son Tyler, wearing prostitute false eyelashes and making duck face? \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: amber-jones-duck-face]\n[Description: ]\n[MediaURL: ../assets/graphics/amber-jones-duck-face.png]\n<img src="../assets/graphics/amber-jones-duck-face.png" width="200" />\n<!-- End Cue -->\n\nHot mom. Cool mom. Babe mom. \n\nDo I know any of this for sure? Nope. But I'm seeing something, and I think I recognize it. And everyone else does, too. \n\nSound off in the comments. Tell me what you see and what you don't see. \n\nThis is the hardest show I've done yet, and it's not going to get easier in the second half, I'm afraid. \n\nBut that's enough about this topic for all of us, for today. All week I've had a Bible passage in my head. I now understand what it meant for the first time. People have asked how anyone could kill a man so good, so righteous, so kind, so loving, as Charlie. That's an ill-posed question. They killed because was good. \n\n"If the world hates you, keep in mind that it hated me first."\n\nJohn 15:18\n\nTHIS NEEDS THE CUT SCENE FROM THE EXORCIST ABOUT MAKING US DESPAIR\n\nSEE OURSELVES AS ANIMALS AND UGLY AND REJECT THE POSSIBILITY THAT GOD COULD LOVE US	\N	None	None	None	None	\N	None	\N	production	2025-09-16 11:22:50.771113+00	2025-09-16 11:40:41.295386+00	f	# Mommy - Pattern Recognition\n\nNow we have to talk about the part no one wants to talk about, and that will get me accused of hating women, jumping to conclusions, and being a hysterical misogynist. To those read to make those accusations, I'll pray that you see the light before it's too late for you and yours. You don't have to like this, and you don't have to like me. But I'm recognizing something real, my pattern spotting is very good, and I have lived this. You scorn me and you only hurt you and yours. Those of us who can see this, and who tell you, are not your enemies. We're not hateful. We're telling the truth as an act of love. \n\nA longtime show viewer and supporter rounded these up. She's a good woman, and she too grew up in a Cluster B household.\n\nAmber Jones Robinson is shooter suspect Tyler Robinson's mother. She's a social worker. You've heard that the family is intact and conservative. For many that means they think they know it was a good family. They've already decided that. And they're upset that people like me are going to probe a little deeper. Being upset about this is only hurting them and their. It's not making me stop saying it. I will never stop saying it. \n\nThis is speculation; that's all it can be. I do not claim to have first person insight into this family. But I don't need to. There are patterns here to recognize. They exist in the real world, it's not Josh Slocum imaginging them for personal reasons. \n\nAnd yes, it is not appropriate to ask these questions and point out these patterns, it is absolutely necessary. Oh I know. A lot of people want to stop at "it's SSRIs." They want to stop at "he was radicallized online." They want to stop at "it was the guns." \n\nNo. We're gonna look at the pattern. And the pattern appears be to a mother who comports herself just like a mother with borderline personality disorder. An emotionally enmeshed, performative, uncomfortably close to her sons mother. \n\nLet's take a look at years of Facebook postings by mother Amber Jones Robinson. Even if you hate that I'm doing this, try to let your eyes show you what you're able to see when your emotional disinclination isn't stopping you from seeing it. \n\nThe friend of the show who rounded these posts up gos by Nua Peasant:\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: tylers-mom-fb]\n[Description: ]\n[MediaURL: ../assets/graphics/tylers-mom-fb.png]\n<img src="../assets/graphics/tylers-mom-fb.png" width="200" />\n<!-- End Cue -->\n\nCan you handle this? Can you commit to trying it on without reacting against it reflexively? Let's try. \n\nHere's a post from 12 years ago when shooter suspect Tyler Robinson was just a boy. It's about how he's got all the computers he wants now so he doesn't have to interact with the family. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: almost-forgot-tyler]\n[Description: ]\n[MediaURL: ../assets/graphics/almost-forgot-tyler.png]\n<img src="../assets/graphics/almost-forgot-tyler.png" width="200" />\n<!-- End Cue -->\n\n"He was radicalized online!"\n\nOK. How did that happen? How was it faciliated? By whom?\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: posting-tylers-scores]\n[Description: ]\n[MediaURL: ../assets/graphics/posting-tylers-scores.png]\n<img src="../assets/graphics/posting-tylers-scores.png" width="200" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: man-child-of-mine]\n[Description: ]\n[MediaURL: ../assets/graphics/man-child-of-mine.png]\n<img src="../assets/graphics/man-child-of-mine.png" width="200" />\n<!-- End Cue -->\n\n-Date. Stay close to momma. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: two-posts-so-far]\n[Description: ]\n[MediaURL: ../assets/graphics/two-posts-so-far.png]\n<img src="../assets/graphics/two-posts-so-far.png" width="200" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: back-to-school-date]\n[Description: ]\n[MediaURL: ../assets/graphics/back-to-school-date.png]\n<img src="../assets/graphics/back-to-school-date.png" width="200" />\n<!-- End Cue -->\n\nSo she dates both her sons. And she jokes about murdering them. \n\nHere's another date, this time with Tyler:\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: again-this-is]\n[Description: ]\n[MediaURL: ../assets/graphics/again-this-is.png]\n<img src="../assets/graphics/again-this-is.png" width="200" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: back-to-school]\n[Description: ]\n[MediaURL: ../assets/graphics/back-to-school.png]\n<img src="../assets/graphics/back-to-school.png" width="200" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: you-may-think]\n[Description: ]\n[MediaURL: ../assets/graphics/you-may-think.png]\n<img src="../assets/graphics/you-may-think.png" width="200" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: since-austin-is]\n[Description: ]\n[MediaURL: ../assets/graphics/since-austin-is.png]\n<img src="../assets/graphics/since-austin-is.png" width="200" />\n<!-- End Cue -->\n\nAnother murder joke:\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: another-murder-joke]\n[Description: ]\n[MediaURL: ../assets/graphics/another-murder-joke.png]\n<img src="../assets/graphics/another-murder-joke.png" width="200" />\n<!-- End Cue -->\n\nMommy is so close to her little boys. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: grad-picture]\n[Description: ]\n[MediaURL: ../assets/graphics/grad-picture.png]\n<img src="../assets/graphics/grad-picture.png" width="200" />\n<!-- End Cue -->\n\n-I know. You've decided I've gone off the rails and i'm just making normal maternal love sound prurient. Are you sure? \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: LOCAL-GFX-20250914-164813]\n[Slug: tit-jut]\n[Description: ]\n[MediaURL: ../assets/graphics/tit-jut.png]\n<img src="../assets/graphics/tit-jut.png" width="200" />\n<!-- End Cue -->\n\nAmber's a hot mommy. I know you see this. \n\nI've talked about emotional incest between mothers and sons many times. I've told you about how my mother would coo at me for being so handsome, so brilliant, how all the girls were gonna want me. Do you know what else was going on that no one could see? Walking around naked when I was too old to see it? In adolescene, making "hilarious jokes" about how she refused to wear a bra in public, along with flapping her boob and laughing hysterically? Or how about swishing her skirt because she was having a hot flash, and making sure I knew she wasn't wearing panties. \n\nBut that's just my mom though. I'm crazy, and she's uniquely crazy, and I'm just projecting. Nothing to see here. What pattern?\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: happy-birthday-to]\n[Description: ]\n[MediaURL: ../assets/graphics/happy-birthday-to.png]\n<img src="../assets/graphics/happy-birthday-to.png" width="200" />\n<!-- End Cue -->\n\nAre you sure that there's nothing to see, here? In the car at age 45 to 50, with her son Tyler, wearing prostitute false eyelashes and making duck face? \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: amber-jones-duck-face]\n[Description: ]\n[MediaURL: ../assets/graphics/amber-jones-duck-face.png]\n<img src="../assets/graphics/amber-jones-duck-face.png" width="200" />\n<!-- End Cue -->\n\nHot mom. Cool mom. Babe mom. \n\nDo I know any of this for sure? Nope. But I'm seeing something, and I think I recognize it. And everyone else does, too. \n\nSound off in the comments. Tell me what you see and what you don't see. \n\nThis is the hardest show I've done yet, and it's not going to get easier in the second half, I'm afraid. \n\nBut that's enough about this topic for all of us, for today. All week I've had a Bible passage in my head. I now understand what it meant for the first time. People have asked how anyone could kill a man so good, so righteous, so kind, so loving, as Charlie. That's an ill-posed question. They killed because was good. \n\n"If the world hates you, keep in mind that it hated me first."\n\nJohn 15:18\n\nTHIS NEEDS THE CUT SCENE FROM THE EXORCIST ABOUT MAKING US DESPAIR\n\nSEE OURSELVES AS ANIMALS AND UGLY AND REJECT THE POSSIBILITY THAT GOD COULD LOVE US
27	ASTMFK0RNJH2GH0RW	6	\N	break	Break	break	30	00:00:00		## Notes\n\n## Description\n\n## Script\n\n<!-- Begin Cue -->\n[Type: BREAK]\n[Slug: break]\n[AssetID: ASTMFK0RNJH2GH0RW]\n<!-- End Cue -->	\N				2025-09-14T18:19:18.893072: Generated server AssetID ASTMFK0RNJH2GH0RW via rundown item creation	\N		\N	production	2025-09-16 11:22:50.771113+00	2025-09-16 11:40:41.295386+00	f	## Notes\n\n## Description\n\n## Script\n\n<!-- Begin Cue -->\n[Type: BREAK]\n[Slug: break]\n[AssetID: ASTMFK0RNJH2GH0RW]\n<!-- End Cue -->
26	ASTMFJXNEKU7DJLZP	6	\N	segment	090 Tease Tease	090-tease-tease	80	00:00:00		## Notes\n\n## Description\n\n## Script\n\nAfter the break we're going to talk about the murder of Iryna Zarustka by a black man on a North Carolina train who walked away bragging that he got that white girl.	\N				2025-09-14T16:52:01.806148: Generated server AssetID ASTMFJXNEKU7DJLZP via rundown item creation	\N		\N	production	2025-09-16 11:22:50.771113+00	2025-09-16 11:40:41.295386+00	f	## Notes\n\n## Description\n\n## Script\n\nAfter the break we're going to talk about the murder of Iryna Zarustka by a black man on a North Carolina train who walked away bragging that he got that white girl.
164	SEGMG1K3F173VJSW8	20	\N	promo	Promo	promo	50	00:00:00:00			\N		\N		\N	\N		\N	draft	2025-09-27 00:52:25.435926+00	2025-09-27 01:30:26.947018+00	f	
28	ASTMFMGRRX2989JL4	6	\N	break	Support Break	support	110	00:02:00	None	# Break - Support\n\n**BREAK**\n\n[Support messaging and transition elements]	\N	None	None	None	None	\N	None	\N	production	2025-09-16 11:22:50.777421+00	2025-09-16 11:40:41.295386+00	f	# Break - Support\n\n**BREAK**\n\n[Support messaging and transition elements]
10	COPMF8N1H7K3QWX4Z	4	\N	coldopen	Cold Open	show-intro	0	00:02:30	Welcome to Disaffected	## Notes\nOpening segment introducing show and main topics for the episode.\n\n## Description  \nWelcome to Disaffected introduction, teaser for upcoming content including Best Buy rant reference.\n\n## Script\nWelcome to Disaffected, it's September 7, 2025. This is the show that talks about politics, culture, and relationships through a psychological lens. I'm Joshua Slocum\n\nIf you didn't catch the special bonus extra rant this week, be sure to go back on Rumble or Youtube and find it. If you like my grocery store stories, you'll love/hate my Best Buy rant. It's got everything, retarded Gen Z's with man boobs, zombie broads weaving around parking lots, and more.	2025-09-07 00:00:00			intro, welcome, topics	Generated for episode 0239 segmentation	\N	high	\N	draft	2025-09-16 11:15:55.200852+00	2025-09-16 17:32:25.473906+00	f	## Notes\nOpening segment introducing show and main topics for the episode.\n\n## Description  \nWelcome to Disaffected introduction, teaser for upcoming content including Best Buy rant reference.\n\n## Script\nWelcome to Disaffected, it's September 7, 2025. This is the show that talks about politics, culture, and relationships through a psychological lens. I'm Joshua Slocum\n\nIf you didn't catch the special bonus extra rant this week, be sure to go back on Rumble or Youtube and find it. If you like my grocery store stories, you'll love/hate my Best Buy rant. It's got everything, retarded Gen Z's with man boobs, zombie broads weaving around parking lots, and more.
12	SEGMF8N3K4Q6SYU8C	4	\N	segment	The Princess and the Pea	princess-and-pea	20	00:12:00	Fairy tale psychology analysis	## Notes\nPsychological exploration of fairy tale themes and their relevance to childhood development and modern identity formation.\n\n## Description\nAnalysis of The Princess and the Pea fairy tale as a metaphor for sensitivity, authenticity, and childhood development patterns.\n\n## Script\n**Media Elements Referenced:**\n- {GFX/align} → align.png\n- {GFX/princess-pea-illustration} → princess pea illustration}.png\n\n**Script Content:**\nThe Princess and the Pea is a fascinating fairy tale that reveals deep psychological truths about sensitivity, authenticity, and the nature of true identity. The story tells us that a real princess can feel a single pea through twenty mattresses and twenty feather beds.\n\nThis hypersensitivity becomes the test of authenticity - only someone of true nobility could be so acutely aware of discomfort that others would never notice.\n\n[Full segment content from original script lines 94-153]	2025-09-07 00:00:00		Hans Christian Andersen works, developmental psychology	fairy tales, psychology, childhood, development, sensitivity	Generated for episode 0239 segmentation	\N	medium	\N	draft	2025-09-16 11:15:55.200852+00	2025-09-16 17:32:25.479267+00	f	## Notes\nPsychological exploration of fairy tale themes and their relevance to childhood development and modern identity formation.\n\n## Description\nAnalysis of The Princess and the Pea fairy tale as a metaphor for sensitivity, authenticity, and childhood development patterns.\n\n## Script\n**Media Elements Referenced:**\n- {GFX/align} → align.png\n- {GFX/princess-pea-illustration} → princess pea illustration}.png\n\n**Script Content:**\nThe Princess and the Pea is a fascinating fairy tale that reveals deep psychological truths about sensitivity, authenticity, and the nature of true identity. The story tells us that a real princess can feel a single pea through twenty mattresses and twenty feather beds.\n\nThis hypersensitivity becomes the test of authenticity - only someone of true nobility could be so acutely aware of discomfort that others would never notice.\n\n[Full segment content from original script lines 94-153]
11	SEGMF8N2J9P5RXT7B	4	\N	segment	Trans Shooter Update	trans-shooter-update	10	00:15:00	Robert Westman case analysis	## Notes\nDeep dive into the Robert "Robin" Westman school shooting case, examining family dynamics and parental responsibility.\n\n## Description\nAnalysis of the Minneapolis Annunciation Catholic School shooting, focusing on family dynamics, parental responsibility, and the role of gender transition in the case.\n\n## Script\n**Media Elements Referenced:**\n- {GFX/robert-westman-and-mom} → robert westman and mom.png\n- {GFX/robert-and-mary-grace} → robert and mary grace.png  \n- {SOT/mary-grace-instagram} → mary grace instagram.mp4\n- {FS quote/mary grace did not} → See quotes_0239.json\n- {GFX/aunt-lyn} → aunt lyn.png\n- {GFX/mainstream-media} → mainstream media.png\n- {GFX/jaimee-michell} → jaimee michell.png\n- {GFX/janedoeuknow} → janedoeuknow.png\n- {GFX/mkdanaher} → mkdanaher.png\n\n**Script Content:** \nLast week we talked about the shooting at Annunciation Catholic School in Minneapolis. A 22 year old man named Robert "Robin" Westman killed two kids and put 17 other people in the hospital on August 27, 2025.\n\nWe talked about how the right wants to blame SSRI antidepressants, and how the left wants to blame guns. Now we're going to talk about how so many people absolutely, positively, never, under no circumstances, want to blame mommy.\n\n[Full segment content from original script lines 17-93]	2025-09-07 00:00:00		Robert Westman case files, Andy Ngo reporting	trans, shooting, family, responsibility, Minneapolis	Generated for episode 0239 segmentation	\N	high	\N	draft	2025-09-16 11:15:55.200852+00	2025-09-16 17:32:25.476632+00	f	## Notes\nDeep dive into the Robert "Robin" Westman school shooting case, examining family dynamics and parental responsibility.\n\n## Description\nAnalysis of the Minneapolis Annunciation Catholic School shooting, focusing on family dynamics, parental responsibility, and the role of gender transition in the case.\n\n## Script\n**Media Elements Referenced:**\n- {GFX/robert-westman-and-mom} → robert westman and mom.png\n- {GFX/robert-and-mary-grace} → robert and mary grace.png  \n- {SOT/mary-grace-instagram} → mary grace instagram.mp4\n- {FS quote/mary grace did not} → See quotes_0239.json\n- {GFX/aunt-lyn} → aunt lyn.png\n- {GFX/mainstream-media} → mainstream media.png\n- {GFX/jaimee-michell} → jaimee michell.png\n- {GFX/janedoeuknow} → janedoeuknow.png\n- {GFX/mkdanaher} → mkdanaher.png\n\n**Script Content:** \nLast week we talked about the shooting at Annunciation Catholic School in Minneapolis. A 22 year old man named Robert "Robin" Westman killed two kids and put 17 other people in the hospital on August 27, 2025.\n\nWe talked about how the right wants to blame SSRI antidepressants, and how the left wants to blame guns. Now we're going to talk about how so many people absolutely, positively, never, under no circumstances, want to blame mommy.\n\n[Full segment content from original script lines 17-93]
138	SEGMG0QOFE506WEI1	19	\N	segment	Segment	segment	110	00:00:00:00			\N		\N		\N	\N		\N	draft	2025-09-26 11:08:57.197355+00	2025-09-26 20:42:27.642166+00	f	
139	SEGMG0SQH198IATBV	19	\N	coldopen	Cold Open	show-cold-open	10	00:00:45:00			\N		\N		\N	\N		\N	draft	2025-09-26 12:06:31.869002+00	2025-09-26 20:42:27.637878+00	f	
140	SEGMG0U3R8FXFY4US	19	\N	tease	Untitled		130	00:00:00:00			\N		\N		\N	\N		\N	draft	2025-09-26 12:44:51.231846+00	2025-09-26 20:42:27.643025+00	f	
15	SEGMF8N6N7T9VXB1F	4	\N	segment	Dress You Up in Ornamentation	dress-you-up	50	00:08:00	Madonna and pop culture analysis	## Notes\nPop culture analysis focusing on Madonna's music and its cultural impact on identity and self-expression.\n\n## Description\nExtended analysis of Madonna's music, particularly focusing on themes of identity, ornamentation, and cultural impact.\n\n## Script\n**Media Elements Referenced:**\n- {SOT/bach-minuet-major} → bach minuet major.mp4\n- {SOT/bach-minuet-minor} → bach minuet minor.mp4\n- {SOT/album-pink-cadillac} → album pink cadillace.mp4\n- {SOT/radio-pink-cadillac} → radio pink cadillac.mp4\n- {SOT/two-of-hearts-stacey} → two of hearts stacey.mp4\n- {SOT/radio-like-a-prayer} → radio like a prayer.mp4\n- {SOT/dress-you-up} → dress you up.mp4\n\n**Script Content:**\nOur final segment explores Madonna's cultural impact and the psychology of ornamentation in popular music. The concept of "dressing up" extends beyond clothing into identity construction and performance.\n\nMadonna's "Dress You Up" represents the ultimate expression of artifice as authenticity - the idea that we become real through performance and decoration.\n\n[Full segment content from original script lines 179-end]	2025-09-07 00:00:00		Madonna discography, pop culture analysis	madonna, pop culture, music, identity, ornamentation	Generated for episode 0239 segmentation	\N	medium	\N	draft	2025-09-16 11:15:55.200852+00	2025-09-16 17:32:25.48703+00	f	## Notes\nPop culture analysis focusing on Madonna's music and its cultural impact on identity and self-expression.\n\n## Description\nExtended analysis of Madonna's music, particularly focusing on themes of identity, ornamentation, and cultural impact.\n\n## Script\n**Media Elements Referenced:**\n- {SOT/bach-minuet-major} → bach minuet major.mp4\n- {SOT/bach-minuet-minor} → bach minuet minor.mp4\n- {SOT/album-pink-cadillac} → album pink cadillace.mp4\n- {SOT/radio-pink-cadillac} → radio pink cadillac.mp4\n- {SOT/two-of-hearts-stacey} → two of hearts stacey.mp4\n- {SOT/radio-like-a-prayer} → radio like a prayer.mp4\n- {SOT/dress-you-up} → dress you up.mp4\n\n**Script Content:**\nOur final segment explores Madonna's cultural impact and the psychology of ornamentation in popular music. The concept of "dressing up" extends beyond clothing into identity construction and performance.\n\nMadonna's "Dress You Up" represents the ultimate expression of artifice as authenticity - the idea that we become real through performance and decoration.\n\n[Full segment content from original script lines 179-end]
124	ASTMFSR6T3UWIHYHD	18	\N	coldopen	Cold Open	show-cold-open	10	00:00:45:00			2025-09-21 00:00:00		\N		\N	\N	normal	\N	production	2025-09-21 03:43:06.658199+00	2025-09-21 03:58:11.848945+00	f	## Notes\n\n## Description\n\n## Script
125	ASTMFSR6T43X378M1	18	\N	tease	Intro Tease	Intro Tease	20	00:00:00:00			2025-09-21 00:00:00		\N		\N	\N	normal	\N	production	2025-09-21 03:43:06.658199+00	2025-09-21 03:58:11.849422+00	f	## Notes\n\n## Description\n\n## Script\n\nTonight we're going to catch up on the aftermath of the Charlie Kirk assassination. People are getting fired for their bloodthirsty social media death orgasms, and they're some pissed.\n\nAnd the media is turning the shooter's relationship with his troon boyfriend into a romance, describing 22-year-old Tyler Robinson's text messages to his animal-costume-wearing boyfriend as "touching." A real Romeo and Furriet story. \n\nAnd you've heard of the woke right, the idea that conservatives have just as many bad lunatics as the left and it's bad bad bad if conservatives use the left's medicine against it. We're going to look at the cuck right, the conservatives afraid to defend their own interests against leftist banshees. \n\nIt's September 21, 2025, and this is Disaffected, the show that talks about politics, culture, and relationships through a psychological lens. I'm Joshua Slocum and put your seatbelt on we're goin'.
126	SEGMFT39C7Q8V9TWE	18	\N	segment	all manson girls	we're all manson girl	30	00:06:39			2025-09-21 00:00:00		\N		\N	\N	normal	\N	production	2025-09-21 03:43:06.658199+00	2025-09-21 03:58:11.850097+00	f	## Notes\n\n## Description\n\n## Script\n\nOn September 10, 22-year-old Tyler Robinson allegedly shot Charlie Kirk dead on a college campus in Utah. The bullet hit his carotid artery and his neck exploded in front of thousands at an event while his family was watching, and he was dead before he hit the grass. \n\nLast week we told you what we knew about Robinson and his family, including a series of Facebook posts from his mother, Amber, which strongly suggest an emotionally incestuous borderline personality stance toward her son. \n\nYou've watched the mainstream leftist media try to blame this murder on right wingers. You've watched them lie directly to the camera and claim they have no idea what his motive was, even though they have heard the same information from law enforcement that we've heard. Tyler Robinson had a boyfriend who's a "furry", an adult who wears full sized sexualized animal costumes. He went full hard antifa leftist over several years despite his family's conservatism. He engraved antifa and trans/furry slogans on the bullets he used, including the one that killed Charlie. \n\nThe media's psychopathy-actual psychopathy–was obvious this week when they just flatly pretended they didn't know this so they could reverse the blame and put it on people like us. You watched thousands of people celebrate his murder, and you noticed the overwhelming proportion of young women who were obviously erotically and emotionally climaxing over this murder.\n\nNow you know that we live in a nation of Manson Girls, except America thinks cult loyalty to brutal killers is now normal and cute, quite a different reaction from what the Manson Girls of 1970 provoked in the public. \n\nWell, you've tried all the rest, so now let's sample the best. In a minute we're going to listen to an NBC news reporter talk about the shooter's relationship with his troonatic boyfriend in a tone usually reserved for a reivew of a romance novel. \n\nBut we have to set it up first by looking at the text message exchanges between shooter Robinson and his  boyfriend. . .Lance Twiggs. Yes. When I first heard the name I wondered if he was related to David Pumpkins. \n\nIt's not confirmed, but it also appears that many more trans and trans sympathetic associates of the shooter had advance knowledge of the shooting judging by online chat messages between them. Again, not confirmed, but it's being investigated and it would be no surprise. \n\nThis week we've seen text messages between the alleged killer, Robinson, and his boyfriend Lance Twiggs. These messages happened on Discord, which is an online chat platform used by videogamers and others. Our show has a Discord chat server. If you remember old school chat rooms like IRC, AOL, and the like, it's like that with more features. \n\nMy friend Holly wrote a Substack article diving deeper into these messages and you should read Better Bent than Blind if you're interested. \n\nHere are some of the exchanges. You'll notice strange, stilted, almost "fake historical dialogue" quality to how Tyler Robinson addresses his boyfriend. Holly sees this as a holdover from Robinson's religious upbringing; that he's talking to his boyfriend the way Mormon boys are taught to talk to women (he's treating Lance as a lady, because Lance is trans, whatever that means). She also thinks the exchanges suggest the boyfriend didn't know about the shooting ahead of time. \n\nI see it differently. This just doesn't read as genuine to me. It looks like a setup, pre-arranged messages that they agreed to make to each other to get the boyfriend out of trouble. To make it seem like Lance Twiggs, the boyfriend, had nothign to do with it. \n\nWe don't know the truth, but maybe we'll find out. \n\nHere's Tyler Robinson:\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: ASTMFT39C85NHP49A]\n[Slug: GFX/10 tyler-robinson]\n[Description: ]\n[MediaURL: ../assets/graphics/10-tyler-robinson.png]\n<img src="../assets/graphics/tyler-robinson.png" width="200" />\n<!-- End Cue -->\n\nHere's his boyfriend Lance Twiggs. Remember, Lance is "trans," so he's a lady, but he's also a furry, which means he's a sexual non-human animal. \n\n  <!-- Begin Cue -->\n[Type: GFX]\n[AssetID: ASTMFT39C8C7NK3Y9]\n[Slug: GFX/20 lance-twiggs]\n[Description: ]\n[MediaURL: ../assets/graphics/20-lance-twiggs.png]\n<img src="../assets/graphics/lance-twiggs.png" width="200" />\n<!-- End Cue -->\n\nHere's lance being a doggy. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: ASTMFT39C8J9XHMST]\n[Slug: GFX/30 lance-doggy]\n[Description: ]\n[MediaURL: ../assets/graphics/30-lance-doggy.png]\n<img src="../assets/graphics/lance-doggy.png" width="200" />\n<!-- End Cue -->\n  \nAnd here are some of the text exhanges on Discord. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: ASTMFT39C8QEPNBQH]\n[Slug: GFX/40 keyboard-note]\n[Description: ]\n[MediaURL: ../assets/graphics/40-keyboard-note.png]\n<img src="../assets/graphics/keyboard-note.png" width="200" />\n<!-- End Cue -->\n\nTyler apparently left Lance a paper note under the keyboard. What kind of dialogue is this? \n\n"I am still OK, my love."\n\n"I had hoped to keep this secret until I died of old age. I am sorry to involve you."\n\nIt reminds me of dialogue from a parody of 50s B scifi movies called the Lost Skeleton of Cadavra. In that movie, space aliens try to pass themselves off as earthlings. The main alien says things like, "I am a normal earth man, I assure you."\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: ASTMFT39C8XYANWUO]\n[Slug: GFX/50 why-did-i]\n[Description: ]\n[MediaURL: ../assets/graphics/50-why-did-i.png]\n<img src="../assets/graphics/why-did-i.png" width="200" />\n<!-- End Cue -->\n\nIt goes on like that. Check out Holly's article for more. \n\nIt doesn't pass my sniff test. This looks like ex-post-facto storytelling. \n\nBut it passes the mainstream media's sniff test. For NBC reporter Matt Gutman, it smelled like the sweetest English roses. \n\n{SOT/matt abc touching shooter}\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: ASTMFT39C942OE6ZU]\n[Slug: SOT/60 abc-touching-shooter]\n[Description: ]\n[MediaURL: ../assets/video/60-abc-touching-shooter.mp4]\n[Duration: 00:00:52]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\n-First of all, Robinson never said "I want to protect you, my love." That's Matt himself confabulating and confessing his own fantasy. \n\n-Touching? Touching cloth maybe. \n\n-An intimate portrait? Is he watching the Patty Duke Story on Lifetime, Television for Women and Homosexuals?\n\nMatt keeps going. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: ASTMFT39C9BIHDDA2]\n[Slug: SOT/70 touching-intimate-portrait]\n[Description: ]\n[MediaURL: ../assets/video/70-touching-intimate-portrait.mp4]\n[Duration: 00:01:50]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\n-Oh, a duality? A portrait of a very human person, a very human experience. \n\nWashed up former talk show host Montel Williams also finds the alleged shooter very, very touching and sympathetic. Naturally, he's on that idiot Abbie Philip's CNN show. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: ASTMFT39C9XCYUL42]\n[Slug: SOT/80 montel-williams]\n[Description: ]\n[MediaURL: ../assets/video/80-montel-williams.mp4]\n[Duration: 00:00:48]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nMontel doesn't think he was motivated politically, despite knowing that he killed conservative Charlie Kirk and said why in text chat. \n\nSee? It's a love story. He was motivated by the power of love. He had to protect his love. See? It's beautiful. He did it all for the glory of love. \n\nThis is psychopathy. Mass pscyhopathy. Don't get used to this. Don't just accommodate it the way you've taken in stride everything else that's gone nuts in the past 10 years. This is a national emergency. \n\nLet's go back to about 1970 and talk about the Manson Family. Those of you too young to remember this or remember it in popular culture, here's what happened. Charles Manson was a psychopathic hippie who formed a commune cult for the purposes of murder. A certain type of young woman flocked to him, a type of young woman we see every single day now. \n\nI'll read a summary from Wikipedia:\n\n"The Manson Family (known among its members as the Family) was a commune, gang and cult led by criminal Charles Manson that was active in California in the late 1960s and early 1970s.[1][2][3] At its peak the group consisted of approximately 100 followers who lived an unconventional lifestyle, frequently using psychoactive drugs, including amphetamine and hallucinogens such as LSD.[1][4] Most were young women from middle-class backgrounds, many of whom were attracted by hippie counterculture and communal living, and then radicalized by Manson's teachings.[1][5] The group murdered at least nine people, and may have killed as many as twenty-four.[1][6]\n\nManson had been institutionalized or incarcerated for more than half of his life by the time he was released from prison in 1967. He began attracting acolytes in the San Francisco Bay Area. They gradually moved to a run-down movie ranch, called the Spahn Ranch, in Los Angeles County.[7] According to group member Susan Atkins, members of the Family became convinced that Manson was a manifestation of Jesus Christ,[1] and believed in his prophecies concerning an imminent, apocalyptic race war.[1][8][9]\n\nIn 1969, Manson Family members Atkins, Charles Denton "Tex" Watson and Patricia Krenwinkel entered the home of actress Sharon Tate and murdered her and four others. Linda Kasabian was also present but did not take part. The following night, members of the Family murdered supermarket executive Leno LaBianca and his wife Rosemary at their home in Los Angeles. Members also committed a number of assaults, petty crimes, theft and street vandalism, including an assassination attempt on U.S. President Gerald Ford in 1975 by Family member Lynette "Squeaky" Fromme."\n\nThis story was the biggest headline in the nation for months, years. I was born 4 years after it took place, but Charles Manson and the Manson Girls were still talked about constantly among adults and in culture. Everyone normal, almost everyone, was shocked by these people and couldn't believe they were real. \n\nHow times have changed. More on that in a minute. \n\nHere are some of the Manson girls holding a vigil for Charlie outside his trial in Los Angeles in 1970.\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: ASTMFT39CANMRT24I]\n[Slug: GFX/90 manson-girls-kneel]\n[Description: ]\n[MediaURL: ../assets/graphics/90-manson-girls-kneel.png]\n<img src="../assets/graphics/manson-girls-kneel.png" width="200" />\n<!-- End Cue -->\n  \nHere they are singing on their way into the court room.\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: ASTMFT39CBDW0BE1X]\n[Slug: SOT/100 manson-girls-singing]\n[Description: ]\n[MediaURL: ../assets/video/100-manson-girls-singing.mp4]\n[Duration: 00:00:24]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nHere's Charlie himself on why the girls loved him so much. See if you have a better understanding after this. \n\n{SOT/manson speaks}\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: ASTMFT39CC3XVAFFE]\n[Slug: SOT/110 manson-speaks]\n[Description: ]\n[MediaURL: ../assets/video/110-manson-speaks.mp4]\n[Duration: 00:00:14]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ...and i play and i sing]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nRemember Luigi Mangione? \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: ASTMFT39CCTV6A883]\n[Slug: GFX/120 luigi-mangione]\n[Description: ]\n[MediaURL: ../assets/graphics/120-luigi-mangione.png]\n<img src="../assets/graphics/luigi-mangione.png" width="200" />\n<!-- End Cue -->\n\nIt was only a few months ago. Young Luigi, hot criminal, allegedly executed United Healthcare CEO Brian Thompson with a gun on December 4, 2024. Countless young people celebrated the death of a nasty capitalist pig who denied people healthcare. \n\nBut it was more than that. You saw young women in the midst of sexual and religious ecstsasy fan girling over this killer. Yes, it's sexual. Yes, they're turned on by violent men. Yes, it makes them tingle. You're seeing what you think you're seeing. \n\nThe difference between 1970 and today is that it was socially unacceptable to openly sympathize with and get hot for brutal psychopathic kilers. Today it's normal. \n\nFrom Axios:\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: ASTMFT39CDJ8I2TAZ]\n[Slug: GFX/130 by-the-numbers]\n[Description: ]\n[MediaURL: ../assets/graphics/130-by-the-numbers.png]\n<img src="../assets/graphics/by-the-numbers.png" width="200" />\n<!-- End Cue -->\n\nHere's a Mangione Girl for you:\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: ASTMFT39CE8FBYXHA]\n[Slug: SOT/140 married-luigi-mangioni]\n[Description: ]\n[MediaURL: ../assets/video/140-married-luigi-mangioni.mp4]\n[Duration: 00:01:28]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nI think this next is from the same event, which was a gathering outside the court room to hear what charges would stick against Mangione and which would go. The court threw out the terrorism charges. This was the crowd on hearing that news:\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: ASTMFT39CELCZPRZT]\n[Slug: SOT/150 cheer-for-luigi]\n[Description: ]\n[MediaURL: ../assets/video/150-cheer-for-luigi.mp4]\n[Duration: 00:01:03]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\n-Murder for profit is terrorism\n-Capitalist pigs, die lol lmao\n\nWe're all Manson boys and girls now. Aren't we. \n\nCome back on the other side to indulge in some schadenfreude as we watch modern day Charlie's girls lose their jobs because they celebrated a bloody murder on social media.
127	SEGMFT39CEVMP5WD9	18	\N	segment	Cancel Culture	cancel culture	60	00:03:12			2025-09-21 00:00:00		\N		\N	\N	normal	\N	production	2025-09-21 03:43:06.658199+00	2025-09-21 03:58:11.851645+00	f	## Notes\n\n## Description\n\n## Script\nYou've seen them fucking around. Now let's see them find out. \n\nThis nurse is no longer a nurse. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: ASTMFT39CF6PENLRD]\n[Slug: SOT/160 nurse-fired]\n[Description: ]\n[MediaURL: ../assets/video/160-nurse-fired.mp4]\n[Duration: 00:00:33]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nGood. Yes. Good. Moral. Right. It needed to happen. Do you want a bloodthirsty psychopathic nurse who celebrates murdering a father and husand taking care of your mother? Your duaghter? \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: ASTMFT39CFDJ3EFG3]\n[Slug: GFX/170 weird-how-people]\n[Description: ]\n[MediaURL: ../assets/graphics/170-weird-how-people.png]\n<img src="../assets/graphics/weird-how-people.png" width="200" />\n<!-- End Cue -->\n\nThis young woman\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: ASTMFT39CFJMPTI97]\n[Slug: SOT/180 fuck-fired-charlie]\n[Description: ]\n[MediaURL: ../assets/video/180-fuck-fired-charlie.mp4]\n[Duration: 00:01:05:03]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\n-Do I go home and goon? Yes, she said, do I go home and masturbate? \n\n-I don't care what you're supposed to do. I don't care if you do anything. \n\n-This is Gen Z. This is the lack of parenting. This is what happens. Chronological adutls who are literally retarded children. \n\nI haven't seen any consequences yet, but I hope these girls get some for destroying a memorial to Charlie Kirk on their college campus and putting out a video of them looking cute and hot doing it. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: ASTMFT39CFQ6LJEJJ]\n[Slug: SOT/190 girls-destroy-memorial]\n[Description: ]\n[MediaURL: ../assets/video/190-girls-destroy-memorial.mp4]\n[Duration: 00:02:39]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\n-"Love your neighbor"\n\n-"I'm not gonna love a man who doesn't even. . ."\n\n"I am not judging."\n\n"We're not the ones"\n\nPsychologist and author Rob Henderson has a fascinating article on Substack discussing the imbalance in how liberals and conservatives see each other. Here's the spoiler: liberals really do hate and fear and dehumanize conservatives, while conservatives don't know or pretend they don't know how much the left actually hates them. The left doesn't disagree with us, they viscerally hate us. \n\nFrom Henderson's Substack:\n\n<!-- Begin Cue -->\n[Type: FSQ]\n[AssetID: fsq_1758417263807_a 2023 stu]\n[Slug: a 2023 study]\n[Quote: \\"A 2023 study from psychologists Christopher D Petsko and Nour S Kteily uncovered something troubling about how Americans see one another. Conservatives tend to view liberals as \\'immature\\' irresponsible, gullible and irrational. Liberals, in turn, tend to see conservatives as \\'savage\\' aggressive, cold-hearted and barbaric.\\"]\n[Align: left]\n[Part: 1x1]\n[WordCount: 45]\n[Attribution: Rob Henderson]\n[Duration: 00:23]\n<!-- End Cue -->\n\n-You see the reversal, right? The actually savage people think we conservatives are the irrational savages. \n\n<!-- Begin Cue -->\n[Type: FSQ]\n[AssetID: fsq_1758417347183_the resear]\n[Slug: the researchers also]\n[Quote: \\"The researchers also found something even more revealing: liberals overestimate how dehumanised they are by conservatives (they think conservatives view them even more negatively than they do). But conservatives underestimate how dehumanised they are by liberals (they think liberals view them more positively than they actually do).\\"]\n[Align: left]\n[Part: 1x1]\n[WordCount: 47]\n[Attribution: Rob Henderson]\n[Duration: 00:24]\n<!-- End Cue -->\n\n-Do you understand now that you're not dealing with morally normal people? Do you understand that I haven't been exaggerating when I say these people, including some of your family, would see you dead? \n\nA number of people on the right are now bellyaching about how the right is just "doing cancel culture" getting these people fired. It's moral insanity to view it that way, and it's suicidal. \n\n"Cancel culture" isn't a thing. Not the way you use it, conservatives. Our side has this badly wrong. \n\n"Cancel culture" is a new word for what we all used to call "social pressure to enforce pro-social behavior and to punish anti-social behavior."\n\nThat's a normal part of human society. It's hardwired. You approve of it, because all human societies, forever, everywhere, operate on *rules*. \n\nWhen you criticize performers who get naked in front of children, or when you boycott stores that cater to LGBTQ and do it to entice kids, you're doing what you scream is "cancel culture" when leftists do it. \n\nWhat you're doing--protesting and boycotting with the aim of using social pressure, not the government, to change behavior--is normal. It's in bounds. \n\nYou know this. \n\nWhat we call "cancel culture" is the left's MIS-USE of this pressure. They've inverted it. \n\nInstead of targeting antisocial behavior, they target pro-social behavior.\n\nInstead of debating, they use social reputation destruction to stop people from being able to disagree and keep their jobs.\n\nBut somehow, you've gotten all twisted up. Somehow, you've allowed yourself to be convinced that normal social pressure against BAD behavior is the same kind of sin as social pressure against GOOD behavior. \n\nDo you see the problem you've backed into? \n\nLet's use the gun analogy. If you treated gun discourse the  same way you're treating this conversation, you would say this:\n\n"NO ONE should EVER have guns. That's death culture. It's not OK when OUR SIDE does it. It's not OK to defend your life with a gun, because a bad guy used his gun to hurt your mother. Therefore, if you use a gun to protect your mother, you're JUST AS BAD and you're practicing DEATH CULTURE.\n\nTherefore, no one should have a gun."\n\nTLDR; you're mistaking the tool for the operator's misuse.\n\nYou have to actually make judgments about right and wrong. \n\nThat's what you're afraid of. That's why you do this. \n\nYou don't want the responsibility. But it is your duty. \n\nJudge.\n\nI want to close this segment out with a letter I got from a viewer. Yes, I said "letter," even though I came by email. I won't name this gentleman, but I do thank him for writing and for being part of the audience. \n\n{FS Quote/greetings mr. slocum}\n\n<!-- Begin Cue -->\n[Type: FSQ]\n[AssetID: fsq_1758417424535_greetings ]\n[Slug: greetings mr. slocum]\n[Quote: Greetings Mr. Slocum,\\n\\nI\\'m a middle-aged heterosexual white man living in California. I had no love for Charlie Kirk, but I wouldn\\'t call myself a Leftist and consider my affiliation \\'politically homeless\\'. The way I found out about Charlie Kirk\\'s assassination was a friend of mine celebrating it on Twitter. He said it was \\'a good thing actually\\' and that \\'we should make this a holiday\\'.\\n]\n[Align: left]\n[Part: 1x1]\n[WordCount: 66]\n[Attribution: viewer letter]\n[Duration: 00:33]\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: FSQ]\n[AssetID: fsq_1758417567627_i have alw]\n[Slug: i have always known]\n[Quote: \\"I\\'ve always known he was far left and was content to stay away from politics, just hang out and play games. This is crossing an unacceptable moral line. This is a hate cult and I cannot associate with these ghouls.\\n\\n\\nWhen will they lynch me? If I die in a car accident, will my death be celebrated too?\\"]\n[Align: left]\n[Part: 1x1]\n[WordCount: 58]\n[Attribution: viewer letter]\n[Duration: 00:29]\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: FSQ]\n[AssetID: fsq_1758417621953_this frien]\n[Slug: this friend once]\n[Quote: \\"This friend once told me he believes in cutting off relationships with people as a social consequence for wrongthink. He\\'s going to get exactly what he wished for and swallow his own medicine.\\n\\nThese people must be socially ostrasized. If you employ them, fire them. If you work for woke, quit. Demand they vacate your place of business.\\n\\nWe must be willing to sacrifice being comfortable. I had to sacrifice this friendship and have gone No Contact.\\"\\n\\n]\n[Align: left]\n[Part: 1x1]\n[WordCount: 77]\n[Attribution: viewer letter]\n[Duration: 00:39]\n<!-- End Cue -->\n\nSir, hats off. You are living in reality, and you don't need me. \n\nCome back after the break to talk about what I'm hearing from my coaching and consulting clients on this topic. Many of them are afraid of, or should be afraid, of the people who live in the same house they do. Also, we'll have little bit of fun to close the show out. Don't you need a laugh? I do.
128	SEGMFT39CFXRU8V4P	18	\N	segment	Your Family is Insane	family insane	90	00:00:00			2025-09-21 00:00:00		\N		\N	\N	normal	\N	production	2025-09-21 03:43:06.658199+00	2025-09-21 03:58:11.853198+00	f	## Notes\n\n## Description\n\n## Script\nYour husband is insane. Your mother is insane. Your sister is insane. Your son is insane. That’s what I’ve said to an increasing number of my coaching/consulting clients. That is not something I say lightly, and I don’t ever say it unless I believe I have good reason to say so based on the specific’s of my client’s circumstances as the client relates them to me (understanding that I don’t have direct knowledge).\n\n\nYou hear me on my show “diagnosing” people all over the place, I know. I do “diagnose” public figures with personality pathology all the time. It’s obvious. We can see their moves and detect patterns.\n\n\n\n\nThat’s not the case when I’m dealing with clients one on one, when my only information about them or their family member comes from that client. I can only go on what they tell me. And, yes, when I’m picking up that my client is also behaving badly/unwisely, I point to the client’s behavior as well. But I am limited in what I can know with confidence from a one-hour conversation with a stranger.\n\n\nIf I were to actually diagnose a person, it would take many more steps. Because I’m not a licensed or degreed mental health pro, I don’t have the medico-legal power to make a diagnosis. When I say above that I “diagnose” celebrities, I’m using the colloquial sense of the word “diagnose.” Because I’m not, actually, “diagnosing” Madonna. I haven’t assessed her in person, and I don’t have the power to make entries in her medical record that inform her course of treatment. That’s why it’s not actual “diagnosis.”\n\n\nDegreed or not, I would be qualified (in my own judgment) to make a real differential diagnosis of a specific personality/trauma disorder. I have the knowledge and the experience. But it could only come after developing a therapeutic relationship over time, one where I could talk with and probe a person in many different ways.\n\n\nIn short, I could pretty rapidly come to “This is likely a Cluster B disorder” in my mind, but I would not commit to it, nor would I say “which one” until I had the time to test my assessment against reality through conversation with the client. And after eliminating other environmental, trauma history, and other influences that might make a person appear to have a disorder that they don’t actually have.\n\n\nI can’t do any of this with the unseen family members of my clients. But I don’t need to delve this deeply to know that many of my clients have family members who are either or a combination of:\n\n\nSeverely situationally traumatized by a world full of evil leftists that they don’t want to be true, so they’re in temporary psychosis to make it “not true” that they’re living in crazy world.\n\n\nFully Cluster B disordered, and have been for decades, but you, client, didn’t see it when you weren’t the target of his ire and disgust. Now you are, since you’ve admitted that you don’t believe Trump or Charlie Kirk should be murdered.\n\n\nDependent, changeable, fickle people who adopt the most strident opinions of the people around them who hold the most power. Weak character, can’t be trusted, has no thoughts of her own.\n\n\nIn a state of cult-induced psychosis: genuine, thorough-going disconnection from reality.\n\n\nHow can I make these assessments, even provisionally, when I haven’t even met these people? Here are the statements and behaviors that clients have reported to me. These are composites; they do not reflect any specific person or situation. But they’re all real. Assuming my clients are telling the truth, what would you think? None of these are one-off statements. They’re all part of a long, sometimes years-long pattern, of similar statements.\n\n\n“I’m glad Charlie Kirk is dead so his children won’t suffer growing up with him for a father.”-told to a client by his father\n\n\n“No one is actually poisoning children or mutilating their genitals. You’re insane, and you’re in a cult. The ‘gender critical’ people you hang around with are psychopaths.”-told to a wife by her husband.\n\n\n“It’s only a few children, a tiny, vanishing number, who are really trans and they need the surgery. You’re insane and full of hate to claim that there are more than a few. Also, no one is doing this to any children yes, the same person often makes these contradictory statements-I see it often.”\n\n\n“Charlie Kirk said that black women shouldn’t have the right to vote, and he said that his political opponents should be executed in public. You’re insane and a psychopath to feel any empathy for him or his family.”-said to a brother by his sister.\n\n\nThis is just a sampling of the things that the family members of my clients are telling them. Any one of these statements, by themselves, suggests disconnection from reality, and suggests membership in a cult. Yes, a literal cult. As culty as The Moonies. Not “cult-like,” an actual ACME, simon-pure cult.\n\n\nGiven the history of these behaviors and statements from some client family members, it’s quite clear that mom/dad/hubby/sister really is a psychopath themselves, and always has been. At least three returning clients have faced the music recently and admitted that it’s true that their loved one has always had a personality disorder, and they can’t deny it or find a workaround any longer after hearing their bloodthirsty rage.\n\n\nI hate this. It’s horrible. My clients are facing deep grief and sorrow, and uncertainty about what the rest of their lives is going to look like.\n\n\nBut what’s most important is that they’re facing the truth, and they’re able to repeat the truth back to me. Yes, my husband is clinically insane. Yes, my wife has a borderline-narcissist personality disorder and she always has, and this is not going to get better. Yes, my father would see me dead.\n\n\nIt’s a horror. Yes. But it is true.
142	SEGMG0U5I5F1CVZBM	19	\N	reader	Reader	reader	50	00:00:00:00			\N		\N		\N	\N		\N	draft	2025-09-26 12:46:12.771181+00	2025-09-26 20:42:27.639605+00	f	
129	SEGMFT39CG6TYWMQB	18	\N	segment	Potpourri du Moquerie	Potpourri du Moquerie	100	00:03:07			2025-09-21 00:00:00		\N		\N	\N	normal	\N	production	2025-09-21 03:43:06.658199+00	2025-09-21 03:58:11.853726+00	f	## Notes\n\n## Description\n\n## Script\n\nThank God we are back!\n\n\nOur first entry comes from a very funny man named Terrence K. Williams, who I call cousin Terrence because he sells pancake mix under the name Cousin T's, and I want this man for my family. He doesn't say anything in this video reaction, but he pulls some good faces. \n\n\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: ASTMFT39CGFV9VMRR]\n[Slug: SOT/200 meow-girl]\n[Description: ]\n[MediaURL: ../assets/video/200-meow-girl.mp4]\n[Duration: 00:01:29]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\n-I need help wiping. \n\n\n-Kitten time. \n\n\n\n\n-I actually want to take care of this girl and be her father and save her. She doesn't have to stay this way. Something tells me she's smart as hell and creative and just needs some guidance. \n\n\nDo you remember Mad TV, and the character Stewart, the overgrown naughty manchild? Well this gentleman would like to say to you "Look what I can do."\n\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: ASTMFT39CGMD4TDX4]\n[Slug: SOT/210 look-what-i-can]\n[Description: ]\n[MediaURL: ../assets/video/210-look-what-i-can.mp4]\n[Duration: 00:00:28]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nFor the next report we turn to our sister network Univision\n\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: ASTMFT39CGSWS1B57]\n[Slug: SOT/220 mom-got-deported]\n[Description: ]\n[MediaURL: ../assets/video/220-mom-got-deported.mp4]\n[Duration: 00:00:43]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nMiguel, I prescribe Miss Clairol Frivolous fawn toner with 10 volume peroxide. Call me back when you've got the brass out of that bleached head. \n\n\nFinally, a lesson from the President in how to talk to bitches. Remember the show a few weeks ago where we watched the cop cam videos with George? How the chicks kept telling the cops that, no, they weren't under arrest, and no, they weren't being taken into custody? Listen to this doxy mouth off in the Oval Office. \n\n\n\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: ASTMFT39CGZUYJYDF]\n[Slug: SOT/230 trump-to-bitches]\n[Description: ]\n[MediaURL: ../assets/video/230-trump-to-bitches.mp4]\n[Duration: 00:00:27]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->
\.


--
-- Data for Name: rundown_items_legacy; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.rundown_items_legacy (id, episode_id, asset_id, slug, type, "order", title, description, duration, priority, status, script_content, notes, resources, guests, tags, created_at, updated_at, file_path, is_test_data) FROM stdin;
\.


--
-- Data for Name: rundowns; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.rundowns (id, asset_id, episode_id, name, description, order_in_episode, estimated_duration, status, created_at, updated_at) FROM stdin;
1	RUND8AX520WY1	1	Default Rundown	Auto-created rundown for standalone items	0	\N	draft	2025-08-16 15:41:40.813318+00	\N
3	ASTMFMGIV8BZF5SF8	6	Main Rundown	Rundown for Episode 238 - Keri Smith	1	\N	draft	2025-09-16 11:15:55.173805+00	\N
4	ASTMFMGIV960OJRIF	7	Main Rundown	Rundown for The Princess and the Pea	1	\N	draft	2025-09-16 11:15:55.200852+00	\N
6	ASTMFMGRRWF7TC15C	8	Main Rundown	Rundown for The Turning Point	1	\N	draft	2025-09-16 11:22:50.755516+00	\N
9	ASTMFMGUNIY1T7V0J	3	Main Rundown	Rundown for Episode 236	1	\N	draft	2025-09-16 11:25:05.057383+00	\N
18	RUN21	21	Main Rundown	Main rundown for episode 0241	0	\N	draft	2025-09-21 03:43:06.658199+00	\N
19	RUNMG07Q6WBURPDRT	22	Episode 0242 Rundown	\N	0	\N	draft	2025-09-26 02:18:26.795048+00	\N
20	RUNMG1FPI855N94QV	23	Episode 0243 Rundown	\N	0	\N	draft	2025-09-26 22:49:37.925703+00	\N
\.


--
-- Data for Name: scripts; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.scripts (id, asset_id, segment_id, role, content, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: seasons; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.seasons (id, asset_id, show_id, name, number, slug, created_at, updated_at) FROM stdin;
1	SSNA0DTJNAYVN	2	Default Season	1	default-season	2025-08-16 15:39:10.681475+00	\N
\.


--
-- Data for Name: segments; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.segments (id, asset_id, episode_id, rundown_type, title, slug, "order", description, tags, thumbnail_url, estimated_duration, actual_duration, in_point, out_point, markers, publishable, published_platforms, created_at, updated_at) FROM stdin;
1	SEGMEEFAFL4C5RT2B	1	SEGMENT	test-segment	test-segment	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-16 15:39:30.287115+00	\N
2	SEGMEEJ3TNWZ5IUEO	\N	SEGMENT	news updates	news updates	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-16 17:26:20.40291+00	\N
3	SEGMEEJ3YD0OKZM7D	\N	SEGMENT	Biltong	Biltong	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-16 17:26:26.494607+00	\N
4	SEGMEEJ44L61P9LZV	\N	SEGMENT	man up	man up	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-16 17:26:34.564141+00	\N
5	SEGMEEJ4JNYVA02T4	\N	SEGMENT	Support our work	Support our work	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-16 17:26:54.105248+00	\N
6	SEGMEEJ56401DC7UN	\N	SEGMENT	borderline wild	borderline wild	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-16 17:27:23.194399+00	\N
7	SEGMEEJ5H1D9I4K1D	\N	SEGMENT	potpourri	potpourri	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-16 17:27:37.354315+00	\N
8	SEGMEENCPXQ375N35	\N	SEGMENT	slocum consulting	slocum consulting	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-16 19:25:14.024959+00	\N
9	SEGMEEOBAPUJXSG4D	\N	SEGMENT	type: promo	type: promo	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-16 19:52:07.17273+00	\N
10	SEGMEEUGQPOVKPL0G	\N	SEGMENT	Untitled Segment	segment-POVKPL0G	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-16 22:44:18.880865+00	\N
11	SEGMENI0G7NHDS95Y	\N	SEGMENT	segment	segment	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-23 00:05:38.973465+00	\N
12	SEGMENJX099GXB5YW	\N	SEGMENT	segment	segment	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-23 00:58:57.551934+00	\N
13	SEGMENN1KTT4WZ9IA	\N	SEGMENT	segment	segment	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-23 02:26:29.691196+00	\N
14	SEGMENNHZMNHN1OLZ	\N	SEGMENT	segment	segment	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-23 02:39:15.369005+00	\N
15	SEGMENNWG7MZFJ7T4	\N	SEGMENT	segment	segment	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-23 02:50:30.044715+00	\N
16	SEGMENO45GP697XFT	\N	SEGMENT	female narcissism	female narcissism	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-23 02:56:29.363266+00	\N
17	SEGMENO4J9M1S526M	\N	SEGMENT	segment	segment	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-23 02:56:47.25253+00	\N
18	SEGMEOFKUYOZE0Y76	\N	SEGMENT	type: coldopen	type: coldopen	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-23 15:45:18.537693+00	\N
19	SEGMEOIYLBRXWRRFC	\N	SEGMENT	segment	segment	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-23 17:19:58.082835+00	\N
20	SEGMEOIZJ66BP0L2S	\N	SEGMENT	type: segment	type: segment	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-23 17:20:41.944314+00	\N
21	SEGMEOJ3IIYIR5I9H	\N	SEGMENT	60 Cracker Barrel	60 Cracker Barrel	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-23 17:23:47.733068+00	\N
22	SEGMEOJ449DRJ4QTV	\N	SEGMENT	taylor swift	taylor swift	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-23 17:24:15.891226+00	\N
23	SEGMEOJ4VJG38C2GD	\N	SEGMENT	segment	segment	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-23 17:24:51.252033+00	\N
24	SEGMEOJ57H90X3NHF	\N	SEGMENT	type: segment	type: segment	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-23 17:25:06.727869+00	\N
25	SEGMEOJK6D4V67EAJ	\N	SEGMENT	Slocum Consulting	Slocum Consulting	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-23 17:36:45.122117+00	\N
26	SEGMEOOMWQVHLKPE7	\N	SEGMENT	Untitled Segment	segment-QVHLKPE7	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-23 19:58:50.705234+00	\N
27	SEGMEXLBQBFLD4KQB	\N	SEGMENT	type: coldopen	type: coldopen	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-30 01:36:05.889581+00	\N
28	SEGMFT39C7Q8V9TWE	\N	SEGMENT	we're all manson girl	we're all manson girl	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-09-21 02:38:58.843562+00	\N
29	SEGMFT39CEVMP5WD9	\N	SEGMENT	cancel culture	cancel culture	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-09-21 02:38:59.099385+00	\N
30	SEGMFT39CFXRU8V4P	\N	SEGMENT	family insane	family insane	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-09-21 02:38:59.135337+00	\N
31	SEGMFT39CG6TYWMQB	\N	SEGMENT	Potpourri du Moquerie	Potpourri du Moquerie	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-09-21 02:38:59.145026+00	\N
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.settings (id, key, value, category, user_id, description, created_at, updated_at) FROM stdin;
2	theme_settings_default	{"theme": "dark"}	theme	\N	Theme settings for 'default' profile	2025-08-13 14:36:40.12776+00	\N
3	enumerate_rundown_markdown_files	true	rundown	\N	Enumerate Rundown Item markdown files with order number	2025-09-02 07:53:41.981982+00	2025-09-02 11:00:35.705344+00
4	auto_number_rundown_items	true	rundown	\N	Auto-number rundown items	2025-09-02 07:53:41.981982+00	2025-09-02 11:00:35.705039+00
5	default_segment_duration	"00:05:00"	rundown	\N	Rundown setting: default_segment_duration	2025-09-02 10:58:48.617548+00	2025-09-02 11:00:35.702475+00
6	enable_timecode	true	rundown	\N	Rundown setting: enable_timecode	2025-09-02 10:58:48.617548+00	2025-09-02 11:00:35.702776+00
7	timecode_format	"HH:MM:SS"	rundown	\N	Rundown setting: timecode_format	2025-09-02 10:58:48.617548+00	2025-09-02 11:00:35.703103+00
8	show_cumulative_time	true	rundown	\N	Rundown setting: show_cumulative_time	2025-09-02 10:58:48.617548+00	2025-09-02 11:00:35.703422+00
9	enable_drag_drop	true	rundown	\N	Rundown setting: enable_drag_drop	2025-09-02 10:58:48.617548+00	2025-09-02 11:00:35.703773+00
10	auto_calculate_duration	true	rundown	\N	Rundown setting: auto_calculate_duration	2025-09-02 10:58:48.617548+00	2025-09-02 11:00:35.704092+00
11	warn_on_delete	true	rundown	\N	Rundown setting: warn_on_delete	2025-09-02 10:58:48.617548+00	2025-09-02 11:00:35.704416+00
12	show_item_numbers	true	rundown	\N	Rundown setting: show_item_numbers	2025-09-02 10:58:48.617548+00	2025-09-02 11:00:35.704731+00
13	theme_colors_default	{"segment": "blue", "ad": "indigo", "promo": "green", "cta": "cyan", "live": "red", "tease": "pink", "tag": "indigo", "bump": "deep-purple", "break": "brown", "block": "grey", "block-a": "blue", "block-b": "green", "block-c": "purple", "block-d": "red", "block-e": "orange", "block-f": "cyan", "block-g": "pink", "block-h": "yellow", "trans": "secondary", "pkg": "purple", "vo": "deep-orange", "sot": "amber", "interview": "teal", "music": "orange", "reader": "amber", "gfx": "cyan", "fsq": "lime", "nat": "light-green", "img": "purple", "Selection-interface": "yellow-darken-1", "selection": "yellow-darken-1", "Hover-interface": "yellow-lighten-3", "hover": "yellow-lighten-3", "Highlight-interface": "yellow-accent", "highlight": "yellow-accent", "Dropline-interface": "deep-orange-darken-4", "dropline": "deep-orange-darken-4", "DragLight-interface": "deep-orange-lighten-3", "draglight": "deep-orange-lighten-3", "Draft-script": "blue-grey", "draft": "blue-grey", "Approved-script": "light-green", "approved": "light-green", "Production-script": "blue", "production": "blue", "Promotion-script": "purple", "promotion": "purple", "Completed-script": "deep-orange-darken-4", "completed": "deep-orange-darken-4"}	colors	\N	Theme color configuration for 'default' profile	2025-09-26 02:45:24.68042+00	2025-09-27 01:08:01.561973+00
\.


--
-- Data for Name: shows; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.shows (id, asset_id, organization_id, name, description, created_at, updated_at, settings, is_test_data) FROM stdin;
1	SHOWQAVRZJ9TUV5	1	Disaffected	dcdfs	2025-08-10 07:58:55.555599+00	2025-08-10 08:57:27.932954+00	{}	f
2	SHWA0DTJNAYVN	7	Default Show	\N	2025-08-16 15:39:10.681475+00	\N	{}	f
\.


--
-- Data for Name: user_groups; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.user_groups (user_id, group_id, joined_at, added_by) FROM stdin;
\.


--
-- Data for Name: user_permission_overrides; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.user_permission_overrides (id, user_id, permission_id, is_granted, resource_type, resource_id, granted_at, granted_by, expires_at, reason) FROM stdin;
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.user_roles (user_id, role_id, assigned_at, assigned_by, expires_at) FROM stdin;
1	5	2025-08-13 13:00:27.045792+00	rbac-test	\N
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.user_sessions (id, session_token, username, ip_address, user_agent, created_at, expires_at, last_activity, is_active) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.users (id, username, hashed_password, access_level, first_name, last_name, email, phone, profile_picture, is_active, is_verified, created_at, updated_at, last_login, preferences, organization_id, is_test_data) FROM stdin;
2	john	$2b$12$T0u873fh7tvFUmLfnG4DhezIrSgIG0p1jtwn8dNEzqz4TO5O9zQW6	user	John	\N	\N	\N	\N	t	f	2025-08-10 06:41:30.049821+00	2025-08-10 06:41:48.683732+00	2025-08-10 06:41:48.684151+00	{}	2	f
4	dev	$2b$12$M/Qqu/5pOMDQ24z7gD/zUO56eeKGFyzCCUX5FhcnilmDG8ABP33Wu	admin	Dev	User	dev@showbuild.local	555-0003		t	f	2025-08-12 07:40:26.818795+00	2025-08-30 14:11:14.613529+00	2025-08-30 14:11:14.613952+00	{}	\N	f
3	admin	$2b$12$xKH50ySM.LRZClMB1WS1Du9AP6/fMlOCGd6QpgZ1lhjBb31/V243O	admin	Admin	User	admin@example.com	\N	\N	t	t	2025-08-12 04:40:21.216425+00	2025-09-14 14:01:37.109765+00	2025-09-14 14:01:37.110138+00	{}	\N	f
1	kevin	$2b$12$1Th59lQmrKsDWJknZCYvxeJFA3QHFIgDLpsqlGz.tlkKylFNlGK4u	admin	Kevin					t	f	2025-08-10 06:09:35.210082+00	2025-09-26 20:33:03.136479+00	2025-09-26 20:33:03.13678+00	{}	1	f
\.


--
-- Name: api_keys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.api_keys_id_seq', 9, true);


--
-- Name: asset_id_pending_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.asset_id_pending_messages_id_seq', 1, false);


--
-- Name: asset_id_registry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.asset_id_registry_id_seq', 352, true);


--
-- Name: asset_id_relationships_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.asset_id_relationships_id_seq', 89, true);


--
-- Name: asset_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.asset_links_id_seq', 61, true);


--
-- Name: asset_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.asset_messages_id_seq', 1, false);


--
-- Name: assets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.assets_id_seq', 1, false);


--
-- Name: blueprint_nodes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.blueprint_nodes_id_seq', 64, true);


--
-- Name: blueprint_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.blueprint_templates_id_seq', 3, true);


--
-- Name: blueprints_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.blueprints_id_seq', 1, true);


--
-- Name: breaks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.breaks_id_seq', 1, false);


--
-- Name: cue_blocks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.cue_blocks_id_seq', 1, false);


--
-- Name: cues_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.cues_id_seq', 59, true);


--
-- Name: elements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.elements_id_seq', 1, false);


--
-- Name: episode_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.episode_templates_id_seq', 12, true);


--
-- Name: episodes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.episodes_id_seq', 23, true);


--
-- Name: extracted_quotes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.extracted_quotes_id_seq', 7, true);


--
-- Name: groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.groups_id_seq', 1, false);


--
-- Name: organizations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.organizations_id_seq', 7, true);


--
-- Name: permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.permissions_id_seq', 25, true);


--
-- Name: processing_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.processing_jobs_id_seq', 1, false);


--
-- Name: rbac_audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.rbac_audit_log_id_seq', 1, true);


--
-- Name: regions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.regions_id_seq', 1, false);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.roles_id_seq', 5, true);


--
-- Name: rundown_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.rundown_items_id_seq', 167, true);


--
-- Name: rundown_items_legacy_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.rundown_items_legacy_id_seq', 1, false);


--
-- Name: rundowns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.rundowns_id_seq', 20, true);


--
-- Name: scripts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.scripts_id_seq', 1, false);


--
-- Name: seasons_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.seasons_id_seq', 1, true);


--
-- Name: segments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.segments_id_seq', 31, true);


--
-- Name: settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.settings_id_seq', 13, true);


--
-- Name: shows_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.shows_id_seq', 2, true);


--
-- Name: user_permission_overrides_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.user_permission_overrides_id_seq', 1, false);


--
-- Name: user_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.user_sessions_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.users_id_seq', 4, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: asset_id_pending_messages asset_id_pending_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.asset_id_pending_messages
    ADD CONSTRAINT asset_id_pending_messages_pkey PRIMARY KEY (id);


--
-- Name: asset_id_registry asset_id_registry_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.asset_id_registry
    ADD CONSTRAINT asset_id_registry_pkey PRIMARY KEY (id);


--
-- Name: asset_id_relationships asset_id_relationships_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.asset_id_relationships
    ADD CONSTRAINT asset_id_relationships_pkey PRIMARY KEY (id);


--
-- Name: asset_links asset_links_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.asset_links
    ADD CONSTRAINT asset_links_pkey PRIMARY KEY (id);


--
-- Name: asset_messages asset_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.asset_messages
    ADD CONSTRAINT asset_messages_pkey PRIMARY KEY (id);


--
-- Name: assets assets_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT assets_pkey PRIMARY KEY (id);


--
-- Name: blueprint_nodes blueprint_nodes_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.blueprint_nodes
    ADD CONSTRAINT blueprint_nodes_pkey PRIMARY KEY (id);


--
-- Name: blueprint_templates blueprint_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.blueprint_templates
    ADD CONSTRAINT blueprint_templates_pkey PRIMARY KEY (id);


--
-- Name: blueprints blueprints_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.blueprints
    ADD CONSTRAINT blueprints_pkey PRIMARY KEY (id);


--
-- Name: breaks breaks_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.breaks
    ADD CONSTRAINT breaks_pkey PRIMARY KEY (id);


--
-- Name: cue_blocks cue_blocks_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.cue_blocks
    ADD CONSTRAINT cue_blocks_pkey PRIMARY KEY (id);


--
-- Name: cues cues_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.cues
    ADD CONSTRAINT cues_pkey PRIMARY KEY (id);


--
-- Name: elements elements_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.elements
    ADD CONSTRAINT elements_pkey PRIMARY KEY (id);


--
-- Name: episode_templates episode_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.episode_templates
    ADD CONSTRAINT episode_templates_pkey PRIMARY KEY (id);


--
-- Name: episodes episodes_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.episodes
    ADD CONSTRAINT episodes_pkey PRIMARY KEY (id);


--
-- Name: extracted_quotes extracted_quotes_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.extracted_quotes
    ADD CONSTRAINT extracted_quotes_pkey PRIMARY KEY (id);


--
-- Name: group_roles group_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.group_roles
    ADD CONSTRAINT group_roles_pkey PRIMARY KEY (group_id, role_id);


--
-- Name: groups groups_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_pkey PRIMARY KEY (id);


--
-- Name: organizations organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: processing_jobs processing_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.processing_jobs
    ADD CONSTRAINT processing_jobs_pkey PRIMARY KEY (id);


--
-- Name: rbac_audit_log rbac_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.rbac_audit_log
    ADD CONSTRAINT rbac_audit_log_pkey PRIMARY KEY (id);


--
-- Name: regions regions_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.regions
    ADD CONSTRAINT regions_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (role_id, permission_id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: rundown_items_legacy rundown_items_legacy_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.rundown_items_legacy
    ADD CONSTRAINT rundown_items_legacy_pkey PRIMARY KEY (id);


--
-- Name: rundown_items rundown_items_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.rundown_items
    ADD CONSTRAINT rundown_items_pkey PRIMARY KEY (id);


--
-- Name: rundowns rundowns_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.rundowns
    ADD CONSTRAINT rundowns_pkey PRIMARY KEY (id);


--
-- Name: scripts scripts_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.scripts
    ADD CONSTRAINT scripts_pkey PRIMARY KEY (id);


--
-- Name: seasons seasons_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.seasons
    ADD CONSTRAINT seasons_pkey PRIMARY KEY (id);


--
-- Name: segments segments_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.segments
    ADD CONSTRAINT segments_pkey PRIMARY KEY (id);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (id);


--
-- Name: shows shows_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.shows
    ADD CONSTRAINT shows_pkey PRIMARY KEY (id);


--
-- Name: user_groups user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.user_groups
    ADD CONSTRAINT user_groups_pkey PRIMARY KEY (user_id, group_id);


--
-- Name: user_permission_overrides user_permission_overrides_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.user_permission_overrides
    ADD CONSTRAINT user_permission_overrides_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (user_id, role_id);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_api_keys_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_api_keys_id ON public.api_keys USING btree (id);


--
-- Name: ix_api_keys_key_hash; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE UNIQUE INDEX ix_api_keys_key_hash ON public.api_keys USING btree (key_hash);


--
-- Name: ix_api_keys_key_prefix; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_api_keys_key_prefix ON public.api_keys USING btree (key_prefix);


--
-- Name: ix_asset_id_pending_messages_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_asset_id_pending_messages_id ON public.asset_id_pending_messages USING btree (id);


--
-- Name: ix_asset_id_pending_messages_pending_asset_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_asset_id_pending_messages_pending_asset_id ON public.asset_id_pending_messages USING btree (pending_asset_id);


--
-- Name: ix_asset_id_registry_asset_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE UNIQUE INDEX ix_asset_id_registry_asset_id ON public.asset_id_registry USING btree (asset_id);


--
-- Name: ix_asset_id_registry_entity_type; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_asset_id_registry_entity_type ON public.asset_id_registry USING btree (entity_type);


--
-- Name: ix_asset_id_registry_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_asset_id_registry_id ON public.asset_id_registry USING btree (id);


--
-- Name: ix_asset_id_relationships_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_asset_id_relationships_id ON public.asset_id_relationships USING btree (id);


--
-- Name: ix_asset_id_relationships_relationship_type; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_asset_id_relationships_relationship_type ON public.asset_id_relationships USING btree (relationship_type);


--
-- Name: ix_asset_id_relationships_source_asset_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_asset_id_relationships_source_asset_id ON public.asset_id_relationships USING btree (source_asset_id);


--
-- Name: ix_asset_id_relationships_target_asset_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_asset_id_relationships_target_asset_id ON public.asset_id_relationships USING btree (target_asset_id);


--
-- Name: ix_asset_links_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_asset_links_id ON public.asset_links USING btree (id);


--
-- Name: ix_asset_links_source_asset_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_asset_links_source_asset_id ON public.asset_links USING btree (source_asset_id);


--
-- Name: ix_asset_links_target_asset_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_asset_links_target_asset_id ON public.asset_links USING btree (target_asset_id);


--
-- Name: ix_asset_messages_asset_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_asset_messages_asset_id ON public.asset_messages USING btree (asset_id);


--
-- Name: ix_asset_messages_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_asset_messages_id ON public.asset_messages USING btree (id);


--
-- Name: ix_assets_asset_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_assets_asset_id ON public.assets USING btree (asset_id);


--
-- Name: ix_assets_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_assets_id ON public.assets USING btree (id);


--
-- Name: ix_assets_slug; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_assets_slug ON public.assets USING btree (slug);


--
-- Name: ix_blueprint_nodes_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_blueprint_nodes_id ON public.blueprint_nodes USING btree (id);


--
-- Name: ix_blueprint_templates_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_blueprint_templates_id ON public.blueprint_templates USING btree (id);


--
-- Name: ix_blueprint_templates_name; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE UNIQUE INDEX ix_blueprint_templates_name ON public.blueprint_templates USING btree (name);


--
-- Name: ix_blueprint_templates_template_type; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_blueprint_templates_template_type ON public.blueprint_templates USING btree (template_type);


--
-- Name: ix_blueprints_episode_number; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE UNIQUE INDEX ix_blueprints_episode_number ON public.blueprints USING btree (episode_number);


--
-- Name: ix_blueprints_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_blueprints_id ON public.blueprints USING btree (id);


--
-- Name: ix_blueprints_status; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_blueprints_status ON public.blueprints USING btree (status);


--
-- Name: ix_breaks_asset_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE UNIQUE INDEX ix_breaks_asset_id ON public.breaks USING btree (asset_id);


--
-- Name: ix_breaks_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_breaks_id ON public.breaks USING btree (id);


--
-- Name: ix_cue_blocks_asset_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_cue_blocks_asset_id ON public.cue_blocks USING btree (asset_id);


--
-- Name: ix_cue_blocks_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_cue_blocks_id ON public.cue_blocks USING btree (id);


--
-- Name: ix_cue_blocks_slug; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_cue_blocks_slug ON public.cue_blocks USING btree (slug);


--
-- Name: ix_cues_asset_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE UNIQUE INDEX ix_cues_asset_id ON public.cues USING btree (asset_id);


--
-- Name: ix_cues_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_cues_id ON public.cues USING btree (id);


--
-- Name: ix_elements_asset_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE UNIQUE INDEX ix_elements_asset_id ON public.elements USING btree (asset_id);


--
-- Name: ix_elements_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_elements_id ON public.elements USING btree (id);


--
-- Name: ix_episode_templates_episode_number; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE UNIQUE INDEX ix_episode_templates_episode_number ON public.episode_templates USING btree (episode_number);


--
-- Name: ix_episode_templates_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_episode_templates_id ON public.episode_templates USING btree (id);


--
-- Name: ix_episode_templates_status; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_episode_templates_status ON public.episode_templates USING btree (status);


--
-- Name: ix_episodes_asset_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE UNIQUE INDEX ix_episodes_asset_id ON public.episodes USING btree (asset_id);


--
-- Name: ix_episodes_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_episodes_id ON public.episodes USING btree (id);


--
-- Name: ix_extracted_quotes_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_extracted_quotes_id ON public.extracted_quotes USING btree (id);


--
-- Name: ix_extracted_quotes_quote_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_extracted_quotes_quote_id ON public.extracted_quotes USING btree (quote_id);


--
-- Name: ix_extracted_quotes_slug; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_extracted_quotes_slug ON public.extracted_quotes USING btree (slug);


--
-- Name: ix_groups_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_groups_id ON public.groups USING btree (id);


--
-- Name: ix_groups_name; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_groups_name ON public.groups USING btree (name);


--
-- Name: ix_groups_organization_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_groups_organization_id ON public.groups USING btree (organization_id);


--
-- Name: ix_groups_slug; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_groups_slug ON public.groups USING btree (slug);


--
-- Name: ix_organizations_asset_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE UNIQUE INDEX ix_organizations_asset_id ON public.organizations USING btree (asset_id);


--
-- Name: ix_organizations_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_organizations_id ON public.organizations USING btree (id);


--
-- Name: ix_permissions_action; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_permissions_action ON public.permissions USING btree (action);


--
-- Name: ix_permissions_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_permissions_id ON public.permissions USING btree (id);


--
-- Name: ix_permissions_name; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE UNIQUE INDEX ix_permissions_name ON public.permissions USING btree (name);


--
-- Name: ix_permissions_resource; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_permissions_resource ON public.permissions USING btree (resource);


--
-- Name: ix_processing_jobs_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_processing_jobs_id ON public.processing_jobs USING btree (id);


--
-- Name: ix_processing_jobs_job_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_processing_jobs_job_id ON public.processing_jobs USING btree (job_id);


--
-- Name: ix_rbac_audit_log_action; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_rbac_audit_log_action ON public.rbac_audit_log USING btree (action);


--
-- Name: ix_rbac_audit_log_created_at; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_rbac_audit_log_created_at ON public.rbac_audit_log USING btree (created_at);


--
-- Name: ix_rbac_audit_log_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_rbac_audit_log_id ON public.rbac_audit_log USING btree (id);


--
-- Name: ix_regions_asset_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE UNIQUE INDEX ix_regions_asset_id ON public.regions USING btree (asset_id);


--
-- Name: ix_regions_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_regions_id ON public.regions USING btree (id);


--
-- Name: ix_roles_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_roles_id ON public.roles USING btree (id);


--
-- Name: ix_roles_name; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE UNIQUE INDEX ix_roles_name ON public.roles USING btree (name);


--
-- Name: ix_roles_slug; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE UNIQUE INDEX ix_roles_slug ON public.roles USING btree (slug);


--
-- Name: ix_rundown_items_asset_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE UNIQUE INDEX ix_rundown_items_asset_id ON public.rundown_items USING btree (asset_id);


--
-- Name: ix_rundown_items_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_rundown_items_id ON public.rundown_items USING btree (id);


--
-- Name: ix_rundown_items_legacy_asset_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_rundown_items_legacy_asset_id ON public.rundown_items_legacy USING btree (asset_id);


--
-- Name: ix_rundown_items_legacy_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_rundown_items_legacy_id ON public.rundown_items_legacy USING btree (id);


--
-- Name: ix_rundown_items_legacy_slug; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_rundown_items_legacy_slug ON public.rundown_items_legacy USING btree (slug);


--
-- Name: ix_rundowns_asset_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE UNIQUE INDEX ix_rundowns_asset_id ON public.rundowns USING btree (asset_id);


--
-- Name: ix_rundowns_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_rundowns_id ON public.rundowns USING btree (id);


--
-- Name: ix_scripts_asset_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE UNIQUE INDEX ix_scripts_asset_id ON public.scripts USING btree (asset_id);


--
-- Name: ix_scripts_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_scripts_id ON public.scripts USING btree (id);


--
-- Name: ix_seasons_asset_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE UNIQUE INDEX ix_seasons_asset_id ON public.seasons USING btree (asset_id);


--
-- Name: ix_seasons_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_seasons_id ON public.seasons USING btree (id);


--
-- Name: ix_segments_asset_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE UNIQUE INDEX ix_segments_asset_id ON public.segments USING btree (asset_id);


--
-- Name: ix_segments_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_segments_id ON public.segments USING btree (id);


--
-- Name: ix_segments_slug; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_segments_slug ON public.segments USING btree (slug);


--
-- Name: ix_settings_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_settings_id ON public.settings USING btree (id);


--
-- Name: ix_settings_key; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE UNIQUE INDEX ix_settings_key ON public.settings USING btree (key);


--
-- Name: ix_shows_asset_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE UNIQUE INDEX ix_shows_asset_id ON public.shows USING btree (asset_id);


--
-- Name: ix_shows_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_shows_id ON public.shows USING btree (id);


--
-- Name: ix_user_permission_overrides_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_user_permission_overrides_id ON public.user_permission_overrides USING btree (id);


--
-- Name: ix_user_permission_overrides_permission_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_user_permission_overrides_permission_id ON public.user_permission_overrides USING btree (permission_id);


--
-- Name: ix_user_permission_overrides_user_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_user_permission_overrides_user_id ON public.user_permission_overrides USING btree (user_id);


--
-- Name: ix_user_sessions_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_user_sessions_id ON public.user_sessions USING btree (id);


--
-- Name: ix_user_sessions_session_token; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE UNIQUE INDEX ix_user_sessions_session_token ON public.user_sessions USING btree (session_token);


--
-- Name: ix_user_sessions_username; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_user_sessions_username ON public.user_sessions USING btree (username);


--
-- Name: ix_users_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_users_id ON public.users USING btree (id);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: blueprint_nodes blueprint_nodes_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.blueprint_nodes
    ADD CONSTRAINT blueprint_nodes_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.blueprint_nodes(id) ON DELETE CASCADE;


--
-- Name: blueprint_nodes blueprint_nodes_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.blueprint_nodes
    ADD CONSTRAINT blueprint_nodes_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.blueprint_templates(id) ON DELETE CASCADE;


--
-- Name: blueprints blueprints_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.blueprints
    ADD CONSTRAINT blueprints_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: blueprints blueprints_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.blueprints
    ADD CONSTRAINT blueprints_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE SET NULL;


--
-- Name: blueprints blueprints_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.blueprints
    ADD CONSTRAINT blueprints_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.blueprint_templates(id) ON DELETE SET NULL;


--
-- Name: breaks breaks_episode_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.breaks
    ADD CONSTRAINT breaks_episode_id_fkey FOREIGN KEY (episode_id) REFERENCES public.episodes(id);


--
-- Name: cue_blocks cue_blocks_rundown_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.cue_blocks
    ADD CONSTRAINT cue_blocks_rundown_item_id_fkey FOREIGN KEY (rundown_item_id) REFERENCES public.rundown_items_legacy(id);


--
-- Name: cues cues_element_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.cues
    ADD CONSTRAINT cues_element_id_fkey FOREIGN KEY (element_id) REFERENCES public.elements(id);


--
-- Name: cues cues_segment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.cues
    ADD CONSTRAINT cues_segment_id_fkey FOREIGN KEY (segment_id) REFERENCES public.segments(id);


--
-- Name: elements elements_segment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.elements
    ADD CONSTRAINT elements_segment_id_fkey FOREIGN KEY (segment_id) REFERENCES public.segments(id);


--
-- Name: episode_templates episode_templates_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.episode_templates
    ADD CONSTRAINT episode_templates_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: episode_templates episode_templates_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.episode_templates
    ADD CONSTRAINT episode_templates_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE SET NULL;


--
-- Name: episode_templates episode_templates_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.episode_templates
    ADD CONSTRAINT episode_templates_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.blueprint_templates(id) ON DELETE SET NULL;


--
-- Name: episodes episodes_season_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.episodes
    ADD CONSTRAINT episodes_season_id_fkey FOREIGN KEY (season_id) REFERENCES public.seasons(id);


--
-- Name: users fk_users_organization; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fk_users_organization FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: group_roles group_roles_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.group_roles
    ADD CONSTRAINT group_roles_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id);


--
-- Name: group_roles group_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.group_roles
    ADD CONSTRAINT group_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id);


--
-- Name: groups groups_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: rbac_audit_log rbac_audit_log_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.rbac_audit_log
    ADD CONSTRAINT rbac_audit_log_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: regions regions_rundown_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.regions
    ADD CONSTRAINT regions_rundown_id_fkey FOREIGN KEY (rundown_id) REFERENCES public.rundowns(id);


--
-- Name: role_permissions role_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES public.permissions(id);


--
-- Name: role_permissions role_permissions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id);


--
-- Name: roles roles_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: roles roles_parent_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_parent_role_id_fkey FOREIGN KEY (parent_role_id) REFERENCES public.roles(id);


--
-- Name: rundown_items rundown_items_rundown_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.rundown_items
    ADD CONSTRAINT rundown_items_rundown_id_fkey FOREIGN KEY (rundown_id) REFERENCES public.rundowns(id);


--
-- Name: rundown_items rundown_items_segment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.rundown_items
    ADD CONSTRAINT rundown_items_segment_id_fkey FOREIGN KEY (segment_id) REFERENCES public.segments(id);


--
-- Name: rundowns rundowns_episode_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.rundowns
    ADD CONSTRAINT rundowns_episode_id_fkey FOREIGN KEY (episode_id) REFERENCES public.episodes(id);


--
-- Name: scripts scripts_segment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.scripts
    ADD CONSTRAINT scripts_segment_id_fkey FOREIGN KEY (segment_id) REFERENCES public.segments(id);


--
-- Name: seasons seasons_show_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.seasons
    ADD CONSTRAINT seasons_show_id_fkey FOREIGN KEY (show_id) REFERENCES public.shows(id);


--
-- Name: segments segments_episode_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.segments
    ADD CONSTRAINT segments_episode_id_fkey FOREIGN KEY (episode_id) REFERENCES public.episodes(id);


--
-- Name: settings settings_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: shows shows_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.shows
    ADD CONSTRAINT shows_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: user_groups user_groups_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.user_groups
    ADD CONSTRAINT user_groups_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id);


--
-- Name: user_groups user_groups_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.user_groups
    ADD CONSTRAINT user_groups_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: user_permission_overrides user_permission_overrides_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.user_permission_overrides
    ADD CONSTRAINT user_permission_overrides_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES public.permissions(id);


--
-- Name: user_permission_overrides user_permission_overrides_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.user_permission_overrides
    ADD CONSTRAINT user_permission_overrides_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: user_roles user_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id);


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

\unrestrict Uf3NgEgMYrR3V8mXZl5OuT5B3BeSUerHplKaPLB5vrvRooB4PIX3wWNK1O9mhIt

