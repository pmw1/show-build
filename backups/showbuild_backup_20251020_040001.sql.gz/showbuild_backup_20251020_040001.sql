--
-- PostgreSQL database dump
--

\restrict IcLrdC3Vutvfkk7pvhxzK8VD6y7V66rBtwjXEEmLDirMkM8wIxLBDJzxscsQtJc

-- Dumped from database version 13.22 (Debian 13.22-1.pgdg13+1)
-- Dumped by pg_dump version 13.22 (Debian 13.22-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.whiteboard_node_links DROP CONSTRAINT IF EXISTS whiteboard_node_links_whiteboard_id_fkey;
ALTER TABLE IF EXISTS ONLY public.whiteboard_node_links DROP CONSTRAINT IF EXISTS whiteboard_node_links_target_item_id_fkey;
ALTER TABLE IF EXISTS ONLY public.whiteboard_node_links DROP CONSTRAINT IF EXISTS whiteboard_node_links_source_item_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_roles DROP CONSTRAINT IF EXISTS user_roles_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_roles DROP CONSTRAINT IF EXISTS user_roles_role_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_permission_overrides DROP CONSTRAINT IF EXISTS user_permission_overrides_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_permission_overrides DROP CONSTRAINT IF EXISTS user_permission_overrides_permission_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_groups DROP CONSTRAINT IF EXISTS user_groups_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_groups DROP CONSTRAINT IF EXISTS user_groups_group_id_fkey;
ALTER TABLE IF EXISTS ONLY public.twitter_oauth_tokens DROP CONSTRAINT IF EXISTS twitter_oauth_tokens_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.speakers DROP CONSTRAINT IF EXISTS speakers_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.speakers DROP CONSTRAINT IF EXISTS speakers_show_id_fkey;
ALTER TABLE IF EXISTS ONLY public.speakers DROP CONSTRAINT IF EXISTS speakers_organization_id_fkey;
ALTER TABLE IF EXISTS ONLY public.shows DROP CONSTRAINT IF EXISTS shows_organization_id_fkey;
ALTER TABLE IF EXISTS ONLY public.settings DROP CONSTRAINT IF EXISTS settings_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.segments DROP CONSTRAINT IF EXISTS segments_episode_id_fkey;
ALTER TABLE IF EXISTS ONLY public.seasons DROP CONSTRAINT IF EXISTS seasons_show_id_fkey;
ALTER TABLE IF EXISTS ONLY public.scripts DROP CONSTRAINT IF EXISTS scripts_segment_id_fkey;
ALTER TABLE IF EXISTS ONLY public.whiteboards DROP CONSTRAINT IF EXISTS scratchpads_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.whiteboard_items DROP CONSTRAINT IF EXISTS scratchpad_items_scratchpad_id_fkey;
ALTER TABLE IF EXISTS ONLY public.rundowns DROP CONSTRAINT IF EXISTS rundowns_episode_id_fkey;
ALTER TABLE IF EXISTS ONLY public.rundown_items DROP CONSTRAINT IF EXISTS rundown_items_speaker_id_fkey;
ALTER TABLE IF EXISTS ONLY public.rundown_items DROP CONSTRAINT IF EXISTS rundown_items_segment_id_fkey;
ALTER TABLE IF EXISTS ONLY public.rundown_items DROP CONSTRAINT IF EXISTS rundown_items_rundown_id_fkey;
ALTER TABLE IF EXISTS ONLY public.roles DROP CONSTRAINT IF EXISTS roles_parent_role_id_fkey;
ALTER TABLE IF EXISTS ONLY public.roles DROP CONSTRAINT IF EXISTS roles_organization_id_fkey;
ALTER TABLE IF EXISTS ONLY public.role_permissions DROP CONSTRAINT IF EXISTS role_permissions_role_id_fkey;
ALTER TABLE IF EXISTS ONLY public.role_permissions DROP CONSTRAINT IF EXISTS role_permissions_permission_id_fkey;
ALTER TABLE IF EXISTS ONLY public.regions DROP CONSTRAINT IF EXISTS regions_rundown_id_fkey;
ALTER TABLE IF EXISTS ONLY public.rbac_audit_log DROP CONSTRAINT IF EXISTS rbac_audit_log_organization_id_fkey;
ALTER TABLE IF EXISTS ONLY public.llm_operations DROP CONSTRAINT IF EXISTS llm_operations_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.llm_notifications DROP CONSTRAINT IF EXISTS llm_notifications_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.groups DROP CONSTRAINT IF EXISTS groups_organization_id_fkey;
ALTER TABLE IF EXISTS ONLY public.group_roles DROP CONSTRAINT IF EXISTS group_roles_role_id_fkey;
ALTER TABLE IF EXISTS ONLY public.group_roles DROP CONSTRAINT IF EXISTS group_roles_group_id_fkey;
ALTER TABLE IF EXISTS ONLY public.whiteboard_items DROP CONSTRAINT IF EXISTS fk_whiteboard_items_parent_item_id;
ALTER TABLE IF EXISTS ONLY public.whiteboard_items DROP CONSTRAINT IF EXISTS fk_whiteboard_items_asset_id;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS fk_users_organization;
ALTER TABLE IF EXISTS ONLY public.blueprint_templates DROP CONSTRAINT IF EXISTS fk_blueprint_templates_parent;
ALTER TABLE IF EXISTS ONLY public.episodes DROP CONSTRAINT IF EXISTS episodes_season_id_fkey;
ALTER TABLE IF EXISTS ONLY public.episode_templates DROP CONSTRAINT IF EXISTS episode_templates_template_id_fkey;
ALTER TABLE IF EXISTS ONLY public.episode_templates DROP CONSTRAINT IF EXISTS episode_templates_organization_id_fkey;
ALTER TABLE IF EXISTS ONLY public.episode_templates DROP CONSTRAINT IF EXISTS episode_templates_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.elements DROP CONSTRAINT IF EXISTS elements_segment_id_fkey;
ALTER TABLE IF EXISTS ONLY public.cues DROP CONSTRAINT IF EXISTS cues_element_id_fkey;
ALTER TABLE IF EXISTS ONLY public.cue_blocks DROP CONSTRAINT IF EXISTS cue_blocks_rundown_item_id_fkey;
ALTER TABLE IF EXISTS ONLY public.breaks DROP CONSTRAINT IF EXISTS breaks_episode_id_fkey;
ALTER TABLE IF EXISTS ONLY public.blueprints DROP CONSTRAINT IF EXISTS blueprints_template_id_fkey;
ALTER TABLE IF EXISTS ONLY public.blueprints DROP CONSTRAINT IF EXISTS blueprints_organization_id_fkey;
ALTER TABLE IF EXISTS ONLY public.blueprints DROP CONSTRAINT IF EXISTS blueprints_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.blueprint_nodes DROP CONSTRAINT IF EXISTS blueprint_nodes_template_id_fkey;
ALTER TABLE IF EXISTS ONLY public.blueprint_nodes DROP CONSTRAINT IF EXISTS blueprint_nodes_parent_id_fkey;
ALTER TABLE IF EXISTS ONLY public.asset_tags DROP CONSTRAINT IF EXISTS asset_tags_asset_id_fkey;
ALTER TABLE IF EXISTS ONLY public.asset_pool_files DROP CONSTRAINT IF EXISTS asset_pool_files_asset_id_fkey;
DROP INDEX IF EXISTS public.ix_users_username;
DROP INDEX IF EXISTS public.ix_users_id;
DROP INDEX IF EXISTS public.ix_user_todos_id;
DROP INDEX IF EXISTS public.ix_user_sessions_username;
DROP INDEX IF EXISTS public.ix_user_sessions_session_token;
DROP INDEX IF EXISTS public.ix_user_sessions_id;
DROP INDEX IF EXISTS public.ix_user_permission_overrides_user_id;
DROP INDEX IF EXISTS public.ix_user_permission_overrides_permission_id;
DROP INDEX IF EXISTS public.ix_user_permission_overrides_id;
DROP INDEX IF EXISTS public.ix_twitter_oauth_tokens_user_id;
DROP INDEX IF EXISTS public.ix_speakers_user_id;
DROP INDEX IF EXISTS public.ix_speakers_slug;
DROP INDEX IF EXISTS public.ix_speakers_name;
DROP INDEX IF EXISTS public.ix_speakers_id;
DROP INDEX IF EXISTS public.ix_sot_processing_jobs_temp_job_id;
DROP INDEX IF EXISTS public.ix_sot_processing_jobs_id;
DROP INDEX IF EXISTS public.ix_shows_id;
DROP INDEX IF EXISTS public.ix_shows_asset_id;
DROP INDEX IF EXISTS public.ix_settings_key;
DROP INDEX IF EXISTS public.ix_settings_id;
DROP INDEX IF EXISTS public.ix_segments_slug;
DROP INDEX IF EXISTS public.ix_segments_id;
DROP INDEX IF EXISTS public.ix_segments_asset_id;
DROP INDEX IF EXISTS public.ix_seasons_id;
DROP INDEX IF EXISTS public.ix_seasons_asset_id;
DROP INDEX IF EXISTS public.ix_scripts_id;
DROP INDEX IF EXISTS public.ix_scripts_asset_id;
DROP INDEX IF EXISTS public.ix_scratchpads_workspace_id;
DROP INDEX IF EXISTS public.ix_scratchpads_episode_number;
DROP INDEX IF EXISTS public.ix_rundowns_id;
DROP INDEX IF EXISTS public.ix_rundowns_asset_id;
DROP INDEX IF EXISTS public.ix_rundown_items_legacy_slug;
DROP INDEX IF EXISTS public.ix_rundown_items_legacy_id;
DROP INDEX IF EXISTS public.ix_rundown_items_legacy_asset_id;
DROP INDEX IF EXISTS public.ix_rundown_items_id;
DROP INDEX IF EXISTS public.ix_rundown_items_asset_id;
DROP INDEX IF EXISTS public.ix_roles_slug;
DROP INDEX IF EXISTS public.ix_roles_name;
DROP INDEX IF EXISTS public.ix_roles_id;
DROP INDEX IF EXISTS public.ix_regions_id;
DROP INDEX IF EXISTS public.ix_regions_asset_id;
DROP INDEX IF EXISTS public.ix_rbac_audit_log_id;
DROP INDEX IF EXISTS public.ix_rbac_audit_log_created_at;
DROP INDEX IF EXISTS public.ix_rbac_audit_log_action;
DROP INDEX IF EXISTS public.ix_processing_jobs_job_id;
DROP INDEX IF EXISTS public.ix_processing_jobs_id;
DROP INDEX IF EXISTS public.ix_permissions_resource;
DROP INDEX IF EXISTS public.ix_permissions_name;
DROP INDEX IF EXISTS public.ix_permissions_id;
DROP INDEX IF EXISTS public.ix_permissions_action;
DROP INDEX IF EXISTS public.ix_organizations_id;
DROP INDEX IF EXISTS public.ix_organizations_asset_id;
DROP INDEX IF EXISTS public.ix_link_preview_cache_url_hash;
DROP INDEX IF EXISTS public.ix_groups_slug;
DROP INDEX IF EXISTS public.ix_groups_organization_id;
DROP INDEX IF EXISTS public.ix_groups_name;
DROP INDEX IF EXISTS public.ix_groups_id;
DROP INDEX IF EXISTS public.ix_extracted_quotes_slug;
DROP INDEX IF EXISTS public.ix_extracted_quotes_quote_id;
DROP INDEX IF EXISTS public.ix_extracted_quotes_id;
DROP INDEX IF EXISTS public.ix_episodes_id;
DROP INDEX IF EXISTS public.ix_episodes_asset_id;
DROP INDEX IF EXISTS public.ix_episode_templates_status;
DROP INDEX IF EXISTS public.ix_episode_templates_id;
DROP INDEX IF EXISTS public.ix_episode_templates_episode_number;
DROP INDEX IF EXISTS public.ix_elements_id;
DROP INDEX IF EXISTS public.ix_elements_asset_id;
DROP INDEX IF EXISTS public.ix_cues_id;
DROP INDEX IF EXISTS public.ix_cues_asset_id;
DROP INDEX IF EXISTS public.ix_cue_blocks_slug;
DROP INDEX IF EXISTS public.ix_cue_blocks_id;
DROP INDEX IF EXISTS public.ix_cue_blocks_asset_id;
DROP INDEX IF EXISTS public.ix_breaks_id;
DROP INDEX IF EXISTS public.ix_breaks_asset_id;
DROP INDEX IF EXISTS public.ix_blueprints_status;
DROP INDEX IF EXISTS public.ix_blueprints_id;
DROP INDEX IF EXISTS public.ix_blueprints_episode_number;
DROP INDEX IF EXISTS public.ix_blueprint_templates_template_type;
DROP INDEX IF EXISTS public.ix_blueprint_templates_parent_template_id;
DROP INDEX IF EXISTS public.ix_blueprint_templates_name;
DROP INDEX IF EXISTS public.ix_blueprint_templates_id;
DROP INDEX IF EXISTS public.ix_blueprint_nodes_id;
DROP INDEX IF EXISTS public.ix_assets_slug;
DROP INDEX IF EXISTS public.ix_assets_id;
DROP INDEX IF EXISTS public.ix_assets_asset_id;
DROP INDEX IF EXISTS public.ix_asset_messages_id;
DROP INDEX IF EXISTS public.ix_asset_messages_asset_id;
DROP INDEX IF EXISTS public.ix_asset_links_target_asset_id;
DROP INDEX IF EXISTS public.ix_asset_links_source_asset_id;
DROP INDEX IF EXISTS public.ix_asset_links_id;
DROP INDEX IF EXISTS public.ix_asset_id_relationships_target_asset_id;
DROP INDEX IF EXISTS public.ix_asset_id_relationships_source_asset_id;
DROP INDEX IF EXISTS public.ix_asset_id_relationships_relationship_type;
DROP INDEX IF EXISTS public.ix_asset_id_relationships_id;
DROP INDEX IF EXISTS public.ix_asset_id_registry_id;
DROP INDEX IF EXISTS public.ix_asset_id_registry_entity_type;
DROP INDEX IF EXISTS public.ix_asset_id_registry_asset_id;
DROP INDEX IF EXISTS public.ix_asset_id_pending_messages_pending_asset_id;
DROP INDEX IF EXISTS public.ix_asset_id_pending_messages_id;
DROP INDEX IF EXISTS public.ix_api_keys_key_prefix;
DROP INDEX IF EXISTS public.ix_api_keys_key_hash;
DROP INDEX IF EXISTS public.ix_api_keys_id;
DROP INDEX IF EXISTS public.idx_prompt_overrides_enabled;
DROP INDEX IF EXISTS public.idx_prompt_overrides_category_operation;
DROP INDEX IF EXISTS public.idx_node_links_target;
DROP INDEX IF EXISTS public.idx_node_links_source;
DROP INDEX IF EXISTS public.idx_llm_operations_user_id;
DROP INDEX IF EXISTS public.idx_llm_notifications_user_id;
DROP INDEX IF EXISTS public.idx_link_preview_url_hash;
DROP INDEX IF EXISTS public.idx_asset_tags_tag;
DROP INDEX IF EXISTS public.idx_asset_tags_asset_id;
DROP INDEX IF EXISTS public.idx_asset_pool_source;
DROP INDEX IF EXISTS public.idx_asset_pool_asset_id;
ALTER TABLE IF EXISTS ONLY public.whiteboard_node_links DROP CONSTRAINT IF EXISTS whiteboard_node_links_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.user_todos DROP CONSTRAINT IF EXISTS user_todos_pkey;
ALTER TABLE IF EXISTS ONLY public.user_sessions DROP CONSTRAINT IF EXISTS user_sessions_pkey;
ALTER TABLE IF EXISTS ONLY public.user_roles DROP CONSTRAINT IF EXISTS user_roles_pkey;
ALTER TABLE IF EXISTS ONLY public.user_permission_overrides DROP CONSTRAINT IF EXISTS user_permission_overrides_pkey;
ALTER TABLE IF EXISTS ONLY public.user_groups DROP CONSTRAINT IF EXISTS user_groups_pkey;
ALTER TABLE IF EXISTS ONLY public.twitter_oauth_tokens DROP CONSTRAINT IF EXISTS twitter_oauth_tokens_pkey;
ALTER TABLE IF EXISTS ONLY public.speakers DROP CONSTRAINT IF EXISTS speakers_slug_key;
ALTER TABLE IF EXISTS ONLY public.speakers DROP CONSTRAINT IF EXISTS speakers_pkey;
ALTER TABLE IF EXISTS ONLY public.sot_processing_jobs DROP CONSTRAINT IF EXISTS sot_processing_jobs_pkey;
ALTER TABLE IF EXISTS ONLY public.shows DROP CONSTRAINT IF EXISTS shows_pkey;
ALTER TABLE IF EXISTS ONLY public.settings DROP CONSTRAINT IF EXISTS settings_pkey;
ALTER TABLE IF EXISTS ONLY public.segments DROP CONSTRAINT IF EXISTS segments_pkey;
ALTER TABLE IF EXISTS ONLY public.seasons DROP CONSTRAINT IF EXISTS seasons_pkey;
ALTER TABLE IF EXISTS ONLY public.scripts DROP CONSTRAINT IF EXISTS scripts_pkey;
ALTER TABLE IF EXISTS ONLY public.whiteboards DROP CONSTRAINT IF EXISTS scratchpads_pkey;
ALTER TABLE IF EXISTS ONLY public.whiteboard_items DROP CONSTRAINT IF EXISTS scratchpad_items_pkey;
ALTER TABLE IF EXISTS ONLY public.rundowns DROP CONSTRAINT IF EXISTS rundowns_pkey;
ALTER TABLE IF EXISTS ONLY public.rundown_items DROP CONSTRAINT IF EXISTS rundown_items_pkey;
ALTER TABLE IF EXISTS ONLY public.rundown_items_legacy DROP CONSTRAINT IF EXISTS rundown_items_legacy_pkey;
ALTER TABLE IF EXISTS ONLY public.roles DROP CONSTRAINT IF EXISTS roles_pkey;
ALTER TABLE IF EXISTS ONLY public.role_permissions DROP CONSTRAINT IF EXISTS role_permissions_pkey;
ALTER TABLE IF EXISTS ONLY public.regions DROP CONSTRAINT IF EXISTS regions_pkey;
ALTER TABLE IF EXISTS ONLY public.rbac_audit_log DROP CONSTRAINT IF EXISTS rbac_audit_log_pkey;
ALTER TABLE IF EXISTS ONLY public.prompt_overrides DROP CONSTRAINT IF EXISTS prompt_overrides_pkey;
ALTER TABLE IF EXISTS ONLY public.processing_jobs DROP CONSTRAINT IF EXISTS processing_jobs_pkey;
ALTER TABLE IF EXISTS ONLY public.permissions DROP CONSTRAINT IF EXISTS permissions_pkey;
ALTER TABLE IF EXISTS ONLY public.organizations DROP CONSTRAINT IF EXISTS organizations_pkey;
ALTER TABLE IF EXISTS ONLY public.llm_operations DROP CONSTRAINT IF EXISTS llm_operations_pkey;
ALTER TABLE IF EXISTS ONLY public.llm_notifications DROP CONSTRAINT IF EXISTS llm_notifications_pkey;
ALTER TABLE IF EXISTS ONLY public.link_preview_cache DROP CONSTRAINT IF EXISTS link_preview_cache_pkey;
ALTER TABLE IF EXISTS ONLY public.groups DROP CONSTRAINT IF EXISTS groups_pkey;
ALTER TABLE IF EXISTS ONLY public.group_roles DROP CONSTRAINT IF EXISTS group_roles_pkey;
ALTER TABLE IF EXISTS ONLY public.extracted_quotes DROP CONSTRAINT IF EXISTS extracted_quotes_pkey;
ALTER TABLE IF EXISTS ONLY public.episodes DROP CONSTRAINT IF EXISTS episodes_pkey;
ALTER TABLE IF EXISTS ONLY public.episode_templates DROP CONSTRAINT IF EXISTS episode_templates_pkey;
ALTER TABLE IF EXISTS ONLY public.elements DROP CONSTRAINT IF EXISTS elements_pkey;
ALTER TABLE IF EXISTS ONLY public.cues DROP CONSTRAINT IF EXISTS cues_pkey;
ALTER TABLE IF EXISTS ONLY public.cue_blocks DROP CONSTRAINT IF EXISTS cue_blocks_pkey;
ALTER TABLE IF EXISTS ONLY public.breaks DROP CONSTRAINT IF EXISTS breaks_pkey;
ALTER TABLE IF EXISTS ONLY public.blueprints DROP CONSTRAINT IF EXISTS blueprints_pkey;
ALTER TABLE IF EXISTS ONLY public.blueprint_templates DROP CONSTRAINT IF EXISTS blueprint_templates_pkey;
ALTER TABLE IF EXISTS ONLY public.blueprint_nodes DROP CONSTRAINT IF EXISTS blueprint_nodes_pkey;
ALTER TABLE IF EXISTS ONLY public.assets DROP CONSTRAINT IF EXISTS assets_pkey;
ALTER TABLE IF EXISTS ONLY public.asset_tags DROP CONSTRAINT IF EXISTS asset_tags_pkey;
ALTER TABLE IF EXISTS ONLY public.asset_pool_files DROP CONSTRAINT IF EXISTS asset_pool_files_pkey;
ALTER TABLE IF EXISTS ONLY public.asset_pool_files DROP CONSTRAINT IF EXISTS asset_pool_files_asset_id_key;
ALTER TABLE IF EXISTS ONLY public.asset_messages DROP CONSTRAINT IF EXISTS asset_messages_pkey;
ALTER TABLE IF EXISTS ONLY public.asset_links DROP CONSTRAINT IF EXISTS asset_links_pkey;
ALTER TABLE IF EXISTS ONLY public.asset_id_relationships DROP CONSTRAINT IF EXISTS asset_id_relationships_pkey;
ALTER TABLE IF EXISTS ONLY public.asset_id_registry DROP CONSTRAINT IF EXISTS asset_id_registry_pkey;
ALTER TABLE IF EXISTS ONLY public.asset_id_pending_messages DROP CONSTRAINT IF EXISTS asset_id_pending_messages_pkey;
ALTER TABLE IF EXISTS ONLY public.api_keys DROP CONSTRAINT IF EXISTS api_keys_pkey;
ALTER TABLE IF EXISTS ONLY public.api_configs DROP CONSTRAINT IF EXISTS api_configs_workflow_category_service_config_key_key;
ALTER TABLE IF EXISTS ONLY public.api_configs DROP CONSTRAINT IF EXISTS api_configs_pkey;
ALTER TABLE IF EXISTS ONLY public.alembic_version DROP CONSTRAINT IF EXISTS alembic_version_pkc;
ALTER TABLE IF EXISTS public.whiteboards ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.whiteboard_node_links ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.whiteboard_items ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.user_todos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.user_sessions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.user_permission_overrides ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.twitter_oauth_tokens ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.speakers ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.sot_processing_jobs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.shows ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.settings ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.segments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.seasons ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.scripts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.rundowns ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.rundown_items_legacy ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.rundown_items ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.roles ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.regions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.rbac_audit_log ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.processing_jobs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.permissions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.organizations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.link_preview_cache ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.groups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.extracted_quotes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.episodes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.episode_templates ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.elements ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.cues ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.cue_blocks ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.breaks ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.blueprints ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.blueprint_templates ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.blueprint_nodes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.assets ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.asset_tags ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.asset_pool_files ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.asset_messages ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.asset_links ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.asset_id_relationships ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.asset_id_registry ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.asset_id_pending_messages ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.api_keys ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.api_configs ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.whiteboard_node_links_id_seq;
DROP TABLE IF EXISTS public.whiteboard_node_links;
DROP SEQUENCE IF EXISTS public.users_id_seq;
DROP TABLE IF EXISTS public.users;
DROP SEQUENCE IF EXISTS public.user_todos_id_seq;
DROP TABLE IF EXISTS public.user_todos;
DROP SEQUENCE IF EXISTS public.user_sessions_id_seq;
DROP TABLE IF EXISTS public.user_sessions;
DROP TABLE IF EXISTS public.user_roles;
DROP SEQUENCE IF EXISTS public.user_permission_overrides_id_seq;
DROP TABLE IF EXISTS public.user_permission_overrides;
DROP TABLE IF EXISTS public.user_groups;
DROP SEQUENCE IF EXISTS public.twitter_oauth_tokens_id_seq;
DROP TABLE IF EXISTS public.twitter_oauth_tokens;
DROP SEQUENCE IF EXISTS public.speakers_id_seq;
DROP TABLE IF EXISTS public.speakers;
DROP SEQUENCE IF EXISTS public.sot_processing_jobs_id_seq;
DROP TABLE IF EXISTS public.sot_processing_jobs;
DROP SEQUENCE IF EXISTS public.shows_id_seq;
DROP TABLE IF EXISTS public.shows;
DROP SEQUENCE IF EXISTS public.settings_id_seq;
DROP TABLE IF EXISTS public.settings;
DROP SEQUENCE IF EXISTS public.segments_id_seq;
DROP TABLE IF EXISTS public.segments;
DROP SEQUENCE IF EXISTS public.seasons_id_seq;
DROP TABLE IF EXISTS public.seasons;
DROP SEQUENCE IF EXISTS public.scripts_id_seq;
DROP TABLE IF EXISTS public.scripts;
DROP SEQUENCE IF EXISTS public.scratchpads_id_seq;
DROP TABLE IF EXISTS public.whiteboards;
DROP SEQUENCE IF EXISTS public.scratchpad_items_id_seq;
DROP TABLE IF EXISTS public.whiteboard_items;
DROP SEQUENCE IF EXISTS public.rundowns_id_seq;
DROP TABLE IF EXISTS public.rundowns;
DROP SEQUENCE IF EXISTS public.rundown_items_legacy_id_seq;
DROP TABLE IF EXISTS public.rundown_items_legacy;
DROP SEQUENCE IF EXISTS public.rundown_items_id_seq;
DROP TABLE IF EXISTS public.rundown_items;
DROP SEQUENCE IF EXISTS public.roles_id_seq;
DROP TABLE IF EXISTS public.roles;
DROP TABLE IF EXISTS public.role_permissions;
DROP SEQUENCE IF EXISTS public.regions_id_seq;
DROP TABLE IF EXISTS public.regions;
DROP SEQUENCE IF EXISTS public.rbac_audit_log_id_seq;
DROP TABLE IF EXISTS public.rbac_audit_log;
DROP TABLE IF EXISTS public.prompt_overrides;
DROP SEQUENCE IF EXISTS public.processing_jobs_id_seq;
DROP TABLE IF EXISTS public.processing_jobs;
DROP SEQUENCE IF EXISTS public.permissions_id_seq;
DROP TABLE IF EXISTS public.permissions;
DROP SEQUENCE IF EXISTS public.organizations_id_seq;
DROP TABLE IF EXISTS public.organizations;
DROP TABLE IF EXISTS public.llm_operations;
DROP TABLE IF EXISTS public.llm_notifications;
DROP SEQUENCE IF EXISTS public.link_preview_cache_id_seq;
DROP TABLE IF EXISTS public.link_preview_cache;
DROP SEQUENCE IF EXISTS public.groups_id_seq;
DROP TABLE IF EXISTS public.groups;
DROP TABLE IF EXISTS public.group_roles;
DROP SEQUENCE IF EXISTS public.extracted_quotes_id_seq;
DROP TABLE IF EXISTS public.extracted_quotes;
DROP SEQUENCE IF EXISTS public.episodes_id_seq;
DROP TABLE IF EXISTS public.episodes;
DROP SEQUENCE IF EXISTS public.episode_templates_id_seq;
DROP TABLE IF EXISTS public.episode_templates;
DROP SEQUENCE IF EXISTS public.elements_id_seq;
DROP TABLE IF EXISTS public.elements;
DROP SEQUENCE IF EXISTS public.cues_id_seq;
DROP TABLE IF EXISTS public.cues;
DROP SEQUENCE IF EXISTS public.cue_blocks_id_seq;
DROP TABLE IF EXISTS public.cue_blocks;
DROP SEQUENCE IF EXISTS public.breaks_id_seq;
DROP TABLE IF EXISTS public.breaks;
DROP SEQUENCE IF EXISTS public.blueprints_id_seq;
DROP TABLE IF EXISTS public.blueprints;
DROP SEQUENCE IF EXISTS public.blueprint_templates_id_seq;
DROP TABLE IF EXISTS public.blueprint_templates;
DROP SEQUENCE IF EXISTS public.blueprint_nodes_id_seq;
DROP TABLE IF EXISTS public.blueprint_nodes;
DROP SEQUENCE IF EXISTS public.assets_id_seq;
DROP TABLE IF EXISTS public.assets;
DROP SEQUENCE IF EXISTS public.asset_tags_id_seq;
DROP TABLE IF EXISTS public.asset_tags;
DROP SEQUENCE IF EXISTS public.asset_pool_files_id_seq;
DROP TABLE IF EXISTS public.asset_pool_files;
DROP SEQUENCE IF EXISTS public.asset_messages_id_seq;
DROP TABLE IF EXISTS public.asset_messages;
DROP SEQUENCE IF EXISTS public.asset_links_id_seq;
DROP TABLE IF EXISTS public.asset_links;
DROP SEQUENCE IF EXISTS public.asset_id_relationships_id_seq;
DROP TABLE IF EXISTS public.asset_id_relationships;
DROP SEQUENCE IF EXISTS public.asset_id_registry_id_seq;
DROP TABLE IF EXISTS public.asset_id_registry;
DROP SEQUENCE IF EXISTS public.asset_id_pending_messages_id_seq;
DROP TABLE IF EXISTS public.asset_id_pending_messages;
DROP SEQUENCE IF EXISTS public.api_keys_id_seq;
DROP TABLE IF EXISTS public.api_keys;
DROP SEQUENCE IF EXISTS public.api_configs_id_seq;
DROP TABLE IF EXISTS public.api_configs;
DROP TABLE IF EXISTS public.alembic_version;
DROP TYPE IF EXISTS public.rundownitemtype;
DROP TYPE IF EXISTS public.elementtype;
DROP TYPE IF EXISTS public.cuetype;
--
-- Name: cuetype; Type: TYPE; Schema: public; Owner: showbuild
--

CREATE TYPE public.cuetype AS ENUM (
    'MEDIA',
    'CAMERA',
    'AUDIO_MIC',
    'LIGHTING',
    'DIRECTOR',
    'TALENT'
);


ALTER TYPE public.cuetype OWNER TO showbuild;

--
-- Name: elementtype; Type: TYPE; Schema: public; Owner: showbuild
--

CREATE TYPE public.elementtype AS ENUM (
    'VIDEO',
    'AUDIO',
    'GRAPHIC',
    'ANIMATION',
    'LOWER_THIRD',
    'QUOTE'
);


ALTER TYPE public.elementtype OWNER TO showbuild;

--
-- Name: rundownitemtype; Type: TYPE; Schema: public; Owner: showbuild
--

CREATE TYPE public.rundownitemtype AS ENUM (
    'SEGMENT',
    'OPENING',
    'TEASER',
    'ADVERTISEMENT',
    'PROMO',
    'INTERVIEW',
    'PACKAGE',
    'TRANSITION',
    'STINGER',
    'REJOIN',
    'READER',
    'CLOSE',
    'BREAK'
);


ALTER TYPE public.rundownitemtype OWNER TO showbuild;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO showbuild;

--
-- Name: api_configs; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.api_configs (
    id integer NOT NULL,
    workflow character varying(50) NOT NULL,
    category character varying(50) NOT NULL,
    service character varying(50) NOT NULL,
    config_key character varying(100) NOT NULL,
    config_value text,
    is_encrypted boolean DEFAULT false,
    is_enabled boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.api_configs OWNER TO showbuild;

--
-- Name: api_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.api_configs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.api_configs_id_seq OWNER TO showbuild;

--
-- Name: api_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.api_configs_id_seq OWNED BY public.api_configs.id;


--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.api_keys (
    id integer NOT NULL,
    key_hash character varying(255) NOT NULL,
    key_prefix character varying(8) NOT NULL,
    client_name character varying(100) NOT NULL,
    access_level character varying(20) NOT NULL,
    created_by_username character varying(50) NOT NULL,
    is_active boolean,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    last_used timestamp with time zone,
    expires_at timestamp with time zone,
    usage_count integer
);


ALTER TABLE public.api_keys OWNER TO showbuild;

--
-- Name: api_keys_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.api_keys_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.api_keys_id_seq OWNER TO showbuild;

--
-- Name: api_keys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.api_keys_id_seq OWNED BY public.api_keys.id;


--
-- Name: asset_id_pending_messages; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.asset_id_pending_messages (
    id integer NOT NULL,
    pending_asset_id character varying(50) NOT NULL,
    message_type character varying(50) NOT NULL,
    content text NOT NULL,
    priority integer,
    created_by character varying(255),
    created_at timestamp with time zone DEFAULT now(),
    delivered character varying(5),
    delivered_at timestamp without time zone,
    expires_at timestamp without time zone,
    context json
);


ALTER TABLE public.asset_id_pending_messages OWNER TO showbuild;

--
-- Name: asset_id_pending_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.asset_id_pending_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.asset_id_pending_messages_id_seq OWNER TO showbuild;

--
-- Name: asset_id_pending_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.asset_id_pending_messages_id_seq OWNED BY public.asset_id_pending_messages.id;


--
-- Name: asset_id_registry; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.asset_id_registry (
    id integer NOT NULL,
    asset_id character varying(50) NOT NULL,
    entity_type character varying(50) NOT NULL,
    entity_table character varying(100),
    entity_id integer,
    request_reason character varying(50) NOT NULL,
    request_context json,
    requested_by character varying(255),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    initial_links json,
    is_active character varying(20),
    meta_data json,
    notes text
);


ALTER TABLE public.asset_id_registry OWNER TO showbuild;

--
-- Name: asset_id_registry_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.asset_id_registry_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.asset_id_registry_id_seq OWNER TO showbuild;

--
-- Name: asset_id_registry_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.asset_id_registry_id_seq OWNED BY public.asset_id_registry.id;


--
-- Name: asset_id_relationships; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.asset_id_relationships (
    id integer NOT NULL,
    source_asset_id character varying(50) NOT NULL,
    target_asset_id character varying(50) NOT NULL,
    relationship_type character varying(50) NOT NULL,
    is_bidirectional character varying(5),
    strength integer,
    created_by character varying(255),
    created_at timestamp with time zone DEFAULT now(),
    context json,
    is_active character varying(20),
    notes text
);


ALTER TABLE public.asset_id_relationships OWNER TO showbuild;

--
-- Name: asset_id_relationships_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.asset_id_relationships_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.asset_id_relationships_id_seq OWNER TO showbuild;

--
-- Name: asset_id_relationships_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.asset_id_relationships_id_seq OWNED BY public.asset_id_relationships.id;


--
-- Name: asset_links; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.asset_links (
    id integer NOT NULL,
    source_asset_id character varying(50) NOT NULL,
    target_asset_id character varying(50) NOT NULL,
    link_type character varying(50) NOT NULL,
    meta_data json,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.asset_links OWNER TO showbuild;

--
-- Name: asset_links_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.asset_links_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.asset_links_id_seq OWNER TO showbuild;

--
-- Name: asset_links_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.asset_links_id_seq OWNED BY public.asset_links.id;


--
-- Name: asset_messages; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.asset_messages (
    id integer NOT NULL,
    asset_id character varying(50) NOT NULL,
    message_type character varying(50) NOT NULL,
    content text NOT NULL,
    user_id character varying(100),
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.asset_messages OWNER TO showbuild;

--
-- Name: asset_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.asset_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.asset_messages_id_seq OWNER TO showbuild;

--
-- Name: asset_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.asset_messages_id_seq OWNED BY public.asset_messages.id;


--
-- Name: asset_pool_files; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.asset_pool_files (
    id integer NOT NULL,
    asset_id character varying(50) NOT NULL,
    file_path text NOT NULL,
    original_filename text,
    mime_type character varying(100),
    file_size bigint,
    thumbnail_path text,
    source character varying(50),
    source_url text,
    source_context json,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.asset_pool_files OWNER TO showbuild;

--
-- Name: asset_pool_files_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.asset_pool_files_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.asset_pool_files_id_seq OWNER TO showbuild;

--
-- Name: asset_pool_files_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.asset_pool_files_id_seq OWNED BY public.asset_pool_files.id;


--
-- Name: asset_tags; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.asset_tags (
    id integer NOT NULL,
    asset_id character varying(50) NOT NULL,
    tag character varying(100) NOT NULL,
    created_by character varying(255),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.asset_tags OWNER TO showbuild;

--
-- Name: asset_tags_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.asset_tags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.asset_tags_id_seq OWNER TO showbuild;

--
-- Name: asset_tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.asset_tags_id_seq OWNED BY public.asset_tags.id;


--
-- Name: assets; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.assets (
    id integer NOT NULL,
    episode_id integer NOT NULL,
    asset_id character varying(50) NOT NULL,
    slug character varying(100) NOT NULL,
    filename character varying(255) NOT NULL,
    asset_type character varying(20) NOT NULL,
    file_path character varying(500) NOT NULL,
    file_size integer,
    mime_type character varying(100),
    width integer,
    height integer,
    duration double precision,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    processed boolean,
    meta_data json,
    is_test_data boolean DEFAULT false NOT NULL
);


ALTER TABLE public.assets OWNER TO showbuild;

--
-- Name: assets_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.assets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.assets_id_seq OWNER TO showbuild;

--
-- Name: assets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.assets_id_seq OWNED BY public.assets.id;


--
-- Name: blueprint_nodes; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.blueprint_nodes (
    id integer NOT NULL,
    template_id integer NOT NULL,
    parent_id integer,
    node_type character varying(20) NOT NULL,
    name character varying(255) NOT NULL,
    content text,
    sort_order integer NOT NULL,
    is_required boolean NOT NULL,
    rundown_item_metadata json
);


ALTER TABLE public.blueprint_nodes OWNER TO showbuild;

--
-- Name: blueprint_nodes_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.blueprint_nodes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.blueprint_nodes_id_seq OWNER TO showbuild;

--
-- Name: blueprint_nodes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.blueprint_nodes_id_seq OWNED BY public.blueprint_nodes.id;


--
-- Name: blueprint_templates; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.blueprint_templates (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    template_type character varying(50) NOT NULL,
    is_active boolean NOT NULL,
    is_default boolean NOT NULL,
    template_metadata json,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone,
    parent_template_id integer,
    inheritance_mode character varying(20) DEFAULT 'merge'::character varying NOT NULL
);


ALTER TABLE public.blueprint_templates OWNER TO showbuild;

--
-- Name: blueprint_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.blueprint_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.blueprint_templates_id_seq OWNER TO showbuild;

--
-- Name: blueprint_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.blueprint_templates_id_seq OWNED BY public.blueprint_templates.id;


--
-- Name: blueprints; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.blueprints (
    id integer NOT NULL,
    episode_number character varying(10) NOT NULL,
    title character varying(200),
    description text,
    episode_metadata json,
    template_id integer,
    status character varying(20) NOT NULL,
    created_by integer,
    organization_id integer,
    file_path character varying(500),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone
);


ALTER TABLE public.blueprints OWNER TO showbuild;

--
-- Name: blueprints_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.blueprints_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.blueprints_id_seq OWNER TO showbuild;

--
-- Name: blueprints_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.blueprints_id_seq OWNED BY public.blueprints.id;


--
-- Name: breaks; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.breaks (
    id integer NOT NULL,
    asset_id character varying(50) NOT NULL,
    episode_id integer NOT NULL,
    name character varying(50) NOT NULL,
    break_type character varying(50),
    order_in_episode integer NOT NULL,
    estimated_duration character varying(20),
    actual_duration character varying(20),
    description text,
    sponsor character varying(255),
    status character varying(50),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.breaks OWNER TO showbuild;

--
-- Name: breaks_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.breaks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.breaks_id_seq OWNER TO showbuild;

--
-- Name: breaks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.breaks_id_seq OWNED BY public.breaks.id;


--
-- Name: cue_blocks; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.cue_blocks (
    id integer NOT NULL,
    rundown_item_id integer NOT NULL,
    asset_id character varying(50) NOT NULL,
    slug character varying(100) NOT NULL,
    cue_type character varying(10) NOT NULL,
    "order" integer NOT NULL,
    quote_text text,
    attribution character varying(255),
    media_url character varying(500),
    transcription text,
    duration character varying(10),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    validated boolean,
    validation_errors json,
    meta_data json,
    is_test_data boolean DEFAULT false NOT NULL
);


ALTER TABLE public.cue_blocks OWNER TO showbuild;

--
-- Name: cue_blocks_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.cue_blocks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cue_blocks_id_seq OWNER TO showbuild;

--
-- Name: cue_blocks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.cue_blocks_id_seq OWNED BY public.cue_blocks.id;


--
-- Name: cues; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.cues (
    id integer NOT NULL,
    asset_id character varying(50) NOT NULL,
    segment_id integer NOT NULL,
    element_id integer,
    cue_type public.cuetype NOT NULL,
    name character varying(255) NOT NULL,
    time_offset double precision NOT NULL,
    duration double precision,
    parameters json,
    notes text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.cues OWNER TO showbuild;

--
-- Name: cues_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.cues_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cues_id_seq OWNER TO showbuild;

--
-- Name: cues_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.cues_id_seq OWNED BY public.cues.id;


--
-- Name: elements; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.elements (
    id integer NOT NULL,
    asset_id character varying(50) NOT NULL,
    segment_id integer NOT NULL,
    element_type public.elementtype NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(100) NOT NULL,
    file_path character varying(500),
    file_url character varying(500),
    modifications json,
    duration double precision,
    resolution character varying(50),
    file_size integer,
    quote_text text,
    attribution character varying(255),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.elements OWNER TO showbuild;

--
-- Name: elements_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.elements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.elements_id_seq OWNER TO showbuild;

--
-- Name: elements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.elements_id_seq OWNED BY public.elements.id;


--
-- Name: episode_templates; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.episode_templates (
    id integer NOT NULL,
    episode_number character varying(10) NOT NULL,
    title character varying(200),
    description text,
    episode_metadata json,
    template_id integer,
    status character varying(20) NOT NULL,
    created_by integer,
    organization_id integer,
    file_path character varying(500),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone
);


ALTER TABLE public.episode_templates OWNER TO showbuild;

--
-- Name: episode_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.episode_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.episode_templates_id_seq OWNER TO showbuild;

--
-- Name: episode_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.episode_templates_id_seq OWNED BY public.episode_templates.id;


--
-- Name: episodes; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.episodes (
    id integer NOT NULL,
    asset_id character varying(50) NOT NULL,
    season_id integer NOT NULL,
    episode_number integer,
    title character varying(255) NOT NULL,
    slug character varying(100) NOT NULL,
    publish_date timestamp without time zone,
    air_date timestamp without time zone,
    target_duration integer,
    actual_duration integer,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    status character varying(50),
    is_test_data boolean DEFAULT false NOT NULL,
    guest_name character varying(255),
    guest_bio text,
    guest_website character varying(500),
    template_type character varying(50),
    template_id character varying(50),
    template_name character varying(100),
    duration_formatted character varying(10),
    is_dummy boolean DEFAULT false NOT NULL
);


ALTER TABLE public.episodes OWNER TO showbuild;

--
-- Name: episodes_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.episodes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.episodes_id_seq OWNER TO showbuild;

--
-- Name: episodes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.episodes_id_seq OWNED BY public.episodes.id;


--
-- Name: extracted_quotes; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.extracted_quotes (
    id integer NOT NULL,
    episode_id integer NOT NULL,
    quote_id character varying(50) NOT NULL,
    slug character varying(100) NOT NULL,
    text text NOT NULL,
    attribution character varying(255),
    context text,
    generated_image_path character varying(500),
    image_generated boolean,
    word_count integer,
    character_count integer,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    source_file character varying(500),
    source_line integer,
    is_test_data boolean DEFAULT false NOT NULL
);


ALTER TABLE public.extracted_quotes OWNER TO showbuild;

--
-- Name: extracted_quotes_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.extracted_quotes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.extracted_quotes_id_seq OWNER TO showbuild;

--
-- Name: extracted_quotes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.extracted_quotes_id_seq OWNED BY public.extracted_quotes.id;


--
-- Name: group_roles; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.group_roles (
    group_id integer NOT NULL,
    role_id integer NOT NULL,
    assigned_at timestamp with time zone DEFAULT now(),
    assigned_by character varying(50)
);


ALTER TABLE public.group_roles OWNER TO showbuild;

--
-- Name: groups; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.groups (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    description text,
    is_active boolean,
    color character varying(7),
    organization_id integer NOT NULL,
    auto_assign_new_users boolean,
    settings json,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    created_by character varying(50)
);


ALTER TABLE public.groups OWNER TO showbuild;

--
-- Name: groups_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.groups_id_seq OWNER TO showbuild;

--
-- Name: groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.groups_id_seq OWNED BY public.groups.id;


--
-- Name: link_preview_cache; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.link_preview_cache (
    id integer NOT NULL,
    url text NOT NULL,
    url_hash character varying(64) NOT NULL,
    preview_data json NOT NULL,
    fetched_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone
);


ALTER TABLE public.link_preview_cache OWNER TO showbuild;

--
-- Name: link_preview_cache_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.link_preview_cache_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.link_preview_cache_id_seq OWNER TO showbuild;

--
-- Name: link_preview_cache_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.link_preview_cache_id_seq OWNED BY public.link_preview_cache.id;


--
-- Name: llm_notifications; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.llm_notifications (
    id character varying NOT NULL,
    user_id integer NOT NULL,
    title character varying NOT NULL,
    message text,
    priority character varying,
    notification_type character varying,
    operation_id character varying,
    success boolean,
    read boolean DEFAULT false,
    dismissed boolean DEFAULT false,
    notification_metadata text,
    error text,
    "timestamp" bigint NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.llm_notifications OWNER TO showbuild;

--
-- Name: llm_operations; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.llm_operations (
    id character varying NOT NULL,
    user_id integer NOT NULL,
    scope character varying NOT NULL,
    target_id character varying NOT NULL,
    operation character varying NOT NULL,
    state character varying NOT NULL,
    model character varying,
    message text,
    operation_metadata text,
    priority character varying,
    start_time bigint NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    persistent boolean DEFAULT false
);


ALTER TABLE public.llm_operations OWNER TO showbuild;

--
-- Name: organizations; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.organizations (
    id integer NOT NULL,
    asset_id character varying(50) NOT NULL,
    legal_name character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    settings json,
    name character varying(255),
    trade_name character varying(255),
    organization_type character varying(50),
    industry character varying(100),
    sector character varying(100),
    registration_number character varying(100),
    tax_id character varying(50),
    address_line1 character varying(255),
    address_line2 character varying(255),
    city character varying(100),
    state_province character varying(100),
    postal_code character varying(20),
    country character varying(100) DEFAULT 'United States'::character varying NOT NULL,
    phone character varying(30),
    email character varying(255),
    website character varying(255),
    founded_date timestamp with time zone,
    number_of_employees integer,
    annual_revenue bigint,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    created_by character varying(100),
    notes text,
    is_test_data boolean DEFAULT false NOT NULL
);


ALTER TABLE public.organizations OWNER TO showbuild;

--
-- Name: organizations_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.organizations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.organizations_id_seq OWNER TO showbuild;

--
-- Name: organizations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.organizations_id_seq OWNED BY public.organizations.id;


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.permissions (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    display_name character varying(255) NOT NULL,
    description text,
    resource character varying(50) NOT NULL,
    action character varying(50) NOT NULL,
    scope character varying(50) NOT NULL,
    is_system boolean,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    created_by character varying(50)
);


ALTER TABLE public.permissions OWNER TO showbuild;

--
-- Name: permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.permissions_id_seq OWNER TO showbuild;

--
-- Name: permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.permissions_id_seq OWNED BY public.permissions.id;


--
-- Name: processing_jobs; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.processing_jobs (
    id integer NOT NULL,
    episode_id integer NOT NULL,
    job_type character varying(50) NOT NULL,
    job_id character varying(100) NOT NULL,
    status character varying(20) NOT NULL,
    parameters json,
    result json,
    error_message text,
    progress integer NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    is_test_data boolean DEFAULT false NOT NULL
);


ALTER TABLE public.processing_jobs OWNER TO showbuild;

--
-- Name: processing_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.processing_jobs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.processing_jobs_id_seq OWNER TO showbuild;

--
-- Name: processing_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.processing_jobs_id_seq OWNED BY public.processing_jobs.id;


--
-- Name: prompt_overrides; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.prompt_overrides (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    category character varying(50) NOT NULL,
    operation_key character varying(100) NOT NULL,
    system_prompt text,
    user_prompt_template text,
    is_enabled boolean DEFAULT true NOT NULL,
    notes text,
    created_by character varying(100),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    metadata jsonb,
    suggested_service character varying(50),
    suggested_model character varying(100),
    temperature numeric(3,2),
    max_tokens integer
);


ALTER TABLE public.prompt_overrides OWNER TO showbuild;

--
-- Name: COLUMN prompt_overrides.suggested_service; Type: COMMENT; Schema: public; Owner: showbuild
--

COMMENT ON COLUMN public.prompt_overrides.suggested_service IS 'Suggested LLM service (ollama, openai, anthropic, gemini, etc)';


--
-- Name: COLUMN prompt_overrides.suggested_model; Type: COMMENT; Schema: public; Owner: showbuild
--

COMMENT ON COLUMN public.prompt_overrides.suggested_model IS 'Suggested model name for this operation';


--
-- Name: COLUMN prompt_overrides.temperature; Type: COMMENT; Schema: public; Owner: showbuild
--

COMMENT ON COLUMN public.prompt_overrides.temperature IS 'Suggested temperature override';


--
-- Name: COLUMN prompt_overrides.max_tokens; Type: COMMENT; Schema: public; Owner: showbuild
--

COMMENT ON COLUMN public.prompt_overrides.max_tokens IS 'Suggested max tokens override';


--
-- Name: rbac_audit_log; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.rbac_audit_log (
    id integer NOT NULL,
    action character varying(50) NOT NULL,
    resource_type character varying(50) NOT NULL,
    resource_id integer NOT NULL,
    actor_type character varying(20) NOT NULL,
    actor_id character varying(50) NOT NULL,
    organization_id integer,
    details json,
    ip_address character varying(45),
    user_agent text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.rbac_audit_log OWNER TO showbuild;

--
-- Name: rbac_audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.rbac_audit_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rbac_audit_log_id_seq OWNER TO showbuild;

--
-- Name: rbac_audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.rbac_audit_log_id_seq OWNED BY public.rbac_audit_log.id;


--
-- Name: regions; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.regions (
    id integer NOT NULL,
    asset_id character varying(50) NOT NULL,
    is_test_data boolean NOT NULL,
    rundown_id integer NOT NULL,
    region_type character varying(50) NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    order_in_rundown integer NOT NULL,
    estimated_duration character varying(20),
    actual_duration character varying(20),
    is_collapsible boolean,
    is_collapsed boolean,
    allow_reorder boolean,
    color_theme character varying(50),
    status character varying(50),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.regions OWNER TO showbuild;

--
-- Name: regions_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.regions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.regions_id_seq OWNER TO showbuild;

--
-- Name: regions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.regions_id_seq OWNED BY public.regions.id;


--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.role_permissions (
    role_id integer NOT NULL,
    permission_id integer NOT NULL,
    granted_at timestamp with time zone DEFAULT now(),
    granted_by character varying(50)
);


ALTER TABLE public.role_permissions OWNER TO showbuild;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    description text,
    parent_role_id integer,
    level integer,
    is_system boolean,
    is_active boolean,
    color character varying(7),
    organization_id integer,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    created_by character varying(50)
);


ALTER TABLE public.roles OWNER TO showbuild;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.roles_id_seq OWNER TO showbuild;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: rundown_items; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.rundown_items (
    id integer NOT NULL,
    asset_id character varying(50) NOT NULL,
    rundown_id integer NOT NULL,
    segment_id integer,
    item_type character varying(50) NOT NULL,
    title character varying(255) NOT NULL,
    slug character varying(100) NOT NULL,
    order_in_rundown integer NOT NULL,
    duration character varying(20),
    subtitle character varying(255),
    description text,
    airdate timestamp without time zone,
    guests character varying(500),
    resources text,
    tags character varying(500),
    server_message text,
    link character varying(500),
    priority character varying(50),
    message text,
    status character varying(50),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    is_test_data boolean DEFAULT false NOT NULL,
    script_content text,
    speaker_id integer
);


ALTER TABLE public.rundown_items OWNER TO showbuild;

--
-- Name: rundown_items_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.rundown_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rundown_items_id_seq OWNER TO showbuild;

--
-- Name: rundown_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.rundown_items_id_seq OWNED BY public.rundown_items.id;


--
-- Name: rundown_items_legacy; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.rundown_items_legacy (
    id integer NOT NULL,
    episode_id integer NOT NULL,
    asset_id character varying(50) NOT NULL,
    slug character varying(100) NOT NULL,
    type character varying(20) NOT NULL,
    "order" integer NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    duration character varying(10),
    priority character varying(20),
    status character varying(20) NOT NULL,
    script_content text,
    notes text,
    resources text,
    guests character varying(255),
    tags json,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    file_path character varying(500) NOT NULL,
    is_test_data boolean DEFAULT false NOT NULL
);


ALTER TABLE public.rundown_items_legacy OWNER TO showbuild;

--
-- Name: rundown_items_legacy_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.rundown_items_legacy_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rundown_items_legacy_id_seq OWNER TO showbuild;

--
-- Name: rundown_items_legacy_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.rundown_items_legacy_id_seq OWNED BY public.rundown_items_legacy.id;


--
-- Name: rundowns; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.rundowns (
    id integer NOT NULL,
    asset_id character varying(50) NOT NULL,
    episode_id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    order_in_episode integer,
    estimated_duration character varying(20),
    status character varying(50),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.rundowns OWNER TO showbuild;

--
-- Name: rundowns_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.rundowns_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rundowns_id_seq OWNER TO showbuild;

--
-- Name: rundowns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.rundowns_id_seq OWNED BY public.rundowns.id;


--
-- Name: whiteboard_items; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.whiteboard_items (
    id integer NOT NULL,
    whiteboard_id integer NOT NULL,
    item_type character varying(20) NOT NULL,
    x_position double precision NOT NULL,
    y_position double precision NOT NULL,
    text_content text,
    url text,
    notes text,
    image_data text,
    caption text,
    width integer,
    z_index integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone,
    preview_title text,
    preview_description text,
    preview_image text,
    preview_domain character varying(255),
    preview_favicon text,
    social_metadata json,
    title character varying(200),
    asset_id character varying(50),
    parent_item_id integer,
    is_child boolean DEFAULT false,
    video_url text,
    audio_url text,
    thumbnail_url text,
    html_content text,
    code_content text,
    code_language character varying(50),
    markdown_content text,
    file_url text,
    mime_type character varying(100),
    file_size bigint,
    collapsed boolean DEFAULT false
);


ALTER TABLE public.whiteboard_items OWNER TO showbuild;

--
-- Name: scratchpad_items_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.scratchpad_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.scratchpad_items_id_seq OWNER TO showbuild;

--
-- Name: scratchpad_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.scratchpad_items_id_seq OWNED BY public.whiteboard_items.id;


--
-- Name: whiteboards; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.whiteboards (
    id integer NOT NULL,
    episode_number character varying(10),
    workspace_id character varying(50),
    name character varying(200),
    created_by integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone
);


ALTER TABLE public.whiteboards OWNER TO showbuild;

--
-- Name: scratchpads_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.scratchpads_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.scratchpads_id_seq OWNER TO showbuild;

--
-- Name: scratchpads_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.scratchpads_id_seq OWNED BY public.whiteboards.id;


--
-- Name: scripts; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.scripts (
    id integer NOT NULL,
    asset_id character varying(50) NOT NULL,
    segment_id integer NOT NULL,
    role character varying(50) NOT NULL,
    content text NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.scripts OWNER TO showbuild;

--
-- Name: scripts_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.scripts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.scripts_id_seq OWNER TO showbuild;

--
-- Name: scripts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.scripts_id_seq OWNED BY public.scripts.id;


--
-- Name: seasons; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.seasons (
    id integer NOT NULL,
    asset_id character varying(50) NOT NULL,
    show_id integer NOT NULL,
    name character varying(255) NOT NULL,
    number integer,
    slug character varying(100) NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.seasons OWNER TO showbuild;

--
-- Name: seasons_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.seasons_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seasons_id_seq OWNER TO showbuild;

--
-- Name: seasons_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.seasons_id_seq OWNED BY public.seasons.id;


--
-- Name: segments; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.segments (
    id integer NOT NULL,
    asset_id character varying(50) NOT NULL,
    episode_id integer,
    rundown_type public.rundownitemtype NOT NULL,
    title character varying(255) NOT NULL,
    slug character varying(100) NOT NULL,
    "order" integer NOT NULL,
    description text,
    tags json,
    thumbnail_url character varying(500),
    estimated_duration integer NOT NULL,
    actual_duration integer,
    in_point double precision,
    out_point double precision,
    markers json,
    publishable boolean,
    published_platforms json,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.segments OWNER TO showbuild;

--
-- Name: segments_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.segments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.segments_id_seq OWNER TO showbuild;

--
-- Name: segments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.segments_id_seq OWNED BY public.segments.id;


--
-- Name: settings; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.settings (
    id integer NOT NULL,
    key character varying(100) NOT NULL,
    value json NOT NULL,
    category character varying(50),
    user_id integer,
    description text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.settings OWNER TO showbuild;

--
-- Name: settings_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.settings_id_seq OWNER TO showbuild;

--
-- Name: settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.settings_id_seq OWNED BY public.settings.id;


--
-- Name: shows; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.shows (
    id integer NOT NULL,
    asset_id character varying(50) NOT NULL,
    organization_id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    settings json,
    is_test_data boolean DEFAULT false NOT NULL
);


ALTER TABLE public.shows OWNER TO showbuild;

--
-- Name: shows_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.shows_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.shows_id_seq OWNER TO showbuild;

--
-- Name: shows_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.shows_id_seq OWNED BY public.shows.id;


--
-- Name: sot_processing_jobs; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.sot_processing_jobs (
    id integer NOT NULL,
    temp_job_id character varying(50) NOT NULL,
    episode character varying(10),
    slug character varying(255),
    asset_id character varying(50),
    current_phase character varying(20) DEFAULT 'upload'::character varying NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    job_type character varying(30) DEFAULT 'full_process'::character varying NOT NULL,
    clips_data text,
    error_message text,
    retry_count integer DEFAULT 0 NOT NULL,
    celery_task_id character varying(50),
    working_directory text,
    final_video_path text,
    final_audio_path text,
    final_thumbnail_path text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.sot_processing_jobs OWNER TO showbuild;

--
-- Name: sot_processing_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.sot_processing_jobs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sot_processing_jobs_id_seq OWNER TO showbuild;

--
-- Name: sot_processing_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.sot_processing_jobs_id_seq OWNED BY public.sot_processing_jobs.id;


--
-- Name: speakers; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.speakers (
    id integer NOT NULL,
    name character varying NOT NULL,
    slug character varying NOT NULL,
    wpm double precision DEFAULT 150.0 NOT NULL,
    wpm_min double precision DEFAULT 130.0,
    wpm_max double precision DEFAULT 180.0,
    role character varying DEFAULT 'host'::character varying,
    voice_type character varying,
    language character varying DEFAULT 'en'::character varying,
    accent character varying,
    xtts_speaker_name character varying,
    voice_sample_path character varying,
    is_active boolean DEFAULT true,
    is_test_data boolean DEFAULT false,
    organization_id integer,
    show_id integer,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    user_id integer
);


ALTER TABLE public.speakers OWNER TO showbuild;

--
-- Name: speakers_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.speakers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.speakers_id_seq OWNER TO showbuild;

--
-- Name: speakers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.speakers_id_seq OWNED BY public.speakers.id;


--
-- Name: twitter_oauth_tokens; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.twitter_oauth_tokens (
    id integer NOT NULL,
    user_id integer NOT NULL,
    access_token text NOT NULL,
    refresh_token text,
    token_type character varying(50) DEFAULT 'Bearer'::character varying NOT NULL,
    expires_at timestamp with time zone,
    scope text,
    twitter_user_id character varying(100),
    twitter_username character varying(100),
    twitter_name character varying(200),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone
);


ALTER TABLE public.twitter_oauth_tokens OWNER TO showbuild;

--
-- Name: twitter_oauth_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.twitter_oauth_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.twitter_oauth_tokens_id_seq OWNER TO showbuild;

--
-- Name: twitter_oauth_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.twitter_oauth_tokens_id_seq OWNED BY public.twitter_oauth_tokens.id;


--
-- Name: user_groups; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.user_groups (
    user_id integer NOT NULL,
    group_id integer NOT NULL,
    joined_at timestamp with time zone DEFAULT now(),
    added_by character varying(50)
);


ALTER TABLE public.user_groups OWNER TO showbuild;

--
-- Name: user_permission_overrides; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.user_permission_overrides (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL,
    is_granted boolean NOT NULL,
    resource_type character varying(50),
    resource_id character varying(50),
    granted_at timestamp with time zone DEFAULT now(),
    granted_by character varying(50) NOT NULL,
    expires_at timestamp with time zone,
    reason text
);


ALTER TABLE public.user_permission_overrides OWNER TO showbuild;

--
-- Name: user_permission_overrides_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.user_permission_overrides_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_permission_overrides_id_seq OWNER TO showbuild;

--
-- Name: user_permission_overrides_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.user_permission_overrides_id_seq OWNED BY public.user_permission_overrides.id;


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.user_roles (
    user_id integer NOT NULL,
    role_id integer NOT NULL,
    assigned_at timestamp with time zone DEFAULT now(),
    assigned_by character varying(50),
    expires_at timestamp with time zone
);


ALTER TABLE public.user_roles OWNER TO showbuild;

--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.user_sessions (
    id integer NOT NULL,
    session_token character varying(255) NOT NULL,
    username character varying(50) NOT NULL,
    ip_address character varying(45),
    user_agent text,
    created_at timestamp with time zone DEFAULT now(),
    expires_at timestamp with time zone NOT NULL,
    last_activity timestamp with time zone DEFAULT now(),
    is_active boolean
);


ALTER TABLE public.user_sessions OWNER TO showbuild;

--
-- Name: user_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.user_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_sessions_id_seq OWNER TO showbuild;

--
-- Name: user_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.user_sessions_id_seq OWNED BY public.user_sessions.id;


--
-- Name: user_todos; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.user_todos (
    id integer NOT NULL,
    content text NOT NULL,
    description text,
    priority character varying(20),
    status character varying(20),
    created_by character varying(100),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    completed_at timestamp with time zone
);


ALTER TABLE public.user_todos OWNER TO showbuild;

--
-- Name: user_todos_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.user_todos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_todos_id_seq OWNER TO showbuild;

--
-- Name: user_todos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.user_todos_id_seq OWNED BY public.user_todos.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    hashed_password character varying(255) NOT NULL,
    access_level character varying(20) DEFAULT 'user'::character varying NOT NULL,
    first_name character varying(100),
    last_name character varying(100),
    email character varying(255),
    phone character varying(20),
    profile_picture character varying(500),
    is_active boolean DEFAULT true,
    is_verified boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    last_login timestamp with time zone,
    preferences json DEFAULT '{}'::json,
    organization_id integer,
    is_test_data boolean DEFAULT false NOT NULL
);


ALTER TABLE public.users OWNER TO showbuild;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO showbuild;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: whiteboard_node_links; Type: TABLE; Schema: public; Owner: showbuild
--

CREATE TABLE public.whiteboard_node_links (
    id integer NOT NULL,
    whiteboard_id integer NOT NULL,
    source_item_id integer NOT NULL,
    target_item_id integer NOT NULL,
    relationship_type character varying(50),
    label text,
    color character varying(20) DEFAULT '#1976d2'::character varying,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.whiteboard_node_links OWNER TO showbuild;

--
-- Name: whiteboard_node_links_id_seq; Type: SEQUENCE; Schema: public; Owner: showbuild
--

CREATE SEQUENCE public.whiteboard_node_links_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.whiteboard_node_links_id_seq OWNER TO showbuild;

--
-- Name: whiteboard_node_links_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: showbuild
--

ALTER SEQUENCE public.whiteboard_node_links_id_seq OWNED BY public.whiteboard_node_links.id;


--
-- Name: api_configs id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.api_configs ALTER COLUMN id SET DEFAULT nextval('public.api_configs_id_seq'::regclass);


--
-- Name: api_keys id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.api_keys ALTER COLUMN id SET DEFAULT nextval('public.api_keys_id_seq'::regclass);


--
-- Name: asset_id_pending_messages id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.asset_id_pending_messages ALTER COLUMN id SET DEFAULT nextval('public.asset_id_pending_messages_id_seq'::regclass);


--
-- Name: asset_id_registry id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.asset_id_registry ALTER COLUMN id SET DEFAULT nextval('public.asset_id_registry_id_seq'::regclass);


--
-- Name: asset_id_relationships id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.asset_id_relationships ALTER COLUMN id SET DEFAULT nextval('public.asset_id_relationships_id_seq'::regclass);


--
-- Name: asset_links id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.asset_links ALTER COLUMN id SET DEFAULT nextval('public.asset_links_id_seq'::regclass);


--
-- Name: asset_messages id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.asset_messages ALTER COLUMN id SET DEFAULT nextval('public.asset_messages_id_seq'::regclass);


--
-- Name: asset_pool_files id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.asset_pool_files ALTER COLUMN id SET DEFAULT nextval('public.asset_pool_files_id_seq'::regclass);


--
-- Name: asset_tags id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.asset_tags ALTER COLUMN id SET DEFAULT nextval('public.asset_tags_id_seq'::regclass);


--
-- Name: assets id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.assets ALTER COLUMN id SET DEFAULT nextval('public.assets_id_seq'::regclass);


--
-- Name: blueprint_nodes id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.blueprint_nodes ALTER COLUMN id SET DEFAULT nextval('public.blueprint_nodes_id_seq'::regclass);


--
-- Name: blueprint_templates id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.blueprint_templates ALTER COLUMN id SET DEFAULT nextval('public.blueprint_templates_id_seq'::regclass);


--
-- Name: blueprints id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.blueprints ALTER COLUMN id SET DEFAULT nextval('public.blueprints_id_seq'::regclass);


--
-- Name: breaks id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.breaks ALTER COLUMN id SET DEFAULT nextval('public.breaks_id_seq'::regclass);


--
-- Name: cue_blocks id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.cue_blocks ALTER COLUMN id SET DEFAULT nextval('public.cue_blocks_id_seq'::regclass);


--
-- Name: cues id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.cues ALTER COLUMN id SET DEFAULT nextval('public.cues_id_seq'::regclass);


--
-- Name: elements id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.elements ALTER COLUMN id SET DEFAULT nextval('public.elements_id_seq'::regclass);


--
-- Name: episode_templates id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.episode_templates ALTER COLUMN id SET DEFAULT nextval('public.episode_templates_id_seq'::regclass);


--
-- Name: episodes id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.episodes ALTER COLUMN id SET DEFAULT nextval('public.episodes_id_seq'::regclass);


--
-- Name: extracted_quotes id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.extracted_quotes ALTER COLUMN id SET DEFAULT nextval('public.extracted_quotes_id_seq'::regclass);


--
-- Name: groups id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.groups ALTER COLUMN id SET DEFAULT nextval('public.groups_id_seq'::regclass);


--
-- Name: link_preview_cache id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.link_preview_cache ALTER COLUMN id SET DEFAULT nextval('public.link_preview_cache_id_seq'::regclass);


--
-- Name: organizations id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.organizations ALTER COLUMN id SET DEFAULT nextval('public.organizations_id_seq'::regclass);


--
-- Name: permissions id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.permissions ALTER COLUMN id SET DEFAULT nextval('public.permissions_id_seq'::regclass);


--
-- Name: processing_jobs id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.processing_jobs ALTER COLUMN id SET DEFAULT nextval('public.processing_jobs_id_seq'::regclass);


--
-- Name: rbac_audit_log id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.rbac_audit_log ALTER COLUMN id SET DEFAULT nextval('public.rbac_audit_log_id_seq'::regclass);


--
-- Name: regions id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.regions ALTER COLUMN id SET DEFAULT nextval('public.regions_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: rundown_items id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.rundown_items ALTER COLUMN id SET DEFAULT nextval('public.rundown_items_id_seq'::regclass);


--
-- Name: rundown_items_legacy id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.rundown_items_legacy ALTER COLUMN id SET DEFAULT nextval('public.rundown_items_legacy_id_seq'::regclass);


--
-- Name: rundowns id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.rundowns ALTER COLUMN id SET DEFAULT nextval('public.rundowns_id_seq'::regclass);


--
-- Name: scripts id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.scripts ALTER COLUMN id SET DEFAULT nextval('public.scripts_id_seq'::regclass);


--
-- Name: seasons id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.seasons ALTER COLUMN id SET DEFAULT nextval('public.seasons_id_seq'::regclass);


--
-- Name: segments id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.segments ALTER COLUMN id SET DEFAULT nextval('public.segments_id_seq'::regclass);


--
-- Name: settings id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.settings ALTER COLUMN id SET DEFAULT nextval('public.settings_id_seq'::regclass);


--
-- Name: shows id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.shows ALTER COLUMN id SET DEFAULT nextval('public.shows_id_seq'::regclass);


--
-- Name: sot_processing_jobs id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.sot_processing_jobs ALTER COLUMN id SET DEFAULT nextval('public.sot_processing_jobs_id_seq'::regclass);


--
-- Name: speakers id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.speakers ALTER COLUMN id SET DEFAULT nextval('public.speakers_id_seq'::regclass);


--
-- Name: twitter_oauth_tokens id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.twitter_oauth_tokens ALTER COLUMN id SET DEFAULT nextval('public.twitter_oauth_tokens_id_seq'::regclass);


--
-- Name: user_permission_overrides id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.user_permission_overrides ALTER COLUMN id SET DEFAULT nextval('public.user_permission_overrides_id_seq'::regclass);


--
-- Name: user_sessions id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.user_sessions ALTER COLUMN id SET DEFAULT nextval('public.user_sessions_id_seq'::regclass);


--
-- Name: user_todos id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.user_todos ALTER COLUMN id SET DEFAULT nextval('public.user_todos_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: whiteboard_items id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.whiteboard_items ALTER COLUMN id SET DEFAULT nextval('public.scratchpad_items_id_seq'::regclass);


--
-- Name: whiteboard_node_links id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.whiteboard_node_links ALTER COLUMN id SET DEFAULT nextval('public.whiteboard_node_links_id_seq'::regclass);


--
-- Name: whiteboards id; Type: DEFAULT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.whiteboards ALTER COLUMN id SET DEFAULT nextval('public.scratchpads_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.alembic_version (version_num) FROM stdin;
fa9e1164b041
\.


--
-- Data for Name: api_configs; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.api_configs (id, workflow, category, service, config_key, config_value, is_encrypted, is_enabled, created_at, updated_at) FROM stdin;
32	all	communication	asterisk	amiPort	5038	f	t	2025-10-09 17:50:50.762976+00	2025-10-18 02:36:44.30675+00
5	preproduction	ai_services	grok	base_url	https://api.x.ai/v1	f	t	2025-10-06 17:08:34.772065+00	2025-10-06 17:08:34.772065+00
7	preproduction	ai_services	grok	enabled	true	f	t	2025-10-06 17:08:34.772065+00	2025-10-06 17:08:34.772065+00
9	preproduction	ai_services	openai	base_url	https://api.openai.com/v1	f	t	2025-10-06 17:25:21.041089+00	2025-10-06 17:25:21.041089+00
11	preproduction	ai_services	openai	enabled	true	f	t	2025-10-06 17:25:21.041089+00	2025-10-06 17:25:21.041089+00
13	preproduction	ai_services	gemini	base_url	https://generativelanguage.googleapis.com/v1	f	t	2025-10-06 17:26:28.104596+00	2025-10-06 17:26:28.104596+00
3	preproduction	ai_services	ollama	enabled	true	f	f	2025-10-06 17:03:25.578157+00	2025-10-06 17:03:25.578157+00
15	preproduction	ai_services	gemini	enabled	true	f	t	2025-10-06 17:26:28.104596+00	2025-10-06 17:26:28.104596+00
1	preproduction	ai_services	ollama	host	http://192.168.51.197:11434	f	f	2025-10-06 17:03:25.578157+00	2025-10-18 02:36:44.30675+00
2	preproduction	ai_services	ollama	model	llama3.2	f	f	2025-10-06 17:03:25.578157+00	2025-10-18 02:36:44.30675+00
16	preproduction	ai_services	ollama	project	show-builder	f	f	2025-10-06 17:26:40.58117+00	2025-10-18 02:36:44.30675+00
29	preproduction	ai_services	whisper	enabled	true	f	t	2025-10-07 06:40:52.061323+00	2025-10-07 06:40:52.061323+00
30	preproduction	ai_services	xtts	enabled	true	f	t	2025-10-07 07:00:55.703085+00	2025-10-07 07:00:55.703085+00
4	preproduction	ai_services	grok	api_key	xai-HhTI62WanYSkZrgRlJ4Uy2eOOMmfQoCl06KvvsBDki54BOL2P507Eud0NbVwAYnQzJi55vnBa6eVGYwC	f	t	2025-10-06 17:08:34.772065+00	2025-10-06 17:08:34.772065+00
8	preproduction	ai_services	openai	api_key	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	f	t	2025-10-06 17:25:21.041089+00	2025-10-06 17:25:21.041089+00
12	preproduction	ai_services	gemini	api_key	gen-lang-client-0170294575	f	t	2025-10-06 17:26:28.104596+00	2025-10-06 17:26:28.104596+00
37	all	communication	asterisk	enabled	true	f	t	2025-10-09 17:53:24.453211+00	2025-10-09 17:53:24.453211+00
38	all	communication	asterisk	dial_in_number	+1-802-221-4885	f	t	2025-10-09 19:30:15.855397+00	2025-10-09 19:30:15.855397+00
39	all	transcription	diarization	enabled	true	f	t	2025-10-10 15:39:53.665716+00	2025-10-10 15:39:53.665716+00
34	all	communication	asterisk	amiSecret	ChangeMe_AMI_Admin!	f	t	2025-10-09 17:50:50.762976+00	2025-10-18 02:36:44.30675+00
33	all	communication	asterisk	amiUsername	admin	f	t	2025-10-09 17:50:50.762976+00	2025-10-18 02:36:44.30675+00
35	all	communication	asterisk	conferenceContext	conferences	f	t	2025-10-09 17:50:50.762976+00	2025-10-18 02:36:44.30675+00
31	all	communication	asterisk	host	192.168.51.223	f	t	2025-10-09 17:50:50.762976+00	2025-10-18 02:36:44.30675+00
36	all	communication	asterisk	recordingsPath	/var/spool/asterisk/monitor	f	t	2025-10-09 17:50:50.762976+00	2025-10-18 02:36:44.30675+00
41	all	transcription	diarization	apiKey	gAAAAABo8v083r4kdinHtj9NXXIlC21B4-oKs1m6I6RGV5p17QUfXPLzqVKNvBoou5aArW00SEWLMK6kHSCLkn8uOHmPV7kxQgNRYhPjNtMWZaTebmn_8n9KWyV9mb3JGXuiendNoMss	t	t	2025-10-10 15:39:53.665716+00	2025-10-18 02:36:44.30675+00
42	all	transcription	diarization	timeout	600	f	t	2025-10-10 15:39:53.665716+00	2025-10-18 02:36:44.30675+00
40	all	transcription	diarization	url	https://192.168.51.197/kairo/diarization	f	t	2025-10-10 15:39:53.665716+00	2025-10-18 02:36:44.30675+00
46	preproduction	ai_services	openai	apiKey	gAAAAABo8v08959l2W87XnhYO3nJ2Kcjn8likrFQ2UXrxvG2Ha-_xvp11Iw9feJnk1GGS54G55ByNq7RV16Z_7keddZ5358xjMH_KEJnj2A69gwpS9FKgMbqT8uFIqNqlKoRX_MjutOtCnD0qHQJSa3BPJEhNrCTh4RQoqLRanfZiVkcyDm1dT1tGP5VCl3b4zzGN5yD1q_g214JO3Ms35FHLaTVK5nbQU2K9WyPNfUcgBIKFSfPS_nvaO2t_k1iwDuxNsYuoyB9_uzgVB34YGbgXzcfCD0HrX66CtakdxLoYPGOKAkVgB0=	t	t	2025-10-13 09:08:35.260331+00	2025-10-18 02:36:44.30675+00
47	preproduction	ai_services	openai	baseUrl	https://api.openai.com/v1	f	t	2025-10-13 09:08:35.260331+00	2025-10-18 02:36:44.30675+00
21	preproduction	ai_services	whisper	endpoint	/v1/audio/transcriptions	f	t	2025-10-07 06:34:28.071694+00	2025-10-18 02:36:44.30675+00
20	preproduction	ai_services	whisper	host	http://192.168.51.197:8887	f	t	2025-10-07 06:34:28.071694+00	2025-10-18 02:36:44.30675+00
23	preproduction	ai_services	xtts	endpoint	/v1/audio/speech	f	t	2025-10-07 06:34:28.071694+00	2025-10-18 02:36:44.30675+00
22	preproduction	ai_services	xtts	host	http://192.168.51.197:5001	f	t	2025-10-07 06:34:28.071694+00	2025-10-18 02:36:44.30675+00
24	preproduction	ai_services	xtts	language	en	f	t	2025-10-07 06:34:28.071694+00	2025-10-18 02:36:44.30675+00
26	preproduction	ai_services	xtts	speaker	onyx	f	t	2025-10-07 06:34:28.071694+00	2025-10-18 02:36:44.30675+00
25	preproduction	ai_services	xtts	speed	1	f	t	2025-10-07 06:34:28.071694+00	2025-10-18 02:36:44.30675+00
69	preproduction	storage	aws	bucket		f	f	2025-10-13 09:08:35.260331+00	2025-10-18 02:36:44.30675+00
245	promotion	social_media	twitter	accessToken	gAAAAABo8v08vJhs5uDgkMbEQYvTR0QZb7UhAggra2g_U1vpox9k6-YRli-tNSlH5j2GV-5Vu2x_WrZZLETZvxnbqqf5Oh6lJnR1hFVfKg4_DW-f00EBzHPh0cNU-E25Z14E1zv-zOVAMA5rKr8bgBjmu7JM5MUeKg==	t	t	2025-10-18 02:29:10.52842+00	2025-10-18 02:36:44.30675+00
14	preproduction	ai_services	gemini	model	gemini-pro	f	t	2025-10-06 17:26:28.104596+00	2025-10-18 02:36:44.30675+00
19	preproduction	ai_services	gemini	project	show-builder	f	t	2025-10-06 17:26:40.58117+00	2025-10-18 02:36:44.30675+00
55	preproduction	ai_services	grok	apiKey	gAAAAABo8v08qF6obv2KQ-TXKAt4hb4tycurxCBKrqgY63CaaKJVj6dnXwb_OUpW9BIDZFL_Bf-gV0yGYSiIjnEeZvEejNDPuNZuGwxmQwOCu1ShzSnhZgsGE3JgHc8mtv-UaWBifzKHlpTEgQ5pfT9nDehqZUciOqNl5Bb5cRuy14p7Hi8CHblnoYFlpb_FqrVdMmx5Nv3s	t	t	2025-10-13 09:08:35.260331+00	2025-10-18 02:36:44.30675+00
56	preproduction	ai_services	grok	baseUrl	https://api.x.ai/v1	f	t	2025-10-13 09:08:35.260331+00	2025-10-18 02:36:44.30675+00
6	preproduction	ai_services	grok	model	grok-4-latest	f	t	2025-10-06 17:08:34.772065+00	2025-10-18 02:36:44.30675+00
17	preproduction	ai_services	grok	project	show-builder	f	t	2025-10-06 17:26:40.58117+00	2025-10-18 02:36:44.30675+00
10	preproduction	ai_services	openai	model	gpt-4o	f	t	2025-10-06 17:25:21.041089+00	2025-10-18 02:36:44.30675+00
18	preproduction	ai_services	openai	project	show-builder	f	t	2025-10-06 17:26:40.58117+00	2025-10-18 02:36:44.30675+00
59	preproduction	ai_services	stabilityAi	apiKey		t	f	2025-10-13 09:08:35.260331+00	2025-10-18 02:36:44.30675+00
72	preproduction	communication	discord	botToken		t	f	2025-10-13 09:08:35.260331+00	2025-10-18 02:36:44.30675+00
73	preproduction	communication	discord	webhookUrl		t	f	2025-10-13 09:08:35.260331+00	2025-10-18 02:36:44.30675+00
70	preproduction	communication	slack	botToken		t	f	2025-10-13 09:08:35.260331+00	2025-10-18 02:36:44.30675+00
71	preproduction	communication	slack	webhookUrl		t	f	2025-10-13 09:08:35.260331+00	2025-10-18 02:36:44.30675+00
74	preproduction	communication	twilio	accountSid		f	f	2025-10-13 09:08:35.260331+00	2025-10-18 02:36:44.30675+00
75	preproduction	communication	twilio	authToken		t	f	2025-10-13 09:08:35.260331+00	2025-10-18 02:36:44.30675+00
66	preproduction	storage	aws	accessKeyId		f	f	2025-10-13 09:08:35.260331+00	2025-10-18 02:36:44.30675+00
68	preproduction	storage	aws	region		f	f	2025-10-13 09:08:35.260331+00	2025-10-18 02:36:44.30675+00
67	preproduction	storage	aws	secretAccessKey		t	f	2025-10-13 09:08:35.260331+00	2025-10-18 02:36:44.30675+00
144	promotion	social_media	twitter	enabled	true	f	t	2025-10-16 05:57:19.287339+00	2025-10-16 05:57:19.287339+00
251	all	communication	asterisk	dialInNumber	+1-802-221-4885	f	t	2025-10-18 02:34:44.621292+00	2025-10-18 02:36:44.30675+00
50	preproduction	ai_services	anthropic	apiKey		t	f	2025-10-13 09:08:35.260331+00	2025-10-18 02:36:44.30675+00
60	preproduction	ai_services	elevenLabs	apiKey		t	f	2025-10-13 09:08:35.260331+00	2025-10-18 02:36:44.30675+00
51	preproduction	ai_services	gemini	apiKey	gAAAAABo8v0806Ws0olfysOPwCj9X3R2d4Zw7yWGRMVQkNxY0wI7YRGP8GknWQgNIgcjb51USbTSV7hd1zfo92XMiSFvBI32uhWzC-ylHHJBCUoiTsbK2A4=	t	t	2025-10-13 09:08:35.260331+00	2025-10-18 02:36:44.30675+00
52	preproduction	ai_services	gemini	baseUrl	https://generativelanguage.googleapis.com/v1	f	t	2025-10-13 09:08:35.260331+00	2025-10-18 02:36:44.30675+00
65	preproduction	storage	google	calendarEnabled	false	f	f	2025-10-13 09:08:35.260331+00	2025-10-18 02:36:44.30675+00
61	preproduction	storage	google	clientId		f	f	2025-10-13 09:08:35.260331+00	2025-10-18 02:36:44.30675+00
62	preproduction	storage	google	clientSecret		t	f	2025-10-13 09:08:35.260331+00	2025-10-18 02:36:44.30675+00
64	preproduction	storage	google	driveEnabled	true	f	f	2025-10-13 09:08:35.260331+00	2025-10-18 02:36:44.30675+00
119	preproduction	storage	google	episodesFolderId	1HTCcvGD52kyvrZ9bGi8MoAyWWnciunol	f	f	2025-10-15 04:44:21.199234+00	2025-10-18 02:36:44.30675+00
63	preproduction	storage	google	serviceAccount	gAAAAABo8v0845tVa9JM5uwSM0J8TKgb_OL0bMneZ5WPF6ndWIXFCgnZXs43JxX5hwbA6k4bZuq7M7dEjHUlbpdpousmFKBTM3zl1eOSMLHx45R9STerCpjtkWOGVTjzGOzHeI21pN7UrV5XuGTWLrdD3qlPsjjE-NNnHTT4Wbt9cAq5aOXDfwXyP4fnzmfUPKz5Ho_MwhFzB8dKyfHUwSDsH9PrLGYtVQ_9rqME0YKPKTgqZ6s5ouALg__FpG3xedJxME5SiGaD5KtxHBYu5i36dbXjp0mpRVfSRh28oZxhzNocE2Lp-GBPzyhgfKFGfATIObfdNnvvBNkCsa_yITewi88xEAqrdeJNqsn-If06yz55NCBNbnGPV-R73jrhQVpOLLDaFxelQ6u8ZvayyWG7EgQRqRfGPX450xLVl7gAW8rENPsR5u8zkoehmmEfY1d4Uo8AH-w1otA18YqpTPRorYxIuZM1sTBR_3JUbI-qyv_1hYvEg5Z2RHfT7MRTfuvBzpNnedY_Och973vISlt3aOK5hJWiOAMFod8V8Y1qetMmJ37Xvlkd2trivhs2mCwoqnz2VMX99kcFXQFbaHOdbTUsMWYuOPDdOC2TxUyqGCb-E7D0B-ygL1g1hl9r9-CZTAyR1A65Ub34OPly98ORzp5OdLrqtKOnmpWmfhe-M-D2CxO8EENIWw9LifYiNftxJoL7M4vpwk-C2QnIkclgFKuKdxAJjeRBFMJMQmSf5UdNQEmH5qEJfVJ7FwTBe1Q6dKK2B0PMO1RAUYbtT8vxtHOSarqUz9rloshxR2wEwaIglyyRnInW2IXTIbteZyrnYqRGYc9G2vuChWxwxxbVXeWQTFYRcfooHebIDOtqHVIZR_DzZcoRZP8ASMe1r0OuQB6XQQOX26okM3_PseNT1YVwolbPYoM267YtdgQfMLXOkwc9ZO9AbTEseGOxdLLca2jj-ok7XVXs2SZqV3r9Dgj9C-cFdamqRE9lLo1c1PEZJFkNn1IFX2wlDl2cc092K4EYZT_Fw-5BYearpP5DSDL_3hFO19vEKaHo79aqv7YYpI0VKcmSJKiTh4-nIppJEuy_KXSwUakBx5IUBho5dmjflTiGjk7HJ38e4hTU3VYHAAeMdEZDmeHKckKU-2Js5ulSeikyo86g0eBePv6Wa9zy5clZmZ57bSFxTA3gkMEjRRMQx-o-nS3yXOSqMgAjenEJJvOU86NaA-xOlHD0xTgXe4Tu-1IZbiMB9OqIqSmzq-w1Oy6chGpt3TpkSM1d0nw8fnU9PpdWcRyZX9MU5ej0LksqbV7MGEdrW3ns5_WkgJ4AbV7XIqnuRinM9VYK7scI0ME5Cj6dALsYiU0OXRXfwlgVIQt9IN-t6z6mhWsMtnKV7_hpkE_HM4XTZh7_QPQQSBcC91yjEmIOpDttDkXMTHsWgmrDfb3FDgpsCum-cO_D5eIMO7lNxvyrcmW2LJRKtsr7QL9Bm-MHSapCyuQDU_Ms2Sge7X3F6fsRp0_YoCXLrCaibW_R9GCT2gVAr2bHoevU0Ug4UMnj15NJfKgZC4fX4Vkd2TnWcd8SOoMzDrXS5O0PmM_ShwvMN9vE2x90R4UJ8eq66iD7GGzFp0kFMLixlG14UposhTSuV9cPkDRMqcE-3CAbHsgwte7TDErSfvVYN4ehEZLik2sf6RBYhsYWwxz36_LEbuZ3Js28-nI54vbVnFc_T7b7vbOO18ayrrOJ_wy7OhOzoBHcLY1LZTYRKxtd2xEzxfZ8SkiMouc_aQbxS9FQiyIhfE2OUPVvUC-B8QO1j773yuBgVB_hGnzJyyoC2sJ_e4FYaaIkF2gm_QARxiUPSANa8jAaWgC70XmCENQXW-zKGY3jEI38A3aKQtxp89_Y04nukBxUQ-CV7948dgrvWvYcAPBgvIylGhGJw5j34kNNEIhSjKscNwnU8LexorjBeBwwgcnm1Hc_y0xoaU24K3zIjKi5QPhF6-6UYSPT894zb2fptoAZsVsxoTBdmMdUhegGxKOE_pM8sABse412aJl0FXH0r-bzpdk4mPMA-KICEC7oiqNigY8Pp8k8VI2q66r0hOi9zXuM3mAhlpV201FW2OBugvu_4aKYfqHN-70ZrMy44ZP-TYN7aNP1FGGrKH0F79iLNCQYQ9Wg2hnXp2CBFM74E-aqAxy6wdRtvJJj6sDyv5W4syywbcRGIUhAgEcU-Dlajsk96Ib0AU6JXBd_El-gOsRrBXAr0UsWbXIBKTELKm4XZ22I-5ej2vx1EDS3NG4RAVUJqh6R6Rcv_RTeCtpRMjeRbcuyn5fE2373s75tyzYO8Cj-JBji4KXpBHt6VQw4AFSdhNtpPkEtoKYc_WCYWSreM0nRPOk0PQFFxwWh-dizaGCbqxvfDNID5bmVy9sNXbLdcrXwVcX16gDhs7x028GqKfv7V1WxBJDRbOlUZhQ8JRuhEJWLX8IxGARP_z_X5X_FeqXltfY0nCucq7JHQjDuZq-CT8XBCaLGQFM3oJwdCZCIK7IaCLKKQe2FnSQPjwE0P-FEW51SrC3SE9B15MMPokYRv0WdCqpXSxj_CApYo6MaC4w0e60YrvCzCkaFLA6v1znl9K3O2vY_o4NHOZ-yo9H5RPPRGZ_wEasApjTewbKlzivpnRU8qSy__xM2ZECKVen-cEBA51_TsgxlPYBV0hjx0KUERgiNSrhEofUxNTOqIWYtVJQTTFK3AwUzZjLFsLvyBJUodimQ2AsYPHBbr45O-Mb8X7zAarU6Rzri5ajTG7ykKvc6-lhIpjPAWP59GdFGr4KsOsxd1BX4tsJwQGM8gQi1Y4YOif1zvZuggqT88U-fd8KA5HW9pCQgD40jqo8GjYhwAJO0U05A0qwkIe-_Yn1fWnger1Mz5G08AMZ_qoMF6sE2z0nbk8YK7QD8hfGJZcOnivIGpEOCQEqNPxeMBmD6dKl7z6lPadmVjf0PFeSiK6iY1tgPFHstsi82GJbtqGfIcsr1ZjLRzFqDDPbOxwVIfCx3-VgwyvOdExnSwThqCy_RAPCa6LEEwUHZQXLjNzLzSYeYXzsEsKg3C9-dtdnqehyK0CY6XzTyEnmQ9lN6LhM-PE4vqLAcXYX1sm7wguWtTNfY5KCRwm--oH1kJnxhQ4a8_q9wz86JiJxlztaTwxUHa3-MmjaVMSpoJsFXZaRPaChFqn6iLUUb5dHfXz17vsLgdQevKBeBzO4upIgqlrNOgr0GbDcWrDz51Ac=	t	f	2025-10-13 09:08:35.260331+00	2025-10-18 02:36:44.30675+00
143	promotion	social_media	twitter	bearerToken	AAAAAAAAAAAAAAAAAAAAAM3f0QEAAAAAX1F6RcUHCEein4CClSkIab7MwmQ%3DR8gZ9BZL42yGBZyqXkCvRtfU1VzXXhpTuezSZIb5Pz9bEse0CC	f	t	2025-10-16 05:57:19.287339+00	2025-10-16 16:31:24.156817+00
81	preproduction	communication	asterisk	amiPort	5038	f	f	2025-10-13 09:08:35.260331+00	2025-10-18 02:36:44.30675+00
83	preproduction	communication	asterisk	amiSecret		f	f	2025-10-13 09:08:35.260331+00	2025-10-18 02:36:44.30675+00
82	preproduction	communication	asterisk	amiUsername		f	f	2025-10-13 09:08:35.260331+00	2025-10-18 02:36:44.30675+00
84	preproduction	communication	asterisk	conferenceContext	conferences	f	f	2025-10-13 09:08:35.260331+00	2025-10-18 02:36:44.30675+00
80	preproduction	communication	asterisk	host		f	f	2025-10-13 09:08:35.260331+00	2025-10-18 02:36:44.30675+00
85	preproduction	communication	asterisk	recordingsPath	/var/spool/asterisk/monitor	f	f	2025-10-13 09:08:35.260331+00	2025-10-18 02:36:44.30675+00
78	preproduction	communication	email	apiKey		t	f	2025-10-13 09:08:35.260331+00	2025-10-18 02:36:44.30675+00
79	preproduction	communication	email	fromEmail		f	f	2025-10-13 09:08:35.260331+00	2025-10-18 02:36:44.30675+00
77	preproduction	communication	email	provider		f	f	2025-10-13 09:08:35.260331+00	2025-10-18 02:36:44.30675+00
76	preproduction	communication	twilio	phoneNumber		f	f	2025-10-13 09:08:35.260331+00	2025-10-18 02:36:44.30675+00
194	promotion	social_media	twitter	apiKey	gAAAAABo8v08YKa6WMNNETS4JOImjL3bEniIXo-iScPoFfhWYJ_cnwc2uL94GzXwnMKmx6ShKgPKFMWBBxjgge-qW0eKaEH8P0W-HpzZGSbFx8oW-9XUEQ8=	t	t	2025-10-16 07:56:12.812148+00	2025-10-18 02:36:44.30675+00
193	promotion	social_media	twitter	apiSecret	gAAAAABo8v08paET_tm5ahB3nyjG-P42ohYk_PaYDkvHl-OiH3qvH0spvFflGMNaqtXTjRHi0MSAVPFywhGs654KBjqxmoWQtXXYc0YVxTd3X1iXr4EOHr-bUMY8AFGjtFtN3GFNycIOeaa11sjUOc6Wd-t1gmtdIQ==	t	t	2025-10-16 07:56:12.812148+00	2025-10-18 02:36:44.30675+00
246	promotion	social_media	twitter	accessTokenSecret	CQW65PFDDwPIj7WWRJ4LX22ax6o1fGGZfyhaTERvwKshJ	f	t	2025-10-18 02:29:10.52842+00	2025-10-18 02:36:44.30675+00
88	promotion	social_media	vimeo	accessToken		t	f	2025-10-13 09:08:35.260331+00	2025-10-18 02:36:44.30675+00
86	promotion	social_media	youtube	apiKey		t	f	2025-10-13 09:08:35.260331+00	2025-10-18 02:36:44.30675+00
87	promotion	social_media	youtube	clientId		f	f	2025-10-13 09:08:35.260331+00	2025-10-18 02:36:44.30675+00
\.


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.api_keys (id, key_hash, key_prefix, client_name, access_level, created_by_username, is_active, created_at, updated_at, last_used, expires_at, usage_count) FROM stdin;
6	thkYqftnji5NZC4w8htatupxJAVII5XKOSgc09Mjgh0	thkYqftn	rbac-test	admin	system	t	2025-08-30 06:22:36.39964+00	2025-08-30 06:23:24.590227+00	2025-08-30 06:23:24.59094+00	\N	2
1	MMRwCQVY8JoK5Z0KlCV7gL30oSEHTb6rOUx5kdlPIXI	MMRwCQVY	rbac-test	admin	system	t	2025-08-13 12:59:51.692531+00	2025-08-13 13:00:39.753136+00	2025-08-13 13:00:39.753443+00	\N	8
2	qguC1QhH2b75BJsrWcdoq8Iks0aYBF9RAWKDF4_oPrw	qguC1QhH	rbac-test	admin	system	t	2025-08-16 15:36:44.8043+00	2025-08-16 15:41:40.806279+00	2025-08-16 15:41:40.806708+00	\N	5
7	yf3QE6TPhIp5iecAJ13j0BmLYx3dxBgnfdGvkXu2Gh4	yf3QE6TP	rbac-test	admin	system	t	2025-08-30 12:22:43.139324+00	2025-08-30 12:40:28.159783+00	2025-08-30 12:40:28.160218+00	\N	10
10	Pj1Pf5R2TKxRvDNe_W_d6MLcqb7yBcO090KYPfyiipE	Pj1Pf5R2	rbac-test	admin	system	t	2025-09-27 12:42:00.973991+00	2025-09-27 13:26:38.371664+00	2025-09-27 13:26:38.372376+00	\N	11
14	_dIw2vjZK-U8VEug7zp6ZFOYsaKsoL6NnVx3AFshnKE	_dIw2vjZ	rbac-test	admin	system	t	2025-10-02 08:59:33.478057+00	2025-10-02 09:06:28.181033+00	2025-10-02 09:06:28.181481+00	\N	3
8	nSudN-zXynaRm04RXTJJBeZi0OZNGMf9dtxlm1fKLNY	nSudN-zX	content-editor	service	dev	t	2025-08-30 14:11:28.440056+00	2025-10-19 18:02:20.622038+00	2025-10-19 18:02:20.623473+00	\N	6325
4	eSrLKf90bDdXpNGSPo7rgh_J0vawzIob2eR4xlGjl74	eSrLKf90	rbac-test	admin	system	t	2025-08-23 20:09:53.380378+00	2025-08-23 20:09:58.31753+00	2025-08-23 20:09:58.317936+00	\N	1
13	FDT5WyO7S2DbBifbDUEsd1H8cmZTT3_qpJXtb3c7qaY	FDT5WyO7	rbac-test	admin	system	t	2025-09-30 10:23:39.71107+00	2025-10-19 18:04:24.966939+00	2025-10-19 18:04:24.967349+00	\N	463
9	wwmh8gaDpVDuc9Zn4NPgiZDOuwfxTKFOGU1kU2Jp8GQ	wwmh8gaD	rbac-test	admin	system	t	2025-09-02 07:36:37.861985+00	2025-09-02 10:00:36.433215+00	2025-09-02 10:00:36.43377+00	\N	7
5	_gJC_OcJvWVbEINXBBHf_Fs5PmBe4aWUEGTOGoXUePM	_gJC_OcJ	rbac-test	admin	system	t	2025-08-29 23:32:33.912908+00	\N	\N	\N	0
3	jWKdST7VA59rdKqPeAO6E0Zjqc5f4HqeemsM11YG5JQ	jWKdST7V	rbac-test	admin	system	t	2025-08-16 16:30:22.771685+00	2025-08-30 01:36:05.870897+00	2025-08-30 01:36:05.876263+00	\N	119
11	E5xs3NhZf5zs21V55w7HZwSG2GHDOaW2AmYzbFp9iE0	E5xs3NhZ	rbac-test	admin	system	t	2025-09-27 17:33:07.178982+00	2025-09-27 18:32:28.734158+00	2025-09-27 18:32:28.73459+00	\N	27
12	5dm-CCEB5FOdUgmw1W3w2Lw1L5krk_wRqM4yUWBo6NA	5dm-CCEB	rbac-test	admin	system	t	2025-09-30 09:51:13.397077+00	2025-09-30 09:52:51.035246+00	2025-09-30 09:52:51.035757+00	\N	3
\.


--
-- Data for Name: asset_id_pending_messages; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.asset_id_pending_messages (id, pending_asset_id, message_type, content, priority, created_by, created_at, delivered, delivered_at, expires_at, context) FROM stdin;
\.


--
-- Data for Name: asset_id_registry; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.asset_id_registry (id, asset_id, entity_type, entity_table, entity_id, request_reason, request_context, requested_by, created_at, initial_links, is_active, meta_data, notes) FROM stdin;
1	EPSMEEFA0DTJNAYVN	episode	\N	\N	create	{"slug": "test-episode", "cue_type": null, "episode_number": 123, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 15:39:10.67386+00	[]	active	{}	\N
2	SEGMEEFAFL4C5RT2B	segment	\N	\N	create	{"slug": "test-segment", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 15:39:30.280946+00	[{"asset_id": "EPSMEEFA0DTJNAYVN", "link_type": "parent_child"}]	active	{}	\N
3	CUEMEEFALU37XGFSZ	cue	\N	\N	create	{"slug": "sot-cue-1", "cue_type": "SOT", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 15:39:38.380119+00	[{"asset_id": "SEGMEEFAFL4C5RT2B", "link_type": "parent_child"}]	active	{}	\N
4	CUEMEEFBKP63U781E	cue	\N	\N	create	{"slug": "test-gfx-cue", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 15:40:23.563499+00	[{"asset_id": "SEGMEEFAFL4C5RT2B", "link_type": "parent_child"}]	active	{}	\N
5	ASTMEEFD8AX520WY1	ad	\N	\N	create	{"slug": "sponsor-message-1", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 15:41:40.810334+00	[]	active	{}	\N
6	CUEMEEH6LU3HLV29L	cue	\N	\N	create	{"slug": "test", "cue_type": "test", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 16:32:30.987611+00	[]	active	{}	\N
8	EPSMEEJ32D9UFK5BU	episode	\N	\N	create	{"slug": "", "cue_type": null, "episode_number": 236, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:25:45.106883+00	[]	active	{}	\N
9	SEGMEEJ3TNWZ5IUEO	segment	\N	\N	create	{"slug": "news updates", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:26:20.397103+00	[]	active	{}	\N
10	SEGMEEJ3YD0OKZM7D	segment	\N	\N	create	{"slug": "Biltong", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:26:26.486972+00	[]	active	{}	\N
11	SEGMEEJ44L61P9LZV	segment	\N	\N	create	{"slug": "man up", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:26:34.556472+00	[]	active	{}	\N
12	SEGMEEJ4JNYVA02T4	segment	\N	\N	create	{"slug": "Support our work", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:26:54.096722+00	[]	active	{}	\N
13	SEGMEEJ56401DC7UN	segment	\N	\N	create	{"slug": "borderline wild", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:27:23.186441+00	[]	active	{}	\N
14	SEGMEEJ5H1D9I4K1D	segment	\N	\N	create	{"slug": "potpourri", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:27:37.347295+00	[]	active	{}	\N
15	CUEMEEJFS6N0Y6BVP	cue	\N	\N	create	{"slug": "vigilante-tube", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:35:38.353619+00	[{"asset_id": "SEGMEEJ3TNWZ5IUEO", "link_type": "parent_child"}]	active	{}	\N
16	CUEMEEJFW5OXH49CV	cue	\N	\N	create	{"slug": "a group of", "cue_type": "FSQ", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:35:43.502736+00	[{"asset_id": "SEGMEEJ3TNWZ5IUEO", "link_type": "parent_child"}]	active	{}	\N
17	CUEMEEJFZ1B48GJAV	cue	\N	\N	create	{"slug": "the clip shows", "cue_type": "FSQ", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:35:47.233777+00	[{"asset_id": "SEGMEEJ3TNWZ5IUEO", "link_type": "parent_child"}]	active	{}	\N
18	CUEMEEJG1BTTZ9RKK	cue	\N	\N	create	{"slug": "The BTP are", "cue_type": "FSQ", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:35:50.203806+00	[{"asset_id": "SEGMEEJ3TNWZ5IUEO", "link_type": "parent_child"}]	active	{}	\N
19	CUEMEEJG43IE9XE52	cue	\N	\N	create	{"slug": "holly-pictures", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:35:53.792435+00	[{"asset_id": "SEGMEEJ3TNWZ5IUEO", "link_type": "parent_child"}]	active	{}	\N
20	CUEMEEJG6CVN16KFJ	cue	\N	\N	create	{"slug": "cincy-black-leaders", "cue_type": "SOT", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:35:56.721694+00	[{"asset_id": "SEGMEEJ3TNWZ5IUEO", "link_type": "parent_child"}]	active	{}	\N
21	CUEMEEJG9AV3QQNDK	cue	\N	\N	create	{"slug": "walter-tweet", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:36:00.53746+00	[{"asset_id": "SEGMEEJ3TNWZ5IUEO", "link_type": "parent_child"}]	active	{}	\N
22	CUEMEEJGLF9OYQXZC	cue	\N	\N	create	{"slug": "male-cheerleaders", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:36:16.247519+00	[{"asset_id": "SEGMEEJ44L61P9LZV", "link_type": "parent_child"}]	active	{}	\N
23	CUEMEEJGNHIAMNDQO	cue	\N	\N	create	{"slug": "dance-like-girl", "cue_type": "SOT", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:36:18.920579+00	[{"asset_id": "SEGMEEJ44L61P9LZV", "link_type": "parent_child"}]	active	{}	\N
24	CUEMEEJGPMGOLLC0T	cue	\N	\N	create	{"slug": "colin-wright-poll", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:36:21.690777+00	[{"asset_id": "SEGMEEJ44L61P9LZV", "link_type": "parent_child"}]	active	{}	\N
25	CUEMEEJGRSTM36X2K	cue	\N	\N	create	{"slug": "billboard-chris-tweet", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:36:24.511574+00	[{"asset_id": "SEGMEEJ44L61P9LZV", "link_type": "parent_child"}]	active	{}	\N
26	CUEMEEJGUC9SV6YC8	cue	\N	\N	create	{"slug": "john-connor-tweet", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:36:27.804037+00	[{"asset_id": "SEGMEEJ44L61P9LZV", "link_type": "parent_child"}]	active	{}	\N
27	CUEMEEJGWBU9O8PJZ	cue	\N	\N	create	{"slug": "brad-polumbo", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:36:30.380586+00	[{"asset_id": "SEGMEEJ44L61P9LZV", "link_type": "parent_child"}]	active	{}	\N
28	CUEMEEJGZ5BR5TNAN	cue	\N	\N	create	{"slug": "prisha-mosley", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:36:34.033802+00	[{"asset_id": "SEGMEEJ44L61P9LZV", "link_type": "parent_child"}]	active	{}	\N
29	CUEMEEJH18K27GCUJ	cue	\N	\N	create	{"slug": "what-youre-saying", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:36:36.74315+00	[{"asset_id": "SEGMEEJ44L61P9LZV", "link_type": "parent_child"}]	active	{}	\N
30	CUEMEEJH39UTHDQPZ	cue	\N	\N	create	{"slug": "when-you-start", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:36:39.380936+00	[{"asset_id": "SEGMEEJ44L61P9LZV", "link_type": "parent_child"}]	active	{}	\N
31	CUEMEEJH5L5EJ0QLB	cue	\N	\N	create	{"slug": "i-couldnt-disagree", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:36:42.379902+00	[{"asset_id": "SEGMEEJ44L61P9LZV", "link_type": "parent_child"}]	active	{}	\N
291	ASTMFT48660I4ZUKA	break	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:06:03.958468+00	[]	active	{}	\N
292	ASTMFT4866JZS6SZA	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:06:03.971127+00	[]	active	{}	\N
32	CUEMEEJH851KUTI9Z	cue	\N	\N	create	{"slug": "this-way-of-thinking", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:36:45.688006+00	[{"asset_id": "SEGMEEJ44L61P9LZV", "link_type": "parent_child"}]	active	{}	\N
33	CUEMEEJHAGOJO5MHZ	cue	\N	\N	create	{"slug": "why-not", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:36:48.698898+00	[{"asset_id": "SEGMEEJ44L61P9LZV", "link_type": "parent_child"}]	active	{}	\N
34	CUEMEEJHCIJ9X84QX	cue	\N	\N	create	{"slug": "i-kept-seeing", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:36:51.35736+00	[{"asset_id": "SEGMEEJ44L61P9LZV", "link_type": "parent_child"}]	active	{}	\N
35	CUEMEEJHEY901HMCU	cue	\N	\N	create	{"slug": "when-you-were", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:36:54.515804+00	[{"asset_id": "SEGMEEJ44L61P9LZV", "link_type": "parent_child"}]	active	{}	\N
36	CUEMEEJHIMKMC68FC	cue	\N	\N	create	{"slug": "if-it-was", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:36:59.278997+00	[{"asset_id": "SEGMEEJ44L61P9LZV", "link_type": "parent_child"}]	active	{}	\N
37	CUEMEEJHWMROXL1L8	cue	\N	\N	create	{"slug": "pdx-real", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:37:17.429394+00	[{"asset_id": "SEGMEEJ56401DC7UN", "link_type": "parent_child"}]	active	{}	\N
38	CUEMEEJHZTQUO2VE3	cue	\N	\N	create	{"slug": "karen-denver", "cue_type": "SOT", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:37:21.567228+00	[{"asset_id": "SEGMEEJ56401DC7UN", "link_type": "parent_child"}]	active	{}	\N
39	CUEMEEJJ87VW7XCBR	cue	\N	\N	create	{"slug": "cookie-dough", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 17:38:19.10189+00	[{"asset_id": "SEGMEEJ5H1D9I4K1D", "link_type": "parent_child"}]	active	{}	\N
40	SEGMEENCPXQ375N35	segment	\N	\N	create	{"slug": "slocum consulting", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 19:25:14.018786+00	[]	active	{}	\N
41	CUEMEEND27OHTCFXG	cue	\N	\N	create	{"slug": "Support Disaffected.com", "cue_type": "ADLIB", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 19:25:29.845127+00	[{"asset_id": "SEGMEENCPXQ375N35", "link_type": "parent_child"}]	active	{}	\N
42	CUEMEENDH3XSJ7GMN	cue	\N	\N	create	{"slug": "Support Disaffected.com", "cue_type": "ADLIB", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 19:25:49.151458+00	[{"asset_id": "SEGMEEJ4JNYVA02T4", "link_type": "parent_child"}]	active	{}	\N
43	CUEMEENDM8FGBUPV8	cue	\N	\N	create	{"slug": "biltong adlib", "cue_type": "ADLIB", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 19:25:55.794044+00	[{"asset_id": "SEGMEEJ3YD0OKZM7D", "link_type": "parent_child"}]	active	{}	\N
44	ASTMEEOASULAQYTLJ	promo	\N	\N	create	{"slug": "promo", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 19:51:44.01617+00	[{"asset_id": "EPSMEEJ32D9UFK5BU", "link_type": "parent_child"}]	active	{}	\N
45	SEGMEEOBAPUJXSG4D	segment	\N	\N	create	{"slug": "type: promo", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 19:52:07.171126+00	[]	active	{}	\N
46	CUEMEEPQ1XNB587ME	cue	\N	\N	create	{"slug": "retarded-neighbors", "cue_type": "SOT", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 20:31:35.245573+00	[{"asset_id": "SEGMEEJ5H1D9I4K1D", "link_type": "parent_child"}]	active	{}	\N
47	CUEMEEQS4B424DL1B	cue	\N	\N	create	{"slug": "chris-elston", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 21:01:11.248743+00	[{"asset_id": "SEGMEEJ3TNWZ5IUEO", "link_type": "parent_child"}]	active	{}	\N
48	SEGMEEUGQPOVKPL0G	segment	\N	\N	create	{"slug": null, "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-16 22:44:18.876763+00	[]	active	{}	\N
49	CUEMEF0GG3OT4EV9G	cue	\N	\N	create	{"slug": "Josh talk", "cue_type": "adlib", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-17 01:32:02.822842+00	[]	active	{}	\N
50	CUEMEF1M0VOTMXHR0	cue	\N	\N	create	{"slug": "a-group-of", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-17 02:04:22.646487+00	[{"asset_id": "SEGMEEJ3TNWZ5IUEO", "link_type": "parent_child"}]	active	{}	\N
51	CUEMEF1MMCNHQ2B7J	cue	\N	\N	create	{"slug": "agrou-of-pt", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-17 02:04:50.473946+00	[{"asset_id": "SEGMEEJ3TNWZ5IUEO", "link_type": "parent_child"}]	active	{}	\N
52	CUEMEF1NP7R2S32UR	cue	\N	\N	create	{"slug": "the-clip-shows", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-17 02:05:40.842083+00	[{"asset_id": "SEGMEEJ3TNWZ5IUEO", "link_type": "parent_child"}]	active	{}	\N
53	CUEMEF1W0XP0Q5PKX	cue	\N	\N	create	{"slug": "btp", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-17 02:12:09.280027+00	[{"asset_id": "SEGMEEJ3TNWZ5IUEO", "link_type": "parent_child"}]	active	{}	\N
54	CUEMEF22TNG6F7ZS8	cue	\N	\N	create	{"slug": "a-group-of", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-17 02:17:26.429128+00	[{"asset_id": "SEGMEEJ3TNWZ5IUEO", "link_type": "parent_child"}]	active	{}	\N
55	CUEMEF23DJ45GABLZ	cue	\N	\N	create	{"slug": "a-group-of-part", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-17 02:17:52.195024+00	[{"asset_id": "SEGMEEJ3TNWZ5IUEO", "link_type": "parent_child"}]	active	{}	\N
56	CUEMEF23VI6WIQ8SW	cue	\N	\N	create	{"slug": "an-off-duty", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-17 02:18:15.489116+00	[{"asset_id": "SEGMEEJ3TNWZ5IUEO", "link_type": "parent_child"}]	active	{}	\N
57	CUEMEF24QS9R6YDTF	cue	\N	\N	create	{"slug": "spokesperson", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-17 02:18:56.025718+00	[{"asset_id": "SEGMEEJ3TNWZ5IUEO", "link_type": "parent_child"}]	active	{}	\N
58	CUEMEF2AE2W19MGZT	cue	\N	\N	create	{"slug": "the-clip", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-17 02:23:19.499039+00	[{"asset_id": "SEGMEEJ3TNWZ5IUEO", "link_type": "parent_child"}]	active	{}	\N
59	SEGMENI0G7NHDS95Y	segment	\N	\N	create	{"slug": "segment", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 00:05:38.965545+00	[]	active	{}	\N
60	CUEMENIEHR7MIKVGP	cue	\N	\N	create	{"slug": "old-cuntry", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 00:16:34.149324+00	[{"asset_id": "slug:", "link_type": "parent_child"}]	active	{}	\N
61	CUEMENIJTO5C5B6VO	cue	\N	\N	create	{"slug": "old-cracker-barrel", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 00:20:42.871436+00	[{"asset_id": "slug:", "link_type": "parent_child"}]	active	{}	\N
62	CUEMENIK9AF8ZAMJJ	cue	\N	\N	create	{"slug": "new-cracker-barrel", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 00:21:03.113902+00	[{"asset_id": "slug:", "link_type": "parent_child"}]	active	{}	\N
63	CUEMENILDKHRC2TKM	cue	\N	\N	create	{"slug": "lgbt-cracker-barrel", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 00:21:55.316206+00	[{"asset_id": "slug:", "link_type": "parent_child"}]	active	{}	\N
64	CUEMENILXIWG7QRQ7	cue	\N	\N	create	{"slug": "black-supremacy-cracker-barrel", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 00:22:21.178816+00	[{"asset_id": "slug:", "link_type": "parent_child"}]	active	{}	\N
65	CUEMENIMRMCYQWKEI	cue	\N	\N	create	{"slug": "neurodiverse-cracker-barrel", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 00:23:00.182543+00	[{"asset_id": "slug:", "link_type": "parent_child"}]	active	{}	\N
66	CUEMENIRGZ906SNAR	cue	\N	\N	create	{"slug": "un-women-journalists", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 00:26:39.669717+00	[{"asset_id": "slug:", "link_type": "parent_child"}]	active	{}	\N
67	CUEMENIS44YIBI1Q7	cue	\N	\N	create	{"slug": "un-women-journalist", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 00:27:09.683049+00	[{"asset_id": "slug:", "link_type": "parent_child"}]	active	{}	\N
68	CUEMENIUDD21M7S2X	cue	\N	\N	create	{"slug": "pamela-tweet", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 00:28:54.953047+00	[{"asset_id": "slug:", "link_type": "parent_child"}]	active	{}	\N
69	CUEMENIWAI54O2R24	cue	\N	\N	create	{"slug": "pam-dr-janja-laich-national-cult-minorities", "cue_type": "sot", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 00:30:24.559332+00	[{"asset_id": "slug:", "link_type": "parent_child"}]	active	{}	\N
70	CUEMENIZ7HH2OW09M	cue	\N	\N	create	{"slug": "assault-ice-officer", "cue_type": "sot", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 00:32:40.616157+00	[{"asset_id": "slug:", "link_type": "parent_child"}]	active	{}	\N
71	CUEMENJ1R1M5WVTRP	cue	\N	\N	create	{"slug": "taylor-swift-whore", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 00:34:39.276316+00	[{"asset_id": "slug:", "link_type": "parent_child"}]	active	{}	\N
72	CUEMENJH97NHXBN4P	cue	\N	\N	create	{"slug": "ozempic-vag", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 00:46:42.661809+00	[{"asset_id": "slug:", "link_type": "parent_child"}]	active	{}	\N
73	CUEMENJIUTTLKPHDF	cue	\N	\N	create	{"slug": "cher-believe", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 00:47:57.332069+00	[{"asset_id": "slug:", "link_type": "parent_child"}]	active	{}	\N
74	CUEMENJJDS312LZRG	cue	\N	\N	create	{"slug": "response-to-cher-believe", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 00:48:21.894202+00	[{"asset_id": "slug:", "link_type": "parent_child"}]	active	{}	\N
75	SEGMENJX099GXB5YW	segment	\N	\N	create	{"slug": "segment", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 00:58:57.549931+00	[]	active	{}	\N
76	CUEMENM36688GBOIO	cue	\N	\N	create	{"slug": "first-ag-vid", "cue_type": "sot", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 01:59:44.386314+00	[{"asset_id": "LOCAL-RD-menkaa03-ma8qf", "link_type": "parent_child"}]	active	{}	\N
77	CUEMENMPWWR6J4IP4	cue	\N	\N	create	{"slug": "shoot-maga", "cue_type": "sot", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 02:17:25.469464+00	[{"asset_id": "LOCAL-RD-menkaa03-ma8qf", "link_type": "parent_child"}]	active	{}	\N
78	CUEMENMRO3E5UHGQO	cue	\N	\N	create	{"slug": "pamela-tweet", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 02:18:47.356425+00	[{"asset_id": "LOCAL-RD-menkaa03-ma8qf", "link_type": "parent_child"}]	active	{}	\N
79	CUEMENMSMYX79Z3L4	cue	\N	\N	create	{"slug": "pam-dr-janja", "cue_type": "sot", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 02:19:32.556155+00	[{"asset_id": "LOCAL-RD-menkaa03-ma8qf", "link_type": "parent_child"}]	active	{}	\N
80	CUEMENMUQO30DJWZ6	cue	\N	\N	create	{"slug": "assault-ice-officer", "cue_type": "sot", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 02:21:10.660382+00	[{"asset_id": "LOCAL-RD-menkaa03-ma8qf", "link_type": "parent_child"}]	active	{}	\N
81	ASTMENN08JNRJDC0G	ad	\N	\N	create	{"slug": "ad", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 02:25:27.109253+00	[]	active	{}	\N
82	SEGMENN1KTT4WZ9IA	segment	\N	\N	create	{"slug": "segment", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 02:26:29.683264+00	[]	active	{}	\N
83	CUEMENN9OHORZFJJL	cue	\N	\N	create	{"slug": "covid-lockdowns", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 02:32:47.678517+00	[{"asset_id": "SEGMEEJ3TNWZ5IUEO", "link_type": "parent_child"}]	active	{}	\N
84	CUEMENNBL547W2F07	cue	\N	\N	create	{"slug": "young-adults-chart", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 02:34:16.650666+00	[{"asset_id": "SEGMEEJ3TNWZ5IUEO", "link_type": "parent_child"}]	active	{}	\N
85	ASTMENNENQDGGNHMO	ad	\N	\N	create	{"slug": "ad", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 02:36:39.976161+00	[]	active	{}	\N
86	ASTMENNGGSESOGQAU	ad	\N	\N	create	{"slug": "ad", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 02:38:04.28881+00	[]	active	{}	\N
87	SEGMENNHZMNHN1OLZ	segment	\N	\N	create	{"slug": "segment", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 02:39:15.361445+00	[]	active	{}	\N
88	CUEMENNQEK7IBMNV5	cue	\N	\N	create	{"slug": "red-mcdonalds", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 02:45:47.961449+00	[{"asset_id": "slug: 60 Cracker Barrel", "link_type": "parent_child"}]	active	{}	\N
89	CUEMENNRBBBQIXF7I	cue	\N	\N	create	{"slug": "new-mdcdonalds", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 02:46:30.407515+00	[{"asset_id": "slug: 60 Cracker Barrel", "link_type": "parent_child"}]	active	{}	\N
90	CUEMENNSC98CS9ZZU	cue	\N	\N	create	{"slug": "old-cracker-barrel", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 02:47:18.287016+00	[{"asset_id": "slug: 60 Cracker Barrel", "link_type": "parent_child"}]	active	{}	\N
91	CUEMENNSXUZ1JDLZ7	cue	\N	\N	create	{"slug": "new-cracker-barrel", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 02:47:46.286321+00	[{"asset_id": "slug: 60 Cracker Barrel", "link_type": "parent_child"}]	active	{}	\N
180	ASTMFMGIV8TOXYGSJ	rundown_item	\N	\N	segment_mirror	{"filename": "Segment.md", "episode_number": "0238", "title": "Segment"}	segment_mirror_script	2025-09-16 11:15:55.173805+00	[]	active	{}	\N
92	CUEMENNVF3E2C7XIL	cue	\N	\N	create	{"slug": "inside-cracker-barrel", "cue_type": "sot", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 02:49:41.932756+00	[{"asset_id": "slug: 60 Cracker Barrel", "link_type": "parent_child"}]	active	{}	\N
93	SEGMENNWG7MZFJ7T4	segment	\N	\N	create	{"slug": "segment", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 02:50:30.037126+00	[]	active	{}	\N
94	SEGMENO45GP697XFT	segment	\N	\N	create	{"slug": "female narcissism", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 02:56:29.356168+00	[]	active	{}	\N
95	SEGMENO4J9M1S526M	segment	\N	\N	create	{"slug": "segment", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 02:56:47.244429+00	[]	active	{}	\N
96	CUEMENOBAE6S4NZSE	cue	\N	\N	create	{"slug": "taylor-swift", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 03:02:02.336303+00	[{"asset_id": "slug: taylor swift", "link_type": "parent_child"}]	active	{}	\N
97	SEGMEOFKUYOZE0Y76	segment	\N	\N	create	{"slug": "type: coldopen", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 15:45:18.530697+00	[]	active	{}	\N
98	SEGMEOIYLBRXWRRFC	segment	\N	\N	create	{"slug": "segment", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 17:19:58.07409+00	[]	active	{}	\N
99	SEGMEOIZJ66BP0L2S	segment	\N	\N	create	{"slug": "type: segment", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 17:20:41.936397+00	[]	active	{}	\N
100	SEGMEOJ3IIYIR5I9H	segment	\N	\N	create	{"slug": "60 Cracker Barrel", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 17:23:47.7244+00	[]	active	{}	\N
101	SEGMEOJ449DRJ4QTV	segment	\N	\N	create	{"slug": "taylor swift", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 17:24:15.889617+00	[]	active	{}	\N
102	SEGMEOJ4VJG38C2GD	segment	\N	\N	create	{"slug": "segment", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 17:24:51.246417+00	[]	active	{}	\N
103	SEGMEOJ57H90X3NHF	segment	\N	\N	create	{"slug": "type: segment", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 17:25:06.719982+00	[]	active	{}	\N
104	SEGMEOJK6D4V67EAJ	segment	\N	\N	create	{"slug": "Slocum Consulting", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 17:36:45.11452+00	[]	active	{}	\N
105	CUEMEOJRS925MMOI8	cue	\N	\N	create	{"slug": "first-ag-vid", "cue_type": "SOT", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 17:42:40.072706+00	[{"asset_id": "SEGMENO45GP697XFT", "link_type": "parent_child"}]	active	{}	\N
106	CUEMEOMV84ZZEZVMG	cue	\N	\N	create	{"slug": "assault-ice-officer", "cue_type": "SOT", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 19:09:19.475796+00	[{"asset_id": "SEGMENO45GP697XFT", "link_type": "parent_child"}]	active	{}	\N
107	CUEMEOMVCAIQ2MDV7	cue	\N	\N	create	{"slug": "shoot-maga", "cue_type": "SOT", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 19:09:24.858709+00	[{"asset_id": "SEGMENO45GP697XFT", "link_type": "parent_child"}]	active	{}	\N
108	CUEMEOMVM8C1BJ23P	cue	\N	\N	create	{"slug": "pamela-tweet", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 19:09:37.740926+00	[{"asset_id": "SEGMENO45GP697XFT", "link_type": "parent_child"}]	active	{}	\N
109	CUEMEOMVPPIAIQMD7	cue	\N	\N	create	{"slug": "pam-dr-janja", "cue_type": "SOT", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 19:09:42.249196+00	[{"asset_id": "SEGMENO45GP697XFT", "link_type": "parent_child"}]	active	{}	\N
110	CUEMEOMVWA97O7H4A	cue	\N	\N	create	{"slug": "un-women-journalists", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 19:09:50.769973+00	[{"asset_id": "SEGMENO45GP697XFT", "link_type": "parent_child"}]	active	{}	\N
111	CUEMEOMVZ52ZIS1IR	cue	\N	\N	create	{"slug": "un-women-journalist", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 19:09:54.470773+00	[{"asset_id": "SEGMENO45GP697XFT", "link_type": "parent_child"}]	active	{}	\N
112	SEGMEOOMWQVHLKPE7	segment	\N	\N	create	{"slug": null, "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 19:58:50.698165+00	[]	active	{}	\N
113	CUEMEOPLOWFSWFCUJ	cue	\N	\N	create	{"slug": "ceo-cracker-barrel", "cue_type": "sot", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 20:25:53.489662+00	[{"asset_id": "SEGMEOOMWQVHLKPE7", "link_type": "parent_child"}]	active	{}	\N
114	CUEMEOPR27Q8GRQ0Z	cue	\N	\N	create	{"slug": "inside-cracker-barrel", "cue_type": "SOT", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 20:30:04.024575+00	[{"asset_id": "SEGMEOOMWQVHLKPE7", "link_type": "parent_child"}]	active	{}	\N
115	CUEMEOPR5F8O373KC	cue	\N	\N	create	{"slug": "new-cracker-barrel", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 20:30:08.180858+00	[{"asset_id": "SEGMEOOMWQVHLKPE7", "link_type": "parent_child"}]	active	{}	\N
116	CUEMEOPR9VVUNF1I6	cue	\N	\N	create	{"slug": "old-cracker-barrel", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 20:30:13.964273+00	[{"asset_id": "SEGMEOOMWQVHLKPE7", "link_type": "parent_child"}]	active	{}	\N
117	CUEMEOPRCZZB1GX3E	cue	\N	\N	create	{"slug": "new-mdcdonalds", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 20:30:18.001871+00	[{"asset_id": "SEGMEOOMWQVHLKPE7", "link_type": "parent_child"}]	active	{}	\N
118	CUEMEOPRF6G39VFYE	cue	\N	\N	create	{"slug": "red-mcdonalds", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 20:30:20.826999+00	[{"asset_id": "SEGMEOOMWQVHLKPE7", "link_type": "parent_child"}]	active	{}	\N
119	CUEMEOSWI106C2RU2	cue	\N	\N	create	{"slug": "shogirl-whore", "cue_type": "gfx", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 21:58:16.646977+00	[{"asset_id": "SEGMEOJ449DRJ4QTV", "link_type": "parent_child"}]	active	{}	\N
120	CUEMEOSWMBZ8DISGQ	cue	\N	\N	create	{"slug": "response-to-cher-believe", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 21:58:22.224229+00	[{"asset_id": "SEGMEOJ449DRJ4QTV", "link_type": "parent_child"}]	active	{}	\N
121	CUEMEOSWQW1HZZOM9	cue	\N	\N	create	{"slug": "cher-believe", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-23 21:58:28.129622+00	[{"asset_id": "SEGMEOJ449DRJ4QTV", "link_type": "parent_child"}]	active	{}	\N
122	EPSMETSMHDWCRS8XH	episode	\N	\N	episode_scaffold_create	{"episode_number": "0238", "template_id": 1, "template_name": "Sunday Show", "title": "Cracker Barrel", "source": "episode_scaffold_service", "blueprint_template_type": "episode"}	1	2025-08-27 09:49:20.128738+00	[]	active	{}	\N
250	ASTMFSR6T3UWIHYHD	coldopen	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-20 21:01:05.363729+00	[]	active	{}	\N
123	EPSMEXH8GS6XXHO2F	episode	\N	\N	episode_scaffold_create	{"episode_number": "0238", "template_id": 1, "template_name": "Sunday Show", "title": null, "source": "episode_scaffold_service", "blueprint_template_type": "episode"}	1	2025-08-29 23:41:35.093242+00	[]	active	{}	\N
124	EPSMEXINEQGJ2NU4R	episode	\N	\N	episode_scaffold_create	{"episode_number": "0238", "template_id": 1, "template_name": "Sunday Show", "title": null, "source": "episode_scaffold_service", "blueprint_template_type": "episode"}	1	2025-08-30 00:21:11.895642+00	[]	active	{}	\N
126	SEGMEXLBQBFLD4KQB	segment	\N	\N	create	{"slug": "type: coldopen", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-08-30 01:36:05.885029+00	[]	active	{}	\N
127	SEGMEXVKAYJRS3HGE	segment	\N	\N	rundown_item_creation	{"slug": "test-server-assetid", "title": "Test Item with Server AssetID", "episode_number": "0237", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	rbac-test	2025-08-30 06:22:42.137555+00	[]	active	{}	\N
128	SEGMEXVL7SLOYOE5V	segment	\N	\N	rundown_item_creation	{"slug": "test-server-assetid", "title": "Test Item with Server AssetID", "episode_number": "0237", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	rbac-test	2025-08-30 06:23:24.698581+00	[]	active	{}	\N
129	ASTMEY3H4JETER0HD	promo	\N	\N	rundown_item_creation	{"slug": "promo", "title": "Promo", "episode_number": "0238", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-08-30 10:04:10.684475+00	[]	active	{}	\N
130	EPSMEY8EVJQRZK24K	episode	\N	\N	episode_scaffold_create	{"episode_number": "0001", "template_id": 1, "template_name": "Sunday Show", "title": null, "source": "episode_scaffold_service", "blueprint_template_type": "episode"}	1	2025-08-30 12:22:23.791988+00	[]	active	{}	\N
131	ASTMEY8F52UKZ8UCD	coldopen	\N	\N	rundown_item_creation	{"slug": "show-cold-open", "title": "Cold Open", "episode_number": "0001", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-08-30 12:22:36.152871+00	[]	active	{}	\N
132	ASTMEY8F888WE9R21	tease	\N	\N	rundown_item_creation	{"slug": "", "title": "", "episode_number": "0001", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-08-30 12:22:40.235122+00	[]	active	{}	\N
133	SEGMEY8FBXICD5NYV	segment	\N	\N	rundown_item_creation	{"slug": "segment", "title": "Segment", "episode_number": "0001", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-08-30 12:22:45.03225+00	[]	active	{}	\N
134	SEGMEY8FDNA1AI2RL	segment	\N	\N	rundown_item_creation	{"slug": "segment", "title": "Segment", "episode_number": "0001", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-08-30 12:22:47.256895+00	[]	active	{}	\N
135	EPSMEY8MLPMRH71P7	episode	\N	\N	episode_scaffold_create	{"episode_number": "0900", "template_id": 1, "template_name": "Sunday Show", "title": "Test Episode 0900 from Scaffold", "source": "episode_scaffold_service", "blueprint_template_type": "episode"}	episode_scaffold_service	2025-08-30 12:28:24.295833+00	[]	active	{}	\N
136	ASTMEY9GMJYCYF0HJ	promo	\N	\N	rundown_item_creation	{"slug": "promo", "title": "Promo", "episode_number": "0001", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-08-30 12:51:45.07224+00	[]	active	{}	\N
137	ASTMEY9HFAGHSKEEQ	ad	\N	\N	rundown_item_creation	{"slug": "advertisement", "title": "Advertisement", "episode_number": "0001", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-08-30 12:52:22.314804+00	[]	active	{}	\N
138	ASTMEY9IOUFCRJENC	reader	\N	\N	rundown_item_creation	{"slug": "reader", "title": "Reader", "episode_number": "0001", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-08-30 12:53:21.35344+00	[]	active	{}	\N
139	ASTMEY9KJJIWV1DD7	break	\N	\N	rundown_item_creation	{"slug": "break", "title": "Break", "episode_number": "0001", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-08-30 12:54:47.792315+00	[]	active	{}	\N
140	ASTMEYC4SM4C7FIXP	break	\N	\N	rundown_item_creation	{"slug": "break", "title": "Break", "episode_number": "0001", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-08-30 14:06:31.902969+00	[]	active	{}	\N
141	EPSMEYLG3N3WWCLAJ	episode	\N	\N	episode_scaffold_create	{"episode_number": "0238", "template_id": 1, "template_name": "Sunday Show", "title": null, "source": "episode_scaffold_service", "blueprint_template_type": "episode"}	1	2025-08-30 18:27:15.943893+00	[]	active	{}	\N
142	ASTMEYLH24D8CRUIN	coldopen	\N	\N	rundown_item_creation	{"slug": "show-cold-open", "title": "Cold Open", "episode_number": "0238", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-08-30 18:28:00.639739+00	[]	active	{}	\N
143	SEGMEYLHB64D1HSOB	segment	\N	\N	rundown_item_creation	{"slug": "segment", "title": "Segment", "episode_number": "0238", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-08-30 18:28:12.366315+00	[]	active	{}	\N
144	ASTMF0PED3L07CS5Z	coldopen	\N	\N	rundown_item_creation	{"slug": "show-cold-open", "title": "Cold Open", "episode_number": "0001", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-01 05:53:25.720143+00	[]	active	{}	\N
145	EPSMF27X37QW1N671	episode	\N	\N	episode_scaffold_create	{"episode_number": "0239", "template_id": 1, "template_name": "Sunday Show", "title": "TBD", "source": "episode_scaffold_service", "blueprint_template_type": "episode"}	1	2025-09-02 07:19:38.622866+00	[]	active	{}	\N
146	ASTMF27XAO8R383HX	coldopen	\N	\N	rundown_item_creation	{"slug": "show-cold-open", "title": "Cold Open", "episode_number": "0239", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-02 07:19:48.298226+00	[]	active	{}	\N
147	ASTMF27XDEOOHVTN0	tease	\N	\N	rundown_item_creation	{"slug": "", "title": "", "episode_number": "0239", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-02 07:19:51.84239+00	[]	active	{}	\N
148	SEGMF27XFJ3JHJVFO	segment	\N	\N	rundown_item_creation	{"slug": "segment", "title": "Segment", "episode_number": "0239", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-02 07:19:54.594068+00	[]	active	{}	\N
149	SEGMF27XGVMCVX1O0	segment	\N	\N	rundown_item_creation	{"slug": "segment", "title": "Segment", "episode_number": "0239", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-02 07:19:56.338806+00	[]	active	{}	\N
150	ASTMF27XJHSIE28AQ	reader	\N	\N	rundown_item_creation	{"slug": "reader", "title": "Reader", "episode_number": "0239", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-02 07:19:59.730899+00	[]	active	{}	\N
287	ASTMFT4829QP1W3O5	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:05:58.908403+00	[]	active	{}	\N
289	ASTMFT482ADDM9PIR	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:05:58.928531+00	[]	active	{}	\N
290	ASTMFT4865N792ZN9	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:06:03.935265+00	[]	active	{}	\N
151	SEGMF27XLOFZ0XJXF	segment	\N	\N	rundown_item_creation	{"slug": "segment", "title": "Segment", "episode_number": "0239", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-02 07:20:02.561988+00	[]	active	{}	\N
152	ASTMF280OENKFAIDI	tease	\N	\N	rundown_item_creation	{"slug": "", "title": "", "episode_number": "0239", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-02 07:22:26.063885+00	[]	active	{}	\N
153	ASTMF28JF748LB5DD	coldopen	\N	\N	rundown_item_creation	{"slug": "show-cold-open", "title": "Test Cold Open", "episode_number": "0238", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	rbac-test	2025-09-02 07:37:00.685906+00	[]	active	{}	\N
154	SEGMF28JSPA3LJ9HU	segment	\N	\N	rundown_item_creation	{"slug": "test-segment", "title": "Test Segment", "episode_number": "0238", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	rbac-test	2025-09-02 07:37:18.094864+00	[]	active	{}	\N
155	SEGMF28K7VQEMC4OW	segment	\N	\N	rundown_item_creation	{"slug": "middle-segment", "title": "Middle Segment", "episode_number": "0238", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	rbac-test	2025-09-02 07:37:37.767087+00	[]	active	{}	\N
156	ASTMF2DXJOA201GWI	promo	\N	\N	rundown_item_creation	{"slug": "promo", "title": "Promo", "episode_number": "0239", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-02 10:07:57.662086+00	[]	active	{}	\N
157	ASTMF2E67ZC9GYV7Q	break	\N	\N	rundown_item_creation	{"slug": "break", "title": "Break", "episode_number": "0239", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-02 10:14:42.408813+00	[]	active	{}	\N
158	SEGMF2GLEDCHVANLV	segment	\N	\N	rundown_item_creation	{"slug": "segment", "title": "Segment", "episode_number": "0239", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-02 11:22:29.767392+00	[]	active	{}	\N
159	EPSMF8MT17N6UZ5FT	episode	\N	\N	episode_scaffold_create	{"episode_number": "0239", "template_id": 1, "template_name": "Sunday Show", "title": "The Princess and the Pea", "source": "episode_scaffold_service", "blueprint_template_type": "episode"}	1	2025-09-06 19:03:00.706171+00	[]	active	{}	\N
160	SEGMF8MUZZPXDQZB1	segment	\N	\N	rundown_item_creation	{"slug": "segment", "title": "Segment", "episode_number": "0239", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-06 19:04:32.440154+00	[]	active	{}	\N
161	EPSMFJRNMJLTMEDTX	episode	\N	\N	episode_scaffold_create	{"episode_number": "0240", "template_id": 1, "template_name": "Sunday Show", "title": "The Turning Point", "source": "episode_scaffold_service", "blueprint_template_type": "episode"}	1	2025-09-14 14:04:14.432264+00	[]	active	{}	\N
162	ASTMFJRV616ICH14B	coldopen	\N	\N	rundown_item_creation	{"slug": "show-cold-open", "title": "Cold Open", "episode_number": "0240", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-14 14:10:06.284667+00	[]	active	{}	\N
163	ASTMFJRXGRKM7U803	tease	\N	\N	rundown_item_creation	{"slug": "", "title": "", "episode_number": "0240", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-14 14:11:53.506763+00	[]	active	{}	\N
164	ASTMFJRXLJJFR9CD6	break	\N	\N	rundown_item_creation	{"slug": "break", "title": "Break", "episode_number": "0240", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-14 14:11:59.698097+00	[]	active	{}	\N
165	ASTMFJSG4BT913KEO	break	\N	\N	rundown_item_creation	{"slug": "break", "title": "Break", "episode_number": "0240", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-14 14:26:23.851293+00	[]	active	{}	\N
166	ASTMFJSIFMFRY2KJB	tease	\N	\N	rundown_item_creation	{"slug": "", "title": "", "episode_number": "0240", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-14 14:28:11.801297+00	[]	active	{}	\N
167	ASTMFJXNEKU7DJLZP	tease	\N	\N	rundown_item_creation	{"slug": "", "title": "", "episode_number": "0240", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-14 16:52:01.808253+00	[]	active	{}	\N
168	ASTMFJXRAJL9DB85K	tease	\N	\N	rundown_item_creation	{"slug": "", "title": "", "episode_number": "0240", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-14 16:55:03.20411+00	[]	active	{}	\N
169	ASTMFJZBY9ZAIA7F8	reader	\N	\N	rundown_item_creation	{"slug": "reader", "title": "Reader", "episode_number": "0240", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-14 17:39:06.698045+00	[]	active	{}	\N
170	ASTMFJZE3OJ9BKXJ6	break	\N	\N	rundown_item_creation	{"slug": "break", "title": "Break", "episode_number": "0240", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-14 17:40:47.013218+00	[]	active	{}	\N
171	ASTMFJZF6Z67H8XAD	tease	\N	\N	rundown_item_creation	{"slug": "", "title": "", "episode_number": "0240", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-14 17:41:37.940481+00	[]	active	{}	\N
172	ASTMFK0RNJH2GH0RW	break	\N	\N	rundown_item_creation	{"slug": "break", "title": "Break", "episode_number": "0240", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-14 18:19:18.895226+00	[]	active	{}	\N
173	ASTMFK659V5Z6YPQJ	promo	\N	\N	rundown_item_creation	{"slug": "promo", "title": "Promo", "episode_number": "0240", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-14 20:49:52.435596+00	[]	active	{}	\N
174	EPSMFM60A0IWPUX9Z	episode	\N	\N	episode_scaffold_create	{"episode_number": "0241", "template_id": 1, "template_name": "Sunday Show", "title": null, "source": "episode_scaffold_service", "blueprint_template_type": "episode"}	1	2025-09-16 06:21:31.691291+00	[]	active	{}	\N
175	EPSMFMCUHX8G7QS6G	episode	\N	\N	episode_scaffold_create	{"episode_number": "0241", "template_id": 1, "template_name": "Sunday Show", "title": null, "source": "episode_scaffold_service", "blueprint_template_type": "episode"}	1	2025-09-16 09:32:59.322298+00	[]	active	{}	\N
176	EPSMFMGBVGXZ495AY	episode	\N	\N	filesystem_mirror	{"episode_number": "0239", "title": "The Princess and the Pea", "source": "filesystem_migration"}	episode_mirror_script	2025-09-16 11:10:28.875364+00	[]	active	{}	\N
177	ASTMFMGHUWAOTYMOG	rundown	\N	\N	segment_mirror	{"episode_number": "0238", "episode_title": "Episode 238 - Keri Smith", "source": "filesystem_segment_migration"}	segment_mirror_script	2025-09-16 11:15:08.06684+00	[]	active	{}	\N
179	ASTMFMGIV8BZF5SF8	rundown	\N	\N	segment_mirror	{"episode_number": "0238", "episode_title": "Episode 238 - Keri Smith", "source": "filesystem_segment_migration"}	segment_mirror_script	2025-09-16 11:15:55.155656+00	[]	active	{}	\N
288	ASTMFT4829Y3FOX43	break	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:05:58.916803+00	[]	active	{}	\N
181	ASTMFMGIV960OJRIF	rundown	\N	\N	segment_mirror	{"episode_number": "0239", "episode_title": "The Princess and the Pea", "source": "filesystem_segment_migration"}	segment_mirror_script	2025-09-16 11:15:55.189103+00	[]	active	{}	\N
182	ASTMFMGOB0NQGJIMX	rundown	\N	\N	segment_mirror	{"episode_number": "0236", "episode_title": "Episode 236", "source": "filesystem_migration"}	mirror_all_script	2025-09-16 11:20:08.895772+00	[]	active	{}	\N
184	EPSMFMGRRW3D4U04V	episode	\N	\N	filesystem_mirror	{"episode_number": "0240", "title": "The Turning Point", "source": "filesystem_migration"}	mirror_remaining_script	2025-09-16 11:22:50.734329+00	[]	active	{}	\N
185	ASTMFMGRRWF7TC15C	rundown	\N	\N	segment_mirror	{"episode_number": "0240", "episode_title": "The Turning Point"}	mirror_remaining_script	2025-09-16 11:22:50.74959+00	[]	active	{}	\N
186	ASTMFMGRRWO0XMK4R	rundown_item	\N	\N	segment_mirror	{"filename": "040-segment-charlie-kirk.md", "episode_number": "0240"}	mirror_remaining_script	2025-09-16 11:22:50.755516+00	[]	active	{}	\N
187	ASTMFMGRRWVUYHVKA	rundown_item	\N	\N	segment_mirror	{"filename": "070-segment-mommy.md", "episode_number": "0240"}	mirror_remaining_script	2025-09-16 11:22:50.764656+00	[]	active	{}	\N
188	ASTMFMGRRX2989JL4	rundown_item	\N	\N	segment_mirror	{"filename": "110-break-support.md", "episode_number": "0240"}	mirror_remaining_script	2025-09-16 11:22:50.771113+00	[]	active	{}	\N
189	ASTMFMGRRX6OW4SYP	rundown_item	\N	\N	segment_mirror	{"filename": "120-segment-iryna-zarutska.md", "episode_number": "0240"}	mirror_remaining_script	2025-09-16 11:22:50.777421+00	[]	active	{}	\N
190	EPSMFMGRRXCVUILZ5	episode	\N	\N	filesystem_mirror	{"episode_number": "0242", "title": "Episode 0242", "source": "filesystem_migration"}	mirror_remaining_script	2025-09-16 11:22:50.784607+00	[]	active	{}	\N
191	ASTMFMGTPCAQMTXD1	rundown	\N	\N	segment_mirror	{"episode_number": "0236", "episode_title": "Episode 236"}	mirror_236_script	2025-09-16 11:24:20.740432+00	[]	active	{}	\N
192	ASTMFMGUC93N0ERT1	rundown	\N	\N	segment_mirror	{"episode_number": "0236", "episode_title": "Episode 236"}	mirror_236_script	2025-09-16 11:24:50.433052+00	[]	active	{}	\N
193	ASTMFMGUNIY1T7V0J	rundown	\N	\N	segment_mirror	{"episode_number": "0236", "episode_title": "Episode 236"}	mirror_236_script	2025-09-16 11:25:05.044782+00	[]	active	{}	\N
194	ASTMFMGUNJ9DWHECM	rundown_item	\N	\N	segment_mirror	{"filename": "25 break.md", "episode_number": "0236"}	mirror_236_script	2025-09-16 11:25:05.057383+00	[]	active	{}	\N
195	ASTMFMGUNJI53Q3M9	rundown_item	\N	\N	segment_mirror	{"filename": "45 break.md", "episode_number": "0236"}	mirror_236_script	2025-09-16 11:25:05.066923+00	[]	active	{}	\N
196	EPSMFMM55FM1YT93W	episode	\N	\N	episode_scaffold_create	{"episode_number": "0241", "template_id": 1, "template_name": "Sunday Show", "title": null, "source": "episode_scaffold_service", "blueprint_template_type": "episode"}	1	2025-09-16 13:53:12.897683+00	[]	active	{}	\N
197	EPSMFMMGLVFSQL61S	episode	\N	\N	episode_scaffold_create	{"episode_number": "0241", "template_id": 1, "template_name": "Sunday Show", "title": null, "source": "episode_scaffold_service", "blueprint_template_type": "episode"}	1	2025-09-16 14:02:07.413151+00	[]	active	{}	\N
198	EPSMFMPEPUSI2Y6WI	episode	\N	\N	episode_scaffold_create	{"episode_number": "0241", "template_id": 1, "template_name": "Sunday Show", "title": null, "source": "episode_scaffold_service", "blueprint_template_type": "episode"}	1	2025-09-16 15:24:38.114996+00	[]	active	{}	\N
199	ASTMFMPUT79QI14W6	coldopen	\N	\N	rundown_item_creation	{"slug": "show-cold-open", "title": "Cold Open", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 15:37:08.95073+00	[]	active	{}	\N
200	ASTMFMQEH3QSS6PQH	coldopen	\N	\N	rundown_item_creation	{"slug": "show-cold-open", "title": "Cold Open", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 15:52:26.392507+00	[]	active	{}	\N
201	ASTMFMSMEKK4DD327	coldopen	\N	\N	rundown_item_creation	{"slug": "show-cold-open", "title": "Cold Open", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 16:54:35.590498+00	[]	active	{}	\N
202	SEGMFMSNZA2JBEEYO	segment	\N	\N	rundown_item_creation	{"slug": "segment", "title": "Segment", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 16:55:49.084878+00	[]	active	{}	\N
203	SEGMFMSO3IYYMDFD5	segment	\N	\N	rundown_item_creation	{"slug": "segment", "title": "Segment", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 16:55:54.58851+00	[]	active	{}	\N
204	ASTMFMSO5J5X2TCLG	tease	\N	\N	rundown_item_creation	{"slug": "", "title": "", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 16:55:57.188125+00	[]	active	{}	\N
205	ASTMFMTH1LHOEEMLZ	coldopen	\N	\N	rundown_item_creation	{"slug": "show-cold-open", "title": "Cold Open", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:18:25.113146+00	[]	active	{}	\N
206	ASTMFMTJBNVNUW4UC	coldopen	\N	\N	rundown_item_creation	{"slug": "show-cold-open", "title": "Cold Open", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:20:11.474584+00	[]	active	{}	\N
207	ASTMFMTK6QJIKFGMM	tease	\N	\N	rundown_item_creation	{"slug": "", "title": "", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:20:51.741614+00	[]	active	{}	\N
208	ASTMFMTKEEQ3NSWR4	reader	\N	\N	rundown_item_creation	{"slug": "reader", "title": "Reader", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:21:01.683294+00	[]	active	{}	\N
209	SEGMFMTKGQAROORCS	segment	\N	\N	rundown_item_creation	{"slug": "segment", "title": "Segment", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:21:04.691383+00	[]	active	{}	\N
210	SEGMFMTKIMEEEEDLG	segment	\N	\N	rundown_item_creation	{"slug": "segment", "title": "Segment", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:21:07.145001+00	[]	active	{}	\N
211	ASTMFMTKM0MC22VRA	tease	\N	\N	rundown_item_creation	{"slug": "", "title": "", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:21:11.544981+00	[]	active	{}	\N
212	ASTMFMTL9WJR2UAD0	break	\N	\N	rundown_item_creation	{"slug": "break", "title": "Break", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:21:42.501597+00	[]	active	{}	\N
213	ASTMFMTLJBHS1C3OX	break	\N	\N	rundown_item_creation	{"slug": "break", "title": "Break", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:21:54.704049+00	[]	active	{}	\N
214	ASTMFMTOJL7M0OXEQ	coldopen	\N	\N	rundown_item_creation	{"slug": "show-cold-open", "title": "Cold Open", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:24:15.027002+00	[]	active	{}	\N
215	ASTMFMTOMX7IEHLCO	tease	\N	\N	rundown_item_creation	{"slug": "", "title": "", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:24:19.341998+00	[]	active	{}	\N
216	SEGMFMTOP9I3N9WEC	segment	\N	\N	rundown_item_creation	{"slug": "segment", "title": "Segment", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:24:22.376278+00	[]	active	{}	\N
217	SEGMFMTOSTUUD3ADJ	segment	\N	\N	rundown_item_creation	{"slug": "segment", "title": "Segment", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:24:26.99678+00	[]	active	{}	\N
218	ASTMFMTPMGXOM4Q0M	rundown	\N	\N	episode_rundown_creation	{"episode_number": "0241"}	system	2025-09-16 17:25:05.404251+00	[{"asset_id": "EPSMFMPEPUSI2Y6WI", "link_type": "belongs_to"}]	active	{}	\N
219	ASTMFMTVDHY2S68UE	coldopen	\N	\N	rundown_item_creation	{"slug": "show-cold-open", "title": "Cold Open", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:29:33.725681+00	[]	active	{}	\N
220	ASTMFMTVIDTIC6KWR	coldopen	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-16 17:29:40.047865+00	[]	active	{}	\N
221	ASTMFMTVIJNWDL5X6	coldopen	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-16 17:29:40.25602+00	[]	active	{}	\N
222	ASTMFMTX41GYR6IBK	coldopen	\N	\N	rundown_item_creation	{"slug": "show-cold-open", "title": "Cold Open", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:30:54.779843+00	[]	active	{}	\N
223	ASTMFMTXABD7G9S4Q	coldopen	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-16 17:31:02.904056+00	[]	active	{}	\N
224	ASTMFMU031DNZA55L	tease	\N	\N	rundown_item_creation	{"slug": "", "title": "", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:33:13.443959+00	[]	active	{}	\N
225	ASTMFMU12HWIPAMR0	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-16 17:33:59.390177+00	[]	active	{}	\N
226	SEGMFMU2RTBAU9XQQ	segment	\N	\N	rundown_item_creation	{"slug": "segment", "title": "Segment", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:35:18.865274+00	[]	active	{}	\N
227	SEGMFMU2TCWTCTOSN	segment	\N	\N	rundown_item_creation	{"slug": "segment", "title": "Segment", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:35:20.864652+00	[]	active	{}	\N
228	ASTMFMU2VF3TL7YIK	promo	\N	\N	rundown_item_creation	{"slug": "promo", "title": "Promo", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:35:23.537365+00	[]	active	{}	\N
229	ASTMFMU2YUEAC4RQB	interview	\N	\N	rundown_item_creation	{"slug": "interview", "title": "Interview", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:35:27.976896+00	[]	active	{}	\N
230	ASTMFMU32AMUH5M0D	break	\N	\N	rundown_item_creation	{"slug": "break", "title": "Break", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:35:32.44854+00	[]	active	{}	\N
231	ASTMFMU4O85DBSE8T	promo	\N	\N	rundown_item_creation	{"slug": "promo", "title": "Promo", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:36:47.527659+00	[]	active	{}	\N
232	SEGMFMU4QN1SGX692	segment	\N	\N	rundown_item_creation	{"slug": "segment", "title": "Segment", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:36:50.655379+00	[]	active	{}	\N
233	SEGMFMU4S4FMKDMSA	segment	\N	\N	rundown_item_creation	{"slug": "segment", "title": "Segment", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:36:52.577394+00	[]	active	{}	\N
234	ASTMFMU4ULWAKD6AT	reader	\N	\N	rundown_item_creation	{"slug": "reader", "title": "Reader", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:36:55.798699+00	[]	active	{}	\N
235	ASTMFMU4Y6DNZ5B1X	break	\N	\N	rundown_item_creation	{"slug": "break", "title": "Break", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-16 17:37:00.423813+00	[]	active	{}	\N
236	ASTMFMU4ZJK14NIL2	promo	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-16 17:37:02.191462+00	[]	active	{}	\N
237	SEGMFMU4ZJNL0MLVK	segment	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-16 17:37:02.195374+00	[]	active	{}	\N
238	SEGMFMU4ZJR2I1UDY	segment	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-16 17:37:02.198805+00	[]	active	{}	\N
239	ASTMFMU4ZJTFQAJFI	reader	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-16 17:37:02.201616+00	[]	active	{}	\N
240	ASTMFMU4ZJX3YYL3X	break	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-16 17:37:02.204971+00	[]	active	{}	\N
241	ASTMFMU5G6O4UPP9B	promo	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-16 17:37:23.751681+00	[]	active	{}	\N
242	SEGMFMU5G712N56VK	segment	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-16 17:37:23.771612+00	[]	active	{}	\N
243	SEGMFMU5G7C7A889V	segment	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-16 17:37:23.782996+00	[]	active	{}	\N
244	ASTMFMU5G7PQOE30E	reader	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-16 17:37:23.795251+00	[]	active	{}	\N
245	ASTMFMU5G80JM8UT4	break	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-16 17:37:23.806381+00	[]	active	{}	\N
246	EPSMFSR3W9KUCTLRM	episode	\N	\N	episode_scaffold_create	{"episode_number": "0241", "template_id": 1, "template_name": "Sunday Show", "title": "Manson Family Values", "source": "episode_scaffold_service", "blueprint_template_type": "episode"}	1	2025-09-20 20:58:49.495614+00	[]	active	{}	\N
247	ASTMFSR4ECMMLM34Y	coldopen	\N	\N	rundown_item_creation	{"slug": "show-cold-open", "title": "Cold Open", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-20 20:59:12.937178+00	[]	active	{}	\N
248	ASTMFSR4IARNH4LRN	tease	\N	\N	rundown_item_creation	{"slug": "", "title": "", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-20 20:59:18.053438+00	[]	active	{}	\N
249	ASTMFSR6T37QO5C5V	rundown	\N	\N	episode_rundown_creation	{"episode_number": "0241"}	system	2025-09-20 21:01:05.343761+00	[{"asset_id": "EPSMFSR3W9KUCTLRM", "link_type": "belongs_to"}]	active	{}	\N
251	ASTMFSR6T43X378M1	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-20 21:01:05.377988+00	[]	active	{}	\N
252	SEGMFSTCOJSAQNNAF	segment	\N	\N	rundown_item_creation	{"slug": "segment", "title": "Segment", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-20 22:01:38.63452+00	[]	active	{}	\N
253	SEGMFSTDTKWZK9ADY	segment	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-20 22:02:31.800699+00	[]	active	{}	\N
254	SEGMFT39C7Q8V9TWE	segment	\N	\N	create	{"slug": "we're all manson girl", "cue_type": null, "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:58.839544+00	[]	active	{}	\N
255	ASTMFT39C85NHP49A	gfx	\N	\N	create	{"slug": "tyler-robinson", "cue_type": "GFX", "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:58.853843+00	[]	active	{}	\N
256	ASTMFT39C8C7NK3Y9	gfx	\N	\N	create	{"slug": "lance-twiggs", "cue_type": "GFX", "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:58.861198+00	[]	active	{}	\N
257	ASTMFT39C8J9XHMST	gfx	\N	\N	create	{"slug": "lance-doggy", "cue_type": "GFX", "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:58.867951+00	[]	active	{}	\N
258	ASTMFT39C8QEPNBQH	gfx	\N	\N	create	{"slug": "keyboard-note", "cue_type": "GFX", "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:58.874861+00	[]	active	{}	\N
259	ASTMFT39C8XYANWUO	gfx	\N	\N	create	{"slug": "why-did-i", "cue_type": "GFX", "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:58.881774+00	[]	active	{}	\N
260	ASTMFT39C942OE6ZU	sot	\N	\N	create	{"slug": "abc-touching-shooter", "cue_type": "SOT", "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:58.888611+00	[]	active	{}	\N
261	ASTMFT39C9BIHDDA2	sot	\N	\N	create	{"slug": "touching-intimate-portrait", "cue_type": "SOT", "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:58.895821+00	[]	active	{}	\N
262	ASTMFT39C9XCYUL42	sot	\N	\N	create	{"slug": "montel-williams", "cue_type": "SOT", "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:58.919781+00	[]	active	{}	\N
263	ASTMFT39CANMRT24I	gfx	\N	\N	create	{"slug": "manson-girls-kneel", "cue_type": "GFX", "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:58.94575+00	[]	active	{}	\N
264	ASTMFT39CBDW0BE1X	sot	\N	\N	create	{"slug": "manson-girls-singing", "cue_type": "SOT", "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:58.971308+00	[]	active	{}	\N
265	ASTMFT39CC3XVAFFE	sot	\N	\N	create	{"slug": "manson-speaks", "cue_type": "SOT", "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:58.997289+00	[]	active	{}	\N
266	ASTMFT39CCTV6A883	gfx	\N	\N	create	{"slug": "luigi-mangione", "cue_type": "GFX", "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:59.023092+00	[]	active	{}	\N
267	ASTMFT39CDJ8I2TAZ	gfx	\N	\N	create	{"slug": "by-the-numbers", "cue_type": "GFX", "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:59.049892+00	[]	active	{}	\N
268	ASTMFT39CE8FBYXHA	sot	\N	\N	create	{"slug": "married-luigi-mangioni", "cue_type": "SOT", "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:59.074118+00	[]	active	{}	\N
269	ASTMFT39CELCZPRZT	sot	\N	\N	create	{"slug": "cheer-for-luigi", "cue_type": "SOT", "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:59.086654+00	[]	active	{}	\N
270	SEGMFT39CEVMP5WD9	segment	\N	\N	create	{"slug": "cancel culture", "cue_type": null, "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:59.096505+00	[]	active	{}	\N
271	ASTMFT39CF6PENLRD	sot	\N	\N	create	{"slug": "nurse-fired", "cue_type": "SOT", "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:59.107004+00	[]	active	{}	\N
272	ASTMFT39CFDJ3EFG3	gfx	\N	\N	create	{"slug": "weird-how-people", "cue_type": "GFX", "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:59.113784+00	[]	active	{}	\N
273	ASTMFT39CFJMPTI97	sot	\N	\N	create	{"slug": "fuck-fired-charlie", "cue_type": "SOT", "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:59.120295+00	[]	active	{}	\N
274	ASTMFT39CFQ6LJEJJ	sot	\N	\N	create	{"slug": "girls-destroy-memorial", "cue_type": "SOT", "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:59.127069+00	[]	active	{}	\N
275	SEGMFT39CFXRU8V4P	segment	\N	\N	create	{"slug": "family insane", "cue_type": null, "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:59.13373+00	[]	active	{}	\N
276	SEGMFT39CG6TYWMQB	segment	\N	\N	create	{"slug": "Potpourri du Moquerie", "cue_type": null, "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:59.14257+00	[]	active	{}	\N
277	ASTMFT39CGFV9VMRR	sot	\N	\N	create	{"slug": "meow-girl", "cue_type": "SOT", "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:59.151963+00	[]	active	{}	\N
278	ASTMFT39CGMD4TDX4	sot	\N	\N	create	{"slug": "look-what-i-can", "cue_type": "SOT", "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:59.158468+00	[]	active	{}	\N
279	ASTMFT39CGSWS1B57	sot	\N	\N	create	{"slug": "mom-got-deported", "cue_type": "SOT", "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:59.164979+00	[]	active	{}	\N
280	ASTMFT39CGZUYJYDF	sot	\N	\N	create	{"slug": "trump-to-bitches", "cue_type": "SOT", "episode_number": 241, "source": "unified_newAssetID_endpoint"}	content-editor	2025-09-21 02:38:59.171688+00	[]	active	{}	\N
281	ASTMFT47H1MIIKAED	break	\N	\N	rundown_item_creation	{"slug": "break", "title": "Break", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-21 03:05:31.402896+00	[]	active	{}	\N
282	ASTMFT47KJ236CTET	break	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:05:35.916209+00	[]	active	{}	\N
283	ASTMFT47NE3NLNFKO	tease	\N	\N	rundown_item_creation	{"slug": "", "title": "", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-21 03:05:39.62775+00	[]	active	{}	\N
284	ASTMFT47PJRWCW1L6	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:05:42.42123+00	[]	active	{}	\N
285	ASTMFT47PJV63KQGL	break	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:05:42.427363+00	[]	active	{}	\N
286	ASTMFT47YHJF30UD5	tease	\N	\N	rundown_item_creation	{"slug": "", "title": "", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-21 03:05:54.008459+00	[]	active	{}	\N
293	ASTMFT489JFTYJMBH	break	\N	\N	rundown_item_creation	{"slug": "break", "title": "Break", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-21 03:06:08.331771+00	[]	active	{}	\N
295	ASTMFT48DAZ8ELDHA	break	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:06:13.211197+00	[]	active	{}	\N
297	ASTMFT48DBOZ0ZMRB	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:06:13.231481+00	[]	active	{}	\N
298	ASTMFT48FTXG0F142	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:06:16.483347+00	[]	active	{}	\N
300	ASTMFT48FU47D4STP	break	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:06:16.4914+00	[]	active	{}	\N
294	ASTMFT48DAWO64O1H	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:06:13.206175+00	[]	active	{}	\N
296	ASTMFT48DB8JN3YZW	break	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:06:13.216092+00	[]	active	{}	\N
299	ASTMFT48FU051EH6E	break	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:06:16.487886+00	[]	active	{}	\N
301	ASTMFT48FU75NOAZ9	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:06:16.494777+00	[]	active	{}	\N
302	ASTMFT4E8X3V8O3ZY	break	\N	\N	rundown_item_creation	{"slug": "break", "title": "Break", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-21 03:10:47.469517+00	[]	active	{}	\N
303	ASTMFT4EBIYCN7VQ2	break	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:10:50.840233+00	[]	active	{}	\N
304	ASTMFT4ED4UA5XMA7	break	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:10:52.924175+00	[]	active	{}	\N
305	ASTMFT4EFUFOUVBU8	tease	\N	\N	rundown_item_creation	{"slug": "", "title": "", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-21 03:10:56.441491+00	[]	active	{}	\N
306	ASTMFT4EJWJORECBB	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:11:01.686787+00	[]	active	{}	\N
307	ASTMFT4EJWWCR4IX8	break	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:11:01.71088+00	[]	active	{}	\N
308	ASTMFT4EOZS8VQLDP	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:11:08.283793+00	[]	active	{}	\N
309	ASTMFT4EP05DDKDK5	break	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:11:08.307634+00	[]	active	{}	\N
310	ASTMFT4EXLWR8EL5Z	tease	\N	\N	rundown_item_creation	{"slug": "", "title": "", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-21 03:11:19.463061+00	[]	active	{}	\N
311	ASTMFT4EZNIDADW8M	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:11:22.099184+00	[]	active	{}	\N
312	ASTMFT4EZNVJP29TJ	break	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:11:22.12145+00	[]	active	{}	\N
313	ASTMFT4EZOAVKLAQ6	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:11:22.133397+00	[]	active	{}	\N
314	ASTMFT4F9RCQ7IUMF	break	\N	\N	rundown_item_creation	{"slug": "break", "title": "Break", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-21 03:11:35.210285+00	[]	active	{}	\N
315	ASTMFT4FGIAMIZSG9	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:11:43.952395+00	[]	active	{}	\N
316	ASTMFT4FGIEGN5J3Y	break	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:11:43.95838+00	[]	active	{}	\N
317	ASTMFT4FGIHRQPOYD	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:11:43.960895+00	[]	active	{}	\N
318	ASTMFT4FGIMH92KEQ	break	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:11:43.965411+00	[]	active	{}	\N
319	ASTMFT4FHYJ3UBZTK	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:11:45.832955+00	[]	active	{}	\N
320	ASTMFT4FHYM9JXL13	break	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:11:45.838254+00	[]	active	{}	\N
321	ASTMFT4FHYQD8MPKG	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:11:45.840785+00	[]	active	{}	\N
322	ASTMFT4FHYUBFM0E1	break	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:11:45.846181+00	[]	active	{}	\N
323	ASTMFT4LF14DHTFTF	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:16:21.973384+00	[]	active	{}	\N
324	ASTMFT4LF1AZJ2WZQ	break	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:16:21.980997+00	[]	active	{}	\N
325	ASTMFT4LF1SEZZQPY	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:16:21.995919+00	[]	active	{}	\N
326	ASTMFT4LF244VX02X	break	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:16:22.011132+00	[]	active	{}	\N
327	ASTMFT4M01YEWJD5R	reader	\N	\N	rundown_item_creation	{"slug": "reader", "title": "Reader", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-21 03:16:49.222509+00	[]	active	{}	\N
328	ASTMFT4WAYXN4LAVJ	tease	\N	\N	rundown_item_creation	{"slug": "", "title": "", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-21 03:24:49.934946+00	[]	active	{}	\N
329	ASTMFT4WDF4UZQUUJ	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:24:53.10355+00	[]	active	{}	\N
330	ASTMFT4WMIWTZH4XX	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:25:04.902941+00	[]	active	{}	\N
331	ASTMFT4WR5538OV9I	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:25:10.877314+00	[]	active	{}	\N
332	ASTMFT4WTFOWLZC7J	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:25:13.857819+00	[]	active	{}	\N
333	ASTMFT4Z0U5GZZ3RE	break	\N	\N	rundown_item_creation	{"slug": "break", "title": "Break", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-21 03:26:56.76719+00	[]	active	{}	\N
334	ASTMFT4Z3IX239XGC	break	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:27:00.247839+00	[]	active	{}	\N
335	ASTMFT5139ND2XSZF	break	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:28:33.223738+00	[]	active	{}	\N
336	ASTMFT51R0Q4ETKQZ	tease	\N	\N	rundown_item_creation	{"slug": "", "title": "", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-21 03:29:04.01092+00	[]	active	{}	\N
337	ASTMFT51TF3GVSA2G	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:29:07.11672+00	[]	active	{}	\N
338	ASTMFT51VJ4LRT1AC	tease	\N	\N	rundown_item_creation_during_save	{"episode_number": "0241"}	system	2025-09-21 03:29:09.844266+00	[]	active	{}	\N
339	ASTMFT58YHT8KUWXZ	reader	\N	\N	rundown_item_creation	{"slug": "reader", "title": "Reader", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-21 03:34:40.292133+00	[]	active	{}	\N
340	ASTMFT595RIZ1I35H	reader	\N	\N	rundown_item_creation	{"slug": "reader", "title": "Reader", "episode_number": "0241", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-21 03:34:49.713067+00	[]	active	{}	\N
369	CUEMG2KVZVQP10KD0	cue	\N	\N	create	{"slug": "ilhn-omar-cnn", "cue_type": "SOT", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-09-27 18:02:24.999323+00	[{"asset_id": "SEGMG2KVSDL9HUS78", "link_type": "parent_child"}]	active	{}	\N
341	EPSMG001SVZY8YW7C	episode	\N	\N	episode_scaffold_create	{"episode_number": "0242", "template_id": 1, "template_name": "Sunday Show", "title": "Forgiveness Discourse", "source": "episode_scaffold_service", "blueprint_template_type": "episode"}	1	2025-09-25 22:43:31.581899+00	[]	active	{}	\N
342	ASTMG0028V6G7EZIV	coldopen	\N	\N	rundown_item_creation	{"slug": "show-cold-open", "title": "Cold Open", "episode_number": "0242", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-25 22:43:52.293111+00	[]	active	{}	\N
343	ASTMG002D69CQKWL8	coldopen	\N	\N	rundown_item_creation	{"slug": "show-cold-open", "title": "Cold Open", "episode_number": "0242", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-25 22:43:57.876006+00	[]	active	{}	\N
344	ASTMG009VUZ4HFPFK	coldopen	\N	\N	rundown_item_creation	{"slug": "show-cold-open", "title": "Cold Open", "episode_number": "0242", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-25 22:49:48.685745+00	[]	active	{}	\N
345	ASTMG01RTKS9TT1BF	coldopen	\N	\N	rundown_item_creation	{"slug": "show-cold-open", "title": "Cold Open", "episode_number": "0242", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-25 23:31:45.14893+00	[]	active	{}	\N
346	ASTMG04EIM1ZYAW35	coldopen	\N	\N	rundown_item_creation	{"slug": "show-cold-open", "title": "Cold Open", "episode_number": "0242", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-26 00:45:23.259228+00	[]	active	{}	\N
347	ASTMG05Z04SIH84VY	coldopen	\N	\N	rundown_item_creation	{"slug": "show-cold-open", "title": "Cold Open", "episode_number": "0242", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-26 01:29:18.701327+00	[]	active	{}	\N
348	ASTMG061CV1JSC2SY	coldopen	\N	\N	rundown_item_creation	{"slug": "show-cold-open", "title": "Cold Open", "episode_number": "0242", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-26 01:31:08.511762+00	[]	active	{}	\N
349	ASTMG061HW3BKFT9O	coldopen	\N	\N	rundown_item_creation	{"slug": "show-cold-open", "title": "Cold Open", "episode_number": "0242", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-26 01:31:15.029404+00	[]	active	{}	\N
350	ASTMG063O1XSUTRW7	coldopen	\N	\N	rundown_item_creation	{"slug": "show-cold-open", "title": "Cold Open", "episode_number": "0242", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-26 01:32:56.327171+00	[]	active	{}	\N
351	ASTMG063SL5K7XCXY	coldopen	\N	\N	rundown_item_creation	{"slug": "show-cold-open", "title": "Cold Open", "episode_number": "0242", "source": "rundown_item_creation_endpoint", "created_via": "ContentEditor_NewItemModal"}	kevin	2025-09-26 01:33:02.203759+00	[]	active	{}	\N
353	EPSMG2JUF1ENW2T8Z	episode	\N	\N	create	{"slug": "episode-0243", "cue_type": null, "episode_number": 243, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-09-27 17:33:11.716226+00	[]	active	{}	\N
354	SEGMG2JULOQ1X5N00	segment	\N	\N	create	{"slug": "cold-open", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-09-27 17:33:20.330624+00	[{"asset_id": "EPSMG1FO7YJDBU685", "link_type": "parent_child"}]	active	{}	\N
355	SEGMG2JURAGJEZPQL	segment	\N	\N	create	{"slug": "main-segment", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-09-27 17:33:27.593123+00	[{"asset_id": "EPSMG1FO7YJDBU685", "link_type": "parent_child"}]	active	{}	\N
356	SEGMG2JUU3S9S96SK	segment	\N	\N	create	{"slug": "reader", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-09-27 17:33:31.240731+00	[{"asset_id": "EPSMG1FO7YJDBU685", "link_type": "parent_child"}]	active	{}	\N
357	ASTMG2JUWUQNG6M0O	ad	\N	\N	create	{"slug": "advertisement", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-09-27 17:33:34.802723+00	[{"asset_id": "EPSMG1FO7YJDBU685", "link_type": "parent_child"}]	active	{}	\N
358	ASTMG2JUZJ3FTWP8I	promo	\N	\N	create	{"slug": "promo", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-09-27 17:33:38.272403+00	[{"asset_id": "EPSMG1FO7YJDBU685", "link_type": "parent_child"}]	active	{}	\N
359	ASTMG2JV2CJ5MEEMQ	cta	\N	\N	create	{"slug": "call-to-action", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-09-27 17:33:41.924283+00	[{"asset_id": "EPSMG1FO7YJDBU685", "link_type": "parent_child"}]	active	{}	\N
360	SEGMG2JV51DS812IP	segment	\N	\N	create	{"slug": "tease", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-09-27 17:33:45.41025+00	[{"asset_id": "EPSMG1FO7YJDBU685", "link_type": "parent_child"}]	active	{}	\N
361	CUEMG2JVYTBHG46P3	cue	\N	\N	create	{"slug": "sample-sot", "cue_type": "SOT", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-09-27 17:34:24.000009+00	[{"asset_id": "SEGMG2JULOQ1X5N00", "link_type": "parent_child"}]	active	{}	\N
362	CUEMG2JW25J5BQ66L	cue	\N	\N	create	{"slug": "sample-gfx", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-09-27 17:34:28.327666+00	[{"asset_id": "SEGMG2JURAGJEZPQL", "link_type": "parent_child"}]	active	{}	\N
363	CUEMG2JW5SMZ5UF4M	cue	\N	\N	create	{"slug": "sample-fsq", "cue_type": "FSQ", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-09-27 17:34:33.047299+00	[{"asset_id": "SEGMG2JUU3S9S96SK", "link_type": "parent_child"}]	active	{}	\N
364	CUEMG2JW91TC7RYC7	cue	\N	\N	create	{"slug": "sample-vo", "cue_type": "VO", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-09-27 17:34:37.265749+00	[{"asset_id": "ASTMG2JUWUQNG6M0O", "link_type": "parent_child"}]	active	{}	\N
365	CUEMG2JWCB2PMURMO	cue	\N	\N	create	{"slug": "sample-net", "cue_type": "NET", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-09-27 17:34:41.487215+00	[{"asset_id": "SEGMG2JV51DS812IP", "link_type": "parent_child"}]	active	{}	\N
366	CUEMG2KVLD89T2X33	cue	\N	\N	create	{"slug": "ilhn-omar-cnn", "cue_type": "SOT", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-09-27 18:02:06.189103+00	[{"asset_id": "EPSMG001SVZY8YW7C", "link_type": "parent_child"}]	active	{}	\N
367	SEGMG2KVSDL9HUS78	segment	\N	\N	create	{"slug": "this-weeks-news-a", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-09-27 18:02:15.274645+00	[{"asset_id": "EPSMG001SVZY8YW7C", "link_type": "parent_child"}]	active	{}	\N
368	SEGMG2KVVKRJ8HDCU	segment	\N	\N	create	{"slug": "forgiveness-and-erika-kirk-b", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-09-27 18:02:19.420451+00	[{"asset_id": "EPSMG001SVZY8YW7C", "link_type": "parent_child"}]	active	{}	\N
520	ASTMGEH4DG6DL3PKO	sot	\N	\N	create	{"slug": "this-is-a-slug", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-06 01:50:11.48113+00	[]	active	{}	\N
521	ASTMGEHBAWVOI38HL	sot	\N	\N	create	{"slug": "babysitter-club", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-06 01:55:34.786066+00	[]	active	{}	\N
370	CUEMG2KW39X1RBRLD	cue	\N	\N	create	{"slug": "kam-kam-harris", "cue_type": "SOT", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-09-27 18:02:29.397703+00	[{"asset_id": "SEGMG2KVSDL9HUS78", "link_type": "parent_child"}]	active	{}	\N
374	CUEMG2KWH4LLTS1MJ	cue	\N	\N	create	{"slug": "tylenol-moms", "cue_type": "SOT", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-09-27 18:02:47.35+00	[{"asset_id": "SEGMG2KVSDL9HUS78", "link_type": "parent_child"}]	active	{}	\N
378	SEGMG2LYK9O94ADTY	segment	\N	\N	create	{"slug": "slocum-consulting", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-09-27 18:32:24.348961+00	[{"asset_id": "EPSMG001SVZY8YW7C", "link_type": "parent_child"}]	active	{}	\N
371	CUEMG2KW6U169BUYJ	cue	\N	\N	create	{"slug": "trump-pinata", "cue_type": "SOT", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-09-27 18:02:34.010268+00	[{"asset_id": "SEGMG2KVSDL9HUS78", "link_type": "parent_child"}]	active	{}	\N
375	CUEMG2KWLAFYEU62Y	cue	\N	\N	create	{"slug": "erika-kirk-forgiveness", "cue_type": "SOT", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-09-27 18:02:52.743936+00	[{"asset_id": "SEGMG2KVVKRJ8HDCU", "link_type": "parent_child"}]	active	{}	\N
379	SEGMG2LYNNLI3QNKQ	segment	\N	\N	create	{"slug": "harrison-koehli-conversation", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-09-27 18:32:28.738052+00	[{"asset_id": "EPSMG001SVZY8YW7C", "link_type": "parent_child"}]	active	{}	\N
372	CUEMG2KWA7KAP8CLY	cue	\N	\N	create	{"slug": "trump-amish-autism", "cue_type": "SOT", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-09-27 18:02:38.385093+00	[{"asset_id": "SEGMG2KVSDL9HUS78", "link_type": "parent_child"}]	active	{}	\N
376	SEGMG2LYDS65PWXQP	segment	\N	\N	create	{"slug": "daughters-tale-part-ii", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-09-27 18:32:15.943267+00	[{"asset_id": "EPSMG001SVZY8YW7C", "link_type": "parent_child"}]	active	{}	\N
373	CUEMG2KWDHHJJIOFA	cue	\N	\N	create	{"slug": "trump-tylenol", "cue_type": "SOT", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-09-27 18:02:42.630309+00	[{"asset_id": "SEGMG2KVSDL9HUS78", "link_type": "parent_child"}]	active	{}	\N
377	SEGMG2LYH4QI36OI8	segment	\N	\N	create	{"slug": "support-us", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-09-27 18:32:20.283151+00	[{"asset_id": "EPSMG001SVZY8YW7C", "link_type": "parent_child"}]	active	{}	\N
380	CUEMG6DO02A49GG0J	cue	\N	\N	create	{"slug": "test-cue", "cue_type": "GFX", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-09-30 09:51:19.379338+00	[]	active	{}	\N
381	ASTMG6DO64K9V8LNR	gfx	\N	\N	create	{"slug": "test-cue", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-09-30 09:51:27.237296+00	[]	active	{}	\N
382	ASTMG6DPYSFAXSOC2	gfx	\N	\N	create	{"slug": "test-from-curl", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-09-30 09:52:51.039754+00	[]	active	{}	\N
383	ASTMG6ETPDTE75J2U	test	\N	\N	create	{"slug": "test-slug", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-09-30 10:23:45.089631+00	[]	active	{}	\N
384	ASTMG6F1J91CAQ08D	img	\N	\N	create	{"slug": "test", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-09-30 10:29:50.390372+00	[]	active	{}	\N
385	CUEMG6F3QAIXHU4J8	cue	\N	\N	create	{"slug": null, "cue_type": "img", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-09-30 10:31:32.827282+00	[]	active	{}	\N
386	CUEMG6F5KYK3ZUE9W	cue	\N	\N	create	{"slug": "test-img", "cue_type": "img", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-09-30 10:32:59.229368+00	[]	active	{}	\N
387	SEGMG6F5RUOT8UBY2	segment	\N	\N	create	{"slug": "test-segment", "cue_type": null, "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-09-30 10:33:08.161379+00	[]	active	{}	\N
388	CUEMG6F8X9LALTGGG	cue	\N	\N	create	{"slug": "test-img-cue", "cue_type": "IMG", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-09-30 10:35:35.146225+00	[{"asset_id": "SEGMG6F5RUOT8UBY2", "link_type": "parent_child"}]	active	{}	\N
389	CUEMG6FJSU9FGGRNO	cue	\N	\N	create	{"slug": "test-slug", "cue_type": "IMG", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-09-30 10:44:02.626521+00	[]	active	{}	\N
390	CUEMG6FJYS5PMI8FK	cue	\N	\N	create	{"slug": "test-slug", "cue_type": "IMG", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-09-30 10:44:10.325744+00	[{"asset_id": "SEG240001", "link_type": "parent_child"}]	active	{}	\N
391	CUEMG6FP7I6VFI51S	cue	\N	\N	create	{"slug": "test-slug", "cue_type": "IMG", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-09-30 10:48:14.910691+00	[]	active	{}	\N
392	CUEMG6FPVKNM5JN45	cue	\N	\N	create	{"slug": "test-img-cue", "cue_type": "IMG", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-09-30 10:48:46.103974+00	[{"asset_id": "SEGMG6F5RUOT8UBY2", "link_type": "parent_child"}]	active	{}	\N
393	CUEMG6FT8MDFBGBXS	cue	\N	\N	create	{"slug": "this is a test 343", "cue_type": "IMG", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-09-30 10:51:22.982059+00	[{"asset_id": "SEGMG2A11VVSDSWZW", "link_type": "parent_child"}]	active	{}	\N
394	CUEMG6FX8LLA9K12N	cue	\N	\N	create	{"slug": "This i an img test", "cue_type": "IMG", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-09-30 10:54:29.578468+00	[{"asset_id": "SEGMG2A11VVSDSWZW", "link_type": "parent_child"}]	active	{}	\N
395	CUEMG6FY46N8HQFXT	cue	\N	\N	create	{"slug": "This i an 877", "cue_type": "IMG", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-09-30 10:55:10.512071+00	[{"asset_id": "SEGMG2A11VVSDSWZW", "link_type": "parent_child"}]	active	{}	\N
396	CUEMG6G1DFG813X19	cue	\N	\N	create	{"slug": "slocum on ai", "cue_type": "IMG", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-09-30 10:57:42.461329+00	[{"asset_id": "SEGMG2A11VVSDSWZW", "link_type": "parent_child"}]	active	{}	\N
397	SEGMG6G2WEO27B0E4	segment	\N	\N	create	{"slug": "untitled-tease", "cue_type": null, "episode_number": 243, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-09-30 10:58:53.712616+00	[]	active	{}	\N
398	CUEMG6G9N8OKE0E9S	cue	\N	\N	create	{"slug": "test-img-cue", "cue_type": "IMG", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-09-30 11:04:08.42491+00	[{"asset_id": "SEGMFT39C7Q8V9TWE", "link_type": "parent_child"}]	active	{}	\N
399	SEGMG6GH8ZH3E23PK	segment	\N	\N	rundown_item_creation	{"episode_number": "0241", "item_type": "segment", "title": "Test Segment 2", "creation_method": "create_rundown_item_endpoint"}	rbac-test	2025-09-30 11:10:03.196879+00	[]	active	{}	\N
400	CUEMG6GU8VK4YD6R6	cue	\N	\N	create	{"slug": "test-img-cue-final", "cue_type": "IMG", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-09-30 11:20:09.585581+00	[{"asset_id": "SEGMG6GH8ZH3E23PK", "link_type": "parent_child"}]	active	{}	\N
401	CUEMG6GXMB8NR28B8	cue	\N	\N	create	{"slug": "test-img-cue-final", "cue_type": "IMG", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-09-30 11:22:46.964958+00	[{"asset_id": "SEGMG6GH8ZH3E23PK", "link_type": "parent_child"}]	active	{}	\N
402	CUEMG6GYQW6SUEQU9	cue	\N	\N	create	{"slug": "test-img-cue-final", "cue_type": "IMG", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-09-30 11:23:39.604245+00	[{"asset_id": "SEGMG6GH8ZH3E23PK", "link_type": "parent_child"}]	active	{}	\N
403	CUEMG6H0CBCMFZ31C	cue	\N	\N	create	{"slug": "test-img-cue-final", "cue_type": "IMG", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-09-30 11:24:53.976938+00	[{"asset_id": "SEGMG6GH8ZH3E23PK", "link_type": "parent_child"}]	active	{}	\N
404	CUEMG6H32XCF62KJ3	cue	\N	\N	create	{"slug": "test-img-cue-success", "cue_type": "IMG", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-09-30 11:27:01.776927+00	[{"asset_id": "SEGMG6GH8ZH3E23PK", "link_type": "parent_child"}]	active	{}	\N
405	SEGMG6HFBUK7XPQFJ	segment	\N	\N	register_existing_frontend_assetid	{"original_asset_id": "SEGMG2A11VVSDSWZW", "repair_action": "register_missing_frontend_assetid", "description": "Frontend was using this AssetID but it was not registered in backend"}	system_repair	2025-09-30 11:36:33.21287+00	[]	active	{}	\N
406	SEGMG6HY0M899RA3X	segment	\N	\N	frontend_data_consistency_repair	{"issue": "AssetID existed in frontend but not in backend registry", "repair_method": "regenerate_and_register", "replaces_asset_id": "SEGMG2A11VVSDSWZW", "generation_reason": "frontend_data_consistency_repair", "original_retirement": false}	rbac-test	2025-09-30 11:51:05.120283+00	[]	active	{}	\N
408	SEGMG6IZM34TPD6XR	segment	\N	\N	user_requested_item_regeneration	{"item_slug": "headline stories", "item_type": "tease", "item_id": "SEGMG2A11VVSDSWZW", "replaces_asset_id": "SEGMG6IZHQJ2RC68I", "generation_reason": "user_requested_item_regeneration", "original_retirement": true}	rbac-test	2025-09-30 12:20:19.216519+00	[]	active	{}	\N
407	SEGMG6IZHQJ2RC68I	segment	\N	\N	user_requested_item_regeneration	{"item_slug": "headline stories", "item_type": "tease", "item_id": "SEGMG2A11VVSDSWZW", "replaces_asset_id": "SEGMG2A11VVSDSWZW", "generation_reason": "user_requested_item_regeneration", "original_retirement": false}	rbac-test	2025-09-30 12:20:13.577811+00	[]	retired	{"retired_at": "2025-09-30T12:20:19.212041", "retirement_reason": "user_requested_item_regeneration", "retired_by": "rbac-test"}	\N
409	CUEMG6M3VR4SFVDF0	cue	\N	\N	create	{"slug": "let us prayu", "cue_type": "IMG", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-09-30 13:47:37.218617+00	[{"asset_id": "SEGMG2A11VVSDSWZW", "link_type": "parent_child"}]	active	{}	\N
410	CUEMG6M6HE6JIFMOM	cue	\N	\N	create	{"slug": "this test", "cue_type": "IMG", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-09-30 13:49:38.575368+00	[{"asset_id": "SEGMG2A11VVSDSWZW", "link_type": "parent_child"}]	active	{}	\N
411	EPSMG6QQT3M84B3XS	episode	\N	\N	user_requested_regeneration	{"replaces_asset_id": "EP0241", "generation_reason": "user_requested_regeneration", "original_retirement": false}	kevin	2025-09-30 15:57:25.329422+00	[]	active	{}	\N
412	EPSMG6TA7BP9PA2VC	episode	\N	\N	user_requested_regeneration	{"replaces_asset_id": "EPSMG1FO7YJDBU685", "generation_reason": "user_requested_regeneration", "original_retirement": true}	kevin	2025-09-30 17:08:29.461919+00	[]	active	{}	\N
352	EPSMG1FO7YJDBU685	episode	\N	\N	episode_scaffold_create	{"episode_number": "0243", "template_id": 1, "template_name": "Sunday Show", "title": null, "source": "episode_scaffold_service", "blueprint_template_type": "episode"}	1	2025-09-26 22:48:37.96228+00	[]	retired	{"retired_at": "2025-09-30T17:08:29.456233", "retirement_reason": "user_requested_regeneration", "retired_by": "kevin"}	\N
413	CUEMG6XIG1UBAVNXT	cue	\N	\N	create	{"slug": "Dan Frost", "cue_type": "IMG", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-09-30 19:06:52.488975+00	[{"asset_id": "SEGMG2BVX15C41J3P", "link_type": "parent_child"}]	active	{}	\N
414	SEGMG6YMY93OE2PNK	segment	\N	\N	user_requested_item_regeneration	{"item_slug": "new-break-placeholder", "item_type": "ad", "item_id": "placeholder_1758984286921_qm5ers3vb", "replaces_asset_id": "placeholder_1758984286921_qm5ers3vb", "generation_reason": "user_requested_item_regeneration", "original_retirement": false}	rbac-test	2025-09-30 19:38:22.309605+00	[]	active	{}	\N
415	SEGMG6YPCZCUNHNK7	segment	\N	\N	rundown_item_creation	{"episode_number": "0243", "item_type": "ad", "title": "Advertisement", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-09-30 19:40:14.711305+00	[]	active	{}	\N
416	SEGMG6YPM8ZINUU65	segment	\N	\N	rundown_item_creation	{"episode_number": "0243", "item_type": "ad", "title": "Advertisement", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-09-30 19:40:26.72238+00	[]	active	{}	\N
417	SEGMG6Z5P8HZW787X	segment	\N	\N	rundown_item_creation	{"episode_number": "0243", "item_type": "segment", "title": "Segment", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-09-30 19:52:57.089073+00	[]	active	{}	\N
418	SEGMG6Z640F83DZPL	segment	\N	\N	rundown_item_creation	{"episode_number": "0243", "item_type": "segment", "title": "Segment", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-09-30 19:53:16.239148+00	[]	active	{}	\N
419	SEGMG70LQU4D6C5EM	segment	\N	\N	rundown_item_creation	{"episode_number": "0243", "item_type": "tease", "title": "", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-09-30 20:33:25.275054+00	[]	active	{}	\N
420	SEGMG78WF2M47H4I1	segment	\N	\N	rundown_item_creation	{"episode_number": "0243", "item_type": "ad", "title": "Advertisement", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-01 00:25:40.173117+00	[]	active	{}	\N
421	SEGMG79CJU6URCJMB	segment	\N	\N	rundown_item_creation	{"episode_number": "0243", "item_type": "interview", "title": "Interview", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-01 00:38:12.845128+00	[]	active	{}	\N
422	SEGMG79E7Q60IU1JW	segment	\N	\N	rundown_item_creation	{"episode_number": "0243", "item_type": "reader", "title": "Reader", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-01 00:39:30.460681+00	[]	active	{}	\N
423	SEGMG79IXDHD3VV27	segment	\N	\N	rundown_item_creation	{"episode_number": "0243", "item_type": "promo", "title": "Promo", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-01 00:43:10.323829+00	[]	active	{}	\N
424	SEGMG79KA1BFA3N2I	segment	\N	\N	rundown_item_creation	{"episode_number": "0243", "item_type": "interview", "title": "Interview", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-01 00:44:13.390919+00	[]	active	{}	\N
425	EPSMG970PCX3YI3SZ	episode	\N	\N	episode_scaffold_create	{"episode_number": "0244", "template_id": 1, "template_name": "Sunday Show", "title": "delete me", "source": "episode_scaffold_service", "blueprint_template_type": "episode"}	1	2025-10-02 09:08:33.247962+00	[]	active	{}	\N
426	SEGMG970Z486U8L3Z	segment	\N	\N	rundown_item_creation	{"episode_number": "0244", "item_type": "coldopen", "title": "Cold Open", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-02 09:08:45.895509+00	[]	active	{}	\N
427	SEGMG9713GVDULRRF	segment	\N	\N	rundown_item_creation	{"episode_number": "0244", "item_type": "segment", "title": "Segment", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-02 09:08:51.534499+00	[]	active	{}	\N
428	SEGMG9718RSRWSPCV	segment	\N	\N	rundown_item_creation	{"episode_number": "0244", "item_type": "promo", "title": "Promo", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-02 09:08:58.407267+00	[]	active	{}	\N
429	SEGMG971AUUWKJ7EU	segment	\N	\N	rundown_item_creation	{"episode_number": "0244", "item_type": "promo", "title": "Promo", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-02 09:09:01.109146+00	[]	active	{}	\N
430	SEGMG971DTJVKI8DV	segment	\N	\N	rundown_item_creation	{"episode_number": "0244", "item_type": "reader", "title": "Reader", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-02 09:09:04.950254+00	[]	active	{}	\N
431	SEGMG971JP1ZWQ7UU	segment	\N	\N	rundown_item_creation	{"episode_number": "0244", "item_type": "cta", "title": "Call to Action", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-02 09:09:12.564397+00	[]	active	{}	\N
432	SEGMG9HEPBEVBIPL4	segment	\N	\N	rundown_item_creation	{"episode_number": "0244", "item_type": "reader", "title": "Reader", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-02 13:59:22.537667+00	[]	active	{}	\N
433	SEGMG9NCKBW2FL3QJ	segment	\N	\N	rundown_item_creation	{"episode_number": "0243", "item_type": "tease", "title": "", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-02 16:45:40.459582+00	[]	active	{}	\N
434	SEGMG9NCTLA67G9HR	segment	\N	\N	rundown_item_creation	{"episode_number": "0243", "item_type": "segment", "title": "Segment", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-02 16:45:52.460818+00	[]	active	{}	\N
435	SEGMG9NCZYU8RPGWV	segment	\N	\N	rundown_item_creation	{"episode_number": "0243", "item_type": "tease", "title": "", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-02 16:46:00.724874+00	[]	active	{}	\N
436	CUEMG9SD4HCM2FSUH	cue	\N	\N	create	{"slug": "dANfROST", "cue_type": "IMG", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-10-02 19:06:04.658548+00	[{"asset_id": "SEGMG6Z5P8HZW787X", "link_type": "parent_child"}]	active	{}	\N
437	CUEMGAK65WGTY1WIN	cue	\N	\N	create	{"slug": "dan frost ", "cue_type": "IMG", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-10-03 08:04:29.153682+00	[{"asset_id": "SEGMG9NCTLA67G9HR", "link_type": "parent_child"}]	active	{}	\N
438	CUEMGAK9DS9T69B3E	cue	\N	\N	create	{"slug": "photo of dan frost", "cue_type": "IMG", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-10-03 08:06:59.33828+00	[{"asset_id": "SEGMG9NCTLA67G9HR", "link_type": "parent_child"}]	active	{}	\N
439	CUEMGAKAUC1PMN9J7	cue	\N	\N	create	{"slug": "test", "cue_type": "IMG", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-10-03 08:08:07.44228+00	[{"asset_id": "SEGMG9NCTLA67G9HR", "link_type": "parent_child"}]	active	{}	\N
440	CUEMGAKD4GAEH6ZNY	cue	\N	\N	create	{"slug": "dan frost", "cue_type": "IMG", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-10-03 08:09:53.867411+00	[{"asset_id": "SEGMG9NCTLA67G9HR", "link_type": "parent_child"}]	active	{}	\N
441	CUEMGAKY8I5LNQD6B	cue	\N	\N	create	{"slug": "Dan Frost is a bitch", "cue_type": "IMG", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-10-03 08:26:18.894047+00	[{"asset_id": "SEGMG9NCTLA67G9HR", "link_type": "parent_child"}]	active	{}	\N
442	CUEMGAL2KN5SEL5VC	cue	\N	\N	create	{"slug": "Dan Frost is a cunt", "cue_type": "IMG", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-10-03 08:29:41.249768+00	[{"asset_id": "SEGMG9NCTLA67G9HR", "link_type": "parent_child"}]	active	{}	\N
443	CUEMGALCH3UCFBRRA	cue	\N	\N	create	{"slug": "dan ", "cue_type": "IMG", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-10-03 08:37:23.228516+00	[{"asset_id": "SEGMG9NCTLA67G9HR", "link_type": "parent_child"}]	active	{}	\N
444	CUEMGALIO324OT3QE	cue	\N	\N	create	{"slug": "Dan frost is kinda a bitch for real", "cue_type": "IMG", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-10-03 08:42:12.208287+00	[{"asset_id": "SEGMG9NCTLA67G9HR", "link_type": "parent_child"}]	active	{}	\N
445	CUEMGALZ85RUF2V33	cue	\N	\N	create	{"slug": "Toshua Blocum watching the walls falling at Tinagra", "cue_type": "IMG", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-10-03 08:55:04.721381+00	[{"asset_id": "SEGMG9NCTLA67G9HR", "link_type": "parent_child"}]	active	{}	\N
446	CUEMGAMBAHIP1TUSD	cue	\N	\N	create	{"slug": "Dan Frost is a big bitch", "cue_type": "IMG", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-10-03 09:04:27.649932+00	[{"asset_id": "SEGMG9NCTLA67G9HR", "link_type": "parent_child"}]	active	{}	\N
447	ASTMGAVCPO7A8XKWU	fsq	\N	\N	create	{"slug": "and-so-it-begins-at-kirks-memorial-service-kirks-w", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-03 13:17:30.488315+00	[]	active	{}	\N
448	ASTMGB08H6E2DXLUH	fsq	\N	\N	create	{"slug": "forgiveness-definition-1-releasing-or-overcoming-a", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-03 15:34:10.936043+00	[]	active	{}	\N
449	ASTMGB0UWSO2IJ1SL	fsq	\N	\N	create	{"slug": "and-so-it-begins-at-kirks-memorial-service-kirks-w", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-03 15:51:37.609238+00	[]	active	{}	\N
450	ASTMGB17IM32HABJW	fsq	\N	\N	create	{"slug": "and-so-it-begins-at-kirks-memorial-service-kirks-w", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-03 16:01:25.756619+00	[]	active	{}	\N
451	ASTMGB185O14JRJ20	fsq	\N	\N	create	{"slug": "and-so-it-begins-at-kirks-memorial-service-kirks-w", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-03 16:01:55.633435+00	[]	active	{}	\N
452	ASTMGB1D5HWC33213	fsq	\N	\N	create	{"slug": "and-so-it-begins-at-kirks-memorial-service-kirks-w", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-03 16:05:48.741094+00	[]	active	{}	\N
453	ASTMGB1EKMXC3D9DR	fsq	\N	\N	create	{"slug": "and-so-it-begins-at-kirks-memorial-service-kirks-w", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-03 16:06:54.97012+00	[]	active	{}	\N
454	ASTMGB2QM02OG0I6I	fsq	\N	\N	create	{"slug": "a-2023-study-from-psychologists-christopher-d-pets", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-03 16:44:16.228948+00	[]	active	{}	\N
455	ASTMGB2QMF8C40WA0	fsq	\N	\N	create	{"slug": "a-2023-study-from-psychologists-christopher-d-pets", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-03 16:44:16.774707+00	[]	active	{}	\N
456	ASTMGB2WOBL26RGDY	fsq	\N	\N	create	{"slug": "a-2023-study-from-psychologists-christopher-d-pets", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-03 16:48:59.172026+00	[]	active	{}	\N
457	ASTMGB2WOQF9CUD6C	fsq	\N	\N	create	{"slug": "a-2023-study-from-psychologists-christopher-d-pets", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-03 16:48:59.703559+00	[]	active	{}	\N
458	ASTMGB2ZLBY8ORDV7	fsq	\N	\N	create	{"slug": "the-researchers-also-found-something-even-more-rev", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-03 16:51:15.264087+00	[]	active	{}	\N
459	ASTMGB2ZLR5VEXALE	fsq	\N	\N	create	{"slug": "the-researchers-also-found-something-even-more-rev", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-03 16:51:15.811283+00	[]	active	{}	\N
460	CUEMGB587TYJMLEGN	cue	\N	\N	create	{"slug": "THIS IS A ABIG NASTEY SLUG", "cue_type": "IMG", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-10-03 17:53:56.904866+00	[{"asset_id": "SEGMG6Z5P8HZW787X", "link_type": "parent_child"}]	active	{}	\N
461	ASTMGB5A4NZX8ANNX	fsq	\N	\N	create	{"slug": "the-researchers-also-found-something-even-more-rev", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-03 17:55:26.113528+00	[]	active	{}	\N
462	ASTMGB5A56EIJQ6VG	fsq	\N	\N	create	{"slug": "the-researchers-also-found-something-even-more-rev", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-03 17:55:26.775204+00	[]	active	{}	\N
463	SEGMGB5BYHAWACB74	segment	\N	\N	rundown_item_creation	{"episode_number": "0243", "item_type": "segment", "title": "Segment", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-03 17:56:51.405514+00	[]	active	{}	\N
464	ASTMGB5ED08UKGLA0	fsq	\N	\N	create	{"slug": "the-researchers-also-found-something-even-more-rev", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-03 17:58:43.546748+00	[]	active	{}	\N
465	ASTMGB5EDJI9BMB9R	fsq	\N	\N	create	{"slug": "the-researchers-also-found-something-even-more-rev", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-03 17:58:44.240493+00	[]	active	{}	\N
466	SEGMGB5X498YYKE28	segment	\N	\N	rundown_item_creation	{"episode_number": "0239", "item_type": "promo", "title": "Promo", "creation_method": "create_rundown_item_endpoint"}	josh	2025-10-03 18:13:18.666955+00	[]	active	{}	\N
467	SEGMGB5XLLKWVML4O	segment	\N	\N	rundown_item_creation	{"episode_number": "0239", "item_type": "interview", "title": "Interview", "creation_method": "create_rundown_item_endpoint"}	josh	2025-10-03 18:13:41.143097+00	[]	active	{}	\N
468	ASTMGB7WP7UQ9WN9X	fsq	\N	\N	create	{"slug": "greetings-mr-slocumnnim-a-middle-aged-heterosexual", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-03 19:08:58.411807+00	[]	active	{}	\N
469	CUEMGBDQUBR5FJTR2	cue	\N	\N	create	{"slug": "Dan Frost is kinda a bitch guy", "cue_type": "IMG", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-10-03 21:52:22.791632+00	[{"asset_id": "SEGMG6Z5P8HZW787X", "link_type": "parent_child"}]	active	{}	\N
470	CUEMGBGQM4IANWPD9	cue	\N	\N	create	{"slug": "this is a test image and as test slugh.", "cue_type": "IMG", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-10-03 23:16:11.01053+00	[{"asset_id": "SEGMG2EMUPX4PS75C", "link_type": "parent_child"}]	active	{}	\N
471	ASTMGBHT464QOY4EN	fsq	\N	\N	create	{"slug": "greetings-mr-slocumnnim-a-middle-aged-heterosexual", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-03 23:46:07.326634+00	[]	active	{}	\N
472	ASTMGBKA81SD5NDK5	fsq	\N	\N	create	{"slug": "this-friend-once-told-me-he-believes-in-cutting-of", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-04 00:55:24.737257+00	[]	active	{}	\N
473	ASTMGBLK6FEOXK1SA	fsq	\N	\N	create	{"slug": "heres-to-the-crazy-ones-the-misfits-the-rebels-the", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-04 01:31:08.810893+00	[]	active	{}	\N
474	ASTMGBOWHRGCJJHIG	fsq	\N	\N	create	{"slug": "heres-to-the-crazy-ones-the-misfits-the-rebels-the", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-04 03:04:42.220764+00	[]	active	{}	\N
475	SEGMGBWS9J1QTO1EL	segment	\N	\N	rundown_item_creation	{"episode_number": "0243", "item_type": "coldopen", "title": "Cold Open", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-04 06:45:21.853647+00	[]	active	{}	\N
478	EPSMGC47HIQWB3DSL	episode	\N	\N	episode_scaffold_create	{"episode_number": "0243", "template_id": 1, "template_name": "Sunday Show", "title": "Untitled", "source": "episode_scaffold_service", "blueprint_template_type": "episode"}	1	2025-10-04 10:13:09.356545+00	[]	active	{}	\N
481	SEGMGC4B1MI0UU7J2	segment	\N	\N	rundown_item_creation	{"episode_number": "0243", "item_type": "segment", "title": "Segment", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-04 10:15:55.386047+00	[]	active	{}	\N
482	CUEMGC4FQ5UPSBAY2	cue	\N	\N	create	{"slug": "Joel Berry Tweet", "cue_type": "IMG", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-10-04 10:19:33.811316+00	[{"asset_id": "SEGMGC4B1MI0UU7J2", "link_type": "parent_child"}]	active	{}	\N
476	EPSMGC45Y2A0K5PZ8	episode	\N	\N	user_requested_regeneration	{"replaces_asset_id": "EPSMG1FO7YJDBU685", "generation_reason": "user_requested_regeneration", "original_retirement": true}	kevin	2025-10-04 10:11:57.491414+00	[]	active	{}	\N
480	SEGMGC47WOLCSZTML	segment	\N	\N	rundown_item_creation	{"episode_number": "0243", "item_type": "tease", "title": "", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-04 10:13:29.011992+00	[]	active	{}	\N
477	EPSMGC461CCMZ937N	episode	\N	\N	user_requested_regeneration	{"replaces_asset_id": "EPSMG1FO7YJDBU685", "generation_reason": "user_requested_regeneration", "original_retirement": true}	kevin	2025-10-04 10:12:01.740963+00	[]	active	{}	\N
479	SEGMGC47MFBBM2VHS	segment	\N	\N	rundown_item_creation	{"episode_number": "0243", "item_type": "coldopen", "title": "Cold Open", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-04 10:13:15.717669+00	[]	active	{}	\N
483	CUEMGC4HUUCGHM56Q	cue	\N	\N	create	{"slug": "joel berry tweet", "cue_type": "IMG", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-10-04 10:21:13.188678+00	[{"asset_id": "SEGMGC4B1MI0UU7J2", "link_type": "parent_child"}]	active	{}	\N
484	ASTMGC7FYC6XX3DS3	sot	\N	\N	create	{"slug": "zohran-mamdani-ad", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-04 11:43:43.273366+00	[]	active	{}	\N
485	ASTMGC7MYTSV5JUF1	sot	\N	\N	create	{"slug": "mamdani-bachelor-ad", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-04 11:49:10.482498+00	[]	active	{}	\N
486	ASTMGC7S1G779RS08	sot	\N	\N	create	{"slug": "zorharan-momdani-ad", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-04 11:53:07.161981+00	[]	active	{}	\N
487	ASTMGC7VAUBBHPHOR	sot	\N	\N	create	{"slug": "zohran-mamdani-ad", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-04 11:55:39.301996+00	[]	active	{}	\N
488	ASTMGCADQ86U91653	sot	\N	\N	create	{"slug": "zohran-mamdani", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-04 13:05:58.278914+00	[]	active	{}	\N
489	ASTMGCAGNHQRGGIP0	sot	\N	\N	create	{"slug": "momdana", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-04 13:08:14.70284+00	[]	active	{}	\N
490	CUEMGCAPXZEKS3EIY	cue	\N	\N	create	{"slug": "Joel Berry Tweet", "cue_type": "IMG", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-10-04 13:15:28.203223+00	[{"asset_id": "SEGMGC4B1MI0UU7J2", "link_type": "parent_child"}]	active	{}	\N
491	ASTMGCAW81A8X422S	sot	\N	\N	create	{"slug": "test", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-04 13:20:21.166526+00	[]	active	{}	\N
492	ASTMGCBI1A3B7HACM	sot	\N	\N	create	{"slug": "mamdani-ad", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-04 13:37:18.845523+00	[]	active	{}	\N
493	ASTMGCBJET0BW90V8	sot	\N	\N	create	{"slug": "mamdani-ad", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-04 13:38:23.031701+00	[]	active	{}	\N
494	ASTMGCBLGSYLMGNCV	sot	\N	\N	create	{"slug": "mamdani-ad", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-04 13:39:58.93304+00	[]	active	{}	\N
495	CUEMGCBTTD90MRKVQ	cue	\N	\N	create	{"slug": "test image", "cue_type": "IMG", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-10-04 13:46:28.464035+00	[{"asset_id": "SEGMGC4B1MI0UU7J2", "link_type": "parent_child"}]	active	{}	\N
496	ASTMGCBY22TG63JJX	sot	\N	\N	create	{"slug": "mamdani-ad", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-04 13:49:46.373684+00	[]	active	{}	\N
497	ASTMGCC3YEQZDXQ4J	sot	\N	\N	create	{"slug": "mamdani", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-04 13:54:21.554677+00	[]	active	{}	\N
498	ASTMGCC933Z77F273	sot	\N	\N	create	{"slug": "adsfdasf", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-04 13:58:20.928169+00	[]	active	{}	\N
499	ASTMGCCIRG6X67AQD	sot	\N	\N	create	{"slug": "jkdfhwkdj", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-04 14:05:52.375316+00	[]	active	{}	\N
500	ASTMGCCP9U3427K67	sot	\N	\N	create	{"slug": "zdcsd", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-04 14:10:56.141287+00	[]	active	{}	\N
501	ASTMGCF1VOFDB5D84	sot	\N	\N	create	{"slug": "test", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-04 15:16:43.552411+00	[]	active	{}	\N
502	CUEMGCF2GDAP3ED1Y	cue	\N	\N	create	{"slug": "test", "cue_type": "IMG", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-10-04 15:17:10.369084+00	[{"asset_id": "SEGMGC4B1MI0UU7J2", "link_type": "parent_child"}]	active	{}	\N
503	ASTMGCF5JD33BE9C9	sot	\N	\N	create	{"slug": "test", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-04 15:19:34.215627+00	[]	active	{}	\N
504	ASTMGCFLNN0L60UVQ	sot	\N	\N	create	{"slug": "mamdani", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-04 15:32:06.253324+00	[]	active	{}	\N
505	ASTMGCFO9LMW5ODKT	sot	\N	\N	create	{"slug": "twest", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-04 15:34:08.028291+00	[]	active	{}	\N
506	ASTMGCJP31AG7QS73	sot	\N	\N	create	{"slug": "zohram-mamdani-ad", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-04 17:26:44.639206+00	[]	active	{}	\N
507	ASTMGCKLA4MNOH71V	sot	\N	\N	create	{"slug": "mm", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-04 17:51:46.82319+00	[]	active	{}	\N
508	ASTMGCKR47P2RH2I0	sot	\N	\N	create	{"slug": "zohran", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-04 17:56:19.093953+00	[]	active	{}	\N
509	ASTMGCKT8ROWYE3KE	sot	\N	\N	create	{"slug": "test-sot", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-04 17:57:58.3102+00	[]	active	{}	\N
510	ASTMGCKZ5JVKGMXSM	sot	\N	\N	create	{"slug": "test-sot", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-04 18:02:34.076025+00	[]	active	{}	\N
511	ASTMGD04IG6KLW247	sot	\N	\N	create	{"slug": "slug", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-05 01:06:38.3145+00	[]	active	{}	\N
512	ASTMGD08D37T0P4YL	sot	\N	\N	create	{"slug": "zohran-mamdani-ad", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-05 01:09:37.988029+00	[]	active	{}	\N
513	ASTMGD0FT391156VP	sot	\N	\N	create	{"slug": "zohran-mamdani", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-05 01:15:25.32743+00	[]	active	{}	\N
514	SEGMGD1F4W4395UT5	segment	\N	\N	rundown_item_creation	{"episode_number": "0244", "item_type": "tease", "title": "", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-05 01:42:53.572004+00	[]	active	{}	\N
515	ASTMGD1LNBQOZK02V	sot	\N	\N	create	{"slug": "zohran-mamdani-ad", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-05 01:47:57.400378+00	[]	active	{}	\N
516	ASTMGD2335T0BPIDL	sot	\N	\N	create	{"slug": "mamdani-ad", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-05 02:01:31.086524+00	[]	active	{}	\N
517	ASTMGD3K3O6Z01ZY8	sot	\N	\N	create	{"slug": "zohran-mamdani-ad", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-05 02:42:44.503214+00	[]	active	{}	\N
518	ASTMGEFKUQ1LXROZ0	sot	\N	\N	create	{"slug": "short-cue", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-06 01:07:01.133928+00	[]	active	{}	\N
519	ASTMGEGWQO33S6I0D	sot	\N	\N	create	{"slug": "mandani-advertisement", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-06 01:44:15.364818+00	[]	active	{}	\N
522	ASTMGEJG5951IF7Y5	sot	\N	\N	create	{"slug": "you-draw-a-sombraro", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-06 02:55:19.963768+00	[]	active	{}	\N
525	ASTMGEKAS7ITUQIXF	sot	\N	\N	create	{"slug": "this-is-a-slug", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-06 03:19:09.392692+00	[]	active	{}	\N
526	ASTMGEKBYS9DIMCQ9	sot	\N	\N	create	{"slug": "black-militatry-dgaf", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-06 03:20:04.571172+00	[]	active	{}	\N
527	ASTMGEKKB5BOZ12NV	sot	\N	\N	create	{"slug": "mamdani-advertisement", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-06 03:26:33.841696+00	[]	active	{}	\N
528	ASTMGER3YQUPNE75V	sot	\N	\N	create	{"slug": "tina-turner-1", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-06 06:29:48.583276+00	[]	active	{}	\N
523	ASTMGEJNYHIOBPLIH	sot	\N	\N	create	{"slug": "test-modal", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-06 03:01:24.440175+00	[]	active	{}	\N
524	ASTMGEK7F46R1DGWN	sot	\N	\N	create	{"slug": "crappy-slug-for-sot", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-06 03:16:32.456893+00	[]	active	{}	\N
529	ASTMGF6KTBIO83RJH	sot	\N	\N	create	{"slug": "slocums-sloc", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-06 13:42:48.990213+00	[]	active	{}	\N
530	ASTMGF6KTD18GP47X	sot	\N	\N	create	{"slug": "slocums-sloc", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-06 13:42:48.999201+00	[]	active	{}	\N
531	SEGMGG7TWOOJDVOJE	segment	\N	\N	rundown_item_creation	{"episode_number": "0243", "item_type": "segment", "title": "Segment", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-07 07:05:38.999959+00	[]	active	{}	\N
532	EPSMGGA62A3K2MGS3	episode	\N	\N	episode_scaffold_create	{"episode_number": "0244", "template_id": 1, "template_name": "Sunday Show", "title": null, "source": "episode_scaffold_service", "blueprint_template_type": "episode"}	1	2025-10-07 08:11:05.353777+00	[]	active	{}	\N
533	SEGMGGA66G2JUC2F8	segment	\N	\N	rundown_item_creation	{"episode_number": "0244", "item_type": "coldopen", "title": "Cold Open", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-07 08:11:10.753137+00	[]	active	{}	\N
534	SEGMGGA6A2TVKCZ9D	segment	\N	\N	rundown_item_creation	{"episode_number": "0244", "item_type": "tease", "title": "", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-07 08:11:15.459809+00	[]	active	{}	\N
535	SEGMGGC6HUO89NB1K	segment	\N	\N	rundown_item_creation	{"episode_number": "0244", "item_type": "segment", "title": "Segment", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-07 09:07:24.768603+00	[]	active	{}	\N
536	SEGMGGIHHPNDQAOBP	segment	\N	\N	rundown_item_creation	{"episode_number": "0244", "item_type": "segment", "title": "Segment", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-07 12:03:55.498738+00	[]	active	{}	\N
537	SEGMGGP7GATRO2I40	segment	\N	\N	rundown_item_creation	{"episode_number": "0244", "item_type": "tease", "title": "", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-07 15:12:04.4213+00	[]	active	{}	\N
538	SEGMGGPHH7UZYFGDK	segment	\N	\N	rundown_item_creation	{"episode_number": "0244", "item_type": "promo", "title": "Promo", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-07 15:19:52.170314+00	[]	active	{}	\N
539	ASTMGIF5FNCTXI10J	fsq	\N	\N	create	{"slug": "heres-the-corrected-text-following-american-englis", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-08 20:06:06.458672+00	[]	active	{}	\N
540	ASTMGIGOJ64DGU2P7	fsq	\N	\N	create	{"slug": "the-fundamental-problem-with-modern-technology-isn", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-08 20:48:57.100962+00	[]	active	{}	\N
541	ASTMGIK9THKVGZ3MF	fsq	\N	\N	create	{"slug": "our-deepest-fear-is-not-that-we-are-inadequate-our", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-08 22:29:29.099003+00	[]	active	{}	\N
542	ASTMGIK9TITBDR7LI	fsq	\N	\N	create	{"slug": "our-deepest-fear-is-not-that-we-are-inadequate-our", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-08 22:29:29.143169+00	[]	active	{}	\N
543	ASTMGIK9TJZRR688L	fsq	\N	\N	create	{"slug": "our-deepest-fear-is-not-that-we-are-inadequate-our", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-08 22:29:29.18523+00	[]	active	{}	\N
544	ASTMGIK9TL5L09YTV	fsq	\N	\N	create	{"slug": "our-deepest-fear-is-not-that-we-are-inadequate-our", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-08 22:29:29.228083+00	[]	active	{}	\N
545	ASTMGISIS4FY0M2O6	fsq	\N	\N	create	{"slug": "our-deepest-fear-is-not-that-we-are-inadequate-our", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-09 02:20:24.159814+00	[]	active	{}	\N
546	ASTMGISXWEVAH2A0W	fsq	\N	\N	create	{"slug": "our-deepest-fear-is-not-that-we-are-inadequate-our", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-09 02:32:09.560101+00	[]	active	{}	\N
547	ASTMGISXWFU4J1L7U	fsq	\N	\N	create	{"slug": "our-deepest-fear-is-not-that-we-are-inadequate-our", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-09 02:32:09.595653+00	[]	active	{}	\N
548	ASTMGISXY1JGLSIKL	fsq	\N	\N	create	{"slug": "our-deepest-fear-is-not-that-we-are-inadequate-our", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-09 02:32:11.67248+00	[]	active	{}	\N
549	ASTMGISXY2PJLKE67	fsq	\N	\N	create	{"slug": "our-deepest-fear-is-not-that-we-are-inadequate-our", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-09 02:32:11.715944+00	[]	active	{}	\N
550	ASTMGITFXZRHJ0BBL	fsq	\N	\N	create	{"slug": "our-deepest-fear-is-not-that-we-are-inadequate-our", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-09 02:46:11.417163+00	[]	active	{}	\N
551	ASTMGITFY11DDPXG2	fsq	\N	\N	create	{"slug": "our-deepest-fear-is-not-that-we-are-inadequate-our", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-09 02:46:11.463713+00	[]	active	{}	\N
552	ASTMGITFY27UBRLRZ	fsq	\N	\N	create	{"slug": "our-deepest-fear-is-not-that-we-are-inadequate-our", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-09 02:46:11.505773+00	[]	active	{}	\N
553	ASTMGITFY3HYSVU9R	fsq	\N	\N	create	{"slug": "our-deepest-fear-is-not-that-we-are-inadequate-our", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-09 02:46:11.552001+00	[]	active	{}	\N
554	ASTMGITOONVD3XO6C	fsq	\N	\N	create	{"slug": "our-deepest-fear-is-not-that-we-are-inadequate-our", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-09 02:52:59.22786+00	[]	active	{}	\N
555	ASTMGITOOODJ8HVB0	fsq	\N	\N	create	{"slug": "our-deepest-fear-is-not-that-we-are-inadequate-our", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-09 02:52:59.245789+00	[]	active	{}	\N
556	ASTMGITOOOU4CN132	fsq	\N	\N	create	{"slug": "our-deepest-fear-is-not-that-we-are-inadequate-our", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-09 02:52:59.263069+00	[]	active	{}	\N
557	ASTMGITOOPJR8HH25	fsq	\N	\N	create	{"slug": "our-deepest-fear-is-not-that-we-are-inadequate-our", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-09 02:52:59.28968+00	[]	active	{}	\N
558	ASTMGIUQJARL6J1Y6	fsq	\N	\N	create	{"slug": "our-deepest-fear-is-not-that-we-are-inadequate-our", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-09 03:22:25.205406+00	[]	active	{}	\N
559	ASTMGIUXAZR2RWZMZ	fsq	\N	\N	create	{"slug": "our-deepest-fear-is-not-that-we-are-inadequate-our", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-09 03:27:41.033811+00	[]	active	{}	\N
560	ASTMGIUXB18F2DND2	fsq	\N	\N	create	{"slug": "our-deepest-fear-is-not-that-we-are-inadequate-our", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-09 03:27:41.086655+00	[]	active	{}	\N
561	ASTMGIUXB28CFX1J0	fsq	\N	\N	create	{"slug": "our-deepest-fear-is-not-that-we-are-inadequate-our", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-09 03:27:41.12291+00	[]	active	{}	\N
566	ASTMGJ0LHCZ4CSUAN	fsq	\N	\N	create	{"slug": "this-is-a-quote-thats-just-being-made-for-fun-well", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-09 06:06:27.109825+00	[]	active	{}	\N
562	ASTMGIUXB3GLR726Z	fsq	\N	\N	create	{"slug": "our-deepest-fear-is-not-that-we-are-inadequate-our", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-09 03:27:41.166451+00	[]	active	{}	\N
568	SEGMGJ1SAFW0XVOVF	segment	\N	\N	rundown_item_creation	{"episode_number": "0244", "item_type": "coldopen", "title": "Cold Open", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-09 06:39:44.34854+00	[]	active	{}	\N
563	ASTMGIUZ58NM7JJAF	fsq	\N	\N	create	{"slug": "our-deepest-fear-is-not-that-we-are-inadequate-our", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-09 03:29:06.888097+00	[]	active	{}	\N
564	ASTMGJ0BL7LOC2ML8	fsq	\N	\N	create	{"slug": "this-is-just-a-test-quote-nothing-too-big-and-noth", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-09 05:58:45.537605+00	[]	active	{}	\N
565	ASTMGJ0BL8W0WGT0U	fsq	\N	\N	create	{"slug": "this-is-just-a-test-quote-nothing-too-big-and-noth", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-09 05:58:45.586572+00	[]	active	{}	\N
567	ASTMGJ0LHE68Q741Q	fsq	\N	\N	create	{"slug": "this-is-a-quote-thats-just-being-made-for-fun-well", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-09 06:06:27.15259+00	[]	active	{}	\N
569	SEGMGJ26HIJ6RBWQS	segment	\N	\N	rundown_item_creation	{"episode_number": "0244", "item_type": "coldopen", "title": "Cold Open", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-09 06:50:46.698483+00	[]	active	{}	\N
570	ASTMGJ7ME0FW1M2U8	fsq	\N	\N	create	{"slug": "this-is-going-to-be-an-interesting-test-not-so-muc", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-09 09:23:06.740326+00	[]	active	{}	\N
571	ASTMGJ7ME17PUMV4B	fsq	\N	\N	create	{"slug": "this-is-going-to-be-an-interesting-test-not-so-muc", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-09 09:23:06.764274+00	[]	active	{}	\N
572	ASTMGJ82GMUFVY5R8	fsq	\N	\N	create	{"slug": "i-cant-believe-it-wants-to-split-a-quote-this-smal", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-09 09:35:36.630981+00	[]	active	{}	\N
573	ASTMGJ8J1DKT9O788	fsq	\N	\N	create	{"slug": "this-is-my-test-quote", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-09 09:48:30.009216+00	[]	active	{}	\N
574	EPSMGJ8MVSR9ET1S9	episode	\N	\N	episode_scaffold_create	{"episode_number": "0244", "template_id": 1, "template_name": "Sunday Show", "title": null, "source": "episode_scaffold_service", "blueprint_template_type": "episode"}	1	2025-10-09 09:51:29.402603+00	[]	active	{}	\N
575	SEGMGJ8N04M7ZXXXA	segment	\N	\N	rundown_item_creation	{"episode_number": "0244", "item_type": "coldopen", "title": "Cold Open", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-09 09:51:35.014011+00	[]	active	{}	\N
576	SEGMGJ8N4X7SMMGJA	segment	\N	\N	rundown_item_creation	{"episode_number": "0244", "item_type": "tease", "title": "", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-09 09:51:41.226106+00	[]	active	{}	\N
577	SEGMGJA5VATKKF9LZ	segment	\N	\N	rundown_item_creation	{"episode_number": "0244", "item_type": "segment", "title": "Segment", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-09 10:34:14.837701+00	[]	active	{}	\N
578	SEGMGJA8C8COYKKVD	segment	\N	\N	rundown_item_creation	{"episode_number": "0244", "item_type": "segment", "title": "Segment", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-09 10:36:10.091952+00	[]	active	{}	\N
579	ASTMGJB6O2X1S1ILR	fsq	\N	\N	create	{"slug": "this-is-a-quote-well-see-how-the-llm-likes-this-on", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-09 11:02:51.753634+00	[]	active	{}	\N
580	ASTMGJC0RHU6DG6V1	fsq	\N	\N	create	{"slug": "this-is-a-sample-text-blah-blah", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-09 11:26:15.860981+00	[]	active	{}	\N
581	ASTMGJC6LL8JOCK86	fsq	\N	\N	create	{"slug": "this-is-going-to-be-a-somewhat-shot-quote-because-", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-09 11:30:48.142812+00	[]	active	{}	\N
582	ASTMGJCEF44RKHDCC	fsq	\N	\N	create	{"slug": "this-is-a-very-short-quote-for-testing", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-09 11:36:52.996962+00	[]	active	{}	\N
583	ASTMGJCXEYW1H4PFC	fsq	\N	\N	create	{"slug": "this-another-little-tiny-one-well-see-how-it-goes", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-09 11:51:39.272748+00	[]	active	{}	\N
584	SEGMGJGQ440NLSJ2B	segment	\N	\N	rundown_item_creation	{"episode_number": "0244", "item_type": "segment", "title": "Segment", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-09 13:37:57.07256+00	[]	active	{}	\N
585	ASTMGJGTX6Q2YD083	fsq	\N	\N	create	{"slug": "it-is-not-the-critic-who-counts-not-the-man-who-po", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-09 13:40:54.723428+00	[]	active	{}	\N
586	ASTMGJGTX7G6LKIQY	fsq	\N	\N	create	{"slug": "it-is-not-the-critic-who-counts-not-the-man-who-po", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-09 13:40:54.750709+00	[]	active	{}	\N
587	ASTMGJGTX8JHXS3J9	fsq	\N	\N	create	{"slug": "it-is-not-the-critic-who-counts-not-the-man-who-po", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-09 13:40:54.789359+00	[]	active	{}	\N
588	ASTMGJGTX9R91CCNK	fsq	\N	\N	create	{"slug": "it-is-not-the-critic-who-counts-not-the-man-who-po", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-09 13:40:54.833593+00	[]	active	{}	\N
589	ASTMGJHC2AVP9AEJJ	fsq	\N	\N	create	{"slug": "it-is-not-the-critic-who-counts-not-the-man-who-po", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-09 13:55:01.159887+00	[]	active	{}	\N
590	ASTMGJHC2BNI31WEG	fsq	\N	\N	create	{"slug": "it-is-not-the-critic-who-counts-not-the-man-who-po", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-09 13:55:01.188122+00	[]	active	{}	\N
591	ASTMGJHC34SAV2PVO	fsq	\N	\N	create	{"slug": "it-is-not-the-critic-who-counts-not-the-man-who-po", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-09 13:55:02.236826+00	[]	active	{}	\N
592	ASTMGJHC35G87NV5A	fsq	\N	\N	create	{"slug": "it-is-not-the-critic-who-counts-not-the-man-who-po", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-09 13:55:02.261353+00	[]	active	{}	\N
593	CUEMGJHEM2F8CRMZI	cue	\N	\N	create	{"slug": "Political Ponerology", "cue_type": "IMG", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-10-09 13:57:00.087816+00	[{"asset_id": "SEGMGJGQ440NLSJ2B", "link_type": "parent_child"}]	active	{}	\N
594	SEGMGJHH4ZAE5HIT4	segment	\N	\N	rundown_item_creation	{"episode_number": "0244", "item_type": "tease", "title": "", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-09 13:58:57.90924+00	[]	active	{}	\N
595	SEGMGJINIJSQVD2X4	segment	\N	\N	rundown_item_creation	{"episode_number": "0244", "item_type": "ad", "title": "Advertisement", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-09 14:31:55.048542+00	[]	active	{}	\N
596	SEGMGJINQASODJ0CY	segment	\N	\N	rundown_item_creation	{"episode_number": "0244", "item_type": "promo", "title": "Promo", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-09 14:32:05.092516+00	[]	active	{}	\N
597	SEGMGJINVAWSVJ31S	segment	\N	\N	rundown_item_creation	{"episode_number": "0244", "item_type": "ad", "title": "Advertisement", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-09 14:32:11.57526+00	[]	active	{}	\N
598	SEGMGJIO3V7IF0D94	segment	\N	\N	rundown_item_creation	{"episode_number": "0244", "item_type": "reader", "title": "Reader", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-09 14:32:22.675441+00	[]	active	{}	\N
599	SEGMGJIO7DLHDYQYS	segment	\N	\N	rundown_item_creation	{"episode_number": "0244", "item_type": "segment", "title": "Segment", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-09 14:32:27.224812+00	[]	active	{}	\N
600	SEGMGJIP56KHQJJVH	segment	\N	\N	rundown_item_creation	{"episode_number": "0244", "item_type": "segment", "title": "Segment", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-09 14:33:11.036344+00	[]	active	{}	\N
601	SEGMGJJ4J0MDFRK9R	segment	\N	\N	rundown_item_creation	{"episode_number": "0244", "item_type": "segment", "title": "Segment", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-09 14:45:08.805619+00	[]	active	{}	\N
602	SEGMGJJ4MNCMSG6JK	segment	\N	\N	rundown_item_creation	{"episode_number": "0244", "item_type": "segment", "title": "Segment", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-09 14:45:13.511352+00	[]	active	{}	\N
603	SEGMGJLVFNHPJCN6K	segment	\N	\N	rundown_item_creation	{"episode_number": "0244", "item_type": "ad", "title": "Advertisement", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-09 16:02:03.389362+00	[]	active	{}	\N
604	ASTMGLLF3IID3YDUG	fsq	\N	\N	create	{"slug": "it-is-not-the-critic-who-counts-not-the-man-who-po", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-11 01:24:53.517448+00	[]	active	{}	\N
605	ASTMGLLF4C5A4AMS6	fsq	\N	\N	create	{"slug": "it-is-not-the-critic-who-counts-not-the-man-who-po", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-11 01:24:54.582375+00	[]	active	{}	\N
606	ASTMGLLF5YGEZRSPU	fsq	\N	\N	create	{"slug": "it-is-not-the-critic-who-counts-not-the-man-who-po", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-11 01:24:56.681047+00	[]	active	{}	\N
607	ASTMGLLF6TSRB22H4	fsq	\N	\N	create	{"slug": "it-is-not-the-critic-who-counts-not-the-man-who-po", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-11 01:24:57.809129+00	[]	active	{}	\N
608	EPSMGMG0VQQ3YNTQG	episode	\N	\N	episode_scaffold_create	{"episode_number": "0244", "template_id": 1, "template_name": "Sunday Show", "title": "The Age of the Goprgon", "source": "episode_scaffold_service", "blueprint_template_type": "episode"}	1	2025-10-11 15:41:38.353442+00	[]	active	{}	\N
609	SEGMGMG13VKT7MHEU	segment	\N	\N	rundown_item_creation	{"episode_number": "0244", "item_type": "coldopen", "title": "Cold Open", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-11 15:41:48.89465+00	[]	active	{}	\N
610	SEGMGMG20FY8HNVGG	segment	\N	\N	rundown_item_creation	{"episode_number": "0244", "item_type": "tease", "title": "", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-11 15:42:31.101281+00	[]	active	{}	\N
611	SEGMGMG2NABR72ATP	segment	\N	\N	rundown_item_creation	{"episode_number": "0244", "item_type": "segment", "title": "Segment", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-11 15:43:00.70666+00	[]	active	{}	\N
612	ASTMGMNYNLPK9P5GZ	sot	\N	\N	create	{"slug": "goodall-death-video", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-11 19:23:51.422455+00	[]	active	{}	\N
613	ASTMGMODWVIK0HGBP	sot	\N	\N	create	{"slug": "goodall-death-video", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-11 19:35:43.280397+00	[]	active	{}	\N
614	SEGMGMPEQS59I0AT0	segment	\N	\N	rundown_item_creation	{"episode_number": "0244", "item_type": "segment", "title": "Segment", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-11 20:04:21.651925+00	[]	active	{}	\N
615	ASTMGMPKFVORV5Z46	sot	\N	\N	create	{"slug": "goodall-death-video", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-11 20:08:47.462462+00	[]	active	{}	\N
616	SEGMGREPP6T07K3RA	segment	\N	\N	rundown_item_creation	{"episode_number": "0244", "item_type": "reader", "title": "Reader", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-15 03:03:47.908469+00	[]	active	{}	\N
617	SEGMGRKYN0Z2XMHYZ	segment	\N	\N	rundown_item_creation	{"episode_number": "0244", "item_type": "promo", "title": "Promo", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-15 05:58:42.707415+00	[]	active	{}	\N
618	EPSMGSNWG7GZUE0I4	episode	\N	\N	episode_scaffold_create	{"episode_number": "0245", "template_id": 5, "template_name": "Canonical Episode Structure", "title": null, "source": "episode_scaffold_service", "blueprint_template_type": "episode"}	1	2025-10-16 00:08:45.578826+00	[]	active	{}	\N
619	SEGMGST9S6RG1VGH5	segment	\N	\N	rundown_item_creation	{"episode_number": "0245", "item_type": "coldopen", "title": "Cold Open", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-16 02:39:05.71509+00	[]	active	{}	\N
620	SEGMGSTC532HPUTF7	segment	\N	\N	rundown_item_creation	{"episode_number": "0245", "item_type": "tease", "title": "", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-16 02:40:55.742002+00	[]	active	{}	\N
621	CUEMGWN9MFXP1F5DI	cue	\N	\N	create	{"slug": "i-love-hitler", "cue_type": "IMG", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-10-18 19:02:05.28461+00	[{"asset_id": "SEG000000MLK61BYF", "link_type": "parent_child"}]	active	{}	\N
622	SEGMGWNBCA45EWPQC	segment	\N	\N	rundown_item_creation	{"episode_number": "0245", "item_type": "ad", "title": "Advertisement", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-18 19:03:25.420423+00	[]	active	{}	\N
623	EPSMGWPSQDYIBEPAI	episode	\N	\N	episode_scaffold_create	{"episode_number": "0245", "template_id": 5, "template_name": "Canonical Episode Structure", "title": "Unknown", "source": "episode_scaffold_service", "blueprint_template_type": "episode"}	1	2025-10-18 20:12:56.085689+00	[]	active	{}	\N
624	SEGMGWPSVKFRX4PZC	segment	\N	\N	rundown_item_creation	{"episode_number": "0245", "item_type": "coldopen", "title": "Cold Open", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-18 20:13:02.797926+00	[]	active	{}	\N
625	SEGMGWPTMGBVEOYPJ	segment	\N	\N	rundown_item_creation	{"episode_number": "0245", "item_type": "coldopen", "title": "Cold Open", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-18 20:13:37.641931+00	[]	active	{}	\N
626	SEGMGWPTSKWZKT1EF	segment	\N	\N	rundown_item_creation	{"episode_number": "0245", "item_type": "tease", "title": "", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-18 20:13:45.582704+00	[]	active	{}	\N
627	SEGMGWPTVXN8AQSR7	segment	\N	\N	rundown_item_creation	{"episode_number": "0245", "item_type": "segment", "title": "Segment", "creation_method": "create_rundown_item_endpoint"}	kevin	2025-10-18 20:13:49.93105+00	[]	active	{}	\N
628	CUEMGWPW8SH8JR4CT	cue	\N	\N	create	{"slug": "I love hitler", "cue_type": "IMG", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-10-18 20:15:39.906208+00	[{"asset_id": "SEGMGWPTVXN8AQSR7", "link_type": "parent_child"}]	active	{}	\N
629	ASTMGWPXX2BWEUEDG	fsq	\N	\N	create	{"slug": "leaders-of-young-republican-groups-throughout-the-", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-18 20:16:58.021275+00	[]	active	{}	\N
630	ASTMGWQ08UKSR59AI	fsq	\N	\N	create	{"slug": "leaders-of-young-republican-groups-throughout-the-", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-18 20:18:46.605714+00	[]	active	{}	\N
631	ASTMGWQ1AUD8MSFD3	fsq	\N	\N	create	{"slug": "leaders-of-young-republican-groups-throughout-the-", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-18 20:19:35.847647+00	[]	active	{}	\N
632	ASTMGWQ450KQXCO2N	fsq	\N	\N	create	{"slug": "leaders-of-young-republican-groups-throughout-the-", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-18 20:21:48.262793+00	[]	active	{}	\N
633	ASTMGWQ6543PBKAZ0	fsq	\N	\N	create	{"slug": "they-referred-to-black-people-as-monkeys-and-the-w", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-18 20:23:21.701989+00	[]	active	{}	\N
634	ASTMGWQ7Q774MVWQ3	fsq	\N	\N	create	{"slug": "william-hendrix-the-kansas-young-republicans-vice-", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-18 20:24:35.685047+00	[]	active	{}	\N
635	ASTMGWQ8GB2F2PDWM	fsq	\N	\N	create	{"slug": "leaders-of-young-republican-groups-throughout-the-", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-18 20:25:09.520247+00	[]	active	{}	\N
636	ASTMGWQ8WQKL18LB3	fsq	\N	\N	create	{"slug": "leaders-of-young-republican-groups-throughout-the-", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-18 20:25:30.813068+00	[]	active	{}	\N
639	ASTMGWQE1NIT33PLJ	fsq	\N	\N	create	{"slug": "since-politico-began-making-inquiries-one-member-o", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-18 20:29:30.464368+00	[]	active	{}	\N
641	ASTMGWQL6S5AMISAO	fsq	\N	\N	create	{"slug": "the-more-the-political-atmosphere-is-open-and-libe", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-18 20:35:03.702758+00	[]	active	{}	\N
642	CUEMGWQNF9NVOKK6Y	cue	\N	\N	create	{"slug": "Text Graphic", "cue_type": "IMG", "episode_number": null, "source": "unified_newAssetID_endpoint"}	rbac-test	2025-10-18 20:36:48.011966+00	[{"asset_id": "SEGMGWPTVXN8AQSR7", "link_type": "parent_child"}]	active	{}	\N
637	ASTMGWQCMRNH759TC	fsq	\N	\N	create	{"slug": "the-exchange-is-part-of-a-trove-of-telegram-chats-", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-18 20:28:24.516293+00	[]	active	{}	\N
638	ASTMGWQE1M9JN2XJB	fsq	\N	\N	create	{"slug": "since-politico-began-making-inquiries-one-member-o", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-18 20:29:30.419205+00	[]	active	{}	\N
640	ASTMGWQL6QZ09J872	fsq	\N	\N	create	{"slug": "the-more-the-political-atmosphere-is-open-and-libe", "legacy_compatibility": true, "original_endpoint": "/next-id"}	rbac-test	2025-10-18 20:35:03.660728+00	[]	active	{}	\N
643	EPSMGXZLLRZO3X7TQ	episode	\N	\N	episode_scaffold_create	{"episode_number": "0246", "template_id": 5, "template_name": "Canonical Episode Structure", "title": "Up Nextca", "source": "episode_scaffold_service", "blueprint_template_type": "episode"}	1	2025-10-19 17:35:05.854552+00	[]	active	{}	\N
644	EPSMGXZRTLWIT8OGF	episode	\N	\N	episode_scaffold_create	{"episode_number": "0246", "template_id": 6, "template_name": "Sunday Show", "title": "Whatachacallit?", "source": "episode_scaffold_service", "blueprint_template_type": "episode"}	1	2025-10-19 17:39:55.936473+00	[]	active	{}	\N
645	EPSMGY0LFC80J3EZG	episode	\N	\N	episode_scaffold_create	{"episode_number": "0245", "template_id": 6, "template_name": "Sunday Show", "title": null, "source": "episode_scaffold_service", "blueprint_template_type": "episode"}	1	2025-10-19 18:02:57.127322+00	[]	active	{}	\N
\.


--
-- Data for Name: asset_id_relationships; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.asset_id_relationships (id, source_asset_id, target_asset_id, relationship_type, is_bidirectional, strength, created_by, created_at, context, is_active, notes) FROM stdin;
1	SEGMEEFAFL4C5RT2B	EPSMEEFA0DTJNAYVN	parent_child	false	1	rbac-test	2025-08-16 15:39:30.280946+00	{"initial_link": true}	active	\N
2	CUEMEEFALU37XGFSZ	SEGMEEFAFL4C5RT2B	parent_child	false	1	rbac-test	2025-08-16 15:39:38.380119+00	{"initial_link": true}	active	\N
3	CUEMEEFBKP63U781E	SEGMEEFAFL4C5RT2B	parent_child	false	1	rbac-test	2025-08-16 15:40:23.563499+00	{"initial_link": true}	active	\N
4	CUEMEEJFS6N0Y6BVP	SEGMEEJ3TNWZ5IUEO	parent_child	false	1	rbac-test	2025-08-16 17:35:38.353619+00	{"initial_link": true}	active	\N
5	CUEMEEJFW5OXH49CV	SEGMEEJ3TNWZ5IUEO	parent_child	false	1	rbac-test	2025-08-16 17:35:43.502736+00	{"initial_link": true}	active	\N
6	CUEMEEJFZ1B48GJAV	SEGMEEJ3TNWZ5IUEO	parent_child	false	1	rbac-test	2025-08-16 17:35:47.233777+00	{"initial_link": true}	active	\N
7	CUEMEEJG1BTTZ9RKK	SEGMEEJ3TNWZ5IUEO	parent_child	false	1	rbac-test	2025-08-16 17:35:50.203806+00	{"initial_link": true}	active	\N
8	CUEMEEJG43IE9XE52	SEGMEEJ3TNWZ5IUEO	parent_child	false	1	rbac-test	2025-08-16 17:35:53.792435+00	{"initial_link": true}	active	\N
9	CUEMEEJG6CVN16KFJ	SEGMEEJ3TNWZ5IUEO	parent_child	false	1	rbac-test	2025-08-16 17:35:56.721694+00	{"initial_link": true}	active	\N
10	CUEMEEJG9AV3QQNDK	SEGMEEJ3TNWZ5IUEO	parent_child	false	1	rbac-test	2025-08-16 17:36:00.53746+00	{"initial_link": true}	active	\N
11	CUEMEEJGLF9OYQXZC	SEGMEEJ44L61P9LZV	parent_child	false	1	rbac-test	2025-08-16 17:36:16.247519+00	{"initial_link": true}	active	\N
12	CUEMEEJGNHIAMNDQO	SEGMEEJ44L61P9LZV	parent_child	false	1	rbac-test	2025-08-16 17:36:18.920579+00	{"initial_link": true}	active	\N
13	CUEMEEJGPMGOLLC0T	SEGMEEJ44L61P9LZV	parent_child	false	1	rbac-test	2025-08-16 17:36:21.690777+00	{"initial_link": true}	active	\N
14	CUEMEEJGRSTM36X2K	SEGMEEJ44L61P9LZV	parent_child	false	1	rbac-test	2025-08-16 17:36:24.511574+00	{"initial_link": true}	active	\N
15	CUEMEEJGUC9SV6YC8	SEGMEEJ44L61P9LZV	parent_child	false	1	rbac-test	2025-08-16 17:36:27.804037+00	{"initial_link": true}	active	\N
16	CUEMEEJGWBU9O8PJZ	SEGMEEJ44L61P9LZV	parent_child	false	1	rbac-test	2025-08-16 17:36:30.380586+00	{"initial_link": true}	active	\N
17	CUEMEEJGZ5BR5TNAN	SEGMEEJ44L61P9LZV	parent_child	false	1	rbac-test	2025-08-16 17:36:34.033802+00	{"initial_link": true}	active	\N
18	CUEMEEJH18K27GCUJ	SEGMEEJ44L61P9LZV	parent_child	false	1	rbac-test	2025-08-16 17:36:36.74315+00	{"initial_link": true}	active	\N
19	CUEMEEJH39UTHDQPZ	SEGMEEJ44L61P9LZV	parent_child	false	1	rbac-test	2025-08-16 17:36:39.380936+00	{"initial_link": true}	active	\N
20	CUEMEEJH5L5EJ0QLB	SEGMEEJ44L61P9LZV	parent_child	false	1	rbac-test	2025-08-16 17:36:42.379902+00	{"initial_link": true}	active	\N
21	CUEMEEJH851KUTI9Z	SEGMEEJ44L61P9LZV	parent_child	false	1	rbac-test	2025-08-16 17:36:45.688006+00	{"initial_link": true}	active	\N
22	CUEMEEJHAGOJO5MHZ	SEGMEEJ44L61P9LZV	parent_child	false	1	rbac-test	2025-08-16 17:36:48.698898+00	{"initial_link": true}	active	\N
23	CUEMEEJHCIJ9X84QX	SEGMEEJ44L61P9LZV	parent_child	false	1	rbac-test	2025-08-16 17:36:51.35736+00	{"initial_link": true}	active	\N
24	CUEMEEJHEY901HMCU	SEGMEEJ44L61P9LZV	parent_child	false	1	rbac-test	2025-08-16 17:36:54.515804+00	{"initial_link": true}	active	\N
25	CUEMEEJHIMKMC68FC	SEGMEEJ44L61P9LZV	parent_child	false	1	rbac-test	2025-08-16 17:36:59.278997+00	{"initial_link": true}	active	\N
26	CUEMEEJHWMROXL1L8	SEGMEEJ56401DC7UN	parent_child	false	1	rbac-test	2025-08-16 17:37:17.429394+00	{"initial_link": true}	active	\N
27	CUEMEEJHZTQUO2VE3	SEGMEEJ56401DC7UN	parent_child	false	1	rbac-test	2025-08-16 17:37:21.567228+00	{"initial_link": true}	active	\N
28	CUEMEEJJ87VW7XCBR	SEGMEEJ5H1D9I4K1D	parent_child	false	1	rbac-test	2025-08-16 17:38:19.10189+00	{"initial_link": true}	active	\N
29	CUEMEEND27OHTCFXG	SEGMEENCPXQ375N35	parent_child	false	1	rbac-test	2025-08-16 19:25:29.845127+00	{"initial_link": true}	active	\N
30	CUEMEENDH3XSJ7GMN	SEGMEEJ4JNYVA02T4	parent_child	false	1	rbac-test	2025-08-16 19:25:49.151458+00	{"initial_link": true}	active	\N
31	CUEMEENDM8FGBUPV8	SEGMEEJ3YD0OKZM7D	parent_child	false	1	rbac-test	2025-08-16 19:25:55.794044+00	{"initial_link": true}	active	\N
32	ASTMEEOASULAQYTLJ	EPSMEEJ32D9UFK5BU	parent_child	false	1	rbac-test	2025-08-16 19:51:44.01617+00	{"initial_link": true}	active	\N
33	CUEMEEPQ1XNB587ME	SEGMEEJ5H1D9I4K1D	parent_child	false	1	rbac-test	2025-08-16 20:31:35.245573+00	{"initial_link": true}	active	\N
34	CUEMEEQS4B424DL1B	SEGMEEJ3TNWZ5IUEO	parent_child	false	1	rbac-test	2025-08-16 21:01:11.248743+00	{"initial_link": true}	active	\N
35	CUEMEF1M0VOTMXHR0	SEGMEEJ3TNWZ5IUEO	parent_child	false	1	rbac-test	2025-08-17 02:04:22.646487+00	{"initial_link": true}	active	\N
36	CUEMEF1MMCNHQ2B7J	SEGMEEJ3TNWZ5IUEO	parent_child	false	1	rbac-test	2025-08-17 02:04:50.473946+00	{"initial_link": true}	active	\N
37	CUEMEF1NP7R2S32UR	SEGMEEJ3TNWZ5IUEO	parent_child	false	1	rbac-test	2025-08-17 02:05:40.842083+00	{"initial_link": true}	active	\N
38	CUEMEF1W0XP0Q5PKX	SEGMEEJ3TNWZ5IUEO	parent_child	false	1	rbac-test	2025-08-17 02:12:09.280027+00	{"initial_link": true}	active	\N
39	CUEMEF22TNG6F7ZS8	SEGMEEJ3TNWZ5IUEO	parent_child	false	1	rbac-test	2025-08-17 02:17:26.429128+00	{"initial_link": true}	active	\N
40	CUEMEF23DJ45GABLZ	SEGMEEJ3TNWZ5IUEO	parent_child	false	1	rbac-test	2025-08-17 02:17:52.195024+00	{"initial_link": true}	active	\N
41	CUEMEF23VI6WIQ8SW	SEGMEEJ3TNWZ5IUEO	parent_child	false	1	rbac-test	2025-08-17 02:18:15.489116+00	{"initial_link": true}	active	\N
42	CUEMEF24QS9R6YDTF	SEGMEEJ3TNWZ5IUEO	parent_child	false	1	rbac-test	2025-08-17 02:18:56.025718+00	{"initial_link": true}	active	\N
43	CUEMEF2AE2W19MGZT	SEGMEEJ3TNWZ5IUEO	parent_child	false	1	rbac-test	2025-08-17 02:23:19.499039+00	{"initial_link": true}	active	\N
44	CUEMENIEHR7MIKVGP	slug:	parent_child	false	1	rbac-test	2025-08-23 00:16:34.149324+00	{"initial_link": true}	active	\N
45	CUEMENIJTO5C5B6VO	slug:	parent_child	false	1	rbac-test	2025-08-23 00:20:42.871436+00	{"initial_link": true}	active	\N
46	CUEMENIK9AF8ZAMJJ	slug:	parent_child	false	1	rbac-test	2025-08-23 00:21:03.113902+00	{"initial_link": true}	active	\N
47	CUEMENILDKHRC2TKM	slug:	parent_child	false	1	rbac-test	2025-08-23 00:21:55.316206+00	{"initial_link": true}	active	\N
48	CUEMENILXIWG7QRQ7	slug:	parent_child	false	1	rbac-test	2025-08-23 00:22:21.178816+00	{"initial_link": true}	active	\N
49	CUEMENIMRMCYQWKEI	slug:	parent_child	false	1	rbac-test	2025-08-23 00:23:00.182543+00	{"initial_link": true}	active	\N
50	CUEMENIRGZ906SNAR	slug:	parent_child	false	1	rbac-test	2025-08-23 00:26:39.669717+00	{"initial_link": true}	active	\N
51	CUEMENIS44YIBI1Q7	slug:	parent_child	false	1	rbac-test	2025-08-23 00:27:09.683049+00	{"initial_link": true}	active	\N
52	CUEMENIUDD21M7S2X	slug:	parent_child	false	1	rbac-test	2025-08-23 00:28:54.953047+00	{"initial_link": true}	active	\N
53	CUEMENIWAI54O2R24	slug:	parent_child	false	1	rbac-test	2025-08-23 00:30:24.559332+00	{"initial_link": true}	active	\N
54	CUEMENIZ7HH2OW09M	slug:	parent_child	false	1	rbac-test	2025-08-23 00:32:40.616157+00	{"initial_link": true}	active	\N
55	CUEMENJ1R1M5WVTRP	slug:	parent_child	false	1	rbac-test	2025-08-23 00:34:39.276316+00	{"initial_link": true}	active	\N
56	CUEMENJH97NHXBN4P	slug:	parent_child	false	1	rbac-test	2025-08-23 00:46:42.661809+00	{"initial_link": true}	active	\N
57	CUEMENJIUTTLKPHDF	slug:	parent_child	false	1	rbac-test	2025-08-23 00:47:57.332069+00	{"initial_link": true}	active	\N
58	CUEMENJJDS312LZRG	slug:	parent_child	false	1	rbac-test	2025-08-23 00:48:21.894202+00	{"initial_link": true}	active	\N
59	CUEMENM36688GBOIO	LOCAL-RD-menkaa03-ma8qf	parent_child	false	1	rbac-test	2025-08-23 01:59:44.386314+00	{"initial_link": true}	active	\N
60	CUEMENMPWWR6J4IP4	LOCAL-RD-menkaa03-ma8qf	parent_child	false	1	rbac-test	2025-08-23 02:17:25.469464+00	{"initial_link": true}	active	\N
61	CUEMENMRO3E5UHGQO	LOCAL-RD-menkaa03-ma8qf	parent_child	false	1	rbac-test	2025-08-23 02:18:47.356425+00	{"initial_link": true}	active	\N
62	CUEMENMSMYX79Z3L4	LOCAL-RD-menkaa03-ma8qf	parent_child	false	1	rbac-test	2025-08-23 02:19:32.556155+00	{"initial_link": true}	active	\N
63	CUEMENMUQO30DJWZ6	LOCAL-RD-menkaa03-ma8qf	parent_child	false	1	rbac-test	2025-08-23 02:21:10.660382+00	{"initial_link": true}	active	\N
64	CUEMENN9OHORZFJJL	SEGMEEJ3TNWZ5IUEO	parent_child	false	1	rbac-test	2025-08-23 02:32:47.678517+00	{"initial_link": true}	active	\N
65	CUEMENNBL547W2F07	SEGMEEJ3TNWZ5IUEO	parent_child	false	1	rbac-test	2025-08-23 02:34:16.650666+00	{"initial_link": true}	active	\N
66	CUEMENNQEK7IBMNV5	slug: 60 Cracker Barrel	parent_child	false	1	rbac-test	2025-08-23 02:45:47.961449+00	{"initial_link": true}	active	\N
67	CUEMENNRBBBQIXF7I	slug: 60 Cracker Barrel	parent_child	false	1	rbac-test	2025-08-23 02:46:30.407515+00	{"initial_link": true}	active	\N
68	CUEMENNSC98CS9ZZU	slug: 60 Cracker Barrel	parent_child	false	1	rbac-test	2025-08-23 02:47:18.287016+00	{"initial_link": true}	active	\N
69	CUEMENNSXUZ1JDLZ7	slug: 60 Cracker Barrel	parent_child	false	1	rbac-test	2025-08-23 02:47:46.286321+00	{"initial_link": true}	active	\N
70	CUEMENNVF3E2C7XIL	slug: 60 Cracker Barrel	parent_child	false	1	rbac-test	2025-08-23 02:49:41.932756+00	{"initial_link": true}	active	\N
71	CUEMENOBAE6S4NZSE	slug: taylor swift	parent_child	false	1	rbac-test	2025-08-23 03:02:02.336303+00	{"initial_link": true}	active	\N
72	CUEMEOJRS925MMOI8	SEGMENO45GP697XFT	parent_child	false	1	rbac-test	2025-08-23 17:42:40.072706+00	{"initial_link": true}	active	\N
73	CUEMEOMV84ZZEZVMG	SEGMENO45GP697XFT	parent_child	false	1	rbac-test	2025-08-23 19:09:19.475796+00	{"initial_link": true}	active	\N
74	CUEMEOMVCAIQ2MDV7	SEGMENO45GP697XFT	parent_child	false	1	rbac-test	2025-08-23 19:09:24.858709+00	{"initial_link": true}	active	\N
75	CUEMEOMVM8C1BJ23P	SEGMENO45GP697XFT	parent_child	false	1	rbac-test	2025-08-23 19:09:37.740926+00	{"initial_link": true}	active	\N
76	CUEMEOMVPPIAIQMD7	SEGMENO45GP697XFT	parent_child	false	1	rbac-test	2025-08-23 19:09:42.249196+00	{"initial_link": true}	active	\N
77	CUEMEOMVWA97O7H4A	SEGMENO45GP697XFT	parent_child	false	1	rbac-test	2025-08-23 19:09:50.769973+00	{"initial_link": true}	active	\N
78	CUEMEOMVZ52ZIS1IR	SEGMENO45GP697XFT	parent_child	false	1	rbac-test	2025-08-23 19:09:54.470773+00	{"initial_link": true}	active	\N
79	CUEMEOPLOWFSWFCUJ	SEGMEOOMWQVHLKPE7	parent_child	false	1	rbac-test	2025-08-23 20:25:53.489662+00	{"initial_link": true}	active	\N
80	CUEMEOPR27Q8GRQ0Z	SEGMEOOMWQVHLKPE7	parent_child	false	1	rbac-test	2025-08-23 20:30:04.024575+00	{"initial_link": true}	active	\N
81	CUEMEOPR5F8O373KC	SEGMEOOMWQVHLKPE7	parent_child	false	1	rbac-test	2025-08-23 20:30:08.180858+00	{"initial_link": true}	active	\N
82	CUEMEOPR9VVUNF1I6	SEGMEOOMWQVHLKPE7	parent_child	false	1	rbac-test	2025-08-23 20:30:13.964273+00	{"initial_link": true}	active	\N
83	CUEMEOPRCZZB1GX3E	SEGMEOOMWQVHLKPE7	parent_child	false	1	rbac-test	2025-08-23 20:30:18.001871+00	{"initial_link": true}	active	\N
84	CUEMEOPRF6G39VFYE	SEGMEOOMWQVHLKPE7	parent_child	false	1	rbac-test	2025-08-23 20:30:20.826999+00	{"initial_link": true}	active	\N
85	CUEMEOSWI106C2RU2	SEGMEOJ449DRJ4QTV	parent_child	false	1	rbac-test	2025-08-23 21:58:16.646977+00	{"initial_link": true}	active	\N
86	CUEMEOSWMBZ8DISGQ	SEGMEOJ449DRJ4QTV	parent_child	false	1	rbac-test	2025-08-23 21:58:22.224229+00	{"initial_link": true}	active	\N
87	CUEMEOSWQW1HZZOM9	SEGMEOJ449DRJ4QTV	parent_child	false	1	rbac-test	2025-08-23 21:58:28.129622+00	{"initial_link": true}	active	\N
88	ASTMFMTPMGXOM4Q0M	EPSMFMPEPUSI2Y6WI	belongs_to	false	1	system	2025-09-16 17:25:05.404251+00	{"initial_link": true}	active	\N
89	ASTMFSR6T37QO5C5V	EPSMFSR3W9KUCTLRM	belongs_to	false	1	system	2025-09-20 21:01:05.343761+00	{"initial_link": true}	active	\N
90	SEGMG2JULOQ1X5N00	EPSMG1FO7YJDBU685	parent_child	false	1	rbac-test	2025-09-27 17:33:20.330624+00	{"initial_link": true}	active	\N
91	SEGMG2JURAGJEZPQL	EPSMG1FO7YJDBU685	parent_child	false	1	rbac-test	2025-09-27 17:33:27.593123+00	{"initial_link": true}	active	\N
92	SEGMG2JUU3S9S96SK	EPSMG1FO7YJDBU685	parent_child	false	1	rbac-test	2025-09-27 17:33:31.240731+00	{"initial_link": true}	active	\N
93	ASTMG2JUWUQNG6M0O	EPSMG1FO7YJDBU685	parent_child	false	1	rbac-test	2025-09-27 17:33:34.802723+00	{"initial_link": true}	active	\N
94	ASTMG2JUZJ3FTWP8I	EPSMG1FO7YJDBU685	parent_child	false	1	rbac-test	2025-09-27 17:33:38.272403+00	{"initial_link": true}	active	\N
95	ASTMG2JV2CJ5MEEMQ	EPSMG1FO7YJDBU685	parent_child	false	1	rbac-test	2025-09-27 17:33:41.924283+00	{"initial_link": true}	active	\N
96	SEGMG2JV51DS812IP	EPSMG1FO7YJDBU685	parent_child	false	1	rbac-test	2025-09-27 17:33:45.41025+00	{"initial_link": true}	active	\N
97	CUEMG2JVYTBHG46P3	SEGMG2JULOQ1X5N00	parent_child	false	1	rbac-test	2025-09-27 17:34:24.000009+00	{"initial_link": true}	active	\N
98	CUEMG2JW25J5BQ66L	SEGMG2JURAGJEZPQL	parent_child	false	1	rbac-test	2025-09-27 17:34:28.327666+00	{"initial_link": true}	active	\N
99	CUEMG2JW5SMZ5UF4M	SEGMG2JUU3S9S96SK	parent_child	false	1	rbac-test	2025-09-27 17:34:33.047299+00	{"initial_link": true}	active	\N
100	CUEMG2JW91TC7RYC7	ASTMG2JUWUQNG6M0O	parent_child	false	1	rbac-test	2025-09-27 17:34:37.265749+00	{"initial_link": true}	active	\N
101	CUEMG2JWCB2PMURMO	SEGMG2JV51DS812IP	parent_child	false	1	rbac-test	2025-09-27 17:34:41.487215+00	{"initial_link": true}	active	\N
102	CUEMG2KVLD89T2X33	EPSMG001SVZY8YW7C	parent_child	false	1	rbac-test	2025-09-27 18:02:06.189103+00	{"initial_link": true}	active	\N
103	SEGMG2KVSDL9HUS78	EPSMG001SVZY8YW7C	parent_child	false	1	rbac-test	2025-09-27 18:02:15.274645+00	{"initial_link": true}	active	\N
104	SEGMG2KVVKRJ8HDCU	EPSMG001SVZY8YW7C	parent_child	false	1	rbac-test	2025-09-27 18:02:19.420451+00	{"initial_link": true}	active	\N
105	CUEMG2KVZVQP10KD0	SEGMG2KVSDL9HUS78	parent_child	false	1	rbac-test	2025-09-27 18:02:24.999323+00	{"initial_link": true}	active	\N
106	CUEMG2KW39X1RBRLD	SEGMG2KVSDL9HUS78	parent_child	false	1	rbac-test	2025-09-27 18:02:29.397703+00	{"initial_link": true}	active	\N
110	CUEMG2KWH4LLTS1MJ	SEGMG2KVSDL9HUS78	parent_child	false	1	rbac-test	2025-09-27 18:02:47.35+00	{"initial_link": true}	active	\N
114	SEGMG2LYK9O94ADTY	EPSMG001SVZY8YW7C	parent_child	false	1	rbac-test	2025-09-27 18:32:24.348961+00	{"initial_link": true}	active	\N
107	CUEMG2KW6U169BUYJ	SEGMG2KVSDL9HUS78	parent_child	false	1	rbac-test	2025-09-27 18:02:34.010268+00	{"initial_link": true}	active	\N
111	CUEMG2KWLAFYEU62Y	SEGMG2KVVKRJ8HDCU	parent_child	false	1	rbac-test	2025-09-27 18:02:52.743936+00	{"initial_link": true}	active	\N
115	SEGMG2LYNNLI3QNKQ	EPSMG001SVZY8YW7C	parent_child	false	1	rbac-test	2025-09-27 18:32:28.738052+00	{"initial_link": true}	active	\N
108	CUEMG2KWA7KAP8CLY	SEGMG2KVSDL9HUS78	parent_child	false	1	rbac-test	2025-09-27 18:02:38.385093+00	{"initial_link": true}	active	\N
112	SEGMG2LYDS65PWXQP	EPSMG001SVZY8YW7C	parent_child	false	1	rbac-test	2025-09-27 18:32:15.943267+00	{"initial_link": true}	active	\N
109	CUEMG2KWDHHJJIOFA	SEGMG2KVSDL9HUS78	parent_child	false	1	rbac-test	2025-09-27 18:02:42.630309+00	{"initial_link": true}	active	\N
113	SEGMG2LYH4QI36OI8	EPSMG001SVZY8YW7C	parent_child	false	1	rbac-test	2025-09-27 18:32:20.283151+00	{"initial_link": true}	active	\N
116	CUEMG6F8X9LALTGGG	SEGMG6F5RUOT8UBY2	parent_child	false	1	rbac-test	2025-09-30 10:35:35.146225+00	{"initial_link": true}	active	\N
117	CUEMG6FJYS5PMI8FK	SEG240001	parent_child	false	1	rbac-test	2025-09-30 10:44:10.325744+00	{"initial_link": true}	active	\N
118	CUEMG6FPVKNM5JN45	SEGMG6F5RUOT8UBY2	parent_child	false	1	rbac-test	2025-09-30 10:48:46.103974+00	{"initial_link": true}	active	\N
119	CUEMG6FT8MDFBGBXS	SEGMG2A11VVSDSWZW	parent_child	false	1	rbac-test	2025-09-30 10:51:22.982059+00	{"initial_link": true}	active	\N
120	CUEMG6FX8LLA9K12N	SEGMG2A11VVSDSWZW	parent_child	false	1	rbac-test	2025-09-30 10:54:29.578468+00	{"initial_link": true}	active	\N
121	CUEMG6FY46N8HQFXT	SEGMG2A11VVSDSWZW	parent_child	false	1	rbac-test	2025-09-30 10:55:10.512071+00	{"initial_link": true}	active	\N
122	CUEMG6G1DFG813X19	SEGMG2A11VVSDSWZW	parent_child	false	1	rbac-test	2025-09-30 10:57:42.461329+00	{"initial_link": true}	active	\N
123	CUEMG6G9N8OKE0E9S	SEGMFT39C7Q8V9TWE	parent_child	false	1	rbac-test	2025-09-30 11:04:08.42491+00	{"initial_link": true}	active	\N
124	CUEMG6GU8VK4YD6R6	SEGMG6GH8ZH3E23PK	parent_child	false	1	rbac-test	2025-09-30 11:20:09.585581+00	{"initial_link": true}	active	\N
125	CUEMG6GXMB8NR28B8	SEGMG6GH8ZH3E23PK	parent_child	false	1	rbac-test	2025-09-30 11:22:46.964958+00	{"initial_link": true}	active	\N
126	CUEMG6GYQW6SUEQU9	SEGMG6GH8ZH3E23PK	parent_child	false	1	rbac-test	2025-09-30 11:23:39.604245+00	{"initial_link": true}	active	\N
127	CUEMG6H0CBCMFZ31C	SEGMG6GH8ZH3E23PK	parent_child	false	1	rbac-test	2025-09-30 11:24:53.976938+00	{"initial_link": true}	active	\N
128	CUEMG6H32XCF62KJ3	SEGMG6GH8ZH3E23PK	parent_child	false	1	rbac-test	2025-09-30 11:27:01.776927+00	{"initial_link": true}	active	\N
129	CUEMG6M3VR4SFVDF0	SEGMG2A11VVSDSWZW	parent_child	false	1	rbac-test	2025-09-30 13:47:37.218617+00	{"initial_link": true}	active	\N
130	CUEMG6M6HE6JIFMOM	SEGMG2A11VVSDSWZW	parent_child	false	1	rbac-test	2025-09-30 13:49:38.575368+00	{"initial_link": true}	active	\N
131	CUEMG6XIG1UBAVNXT	SEGMG2BVX15C41J3P	parent_child	false	1	rbac-test	2025-09-30 19:06:52.488975+00	{"initial_link": true}	active	\N
132	CUEMG9SD4HCM2FSUH	SEGMG6Z5P8HZW787X	parent_child	false	1	rbac-test	2025-10-02 19:06:04.658548+00	{"initial_link": true}	active	\N
133	CUEMGAK65WGTY1WIN	SEGMG9NCTLA67G9HR	parent_child	false	1	rbac-test	2025-10-03 08:04:29.153682+00	{"initial_link": true}	active	\N
134	CUEMGAK9DS9T69B3E	SEGMG9NCTLA67G9HR	parent_child	false	1	rbac-test	2025-10-03 08:06:59.33828+00	{"initial_link": true}	active	\N
135	CUEMGAKAUC1PMN9J7	SEGMG9NCTLA67G9HR	parent_child	false	1	rbac-test	2025-10-03 08:08:07.44228+00	{"initial_link": true}	active	\N
136	CUEMGAKD4GAEH6ZNY	SEGMG9NCTLA67G9HR	parent_child	false	1	rbac-test	2025-10-03 08:09:53.867411+00	{"initial_link": true}	active	\N
137	CUEMGAKY8I5LNQD6B	SEGMG9NCTLA67G9HR	parent_child	false	1	rbac-test	2025-10-03 08:26:18.894047+00	{"initial_link": true}	active	\N
138	CUEMGAL2KN5SEL5VC	SEGMG9NCTLA67G9HR	parent_child	false	1	rbac-test	2025-10-03 08:29:41.249768+00	{"initial_link": true}	active	\N
139	CUEMGALCH3UCFBRRA	SEGMG9NCTLA67G9HR	parent_child	false	1	rbac-test	2025-10-03 08:37:23.228516+00	{"initial_link": true}	active	\N
140	CUEMGALIO324OT3QE	SEGMG9NCTLA67G9HR	parent_child	false	1	rbac-test	2025-10-03 08:42:12.208287+00	{"initial_link": true}	active	\N
141	CUEMGALZ85RUF2V33	SEGMG9NCTLA67G9HR	parent_child	false	1	rbac-test	2025-10-03 08:55:04.721381+00	{"initial_link": true}	active	\N
142	CUEMGAMBAHIP1TUSD	SEGMG9NCTLA67G9HR	parent_child	false	1	rbac-test	2025-10-03 09:04:27.649932+00	{"initial_link": true}	active	\N
143	CUEMGB587TYJMLEGN	SEGMG6Z5P8HZW787X	parent_child	false	1	rbac-test	2025-10-03 17:53:56.904866+00	{"initial_link": true}	active	\N
144	CUEMGBDQUBR5FJTR2	SEGMG6Z5P8HZW787X	parent_child	false	1	rbac-test	2025-10-03 21:52:22.791632+00	{"initial_link": true}	active	\N
145	CUEMGBGQM4IANWPD9	SEGMG2EMUPX4PS75C	parent_child	false	1	rbac-test	2025-10-03 23:16:11.01053+00	{"initial_link": true}	active	\N
146	CUEMGC4FQ5UPSBAY2	SEGMGC4B1MI0UU7J2	parent_child	false	1	rbac-test	2025-10-04 10:19:33.811316+00	{"initial_link": true}	active	\N
147	CUEMGC4HUUCGHM56Q	SEGMGC4B1MI0UU7J2	parent_child	false	1	rbac-test	2025-10-04 10:21:13.188678+00	{"initial_link": true}	active	\N
148	CUEMGCAPXZEKS3EIY	SEGMGC4B1MI0UU7J2	parent_child	false	1	rbac-test	2025-10-04 13:15:28.203223+00	{"initial_link": true}	active	\N
149	CUEMGCBTTD90MRKVQ	SEGMGC4B1MI0UU7J2	parent_child	false	1	rbac-test	2025-10-04 13:46:28.464035+00	{"initial_link": true}	active	\N
150	CUEMGCF2GDAP3ED1Y	SEGMGC4B1MI0UU7J2	parent_child	false	1	rbac-test	2025-10-04 15:17:10.369084+00	{"initial_link": true}	active	\N
151	CUEMGJHEM2F8CRMZI	SEGMGJGQ440NLSJ2B	parent_child	false	1	rbac-test	2025-10-09 13:57:00.087816+00	{"initial_link": true}	active	\N
152	CUEMGWN9MFXP1F5DI	SEG000000MLK61BYF	parent_child	false	1	rbac-test	2025-10-18 19:02:05.28461+00	{"initial_link": true}	active	\N
153	CUEMGWPW8SH8JR4CT	SEGMGWPTVXN8AQSR7	parent_child	false	1	rbac-test	2025-10-18 20:15:39.906208+00	{"initial_link": true}	active	\N
154	CUEMGWQNF9NVOKK6Y	SEGMGWPTVXN8AQSR7	parent_child	false	1	rbac-test	2025-10-18 20:36:48.011966+00	{"initial_link": true}	active	\N
\.


--
-- Data for Name: asset_links; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.asset_links (id, source_asset_id, target_asset_id, link_type, meta_data, created_at) FROM stdin;
1	EPSMEEFA0DTJNAYVN	SEGMEEFAFL4C5RT2B	parent_child	{"child_type": "segment", "relationship": "parent_to_child"}	2025-08-16 15:39:30.287115+00
2	SEGMEEFAFL4C5RT2B	CUEMEEFALU37XGFSZ	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 15:39:38.383655+00
3	SEGMEEFAFL4C5RT2B	CUEMEEFBKP63U781E	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 15:40:23.56598+00
4	SEGMEEJ3TNWZ5IUEO	CUEMEEJFS6N0Y6BVP	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 17:35:38.36818+00
5	SEGMEEJ3TNWZ5IUEO	CUEMEEJFW5OXH49CV	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 17:35:43.512048+00
6	SEGMEEJ3TNWZ5IUEO	CUEMEEJFZ1B48GJAV	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 17:35:47.241977+00
7	SEGMEEJ3TNWZ5IUEO	CUEMEEJG1BTTZ9RKK	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 17:35:50.213026+00
8	SEGMEEJ3TNWZ5IUEO	CUEMEEJG43IE9XE52	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 17:35:53.801346+00
9	SEGMEEJ3TNWZ5IUEO	CUEMEEJG6CVN16KFJ	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 17:35:56.73086+00
10	SEGMEEJ3TNWZ5IUEO	CUEMEEJG9AV3QQNDK	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 17:36:00.543013+00
11	SEGMEEJ44L61P9LZV	CUEMEEJGLF9OYQXZC	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 17:36:16.257623+00
12	SEGMEEJ44L61P9LZV	CUEMEEJGNHIAMNDQO	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 17:36:18.924443+00
13	SEGMEEJ44L61P9LZV	CUEMEEJGPMGOLLC0T	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 17:36:21.696744+00
14	SEGMEEJ44L61P9LZV	CUEMEEJGRSTM36X2K	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 17:36:24.520699+00
15	SEGMEEJ44L61P9LZV	CUEMEEJGUC9SV6YC8	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 17:36:27.813382+00
16	SEGMEEJ44L61P9LZV	CUEMEEJGWBU9O8PJZ	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 17:36:30.388339+00
17	SEGMEEJ44L61P9LZV	CUEMEEJGZ5BR5TNAN	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 17:36:34.042022+00
18	SEGMEEJ44L61P9LZV	CUEMEEJH18K27GCUJ	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 17:36:36.752045+00
19	SEGMEEJ44L61P9LZV	CUEMEEJH39UTHDQPZ	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 17:36:39.390158+00
20	SEGMEEJ44L61P9LZV	CUEMEEJH5L5EJ0QLB	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 17:36:42.385812+00
21	SEGMEEJ44L61P9LZV	CUEMEEJH851KUTI9Z	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 17:36:45.693497+00
22	SEGMEEJ44L61P9LZV	CUEMEEJHAGOJO5MHZ	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 17:36:48.708642+00
23	SEGMEEJ44L61P9LZV	CUEMEEJHCIJ9X84QX	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 17:36:51.365654+00
24	SEGMEEJ44L61P9LZV	CUEMEEJHEY901HMCU	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 17:36:54.525608+00
25	SEGMEEJ44L61P9LZV	CUEMEEJHIMKMC68FC	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 17:36:59.288465+00
26	SEGMEEJ56401DC7UN	CUEMEEJHWMROXL1L8	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 17:37:17.439289+00
27	SEGMEEJ56401DC7UN	CUEMEEJHZTQUO2VE3	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 17:37:21.570439+00
28	SEGMEEJ5H1D9I4K1D	CUEMEEJJ87VW7XCBR	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 17:38:19.111696+00
29	SEGMEENCPXQ375N35	CUEMEEND27OHTCFXG	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 19:25:29.849579+00
30	SEGMEEJ4JNYVA02T4	CUEMEENDH3XSJ7GMN	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 19:25:49.15971+00
31	SEGMEEJ3YD0OKZM7D	CUEMEENDM8FGBUPV8	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 19:25:55.802584+00
32	EPSMEEJ32D9UFK5BU	ASTMEEOASULAQYTLJ	parent_child	{"child_type": "promo", "relationship": "parent_to_child"}	2025-08-16 19:51:44.029508+00
33	SEGMEEJ5H1D9I4K1D	CUEMEEPQ1XNB587ME	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 20:31:35.25587+00
34	SEGMEEJ3TNWZ5IUEO	CUEMEEQS4B424DL1B	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-16 21:01:11.252206+00
35	SEGMEEJ3TNWZ5IUEO	CUEMEF1M0VOTMXHR0	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-17 02:04:22.656584+00
36	SEGMEEJ3TNWZ5IUEO	CUEMEF1MMCNHQ2B7J	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-17 02:04:50.482495+00
37	SEGMEEJ3TNWZ5IUEO	CUEMEF1NP7R2S32UR	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-17 02:05:40.850609+00
38	SEGMEEJ3TNWZ5IUEO	CUEMEF1W0XP0Q5PKX	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-17 02:12:09.289389+00
39	SEGMEEJ3TNWZ5IUEO	CUEMEF22TNG6F7ZS8	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-17 02:17:26.432519+00
40	SEGMEEJ3TNWZ5IUEO	CUEMEF23DJ45GABLZ	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-17 02:17:52.203757+00
41	SEGMEEJ3TNWZ5IUEO	CUEMEF23VI6WIQ8SW	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-17 02:18:15.497874+00
42	SEGMEEJ3TNWZ5IUEO	CUEMEF24QS9R6YDTF	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-17 02:18:56.029171+00
43	SEGMEEJ3TNWZ5IUEO	CUEMEF2AE2W19MGZT	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-17 02:23:19.508915+00
44	SEGMEEJ3TNWZ5IUEO	CUEMENN9OHORZFJJL	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-23 02:32:47.687958+00
45	SEGMEEJ3TNWZ5IUEO	CUEMENNBL547W2F07	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-23 02:34:16.660557+00
46	SEGMENO45GP697XFT	CUEMEOJRS925MMOI8	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-23 17:42:40.08211+00
47	SEGMENO45GP697XFT	CUEMEOMV84ZZEZVMG	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-23 19:09:19.479716+00
48	SEGMENO45GP697XFT	CUEMEOMVCAIQ2MDV7	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-23 19:09:24.862531+00
49	SEGMENO45GP697XFT	CUEMEOMVM8C1BJ23P	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-23 19:09:37.74293+00
50	SEGMENO45GP697XFT	CUEMEOMVPPIAIQMD7	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-23 19:09:42.258051+00
51	SEGMENO45GP697XFT	CUEMEOMVWA97O7H4A	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-23 19:09:50.772378+00
52	SEGMENO45GP697XFT	CUEMEOMVZ52ZIS1IR	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-23 19:09:54.474113+00
53	SEGMEOOMWQVHLKPE7	CUEMEOPLOWFSWFCUJ	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-23 20:25:53.500521+00
54	SEGMEOOMWQVHLKPE7	CUEMEOPR27Q8GRQ0Z	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-23 20:30:04.033827+00
55	SEGMEOOMWQVHLKPE7	CUEMEOPR5F8O373KC	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-23 20:30:08.185553+00
56	SEGMEOOMWQVHLKPE7	CUEMEOPR9VVUNF1I6	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-23 20:30:13.967925+00
57	SEGMEOOMWQVHLKPE7	CUEMEOPRCZZB1GX3E	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-23 20:30:18.010294+00
58	SEGMEOOMWQVHLKPE7	CUEMEOPRF6G39VFYE	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-23 20:30:20.835361+00
59	SEGMEOJ449DRJ4QTV	CUEMEOSWI106C2RU2	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-23 21:58:16.656421+00
60	SEGMEOJ449DRJ4QTV	CUEMEOSWMBZ8DISGQ	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-23 21:58:22.227933+00
61	SEGMEOJ449DRJ4QTV	CUEMEOSWQW1HZZOM9	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-08-23 21:58:28.13219+00
62	EPSMG1FO7YJDBU685	SEGMG2JULOQ1X5N00	parent_child	{"child_type": "segment", "relationship": "parent_to_child"}	2025-09-27 17:33:20.337095+00
63	EPSMG1FO7YJDBU685	SEGMG2JURAGJEZPQL	parent_child	{"child_type": "segment", "relationship": "parent_to_child"}	2025-09-27 17:33:27.595459+00
64	EPSMG1FO7YJDBU685	SEGMG2JUU3S9S96SK	parent_child	{"child_type": "segment", "relationship": "parent_to_child"}	2025-09-27 17:33:31.243859+00
65	EPSMG1FO7YJDBU685	ASTMG2JUWUQNG6M0O	parent_child	{"child_type": "ad", "relationship": "parent_to_child"}	2025-09-27 17:33:34.806098+00
66	EPSMG1FO7YJDBU685	ASTMG2JUZJ3FTWP8I	parent_child	{"child_type": "promo", "relationship": "parent_to_child"}	2025-09-27 17:33:38.274482+00
67	EPSMG1FO7YJDBU685	ASTMG2JV2CJ5MEEMQ	parent_child	{"child_type": "cta", "relationship": "parent_to_child"}	2025-09-27 17:33:41.92638+00
68	EPSMG1FO7YJDBU685	SEGMG2JV51DS812IP	parent_child	{"child_type": "segment", "relationship": "parent_to_child"}	2025-09-27 17:33:45.412016+00
69	SEGMG2JULOQ1X5N00	CUEMG2JVYTBHG46P3	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-09-27 17:34:24.003019+00
70	SEGMG2JURAGJEZPQL	CUEMG2JW25J5BQ66L	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-09-27 17:34:28.330503+00
71	SEGMG2JUU3S9S96SK	CUEMG2JW5SMZ5UF4M	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-09-27 17:34:33.049233+00
72	SEGMG2JV51DS812IP	CUEMG2JWCB2PMURMO	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-09-27 17:34:41.489483+00
73	EPSMG001SVZY8YW7C	SEGMG2KVSDL9HUS78	parent_child	{"child_type": "segment", "relationship": "parent_to_child"}	2025-09-27 18:02:15.279026+00
74	EPSMG001SVZY8YW7C	SEGMG2KVVKRJ8HDCU	parent_child	{"child_type": "segment", "relationship": "parent_to_child"}	2025-09-27 18:02:19.423428+00
75	SEGMG2KVSDL9HUS78	CUEMG2KVZVQP10KD0	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-09-27 18:02:25.001332+00
76	SEGMG2KVSDL9HUS78	CUEMG2KW39X1RBRLD	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-09-27 18:02:29.400137+00
77	SEGMG2KVSDL9HUS78	CUEMG2KW6U169BUYJ	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-09-27 18:02:34.014803+00
78	SEGMG2KVSDL9HUS78	CUEMG2KWA7KAP8CLY	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-09-27 18:02:38.387929+00
79	SEGMG2KVSDL9HUS78	CUEMG2KWDHHJJIOFA	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-09-27 18:02:42.633819+00
80	SEGMG2KVSDL9HUS78	CUEMG2KWH4LLTS1MJ	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-09-27 18:02:47.353139+00
81	SEGMG2KVVKRJ8HDCU	CUEMG2KWLAFYEU62Y	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-09-27 18:02:52.745884+00
82	EPSMG001SVZY8YW7C	SEGMG2LYDS65PWXQP	parent_child	{"child_type": "segment", "relationship": "parent_to_child"}	2025-09-27 18:32:15.946766+00
83	EPSMG001SVZY8YW7C	SEGMG2LYH4QI36OI8	parent_child	{"child_type": "segment", "relationship": "parent_to_child"}	2025-09-27 18:32:20.285161+00
84	EPSMG001SVZY8YW7C	SEGMG2LYK9O94ADTY	parent_child	{"child_type": "segment", "relationship": "parent_to_child"}	2025-09-27 18:32:24.351839+00
85	EPSMG001SVZY8YW7C	SEGMG2LYNNLI3QNKQ	parent_child	{"child_type": "segment", "relationship": "parent_to_child"}	2025-09-27 18:32:28.739894+00
86	SEGMG6F5RUOT8UBY2	CUEMG6F8X9LALTGGG	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-09-30 10:35:35.153788+00
87	SEGMG6F5RUOT8UBY2	CUEMG6FPVKNM5JN45	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-09-30 10:48:46.108053+00
88	SEGMFT39C7Q8V9TWE	CUEMG6G9N8OKE0E9S	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-09-30 11:04:08.428553+00
89	SEGMG6GH8ZH3E23PK	CUEMG6H32XCF62KJ3	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-09-30 11:27:01.779436+00
90	SEGMG6IZM34TPD6XR	SEGMG6IZHQJ2RC68I	replaces	{"replacement_type": "user_regeneration", "replaced_at": "2025-09-30T12:20:19.218062"}	2025-09-30 12:20:19.222422+00
91	EPSMG6TA7BP9PA2VC	EPSMG1FO7YJDBU685	replaces	{"replacement_type": "user_regeneration", "replaced_at": "2025-09-30T17:08:29.464345"}	2025-09-30 17:08:29.465844+00
92	SEGMG2BVX15C41J3P	CUEMG6XIG1UBAVNXT	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-09-30 19:06:52.511661+00
93	SEGMG6Z5P8HZW787X	CUEMG9SD4HCM2FSUH	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-10-02 19:06:04.675462+00
94	SEGMG9NCTLA67G9HR	CUEMGAK65WGTY1WIN	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-10-03 08:04:29.173578+00
95	SEGMG9NCTLA67G9HR	CUEMGAK9DS9T69B3E	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-10-03 08:06:59.342287+00
96	SEGMG9NCTLA67G9HR	CUEMGAKAUC1PMN9J7	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-10-03 08:08:07.445404+00
97	SEGMG9NCTLA67G9HR	CUEMGAKD4GAEH6ZNY	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-10-03 08:09:53.869221+00
98	SEGMG9NCTLA67G9HR	CUEMGAKY8I5LNQD6B	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-10-03 08:26:18.897554+00
99	SEGMG9NCTLA67G9HR	CUEMGAL2KN5SEL5VC	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-10-03 08:29:41.252039+00
100	SEGMG9NCTLA67G9HR	CUEMGALCH3UCFBRRA	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-10-03 08:37:23.238935+00
101	SEGMG9NCTLA67G9HR	CUEMGALIO324OT3QE	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-10-03 08:42:12.217985+00
102	SEGMG9NCTLA67G9HR	CUEMGALZ85RUF2V33	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-10-03 08:55:04.731002+00
103	SEGMG9NCTLA67G9HR	CUEMGAMBAHIP1TUSD	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-10-03 09:04:27.656514+00
104	SEGMG6Z5P8HZW787X	CUEMGB587TYJMLEGN	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-10-03 17:53:56.922148+00
105	SEGMG6Z5P8HZW787X	CUEMGBDQUBR5FJTR2	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-10-03 21:52:22.799387+00
106	EPSMGC45Y2A0K5PZ8	EPSMG1FO7YJDBU685	replaces	{"replacement_type": "user_regeneration", "replaced_at": "2025-10-04T10:11:57.493916"}	2025-10-04 10:11:57.494312+00
107	EPSMGC461CCMZ937N	EPSMG1FO7YJDBU685	replaces	{"replacement_type": "user_regeneration", "replaced_at": "2025-10-04T10:12:01.742409"}	2025-10-04 10:12:01.742776+00
108	SEGMGC4B1MI0UU7J2	CUEMGC4FQ5UPSBAY2	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-10-04 10:19:33.816269+00
109	SEGMGC4B1MI0UU7J2	CUEMGC4HUUCGHM56Q	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-10-04 10:21:13.192232+00
110	SEGMGC4B1MI0UU7J2	CUEMGCAPXZEKS3EIY	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-10-04 13:15:28.207526+00
111	SEGMGC4B1MI0UU7J2	CUEMGCBTTD90MRKVQ	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-10-04 13:46:28.473832+00
112	SEGMGC4B1MI0UU7J2	CUEMGCF2GDAP3ED1Y	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-10-04 15:17:10.389975+00
113	SEGMGJGQ440NLSJ2B	CUEMGJHEM2F8CRMZI	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-10-09 13:57:00.099979+00
114	SEG000000MLK61BYF	CUEMGWN9MFXP1F5DI	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-10-18 19:02:05.318843+00
115	SEGMGWPTVXN8AQSR7	CUEMGWPW8SH8JR4CT	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-10-18 20:15:39.909366+00
116	SEGMGWPTVXN8AQSR7	CUEMGWQNF9NVOKK6Y	parent_child	{"child_type": "cue", "relationship": "parent_to_child"}	2025-10-18 20:36:48.015469+00
\.


--
-- Data for Name: asset_messages; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.asset_messages (id, asset_id, message_type, content, user_id, created_at) FROM stdin;
1	SEGMG6IZHQJ2RC68I	retirement	AssetID retired and replaced. Reason: user_requested_item_regeneration	rbac-test	2025-09-30 12:20:19.211754+00
2	EPSMG1FO7YJDBU685	retirement	AssetID retired and replaced. Reason: user_requested_regeneration	kevin	2025-09-30 17:08:29.455005+00
3	EPSMG1FO7YJDBU685	retirement	AssetID retired and replaced. Reason: user_requested_regeneration	kevin	2025-10-04 10:11:57.485365+00
4	EPSMG1FO7YJDBU685	retirement	AssetID retired and replaced. Reason: user_requested_regeneration	kevin	2025-10-04 10:12:01.737194+00
\.


--
-- Data for Name: asset_pool_files; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.asset_pool_files (id, asset_id, file_path, original_filename, mime_type, file_size, thumbnail_path, source, source_url, source_context, created_at) FROM stdin;
\.


--
-- Data for Name: asset_tags; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.asset_tags (id, asset_id, tag, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: assets; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.assets (id, episode_id, asset_id, slug, filename, asset_type, file_path, file_size, mime_type, width, height, duration, created_at, updated_at, processed, meta_data, is_test_data) FROM stdin;
\.


--
-- Data for Name: blueprint_nodes; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.blueprint_nodes (id, template_id, parent_id, node_type, name, content, sort_order, is_required, rundown_item_metadata) FROM stdin;
97	6	\N	rundown_item	Cold Open	# Cold Open\\n\\nWeekly topical opener or guest teaser.	10	t	{"item_type": "segment", "duration": "00:03:00", "status": "draft"}
98	6	\N	rundown_item	News Rundown	# News Rundown\\n\\nWeek in review with analysis.	20	t	{"item_type": "segment", "duration": "00:15:00", "status": "draft"}
99	6	\N	rundown_item	Guest Interview	# Guest Interview\\n\\nMain segment - in-depth conversation.	30	t	{"item_type": "segment", "duration": "00:45:00", "status": "draft"}
100	6	\N	rundown_item	Q&A	# Viewer Q&A\\n\\nQuestions from supporters and viewers.	40	f	{"item_type": "segment", "duration": "00:20:00", "status": "draft"}
101	6	\N	rundown_item	Wrap-Up	# Closing Thoughts\\n\\nWeekly summary and next episode preview.	50	t	{"item_type": "segment", "duration": "00:05:00", "status": "draft"}
81	5	\N	directory	projects	\N	0	t	\N
82	5	81	directory	teasers	\N	0	t	\N
83	5	81	directory	graphics	\N	1	t	\N
84	5	\N	directory	captures	\N	1	t	\N
85	5	\N	directory	thumbnails	\N	2	t	\N
86	5	\N	directory	assets	\N	3	t	\N
87	5	86	directory	video	\N	0	t	\N
88	5	86	directory	images	\N	1	t	\N
89	5	86	directory	audio	\N	2	t	\N
90	5	86	directory	graphics	\N	3	t	\N
91	5	\N	directory	rundown	\N	4	t	\N
92	5	91	directory	media-list	\N	0	t	\N
93	5	\N	directory	scripts	\N	5	t	\N
94	5	93	directory	versions	\N	0	t	\N
95	5	93	directory	current	\N	1	t	\N
96	5	\N	directory	exports	\N	6	t	\N
\.


--
-- Data for Name: blueprint_templates; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.blueprint_templates (id, name, description, template_type, is_active, is_default, template_metadata, created_at, updated_at, parent_template_id, inheritance_mode) FROM stdin;
5	Canonical Episode Structure	Standard episode directory structure per EPISODE_DIRECTORY_STANDARD.md v1.0 (2025-10-13)	episode	t	t	{"source": "EPISODE_DIRECTORY_STANDARD.md", "version": "1.0", "date": "2025-10-13", "authority": "Authoritative - Single Source of Truth"}	2025-10-15 23:30:33.033525+00	\N	\N	merge
6	Sunday Show	Weekly Sunday show format with guest interviews, news commentary, and recurring segments. Inherits canonical episode structure with Sunday-specific customizations.	episode	t	f	{\n      "show_format": "weekly",\n      "air_day": "Sunday",\n      "typical_duration": "90-120 minutes",\n      "recurring_segments": [\n        "Cold Open",\n        "News of the Week",\n        "Guest Interview",\n        "Viewer Questions",\n        "Closing Thoughts"\n      ],\n      "production_notes": "Standard 2-block format with breaks. Guest typically joins for middle segment.",\n      "source": "Custom Sunday Show Template",\n      "version": "1.0"\n    }	2025-10-19 17:28:22.514109+00	\N	5	merge
\.


--
-- Data for Name: blueprints; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.blueprints (id, episode_number, title, description, episode_metadata, template_id, status, created_by, organization_id, file_path, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: breaks; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.breaks (id, asset_id, episode_id, name, break_type, order_in_episode, estimated_duration, actual_duration, description, sponsor, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: cue_blocks; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.cue_blocks (id, rundown_item_id, asset_id, slug, cue_type, "order", quote_text, attribution, media_url, transcription, duration, created_at, updated_at, validated, validation_errors, meta_data, is_test_data) FROM stdin;
\.


--
-- Data for Name: cues; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.cues (id, asset_id, segment_id, element_id, cue_type, name, time_offset, duration, parameters, notes, created_at, updated_at) FROM stdin;
1	CUEMEEFALU37XGFSZ	1	\N	MEDIA	sot-cue-1	0	\N	{"original_cue_type": "SOT", "slug": "sot-cue-1"}	\N	2025-08-16 15:39:38.383655+00	\N
2	CUEMEEFBKP63U781E	1	\N	MEDIA	test-gfx-cue	0	\N	{"original_cue_type": "GFX", "slug": "test-gfx-cue"}	\N	2025-08-16 15:40:23.56598+00	\N
3	CUEMEEJFS6N0Y6BVP	2	\N	MEDIA	vigilante-tube	0	\N	{"original_cue_type": "GFX", "slug": "vigilante-tube"}	\N	2025-08-16 17:35:38.36818+00	\N
4	CUEMEEJFW5OXH49CV	2	\N	MEDIA	a group of	0	\N	{"original_cue_type": "FSQ", "slug": "a group of"}	\N	2025-08-16 17:35:43.512048+00	\N
5	CUEMEEJFZ1B48GJAV	2	\N	MEDIA	the clip shows	0	\N	{"original_cue_type": "FSQ", "slug": "the clip shows"}	\N	2025-08-16 17:35:47.241977+00	\N
6	CUEMEEJG1BTTZ9RKK	2	\N	MEDIA	The BTP are	0	\N	{"original_cue_type": "FSQ", "slug": "The BTP are"}	\N	2025-08-16 17:35:50.213026+00	\N
7	CUEMEEJG43IE9XE52	2	\N	MEDIA	holly-pictures	0	\N	{"original_cue_type": "GFX", "slug": "holly-pictures"}	\N	2025-08-16 17:35:53.801346+00	\N
8	CUEMEEJG6CVN16KFJ	2	\N	MEDIA	cincy-black-leaders	0	\N	{"original_cue_type": "SOT", "slug": "cincy-black-leaders"}	\N	2025-08-16 17:35:56.73086+00	\N
9	CUEMEEJG9AV3QQNDK	2	\N	MEDIA	walter-tweet	0	\N	{"original_cue_type": "GFX", "slug": "walter-tweet"}	\N	2025-08-16 17:36:00.543013+00	\N
10	CUEMEEJGLF9OYQXZC	4	\N	MEDIA	male-cheerleaders	0	\N	{"original_cue_type": "GFX", "slug": "male-cheerleaders"}	\N	2025-08-16 17:36:16.257623+00	\N
11	CUEMEEJGNHIAMNDQO	4	\N	MEDIA	dance-like-girl	0	\N	{"original_cue_type": "SOT", "slug": "dance-like-girl"}	\N	2025-08-16 17:36:18.924443+00	\N
12	CUEMEEJGPMGOLLC0T	4	\N	MEDIA	colin-wright-poll	0	\N	{"original_cue_type": "GFX", "slug": "colin-wright-poll"}	\N	2025-08-16 17:36:21.696744+00	\N
13	CUEMEEJGRSTM36X2K	4	\N	MEDIA	billboard-chris-tweet	0	\N	{"original_cue_type": "GFX", "slug": "billboard-chris-tweet"}	\N	2025-08-16 17:36:24.520699+00	\N
14	CUEMEEJGUC9SV6YC8	4	\N	MEDIA	john-connor-tweet	0	\N	{"original_cue_type": "GFX", "slug": "john-connor-tweet"}	\N	2025-08-16 17:36:27.813382+00	\N
15	CUEMEEJGWBU9O8PJZ	4	\N	MEDIA	brad-polumbo	0	\N	{"original_cue_type": "GFX", "slug": "brad-polumbo"}	\N	2025-08-16 17:36:30.388339+00	\N
16	CUEMEEJGZ5BR5TNAN	4	\N	MEDIA	prisha-mosley	0	\N	{"original_cue_type": "GFX", "slug": "prisha-mosley"}	\N	2025-08-16 17:36:34.042022+00	\N
17	CUEMEEJH18K27GCUJ	4	\N	MEDIA	what-youre-saying	0	\N	{"original_cue_type": "GFX", "slug": "what-youre-saying"}	\N	2025-08-16 17:36:36.752045+00	\N
18	CUEMEEJH39UTHDQPZ	4	\N	MEDIA	when-you-start	0	\N	{"original_cue_type": "GFX", "slug": "when-you-start"}	\N	2025-08-16 17:36:39.390158+00	\N
19	CUEMEEJH5L5EJ0QLB	4	\N	MEDIA	i-couldnt-disagree	0	\N	{"original_cue_type": "GFX", "slug": "i-couldnt-disagree"}	\N	2025-08-16 17:36:42.385812+00	\N
20	CUEMEEJH851KUTI9Z	4	\N	MEDIA	this-way-of-thinking	0	\N	{"original_cue_type": "GFX", "slug": "this-way-of-thinking"}	\N	2025-08-16 17:36:45.693497+00	\N
21	CUEMEEJHAGOJO5MHZ	4	\N	MEDIA	why-not	0	\N	{"original_cue_type": "GFX", "slug": "why-not"}	\N	2025-08-16 17:36:48.708642+00	\N
22	CUEMEEJHCIJ9X84QX	4	\N	MEDIA	i-kept-seeing	0	\N	{"original_cue_type": "GFX", "slug": "i-kept-seeing"}	\N	2025-08-16 17:36:51.365654+00	\N
23	CUEMEEJHEY901HMCU	4	\N	MEDIA	when-you-were	0	\N	{"original_cue_type": "GFX", "slug": "when-you-were"}	\N	2025-08-16 17:36:54.525608+00	\N
24	CUEMEEJHIMKMC68FC	4	\N	MEDIA	if-it-was	0	\N	{"original_cue_type": "GFX", "slug": "if-it-was"}	\N	2025-08-16 17:36:59.288465+00	\N
25	CUEMEEJHWMROXL1L8	6	\N	MEDIA	pdx-real	0	\N	{"original_cue_type": "GFX", "slug": "pdx-real"}	\N	2025-08-16 17:37:17.439289+00	\N
26	CUEMEEJHZTQUO2VE3	6	\N	MEDIA	karen-denver	0	\N	{"original_cue_type": "SOT", "slug": "karen-denver"}	\N	2025-08-16 17:37:21.570439+00	\N
27	CUEMEEJJ87VW7XCBR	7	\N	MEDIA	cookie-dough	0	\N	{"original_cue_type": "GFX", "slug": "cookie-dough"}	\N	2025-08-16 17:38:19.111696+00	\N
28	CUEMEEND27OHTCFXG	8	\N	MEDIA	Support Disaffected.com	0	\N	{"original_cue_type": "ADLIB", "slug": "Support Disaffected.com"}	\N	2025-08-16 19:25:29.849579+00	\N
29	CUEMEENDH3XSJ7GMN	5	\N	MEDIA	Support Disaffected.com	0	\N	{"original_cue_type": "ADLIB", "slug": "Support Disaffected.com"}	\N	2025-08-16 19:25:49.15971+00	\N
30	CUEMEENDM8FGBUPV8	3	\N	MEDIA	biltong adlib	0	\N	{"original_cue_type": "ADLIB", "slug": "biltong adlib"}	\N	2025-08-16 19:25:55.802584+00	\N
31	CUEMEEPQ1XNB587ME	7	\N	MEDIA	retarded-neighbors	0	\N	{"original_cue_type": "SOT", "slug": "retarded-neighbors"}	\N	2025-08-16 20:31:35.25587+00	\N
32	CUEMEEQS4B424DL1B	2	\N	MEDIA	chris-elston	0	\N	{"original_cue_type": "GFX", "slug": "chris-elston"}	\N	2025-08-16 21:01:11.252206+00	\N
33	CUEMEF1M0VOTMXHR0	2	\N	MEDIA	a-group-of	0	\N	{"original_cue_type": "gfx", "slug": "a-group-of"}	\N	2025-08-17 02:04:22.656584+00	\N
34	CUEMEF1MMCNHQ2B7J	2	\N	MEDIA	agrou-of-pt	0	\N	{"original_cue_type": "gfx", "slug": "agrou-of-pt"}	\N	2025-08-17 02:04:50.482495+00	\N
35	CUEMEF1NP7R2S32UR	2	\N	MEDIA	the-clip-shows	0	\N	{"original_cue_type": "gfx", "slug": "the-clip-shows"}	\N	2025-08-17 02:05:40.850609+00	\N
36	CUEMEF1W0XP0Q5PKX	2	\N	MEDIA	btp	0	\N	{"original_cue_type": "gfx", "slug": "btp"}	\N	2025-08-17 02:12:09.289389+00	\N
37	CUEMEF22TNG6F7ZS8	2	\N	MEDIA	a-group-of	0	\N	{"original_cue_type": "gfx", "slug": "a-group-of"}	\N	2025-08-17 02:17:26.432519+00	\N
38	CUEMEF23DJ45GABLZ	2	\N	MEDIA	a-group-of-part	0	\N	{"original_cue_type": "gfx", "slug": "a-group-of-part"}	\N	2025-08-17 02:17:52.203757+00	\N
39	CUEMEF23VI6WIQ8SW	2	\N	MEDIA	an-off-duty	0	\N	{"original_cue_type": "gfx", "slug": "an-off-duty"}	\N	2025-08-17 02:18:15.497874+00	\N
40	CUEMEF24QS9R6YDTF	2	\N	MEDIA	spokesperson	0	\N	{"original_cue_type": "gfx", "slug": "spokesperson"}	\N	2025-08-17 02:18:56.029171+00	\N
41	CUEMEF2AE2W19MGZT	2	\N	MEDIA	the-clip	0	\N	{"original_cue_type": "gfx", "slug": "the-clip"}	\N	2025-08-17 02:23:19.508915+00	\N
42	CUEMENN9OHORZFJJL	2	\N	MEDIA	covid-lockdowns	0	\N	{"original_cue_type": "gfx", "slug": "covid-lockdowns"}	\N	2025-08-23 02:32:47.687958+00	\N
43	CUEMENNBL547W2F07	2	\N	MEDIA	young-adults-chart	0	\N	{"original_cue_type": "gfx", "slug": "young-adults-chart"}	\N	2025-08-23 02:34:16.660557+00	\N
44	CUEMEOJRS925MMOI8	16	\N	MEDIA	first-ag-vid	0	\N	{"original_cue_type": "SOT", "slug": "first-ag-vid"}	\N	2025-08-23 17:42:40.08211+00	\N
45	CUEMEOMV84ZZEZVMG	16	\N	MEDIA	assault-ice-officer	0	\N	{"original_cue_type": "SOT", "slug": "assault-ice-officer"}	\N	2025-08-23 19:09:19.479716+00	\N
46	CUEMEOMVCAIQ2MDV7	16	\N	MEDIA	shoot-maga	0	\N	{"original_cue_type": "SOT", "slug": "shoot-maga"}	\N	2025-08-23 19:09:24.862531+00	\N
47	CUEMEOMVM8C1BJ23P	16	\N	MEDIA	pamela-tweet	0	\N	{"original_cue_type": "GFX", "slug": "pamela-tweet"}	\N	2025-08-23 19:09:37.74293+00	\N
48	CUEMEOMVPPIAIQMD7	16	\N	MEDIA	pam-dr-janja	0	\N	{"original_cue_type": "SOT", "slug": "pam-dr-janja"}	\N	2025-08-23 19:09:42.258051+00	\N
49	CUEMEOMVWA97O7H4A	16	\N	MEDIA	un-women-journalists	0	\N	{"original_cue_type": "GFX", "slug": "un-women-journalists"}	\N	2025-08-23 19:09:50.772378+00	\N
50	CUEMEOMVZ52ZIS1IR	16	\N	MEDIA	un-women-journalist	0	\N	{"original_cue_type": "GFX", "slug": "un-women-journalist"}	\N	2025-08-23 19:09:54.474113+00	\N
51	CUEMEOPLOWFSWFCUJ	26	\N	MEDIA	ceo-cracker-barrel	0	\N	{"original_cue_type": "sot", "slug": "ceo-cracker-barrel"}	\N	2025-08-23 20:25:53.500521+00	\N
52	CUEMEOPR27Q8GRQ0Z	26	\N	MEDIA	inside-cracker-barrel	0	\N	{"original_cue_type": "SOT", "slug": "inside-cracker-barrel"}	\N	2025-08-23 20:30:04.033827+00	\N
53	CUEMEOPR5F8O373KC	26	\N	MEDIA	new-cracker-barrel	0	\N	{"original_cue_type": "GFX", "slug": "new-cracker-barrel"}	\N	2025-08-23 20:30:08.185553+00	\N
54	CUEMEOPR9VVUNF1I6	26	\N	MEDIA	old-cracker-barrel	0	\N	{"original_cue_type": "GFX", "slug": "old-cracker-barrel"}	\N	2025-08-23 20:30:13.967925+00	\N
55	CUEMEOPRCZZB1GX3E	26	\N	MEDIA	new-mdcdonalds	0	\N	{"original_cue_type": "GFX", "slug": "new-mdcdonalds"}	\N	2025-08-23 20:30:18.010294+00	\N
56	CUEMEOPRF6G39VFYE	26	\N	MEDIA	red-mcdonalds	0	\N	{"original_cue_type": "GFX", "slug": "red-mcdonalds"}	\N	2025-08-23 20:30:20.835361+00	\N
57	CUEMEOSWI106C2RU2	22	\N	MEDIA	shogirl-whore	0	\N	{"original_cue_type": "gfx", "slug": "shogirl-whore"}	\N	2025-08-23 21:58:16.656421+00	\N
58	CUEMEOSWMBZ8DISGQ	22	\N	MEDIA	response-to-cher-believe	0	\N	{"original_cue_type": "GFX", "slug": "response-to-cher-believe"}	\N	2025-08-23 21:58:22.227933+00	\N
59	CUEMEOSWQW1HZZOM9	22	\N	MEDIA	cher-believe	0	\N	{"original_cue_type": "GFX", "slug": "cher-believe"}	\N	2025-08-23 21:58:28.13219+00	\N
64	CUEMG2KVZVQP10KD0	36	\N	MEDIA	ilhn-omar-cnn	0	\N	{"original_cue_type": "SOT", "slug": "ilhn-omar-cnn"}	\N	2025-09-27 18:02:25.001332+00	\N
65	CUEMG2KW39X1RBRLD	36	\N	MEDIA	kam-kam-harris	0	\N	{"original_cue_type": "SOT", "slug": "kam-kam-harris"}	\N	2025-09-27 18:02:29.400137+00	\N
66	CUEMG2KW6U169BUYJ	36	\N	MEDIA	trump-pinata	0	\N	{"original_cue_type": "SOT", "slug": "trump-pinata"}	\N	2025-09-27 18:02:34.014803+00	\N
67	CUEMG2KWA7KAP8CLY	36	\N	MEDIA	trump-amish-autism	0	\N	{"original_cue_type": "SOT", "slug": "trump-amish-autism"}	\N	2025-09-27 18:02:38.387929+00	\N
68	CUEMG2KWDHHJJIOFA	36	\N	MEDIA	trump-tylenol	0	\N	{"original_cue_type": "SOT", "slug": "trump-tylenol"}	\N	2025-09-27 18:02:42.633819+00	\N
69	CUEMG2KWH4LLTS1MJ	36	\N	MEDIA	tylenol-moms	0	\N	{"original_cue_type": "SOT", "slug": "tylenol-moms"}	\N	2025-09-27 18:02:47.353139+00	\N
70	CUEMG2KWLAFYEU62Y	37	\N	MEDIA	erika-kirk-forgiveness	0	\N	{"original_cue_type": "SOT", "slug": "erika-kirk-forgiveness"}	\N	2025-09-27 18:02:52.745884+00	\N
71	CUEMG6F8X9LALTGGG	42	\N	MEDIA	test-img-cue	0	\N	{"original_cue_type": "IMG", "slug": "test-img-cue"}	\N	2025-09-30 10:35:35.153788+00	\N
72	CUEMG6FPVKNM5JN45	42	\N	MEDIA	test-img-cue	0	\N	{"original_cue_type": "IMG", "slug": "test-img-cue"}	\N	2025-09-30 10:48:46.108053+00	\N
73	CUEMG6G9N8OKE0E9S	28	\N	MEDIA	test-img-cue	0	\N	{"original_cue_type": "IMG", "slug": "test-img-cue"}	\N	2025-09-30 11:04:08.428553+00	\N
76	CUEMG6H32XCF62KJ3	198	\N	MEDIA	test-img-cue-success	0	\N	{"original_cue_type": "IMG", "slug": "test-img-cue-success"}	\N	2025-09-30 11:27:01.779436+00	\N
77	CUEMG6XIG1UBAVNXT	183	\N	MEDIA	Dan Frost	0	\N	{"original_cue_type": "IMG", "slug": "Dan Frost"}	\N	2025-09-30 19:06:52.511661+00	\N
78	CUEMG9SD4HCM2FSUH	201	\N	MEDIA	dANfROST	0	\N	{"original_cue_type": "IMG", "slug": "dANfROST"}	\N	2025-10-02 19:06:04.675462+00	\N
79	CUEMGAK65WGTY1WIN	218	\N	MEDIA	dan frost 	0	\N	{"original_cue_type": "IMG", "slug": "dan frost "}	\N	2025-10-03 08:04:29.173578+00	\N
80	CUEMGAK9DS9T69B3E	218	\N	MEDIA	photo of dan frost	0	\N	{"original_cue_type": "IMG", "slug": "photo of dan frost"}	\N	2025-10-03 08:06:59.342287+00	\N
81	CUEMGAKAUC1PMN9J7	218	\N	MEDIA	test	0	\N	{"original_cue_type": "IMG", "slug": "test"}	\N	2025-10-03 08:08:07.445404+00	\N
82	CUEMGAKD4GAEH6ZNY	218	\N	MEDIA	dan frost	0	\N	{"original_cue_type": "IMG", "slug": "dan frost"}	\N	2025-10-03 08:09:53.869221+00	\N
83	CUEMGAKY8I5LNQD6B	218	\N	MEDIA	Dan Frost is a bitch	0	\N	{"original_cue_type": "IMG", "slug": "Dan Frost is a bitch"}	\N	2025-10-03 08:26:18.897554+00	\N
84	CUEMGAL2KN5SEL5VC	218	\N	MEDIA	Dan Frost is a cunt	0	\N	{"original_cue_type": "IMG", "slug": "Dan Frost is a cunt"}	\N	2025-10-03 08:29:41.252039+00	\N
85	CUEMGALCH3UCFBRRA	218	\N	MEDIA	dan 	0	\N	{"original_cue_type": "IMG", "slug": "dan "}	\N	2025-10-03 08:37:23.238935+00	\N
86	CUEMGALIO324OT3QE	218	\N	MEDIA	Dan frost is kinda a bitch for real	0	\N	{"original_cue_type": "IMG", "slug": "Dan frost is kinda a bitch for real"}	\N	2025-10-03 08:42:12.217985+00	\N
87	CUEMGALZ85RUF2V33	218	\N	MEDIA	Toshua Blocum watching the walls falling at Tinagra	0	\N	{"original_cue_type": "IMG", "slug": "Toshua Blocum watching the walls falling at Tinagra"}	\N	2025-10-03 08:55:04.731002+00	\N
88	CUEMGAMBAHIP1TUSD	218	\N	MEDIA	Dan Frost is a big bitch	0	\N	{"original_cue_type": "IMG", "slug": "Dan Frost is a big bitch"}	\N	2025-10-03 09:04:27.656514+00	\N
89	CUEMGB587TYJMLEGN	201	\N	MEDIA	THIS IS A ABIG NASTEY SLUG	0	\N	{"original_cue_type": "IMG", "slug": "THIS IS A ABIG NASTEY SLUG"}	\N	2025-10-03 17:53:56.922148+00	\N
90	CUEMGBDQUBR5FJTR2	201	\N	MEDIA	Dan Frost is kinda a bitch guy	0	\N	{"original_cue_type": "IMG", "slug": "Dan Frost is kinda a bitch guy"}	\N	2025-10-03 21:52:22.799387+00	\N
91	CUEMGC4FQ5UPSBAY2	228	\N	MEDIA	Joel Berry Tweet	0	\N	{"original_cue_type": "IMG", "slug": "Joel Berry Tweet"}	\N	2025-10-04 10:19:33.816269+00	\N
92	CUEMGC4HUUCGHM56Q	228	\N	MEDIA	joel berry tweet	0	\N	{"original_cue_type": "IMG", "slug": "joel berry tweet"}	\N	2025-10-04 10:21:13.192232+00	\N
93	CUEMGCAPXZEKS3EIY	228	\N	MEDIA	Joel Berry Tweet	0	\N	{"original_cue_type": "IMG", "slug": "Joel Berry Tweet"}	\N	2025-10-04 13:15:28.207526+00	\N
94	CUEMGCBTTD90MRKVQ	228	\N	MEDIA	test image	0	\N	{"original_cue_type": "IMG", "slug": "test image"}	\N	2025-10-04 13:46:28.473832+00	\N
95	CUEMGCF2GDAP3ED1Y	228	\N	MEDIA	test	0	\N	{"original_cue_type": "IMG", "slug": "test"}	\N	2025-10-04 15:17:10.389975+00	\N
96	CUEMGJHEM2F8CRMZI	245	\N	MEDIA	Political Ponerology	0	\N	{"original_cue_type": "IMG", "slug": "Political Ponerology"}	\N	2025-10-09 13:57:00.099979+00	\N
97	CUEMGWN9MFXP1F5DI	306	\N	MEDIA	i-love-hitler	0	\N	{"original_cue_type": "IMG", "slug": "i-love-hitler"}	\N	2025-10-18 19:02:05.318843+00	\N
98	CUEMGWPW8SH8JR4CT	371	\N	MEDIA	I love hitler	0	\N	{"original_cue_type": "IMG", "slug": "I love hitler"}	\N	2025-10-18 20:15:39.909366+00	\N
99	CUEMGWQNF9NVOKK6Y	371	\N	MEDIA	Text Graphic	0	\N	{"original_cue_type": "IMG", "slug": "Text Graphic"}	\N	2025-10-18 20:36:48.015469+00	\N
\.


--
-- Data for Name: elements; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.elements (id, asset_id, segment_id, element_type, name, slug, file_path, file_url, modifications, duration, resolution, file_size, quote_text, attribution, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: episode_templates; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.episode_templates (id, episode_number, title, description, episode_metadata, template_id, status, created_by, organization_id, file_path, created_at, updated_at) FROM stdin;
6	0001	\N	\N	{"airdate": "2025-08-31", "status": "draft", "duration": "00:00:00", "template_type": "sunday_show", "asset_id": "EPSMEY8EVJQRZK24K", "episode_number": "0001", "template_id": 1, "template_name": "Sunday Show"}	\N	draft	1	\N	/home/episodes/0001	2025-08-30 12:22:23.822887+00	\N
8	0238	\N	\N	{"airdate": "2025-08-31", "status": "draft", "duration": "00:00:00", "template_type": "sunday_show", "asset_id": "EPSMEYLG3N3WWCLAJ", "episode_number": "0238", "template_id": 1, "template_name": "Sunday Show"}	\N	draft	1	\N	/home/episodes/0238	2025-08-30 18:27:15.960536+00	\N
11	0240	The Turning Point	\N	{"airdate": "2025-09-14", "status": "draft", "duration": "00:00:00", "template_type": "sunday_show", "asset_id": "EPSMFJRNMJLTMEDTX", "episode_number": "0240", "template_id": 1, "template_name": "Sunday Show"}	\N	draft	1	\N	/home/episodes/0240	2025-09-14 14:04:14.438412+00	\N
12	0241	\N	\N	{"airdate": "2025-09-21", "status": "draft", "duration": "00:00:00", "template_type": "sunday_show", "asset_id": "EPSMFM60A0IWPUX9Z", "episode_number": "0241", "template_id": 1, "template_name": "Sunday Show"}	\N	draft	1	\N	/home/episodes/0241	2025-09-16 06:21:31.707446+00	\N
\.


--
-- Data for Name: episodes; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.episodes (id, asset_id, season_id, episode_number, title, slug, publish_date, air_date, target_duration, actual_duration, created_at, updated_at, status, is_test_data, guest_name, guest_bio, guest_website, template_type, template_id, template_name, duration_formatted, is_dummy) FROM stdin;
1	EPSMEEFA0DTJNAYVN	1	123	test-episode	test-episode	\N	\N	\N	\N	2025-08-16 15:39:10.681475+00	\N	draft	f	\N	\N	\N	\N	\N	\N	\N	f
3	EPSMEEJ32D9UFK5BU	1	236	Episode 236	episode-236	\N	\N	\N	\N	2025-08-16 17:25:45.111232+00	\N	draft	f	\N	\N	\N	\N	\N	\N	\N	f
21	EP0241	1	241	Manson Family Values	manson-family-values	\N	2025-09-21 00:00:00	\N	3600	2025-09-21 03:43:06.658199+00	2025-09-30 15:58:24.788581+00	promotion	f	\N	\N	\N	\N	\N	\N	01:00:00	f
7	EPSMFMGBVGXZ495AY	1	239	The Princess and the Pea	episode-0239	2025-09-07 00:00:00	2025-09-07 00:00:00	2700	\N	2025-09-16 11:10:28.889091+00	2025-10-03 18:18:36.67614+00	approved	f				sunday_show		Sunday Show	00:45:00	f
6	EPSMEYLG3N3WWCLAJ	1	238	Episode 238 - Keri Smith	episode-0238	2025-08-31 00:00:00	2025-08-31 00:00:00	\N	0	2025-09-16 09:48:26.547467+00	2025-10-02 08:57:05.029456+00	completed	f	Keri Smith	Host of Deprogrammed with Keri Smith	https://www.kerismith.net/	sunday_show	1	Sunday Show	00:00:00	f
22	EPSMG001SVZY8YW7C	1	242	Forgiveness Discourse	episode-0242	\N	2025-09-28 00:00:00	\N	0	2025-09-25 22:43:31.59806+00	2025-09-30 15:59:03.816095+00	promotion	f	\N	\N	\N	episode	\N	Sunday Show	00:00:00	f
25	EPSMGC47HIQWB3DSL	1	243	Well Spoken	episode-0243	\N	2025-10-05 00:00:00	\N	\N	2025-10-04 10:13:09.373458+00	2025-10-16 02:38:29.621287+00	promotion	f	\N	\N	\N	episode	\N	Sunday Show	00:00:00	f
33	EPSMGY0LFC80J3EZG	1	245	Episode 0245	episode-0245	\N	\N	\N	\N	2025-10-19 18:02:57.133487+00	\N	draft	f	\N	\N	\N	episode	\N	Sunday Show	00:00:00	f
8	EPSMFMGRRW3D4U04V	1	240	The Turning Point	episode-0240	2025-09-14 00:00:00	2025-09-14 00:00:00	\N	\N	2025-09-16 11:22:50.74959+00	2025-10-03 18:04:40.449823+00	published	f		\N	\N	sunday_show	\N		01:00:00	f
28	EPSMGMG0VQQ3YNTQG	1	244	The Age of the Gorgon	episode-0244	\N	2025-10-12 00:00:00	\N	\N	2025-10-11 15:41:38.358797+00	2025-10-18 18:57:41.175947+00	production	f	\N	\N	\N	episode	\N	Sunday Show	00:00:00	f
\.


--
-- Data for Name: extracted_quotes; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.extracted_quotes (id, episode_id, quote_id, slug, text, attribution, context, generated_image_path, image_generated, word_count, character_count, created_at, updated_at, source_file, source_line, is_test_data) FROM stdin;
3	5	westman_001	to-my-mother-westman_001	To my mother and father, I am sorry I didn't turn out as you had hoped. You did not fail me, you gave me so much. I truly appreciate the love you have given me. I feel I was raised to be a good person. I've kept those traits of empahty, self-sacrifice, and good character	Robert "Robin" Westman's suicide note	{"category": "FS Quote/to my mother", "tags": ["family", "apology", "character", "self-reflection"], "content_warning": "suicide", "priority": "high", "source_type": "suicide_note", "metadata": {"source": "westman_suicide_note", "date_processed": "2025-08-30", "content_type": "sensitive", "requires_review": true, "broadcast_ready": false}}	\N	f	55	271	2025-08-30 18:50:36.795564+00	\N	/app/quotes_input.json	\N	t
4	5	westman_002	i-have-wanted-westman_002	I have wanted this for so long. I am not well. I am not right. I am a sad person, hautned by those things that do not go away. I know this is wrong but I can't seem to stop myself. I am severely depressed and have been suicidal for years. Only recently have I lost all hope and decided to perform my fainal action against this world. I don't want to kneel down for the injustices of this world. I want to die. I'd rather die on my feet than live on my knees, constantly in pain.	Robert "Robin" Westman's suicide note	{"category": "FS Quote/I have wanted", "tags": ["depression", "suicide", "mental_health", "pain", "desperation"], "content_warning": "suicide, mental_health", "priority": "high", "source_type": "suicide_note", "metadata": {"source": "westman_suicide_note", "date_processed": "2025-08-30", "content_type": "sensitive", "requires_review": true, "broadcast_ready": false}}	\N	f	98	478	2025-08-30 18:50:36.795564+00	\N	/app/quotes_input.json	\N	t
\.


--
-- Data for Name: group_roles; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.group_roles (group_id, role_id, assigned_at, assigned_by) FROM stdin;
\.


--
-- Data for Name: groups; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.groups (id, name, slug, description, is_active, color, organization_id, auto_assign_new_users, settings, created_at, updated_at, created_by) FROM stdin;
1	MetaFactory	metafactory	MetaFactory team - metadata and content organization	t	\N	1	f	\N	2025-10-09 15:46:55.032827+00	\N	system
2	MediaFactory	mediafactory	MediaFactory team - media asset creation and processing	t	\N	1	f	\N	2025-10-09 15:46:55.032827+00	\N	system
3	ScriptFactory	scriptfactory	ScriptFactory team - script writing and content generation	t	\N	1	f	\N	2025-10-09 15:46:55.032827+00	\N	system
\.


--
-- Data for Name: link_preview_cache; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.link_preview_cache (id, url, url_hash, preview_data, fetched_at, expires_at) FROM stdin;
14	https://x.com/EricLDaugh/status/1979332390276468966	a0826209815a6372c0948deadf8b9e42d7932de7ca9cc7a3978d25804dba5b75	{"image": "", "title": "", "domain": "x.com", "favicon": "https://abs.twimg.com/favicons/twitter.3.ico", "x_platform": "x", "x_tweet_id": "1979332390276468966", "description": "", "x_author_name": "X (formerly Twitter)", "x_username_from_url": "EricLDaugh"}	2025-10-18 02:47:44.13753+00	2025-11-17 02:47:44.423027+00
15	https://x.com/IanJaeger29/status/1979252751784726714	fcfce22814c37c6eb4ba9991c68ad80b1aa9d52120b7560be3f523fa0a8da449	{"image": "", "title": "", "domain": "x.com", "favicon": "https://abs.twimg.com/favicons/twitter.3.ico", "x_platform": "x", "x_tweet_id": "1979252751784726714", "description": "", "x_author_name": "X (formerly Twitter)", "x_username_from_url": "IanJaeger29"}	2025-10-18 02:47:56.08015+00	2025-11-17 02:47:56.339463+00
16	https://x.com/DrClownPhD/status/1979299127935594692	1dca6dd623357757efa39c76619b44fb2231edd5cdd8f3fdddaa76711ab84179	{"image": "", "title": "", "domain": "x.com", "favicon": "https://abs.twimg.com/favicons/twitter.3.ico", "x_platform": "x", "x_tweet_id": "1979299127935594692", "description": "", "x_author_name": "X (formerly Twitter)", "x_username_from_url": "DrClownPhD"}	2025-10-18 02:47:56.342927+00	2025-11-17 02:47:56.630123+00
18	https://x.com/DisaffectedPod/status/1978921381669806241	3782ae0acac562c7e1589c99a717ee05028d07e36c1287500c62d5b9150734f8	{"image": "", "title": "", "domain": "x.com", "favicon": "https://abs.twimg.com/favicons/twitter.3.ico", "x_platform": "x", "x_tweet_id": "1978921381669806241", "description": "", "x_author_name": "X (formerly Twitter)", "x_username_from_url": "DisaffectedPod"}	2025-10-18 02:48:31.323893+00	2025-11-17 02:48:31.624229+00
19	https://x.com/realMaalouf/status/1979369186020212825	b06d2f8d3cd289d29c68f4f890674ccbd52b0df9efdd20cd1e69110ceacd1aa7	{"image": "", "title": "", "domain": "x.com", "favicon": "https://abs.twimg.com/favicons/twitter.3.ico", "x_likes": 638, "x_quotes": 32, "x_replies": 184, "x_entities": {"urls": [{"end": 159, "url": "https://t.co/6zoTRwvAR0", "start": 136, "media_key": "13_1978783044900454400", "display_url": "pic.x.com/6zoTRwvAR0", "expanded_url": "https://x.com/clowndownunder/status/1978783553023300086/video/1"}], "annotations": [{"end": 41, "type": "Place", "start": 33, "probability": 0.9807, "normalized_text": "Australia"}]}, "x_platform": "x", "x_retweets": 141, "x_tweet_id": "1979369186020212825", "description": "", "x_author_bio": "🚨Breaking News | ⚔️History 🗺️Geopolitics", "x_media_urls": ["https://pbs.twimg.com/amplify_video_thumb/1978783044900454400/img/EwJwQ2_vlpfMzLaO.jpg"], "x_tweet_text": "A trans man converts to Islam in Australia.\\n\\nThe imam performing the conversion is unaware that he’s trans.\\n\\nHow will this story end?\\n\\n https://t.co/6zoTRwvAR0", "x_author_name": "Dr. Maalouf ‏", "x_author_avatar": "https://pbs.twimg.com/profile_images/1771658176200318976/zppeMEGD_normal.jpg", "x_author_handle": "realMaalouf", "x_published_time": "2025-10-18T02:09:23.000Z", "x_author_verified": false, "x_conversation_id": "1979369186020212825", "x_author_followers": 365376, "x_author_following": 1310}	2025-10-18 07:18:03.320979+00	2025-11-17 07:18:03.676237+00
20	https://x.com/elonmusk/status/1979515363411804644	a7d151badd61b2bc915b55aafef30929b9f97c4e0813ebb4093af30eb919a0b4	{"image": "", "title": "", "domain": "x.com", "favicon": "https://abs.twimg.com/favicons/twitter.3.ico", "x_likes": 466, "x_quotes": 1, "x_replies": 204, "x_entities": {"urls": [{"end": 68, "url": "https://t.co/Wdwac8ykKJ", "start": 45, "display_url": "x.com/tesla/status/1…", "expanded_url": "https://twitter.com/tesla/status/1979268933707534805"}], "annotations": [{"end": 24, "type": "Other", "start": 21, "probability": 0.6106, "normalized_text": "ISIS"}]}, "x_platform": "x", "x_retweets": 58, "x_tweet_id": "1979515363411804644", "description": "", "x_author_bio": "", "x_tweet_text": "Wow, I can’t believe ISIS voted against me 😂 https://t.co/Wdwac8ykKJ", "x_author_name": "Elon Musk", "x_author_avatar": "https://pbs.twimg.com/profile_images/1936002956333080576/kqqe2iWO_normal.jpg", "x_author_handle": "elonmusk", "x_published_time": "2025-10-18T11:50:14.000Z", "x_author_verified": false, "x_conversation_id": "1979515363411804644", "x_author_followers": 227951031, "x_author_following": 1220, "x_referenced_tweets": [{"id": "1979268933707534805", "type": "quoted"}]}	2025-10-18 11:53:01.952094+00	2025-11-17 11:53:02.384426+00
21	https://x.com/KamalaHarris/status/1979392929388204241	61b8137ddaf3a9cec814cfe5faa93d277c3101095fef1831a4ec6dc074409780	{"image": "", "title": "", "domain": "x.com", "favicon": "https://abs.twimg.com/favicons/twitter.3.ico", "x_likes": 33365, "x_quotes": 679, "x_replies": 8550, "x_entities": {"urls": [{"end": 171, "url": "https://t.co/tAXlyqoamq", "start": 148, "media_key": "13_1979392384929579008", "display_url": "pic.x.com/tAXlyqoamq", "expanded_url": "https://x.com/KamalaHarris/status/1979392929388204241/video/1"}]}, "x_platform": "x", "x_retweets": 5482, "x_tweet_id": "1979392929388204241", "description": "", "x_author_bio": "Always fighting for the people. Wife, Momala, Auntie. She/her. 107 Days available now.", "x_media_urls": ["https://pbs.twimg.com/media/G3g3OEwakAAnrie.jpg"], "x_tweet_text": "In our country, the power is with the people. Tomorrow, October 18, I encourage you to join your neighbors in peaceful protest at a No Kings event. https://t.co/tAXlyqoamq", "x_author_name": "Kamala Harris", "x_author_avatar": "https://pbs.twimg.com/profile_images/1592241313700782081/T2pTYU8d_normal.jpg", "x_author_handle": "KamalaHarris", "x_published_time": "2025-10-18T03:43:44.000Z", "x_author_verified": false, "x_conversation_id": "1979392929388204241", "x_author_followers": 20839436, "x_author_following": 704}	2025-10-18 13:43:50.764559+00	2025-11-17 13:43:51.096844+00
\.


--
-- Data for Name: llm_notifications; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.llm_notifications (id, user_id, title, message, priority, notification_type, operation_id, success, read, dismissed, notification_metadata, error, "timestamp", created_at) FROM stdin;
notif-10	1	FSQ Quote Analysis	AI is analyzing...	normal	operation-start	llm-op-3	\N	t	f	\N	\N	1760002390358	2025-10-09 09:33:11.467121
notif-11	1	AI analyzing completed	Operation completed in 0.0s	normal	operation-complete	llm-op-3	t	t	f	\N	\N	1760002390366	2025-10-09 09:33:11.467122
notif-12	1	FSQ Quote Analysis	AI is analyzing...	normal	operation-start	llm-op-4	\N	t	f	\N	\N	1760002483515	2025-10-09 09:34:45.568256
notif-13	1	FSQ Quote Analysis	AI is analyzing...	normal	operation-start	llm-op-5	\N	t	f	\N	\N	1760002489678	2025-10-09 09:34:51.704197
notif-2	1	AI analyzing completed	Operation completed in 0.0s	normal	operation-complete	llm-op-1	t	t	f	\N	\N	1760001238721	2025-10-09 09:14:00.295912
notif-4	1	FSQ Quote Analysis	AI is analyzing...	normal	operation-start	llm-op-1	\N	t	f	\N	\N	1760001694808	2025-10-09 09:21:35.938392
notif-6	1	FSQ Quote Analysis	AI is analyzing...	normal	operation-start	llm-op-1	\N	t	f	\N	\N	1760002250595	2025-10-09 09:30:51.697566
notif-7	1	FSQ Quote Analysis	AI is analyzing...	normal	operation-start	llm-op-2	\N	t	f	\N	\N	1760002265707	2025-10-09 09:31:08.697962
notif-8	1	AI analyzing completed	Operation completed in 29.8s	normal	operation-complete	llm-op-2	t	t	f	\N	\N	1760002295508	2025-10-09 09:33:11.467117
notif-9	1	AI analyzing completed	Operation completed in 45.0s	normal	operation-complete	llm-op-1	t	t	f	\N	\N	1760002295545	2025-10-09 09:33:11.46712
notif-15	1	FSQ Quote Analysis	AI is analyzing...	normal	operation-start	llm-op-1	\N	t	f	\N	\N	1760003251802	2025-10-09 09:47:32.972486
notif-16	1	FSQ Quote Analysis	AI is analyzing...	normal	operation-start	llm-op-2	\N	t	f	\N	\N	1760003265895	2025-10-09 09:47:47.05188
notif-17	1	FSQ Quote Analysis	AI is analyzing...	normal	operation-start	llm-op-3	\N	t	f	\N	\N	1760003269013	2025-10-09 09:47:50.128155
notif-19	1	AI generating	Generating sample script with Qwen...	normal	operation-start	llm-op-1	\N	t	f	\N	\N	1760005203602	2025-10-09 10:20:04.855506
notif-20	1	AI generating completed	Script generated successfully	normal	operation-complete	llm-op-1	t	t	f	\N	\N	1760005242074	2025-10-09 10:23:17.067954
notif-21	1	AI generating	Generating sample script with Qwen...	normal	operation-start	llm-op-2	\N	t	f	\N	\N	1760005395893	2025-10-09 10:23:17.067958
notif-22	1	AI generating completed	Script generated successfully	normal	operation-complete	llm-op-2	t	t	f	\N	\N	1760005418856	2025-10-09 10:24:22.599663
notif-23	1	AI generating	Generating sample script with Qwen...	normal	operation-start	llm-op-3	\N	t	f	\N	\N	1760005461436	2025-10-09 10:24:22.599666
notif-1	1	AI failed analyzing episode	Request failed: 500 Internal Server Error	high	operation-error	llm-op-1	f	t	f	\N	\N	1760583646932	2025-10-09 09:14:00.295911
notif-25	1	FSQ Quote Analysis	AI is analyzing field...	normal	operation-start	llm-op-1	\N	t	f	\N	\N	1760007762068	2025-10-09 11:02:43.219845
notif-27	1	FSQ Quote Analysis	AI is analyzing field...	normal	operation-start	llm-op-1	\N	t	f	\N	\N	1760007896303	2025-10-09 11:04:57.506593
notif-28	1	AI analyzed field	Successfully analyzed field in 0.0s	normal	operation-complete	llm-op-1	t	t	f	\N	\N	1760007896309	2025-10-09 11:04:57.506596
notif-30	1	FSQ Quote Analysis	AI is analyzing field...	normal	operation-start	llm-op-1	\N	t	f	\N	\N	1760009107810	2025-10-09 11:25:09.022516
notif-31	1	FSQ Quote Analysis	AI is analyzing field...	normal	operation-start	llm-op-2	\N	t	f	\N	\N	1760009116990	2025-10-09 11:25:18.211584
notif-33	1	FSQ Quote Analysis	AI is analyzing field...	normal	operation-start	llm-op-1	\N	t	f	\N	\N	1760009337963	2025-10-09 11:29:00.047015
notif-34	1	FSQ Quote Analysis	AI is analyzing field...	normal	operation-start	llm-op-2	\N	t	f	\N	\N	1760009343694	2025-10-09 11:29:06.150418
notif-36	1	FSQ Quote Analysis	AI is analyzing field...	normal	operation-start	llm-op-1	\N	t	f	\N	\N	1760009793824	2025-10-09 11:36:35.001047
notif-38	1	FSQ Quote Analysis	AI is analyzing field...	normal	operation-start	llm-op-1	\N	t	f	\N	\N	1760010668467	2025-10-09 11:51:10.352513
notif-39	1	AI analyzed field	Successfully analyzed field in 23.4s	normal	operation-complete	llm-op-1	t	t	f	\N	\N	1760010691879	2025-10-09 11:54:05.76917
notif-40	1	FSQ Quote Analysis	AI is analyzing field...	normal	operation-start	llm-op-2	\N	t	f	\N	\N	1760010844551	2025-10-09 11:54:05.769173
notif-41	1	AI analyzed field	Successfully analyzed field in 0.0s	normal	operation-complete	llm-op-2	t	t	f	\N	\N	1760010844557	2025-10-09 11:54:05.769173
notif-42	1	FSQ Quote Analysis	AI is analyzing field...	normal	operation-start	llm-op-3	\N	t	f	\N	\N	1760010990601	2025-10-09 11:56:31.772244
notif-43	1	AI analyzed field	Successfully analyzed field in 0.0s	normal	operation-complete	llm-op-3	t	t	f	\N	\N	1760010990608	2025-10-09 11:56:31.772246
notif-45	1	FSQ Quote Analysis	AI is analyzing field...	normal	operation-start	llm-op-1	\N	t	f	\N	\N	1760011108892	2025-10-09 11:58:30.130706
notif-46	1	AI analyzed field	Successfully analyzed field in 22.8s	normal	operation-complete	llm-op-1	t	t	f	\N	\N	1760011131653	2025-10-09 11:59:34.786706
notif-47	1	FSQ Quote Analysis	AI is analyzing field...	normal	operation-start	llm-op-2	\N	t	f	\N	\N	1760011173177	2025-10-09 11:59:34.786708
notif-48	1	AI analyzed field	Successfully analyzed field in 1.5s	normal	operation-complete	llm-op-2	t	t	f	\N	\N	1760011174724	2025-10-09 11:59:43.001936
notif-49	1	FSQ Quote Analysis	AI is analyzing field...	normal	operation-start	llm-op-3	\N	t	f	\N	\N	1760011181804	2025-10-09 11:59:43.001937
notif-50	1	AI analyzed field	Successfully analyzed field in 0.0s	normal	operation-complete	llm-op-3	t	t	f	\N	\N	1760011181810	2025-10-09 11:59:43.001937
notif-51	1	FSQ Quote Analysis	AI is analyzing field...	normal	operation-start	llm-op-4	\N	t	f	\N	\N	1760011322708	2025-10-09 12:02:03.886994
notif-52	1	AI analyzed field	Successfully analyzed field in 0.0s	normal	operation-complete	llm-op-4	t	t	f	\N	\N	1760011322714	2025-10-09 12:02:03.886996
notif-53	1	FSQ Quote Analysis	AI is analyzing field...	normal	operation-start	llm-op-5	\N	t	f	\N	\N	1760011334363	2025-10-09 12:02:16.000741
notif-54	1	AI analyzed field	Successfully analyzed field in 0.0s	normal	operation-complete	llm-op-5	t	t	f	\N	\N	1760011334369	2025-10-09 12:02:16.000742
notif-55	1	FSQ Quote Analysis	AI is analyzing field...	normal	operation-start	llm-op-6	\N	t	f	\N	\N	1760011482134	2025-10-09 12:04:43.374371
notif-56	1	AI analyzed field	Successfully analyzed field in 0.0s	normal	operation-complete	llm-op-6	t	t	f	\N	\N	1760011482141	2025-10-09 12:04:43.374372
notif-58	1	FSQ Quote Analysis	AI is analyzing field...	normal	operation-start	llm-op-1	\N	t	f	\N	\N	1760017164078	2025-10-09 13:39:26.061227
notif-60	1	AI generated rundown item in Content Editor Test Segment Generator	Successfully generated rundown item in 19.3s	normal	operation-complete	llm-op-1	t	t	f	\N	\N	1760017943811	2025-10-09 13:53:40.108702
notif-61	1	FSQ Quote Analysis	AI is analyzing field...	normal	operation-start	llm-op-2	\N	t	f	\N	\N	1760018018150	2025-10-09 13:53:40.108703
notif-62	1	AI analyzed field in FSQ Modal Quote Field (quote)	Successfully analyzed field in 34.5s - Recommends 4-part split ⏸️ Action required	normal	operation-complete	llm-op-2	t	t	f	\N	\N	1760018052649	2025-10-09 13:59:10.090473
notif-63	1	AI generated rundown item in Content Editor Test Segment Generator	Successfully generated rundown item in 8.7s	normal	operation-complete	llm-op-3	t	t	f	\N	\N	1760018357340	2025-10-09 13:59:52.293902
notif-65	1	AI generated rundown item in Content Editor Test Segment Generator	Successfully generated rundown item in 5.4s	normal	operation-complete	llm-op-1	t	t	f	\N	\N	1760020605803	2025-10-09 14:45:46.007901
notif-67	1	AI failed analyzing episode	showInfo is not a function	high	operation-error	llm-op-1	f	t	f	\N	\N	1760519282491	2025-10-15 09:08:04.91015
notif-69	1	AI failed analyzing episode	showInfo is not a function	high	operation-error	llm-op-1	f	t	f	\N	\N	1760519596956	2025-10-15 09:13:19.662465
notif-1760520951992-7blgc7lx5	1	File System Load Error	Error loading file systems: Failed to fetch	high	operation-error	\N	f	t	f	\N	{"message": "Error loading file systems: Failed to fetch", "component": "ConsolidationView"}	1760520951992	2025-10-15 09:36:12.300428
notif-1760553034908-na1x041o0	1	Show Build LLM Scan Failed	Show Build LLM scan failed: Unexpected token 'P', "Proxy erro"... is not valid JSON	high	operation-error	llm-op-1	f	t	f	\N	{"message": "Show Build LLM scan failed: Unexpected token 'P', \\"Proxy erro\\"... is not valid JSON", "component": "ConsolidationView"}	1760553034908	2025-10-15 18:31:03.234274
notif-1760553210805-43d2prvdz	1	Google Drive LLM Scan Failed	Google Drive LLM scan failed: Unexpected token 'P', "Proxy erro"... is not valid JSON	high	operation-error	llm-op-2	f	t	f	\N	{"message": "Google Drive LLM scan failed: Unexpected token 'P', \\"Proxy erro\\"... is not valid JSON", "component": "ConsolidationView"}	1760553210805	2025-10-15 18:33:31.811701
notif-1760553701205-82cwecm91	1	Show Build LLM Scan Failed	Show Build LLM scan failed: Unexpected token 'P', "Proxy erro"... is not valid JSON	high	operation-error	llm-op-1	f	t	f	\N	{"message": "Show Build LLM scan failed: Unexpected token 'P', \\"Proxy erro\\"... is not valid JSON", "component": "ConsolidationView"}	1760553701205	2025-10-15 18:42:06.173215
notif-1760553823481-9mxdj877g	1	Google Drive LLM Scan Failed	Google Drive LLM scan failed: Unexpected token 'P', "Proxy erro"... is not valid JSON	high	operation-error	llm-op-2	f	t	f	\N	{"message": "Google Drive LLM scan failed: Unexpected token 'P', \\"Proxy erro\\"... is not valid JSON", "component": "ConsolidationView"}	1760553823482	2025-10-15 18:44:31.754295
notif-71	1	AI failed analyzing episode	Unexpected token 'P', "Proxy erro"... is not valid JSON	high	operation-error	llm-op-1	f	t	f	\N	\N	1760553209623	2025-10-15 18:33:31.844776
notif-72	1	AI failed analyzing episode	Unexpected token 'P', "Proxy erro"... is not valid JSON	high	operation-error	llm-op-2	f	t	f	\N	\N	1760553210805	2025-10-15 18:33:31.844777
notif-74	1	AI failed analyzing episode	Unexpected token 'P', "Proxy erro"... is not valid JSON	high	operation-error	llm-op-1	f	t	f	\N	\N	1760553701205	2025-10-15 18:42:06.210773
notif-75	1	AI failed analyzing episode	Unexpected token 'P', "Proxy erro"... is not valid JSON	high	operation-error	llm-op-2	f	t	f	\N	\N	1760553823481	2025-10-15 18:44:33.861666
notif-1760554377282-brbz80kr2	1	Show Build LLM Scan Failed	Show Build LLM scan failed: Unexpected token 'P', "Proxy erro"... is not valid JSON	high	operation-error	llm-op-1	f	t	f	\N	{"message": "Show Build LLM scan failed: Unexpected token 'P', \\"Proxy erro\\"... is not valid JSON", "component": "ConsolidationView"}	1760554377282	2025-10-15 18:53:45.403128
notif-84	1	AI failed analyzing episode	Unexpected token 'P', "Proxy erro"... is not valid JSON	high	operation-error	llm-op-1	f	t	f	\N	\N	1760554377282	2025-10-15 18:55:00.866223
notif-85	1	AI failed analyzing episode	Unexpected token 'P', "Proxy erro"... is not valid JSON	high	operation-error	llm-op-3	f	t	f	\N	\N	1760554499584	2025-10-15 18:55:00.955776
notif-88	1	AI failed analyzing episode	Unexpected token 'P', "Proxy erro"... is not valid JSON	high	operation-error	llm-op-1	f	t	f	\N	\N	1760570613160	2025-10-15 23:38:51.800182
notif-89	1	AI failed analyzing episode	Unexpected token 'P', "Proxy erro"... is not valid JSON	high	operation-error	llm-op-2	f	t	f	\N	\N	1760570614735	2025-10-15 23:38:51.800183
notif-90	1	AI failed analyzing episode	Unexpected token 'P', "Proxy erro"... is not valid JSON	high	operation-error	llm-op-4	f	t	f	\N	\N	1760570966764	2025-10-15 23:38:51.800185
notif-1760554499585-nt8nn8fcp	1	Google Drive LLM Scan Failed	Google Drive LLM scan failed: Unexpected token 'P', "Proxy erro"... is not valid JSON	high	operation-error	llm-op-3	f	t	f	\N	{"message": "Google Drive LLM scan failed: Unexpected token 'P', \\"Proxy erro\\"... is not valid JSON", "component": "ConsolidationView"}	1760554499585	2025-10-15 18:55:00.930644
notif-1760554499694-1i8c9csng	1	Show Build LLM Scan Failed	Show Build LLM scan failed: Unexpected token 'P', "Proxy erro"... is not valid JSON	high	operation-error	llm-op-2	f	t	f	\N	{"message": "Show Build LLM scan failed: Unexpected token 'P', \\"Proxy erro\\"... is not valid JSON", "component": "ConsolidationView"}	1760554499694	2025-10-15 18:55:00.934451
notif-1760554621895-cybv1p0wy	1	Google Drive LLM Scan Failed	Google Drive LLM scan failed: Unexpected token 'P', "Proxy erro"... is not valid JSON	high	operation-error	llm-op-4	f	t	f	\N	{"message": "Google Drive LLM scan failed: Unexpected token 'P', \\"Proxy erro\\"... is not valid JSON", "component": "ConsolidationView"}	1760554621895	2025-10-15 18:57:18.638374
notif-1760570966765-z2u55e4i1	1	Show Build LLM Scan Failed	Show Build LLM scan failed: Unexpected token 'P', "Proxy erro"... is not valid JSON	high	operation-error	llm-op-4	f	t	f	\N	{"message": "Show Build LLM scan failed: Unexpected token 'P', \\"Proxy erro\\"... is not valid JSON", "component": "ConsolidationView"}	1760570966765	2025-10-15 23:32:12.570533
notif-1760571403180-rb1cvctzn	1	Google Drive LLM Scan Failed	Google Drive LLM scan failed: Failed to fetch	high	operation-error	llm-op-6	f	t	f	\N	{"message": "Google Drive LLM scan failed: Failed to fetch", "component": "ConsolidationView"}	1760571403180	2025-10-15 23:39:35.633989
notif-1760571089032-63eiqqnbp	1	Show Build LLM Scan Failed	Show Build LLM scan failed: Unexpected token 'P', "Proxy erro"... is not valid JSON	high	operation-error	llm-op-4	f	t	f	\N	{"message": "Show Build LLM scan failed: Unexpected token 'P', \\"Proxy erro\\"... is not valid JSON", "component": "ConsolidationView"}	1760571089032	2025-10-15 23:33:15.981045
notif-1760571343424-rmf8le217	1	Google Drive LLM Scan Failed	Google Drive LLM scan failed: Unexpected token 'P', "Proxy erro"... is not valid JSON	high	operation-error	llm-op-6	f	t	f	\N	{"message": "Google Drive LLM scan failed: Unexpected token 'P', \\"Proxy erro\\"... is not valid JSON", "component": "ConsolidationView"}	1760571343424	2025-10-15 23:38:46.366956
notif-86	1	AI failed analyzing episode	Unexpected token 'P', "Proxy erro"... is not valid JSON	high	operation-error	llm-op-2	f	t	f	\N	\N	1760554499694	2025-10-15 18:55:00.955777
notif-91	1	AI failed analyzing episode	Unexpected token 'P', "Proxy erro"... is not valid JSON	high	operation-error	llm-op-6	f	t	f	\N	\N	1760571343423	2025-10-15 23:38:51.800185
notif-1760573109028-khqjb2wmm	1	Show Build LLM Scan Failed	Show Build LLM scan failed: Request failed: 500 Internal Server Error	high	operation-error	llm-op-1	f	t	f	\N	{"message": "Show Build LLM scan failed: Request failed: 500 Internal Server Error", "component": "ConsolidationView"}	1760573109028	2025-10-16 00:05:35.795114
notif-1760573231278-y0bn1nmut	1	Google Drive LLM Scan Failed	Google Drive LLM scan failed: Network error: Unable to reach server	high	operation-error	llm-op-2	f	t	f	\N	{"message": "Google Drive LLM scan failed: Network error: Unable to reach server", "component": "ConsolidationView"}	1760573231278	2025-10-16 00:07:12.741782
notif-93	1	AI failed analyzing episode	Request failed: 500 Internal Server Error	high	operation-error	llm-op-1	f	t	f	\N	\N	1760573109028	2025-10-16 00:05:35.791456
notif-111	1	FSQ Quote Analysis	AI is analyzing field...	normal	operation-start	llm-op-7	\N	f	f	\N	\N	1760819363154	2025-10-18 20:29:25.627331
notif-100	1	AI analyzed field in FSQ Modal Quote Field (quote)	Successfully analyzed field in 2.2s - Quote fits on single screen	normal	operation-complete	llm-op-1	t	t	f	\N	\N	1760818906847	2025-10-18 20:22:57.443583
notif-101	1	FSQ Quote Analysis	AI is analyzing field...	normal	operation-start	llm-op-2	\N	t	f	\N	\N	1760818974981	2025-10-18 20:22:57.443585
notif-102	1	AI analyzed field in FSQ Modal Quote Field (quote)	Successfully analyzed field in 1.9s - Recommends 2-part split ⏸️ Action required	normal	operation-complete	llm-op-2	t	t	f	\N	\N	1760818976838	2025-10-18 20:24:07.407927
notif-103	1	FSQ Quote Analysis	AI is analyzing field...	normal	operation-start	llm-op-3	\N	t	f	\N	\N	1760819045016	2025-10-18 20:24:07.407928
notif-104	1	AI analyzed field in FSQ Modal Quote Field (quote)	Successfully analyzed field in 3.2s - Recommends 2-part split ⏸️ Action required	normal	operation-complete	llm-op-3	t	t	f	\N	\N	1760819048187	2025-10-18 20:25:09.214613
notif-105	1	FSQ Quote Analysis	AI is analyzing field...	normal	operation-start	llm-op-4	\N	t	f	\N	\N	1760819106798	2025-10-18 20:25:09.214614
notif-106	1	AI analyzed field in FSQ Modal Quote Field (quote)	Successfully analyzed field in 1.2s - Quote fits on single screen	normal	operation-complete	llm-op-4	t	t	f	\N	\N	1760819107978	2025-10-18 20:25:29.651135
notif-107	1	FSQ Quote Analysis	AI is analyzing field...	normal	operation-start	llm-op-5	\N	t	f	\N	\N	1760819127174	2025-10-18 20:25:29.651137
notif-108	1	AI analyzed field in FSQ Modal Quote Field (quote)	Successfully analyzed field in 1.8s - Quote fits on single screen	normal	operation-complete	llm-op-5	t	t	f	\N	\N	1760819128947	2025-10-18 20:28:16.522663
notif-109	1	FSQ Quote Analysis	AI is analyzing field...	normal	operation-start	llm-op-6	\N	t	f	\N	\N	1760819294069	2025-10-18 20:28:16.522664
notif-110	1	AI analyzed field in FSQ Modal Quote Field (quote)	Successfully analyzed field in 3.4s - Recommends 2-part split ⏸️ Action required	normal	operation-complete	llm-op-6	t	t	f	\N	\N	1760819297449	2025-10-18 20:29:25.62733
notif-1760583646933-sprvz08vp	1	Show Build LLM Scan Failed	Show Build LLM scan failed: Request failed: 500 Internal Server Error	high	operation-error	llm-op-1	f	t	f	\N	{"message": "Show Build LLM scan failed: Request failed: 500 Internal Server Error", "component": "ConsolidationView"}	1760583646933	2025-10-16 03:02:36.786154
notif-95	1	FSQ Quote Analysis	AI is analyzing field...	normal	operation-start	llm-op-1	\N	t	f	\N	\N	1760818596969	2025-10-18 20:16:39.378014
notif-97	1	FSQ Quote Analysis	AI is analyzing field...	normal	operation-start	llm-op-1	\N	t	f	\N	\N	1760818773598	2025-10-18 20:19:36.023319
notif-99	1	FSQ Quote Analysis	AI is analyzing field...	normal	operation-start	llm-op-1	\N	t	f	\N	\N	1760818904624	2025-10-18 20:21:47.023871
notif-113	1	FSQ Quote Analysis	AI is analyzing field...	normal	operation-start	llm-op-1	\N	f	f	\N	\N	1760819684071	2025-10-18 20:34:46.493113
\.


--
-- Data for Name: llm_operations; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.llm_operations (id, user_id, scope, target_id, operation, state, model, message, operation_metadata, priority, start_time, created_at, updated_at, persistent) FROM stdin;
\.


--
-- Data for Name: organizations; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.organizations (id, asset_id, legal_name, created_at, updated_at, settings, name, trade_name, organization_type, industry, sector, registration_number, tax_id, address_line1, address_line2, city, state_province, postal_code, country, phone, email, website, founded_date, number_of_employees, annual_revenue, status, created_by, notes, is_test_data) FROM stdin;
2	ORGH5ZI5TKE88NN	TechCorp Solutions LLC	2025-08-10 06:40:03.81508+00	\N	\N	TechCorp	\N	\N	Technology	\N	\N	\N	\N	\N	San Francisco	CA	\N	United States	\N	\N	\N	\N	\N	\N	active	system	\N	f
3	ORGCIDYCO7JX9EZ	Green Valley Media Inc	2025-08-10 06:40:03.820306+00	\N	\N	Green Valley	\N	\N	Media	\N	\N	\N	\N	\N	Portland	OR	\N	United States	\N	\N	\N	\N	\N	\N	active	system	\N	f
4	ORGQ2GL520UIANC	Midwest Manufacturing Corp	2025-08-10 06:40:03.82063+00	\N	\N	Midwest Mfg	\N	\N	Manufacturing	\N	\N	\N	\N	\N	Detroit	MI	\N	United States	\N	\N	\N	\N	\N	\N	active	system	\N	f
5	ORGE1AWSKKPSNZ7	Coastal Services Group	2025-08-10 06:40:03.821015+00	\N	\N	Coastal Services	\N	\N	Professional Services	\N	\N	\N	\N	\N	Miami	FL	\N	United States	\N	\N	\N	\N	\N	\N	active	system	\N	f
6	ORGWHPND5I9HDZ9	Mountain Peak Ventures LLC	2025-08-10 06:40:03.821322+00	\N	\N	Mountain Peak	\N	\N	Investment	\N	\N	\N	\N	\N	Denver	CO	\N	United States	\N	\N	\N	\N	\N	\N	active	system	\N	f
1	ORGME59KA79S92XIP	Polaris Broadcasting LLC	2025-08-10 05:49:16.613655+00	2025-08-10 06:35:26.55891+00	{"migrated_from_settings": true}	Polaris Mediaworks	Polaris Media	LLC	Broadcasting	Media & Entertainment	124456465	54564579686	190 Main St.	\N	Ravena	NY	12143	United States	(518) 605-6460	info@polarisbroadcasting.com	https://polarisbroadcasting.com	2025-01-15 00:00:00+00	1	250000000	active	kevin	Regional broadcasting company focused on local news and community content	f
7	ORGA0DTJNAYVN	Default Organization	2025-08-16 15:39:10.681475+00	\N	{}	Default Organization	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	United States	\N	\N	\N	\N	\N	\N	active	\N	\N	f
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.permissions (id, name, display_name, description, resource, action, scope, is_system, created_at, updated_at, created_by) FROM stdin;
1	users.create	Create Users	\N	users	create	global	t	2025-08-13 12:59:32.624322+00	\N	system
2	users.read	View Users	\N	users	read	organization	t	2025-08-13 12:59:32.624322+00	\N	system
3	users.update	Update Users	\N	users	update	organization	t	2025-08-13 12:59:32.624322+00	\N	system
4	users.delete	Delete Users	\N	users	delete	organization	t	2025-08-13 12:59:32.624322+00	\N	system
5	organizations.create	Create Organizations	\N	organizations	create	global	t	2025-08-13 12:59:32.624322+00	\N	system
6	organizations.read	View Organizations	\N	organizations	read	own	t	2025-08-13 12:59:32.624322+00	\N	system
7	organizations.update	Update Organizations	\N	organizations	update	own	t	2025-08-13 12:59:32.624322+00	\N	system
8	organizations.delete	Delete Organizations	\N	organizations	delete	global	t	2025-08-13 12:59:32.624322+00	\N	system
9	shows.create	Create Shows	\N	shows	create	organization	t	2025-08-13 12:59:32.624322+00	\N	system
10	shows.read	View Shows	\N	shows	read	organization	t	2025-08-13 12:59:32.624322+00	\N	system
11	shows.update	Update Shows	\N	shows	update	organization	t	2025-08-13 12:59:32.624322+00	\N	system
12	shows.delete	Delete Shows	\N	shows	delete	organization	t	2025-08-13 12:59:32.624322+00	\N	system
13	episodes.create	Create Episodes	\N	episodes	create	organization	t	2025-08-13 12:59:32.624322+00	\N	system
14	episodes.read	View Episodes	\N	episodes	read	organization	t	2025-08-13 12:59:32.624322+00	\N	system
15	episodes.update	Update Episodes	\N	episodes	update	organization	t	2025-08-13 12:59:32.624322+00	\N	system
16	episodes.delete	Delete Episodes	\N	episodes	delete	organization	t	2025-08-13 12:59:32.624322+00	\N	system
17	episodes.publish	Publish Episodes	\N	episodes	publish	organization	t	2025-08-13 12:59:32.624322+00	\N	system
18	content.create	Create Content	\N	content	create	organization	t	2025-08-13 12:59:32.624322+00	\N	system
19	content.read	View Content	\N	content	read	organization	t	2025-08-13 12:59:32.624322+00	\N	system
20	content.update	Update Content	\N	content	update	organization	t	2025-08-13 12:59:32.624322+00	\N	system
21	content.delete	Delete Content	\N	content	delete	organization	t	2025-08-13 12:59:32.624322+00	\N	system
22	rbac.manage	Manage Roles & Permissions	\N	rbac	manage	organization	t	2025-08-13 12:59:32.624322+00	\N	system
23	rbac.assign	Assign Roles	\N	rbac	assign	organization	t	2025-08-13 12:59:32.624322+00	\N	system
24	rbac.audit	View Audit Logs	\N	rbac	audit	organization	t	2025-08-13 12:59:32.624322+00	\N	system
25	admin.all	Full System Access	\N	admin	all	global	t	2025-08-13 12:59:32.624322+00	\N	system
\.


--
-- Data for Name: processing_jobs; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.processing_jobs (id, episode_id, job_type, job_id, status, parameters, result, error_message, progress, created_at, started_at, completed_at, is_test_data) FROM stdin;
\.


--
-- Data for Name: prompt_overrides; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.prompt_overrides (id, category, operation_key, system_prompt, user_prompt_template, is_enabled, notes, created_by, created_at, updated_at, metadata, suggested_service, suggested_model, temperature, max_tokens) FROM stdin;
28bed68e-3c06-4ecf-a145-4596ccabf815	inventory	inventory-match-file-to-slot	You are a file classification expert analyzing episode production files.\n\nYour task: Determine if a file satisfies a specific slot expectation.\n\nRespond ONLY with valid JSON in this exact format:\n{\n  "matches": true/false,\n  "confidence": 0-100,\n  "reasoning": "brief explanation why it matches or doesn't",\n  "block_id": "A/B/C/D" (only if file is a block capture/export),\n  "break_id": "1/2/3" (only if file is a break recording),\n  "guest_name": "name" (only if file is guest-related)\n}\n\nBe strict: Only match if the file clearly satisfies the slot's purpose and characteristics.\nConfidence guidelines:\n- 95-100: Perfect match, all characteristics align\n- 85-94: Strong match, minor discrepancies\n- 75-84: Probable match, some uncertainty\n- Below 75: Weak match, significant doubts	SLOT EXPECTATION:\n- Slot: {{slot}}\n- Purpose: {{purpose}}\n- Characteristics: {{characteristics}}\n- Location hints: {{location_hints}}\n- Episode: {{episode}}\n\nFILE TO EVALUATE:\n- Path: {{file_path}}\n- Filename: {{filename}}\n- Extension: {{extension}}\n- Size: {{size}} bytes\n- Folder: {{folder_path}}\n- Dimensions: {{dimensions}}\n- Aspect Ratio: {{aspect_ratio}}\n- Modified: {{modified}}\n\nDoes this file satisfy the slot expectation? Respond with JSON.	f	Default prompt for inventory-match-file-to-slot	system	2025-10-15 10:52:41.317466	2025-10-15 10:52:41.317031	\N	\N	\N	\N	\N
9f660cb7-1a08-47e9-b0ff-bce4afb7425d	inventory	inventory-classify-stray-file	You are classifying files that don't match any expected slot.\n\nCategories:\n- script.rundown_item: Markdown rundown files (keep these)\n- stray.misplaced_asset: Asset in wrong directory (relocate)\n- stray.test_file: Test/dummy files (delete)\n- stray.backup: Backup/old versions (review before delete)\n- stray.duplicate: Duplicate of another file (review/delete)\n- stray.temp: Temporary/cache files (delete)\n- stray.system: OS system files like .DS_Store (ignore/delete)\n- stray.sync_conflict: Sync conflict files (review)\n- stray.unknown: Can't determine purpose (review)\n\nRespond with JSON:\n{\n  "category": "one of above",\n  "confidence": 0-100,\n  "reasoning": "why you classified it this way",\n  "suggested_action": "keep/delete/relocate/review",\n  "relocation_target": "path" (only if action=relocate),\n  "safety": "safe/caution/dangerous"\n}\n\nSafety levels:\n- safe: Can act on immediately\n- caution: Review recommended\n- dangerous: Manual review required	FILE TO CLASSIFY:\n- Path: {{file_path}}\n- Filename: {{filename}}\n- Extension: {{extension}}\n- Size: {{size}} bytes\n- Folder: {{folder_path}}\n- Dimensions: {{dimensions}}\n- Modified: {{modified}}\n\nThis file didn't match any expected slot. What is it and what should we do with it? Respond with JSON.	f	Default prompt for inventory-classify-stray-file	system	2025-10-15 10:52:41.317941	2025-10-15 10:52:41.317031	\N	\N	\N	\N	\N
7ed98565-e271-4967-9776-27988d3ae6ca	inventory	inventory-batch-match-slots	You are a file classification expert analyzing episode production files.\n\nYour task: Match files from a directory tree to expected file slots based on their purpose and characteristics.\n\nIMPORTANT RULES:\n1. A slot can remain EMPTY if no matching file exists - this is completely normal and acceptable\n2. DO NOT force every slot to be filled\n3. DO NOT match files that don't truly fit the slot characteristics\n4. If no file matches a slot's requirements, return empty array for that slot\n5. Only match files when you have reasonable confidence (75%+) they serve the slot's purpose\n6. Multiple files can match the same slot ONLY if the slot characteristics indicate "multiple files"\n7. A single file should NOT match multiple slots - choose the BEST fit\n\nReturn your analysis as valid JSON with this structure:\n{\n  "slot_name": {\n    "matches": ["relative/path/to/file1.ext", "relative/path/to/file2.ext"],\n    "confidence": 85,\n    "reasoning": "Brief explanation"\n  }\n}\n\nUse EMPTY ARRAY [] for slots with no matches.\nBe strict: It is BETTER to leave a slot empty than to make a poor match.\nMissing files are normal in production workflows - many slots will be unfilled.\n\nRespond ONLY with valid JSON, no additional text.	EPISODE: {{episode_number}}\n\nDIRECTORY TREE:\n{{file_tree}}\n\nSLOTS TO EVALUATE ({{slot_count}} slots):\n\n{{slot_definitions}}\n\nCRITICAL RULES:\n- You MUST ONLY match files that appear in the DIRECTORY TREE above\n- DO NOT invent, suggest, or create filenames - even if they fit the pattern\n- DO NOT match files based on what "should" exist or what the examples show\n- ONLY match files from the exact list in the directory tree\n- It is NORMAL and EXPECTED for many slots to be empty\n- Return empty array [] for slots with no matching files\n- Use the relative path EXACTLY as shown in the directory tree\n\nFor each slot above, identify matching files from the directory tree.\nReturn JSON with all slot results, using empty arrays for unfilled slots.\n\nIMPORTANT: If a file is not listed in the DIRECTORY TREE above, it does NOT exist - do not match it.	f	Default prompt for inventory-batch-match-slots	system	2025-10-15 10:52:41.318297	2025-10-15 10:59:59.380915	\N	\N	\N	\N	\N
\.


--
-- Data for Name: rbac_audit_log; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.rbac_audit_log (id, action, resource_type, resource_id, actor_type, actor_id, organization_id, details, ip_address, user_agent, created_at) FROM stdin;
1	role_assigned	user	1	user	rbac-test	1	{"role_id": 5, "role_name": "Viewer"}	\N	\N	2025-08-13 13:00:27.045792+00
\.


--
-- Data for Name: regions; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.regions (id, asset_id, is_test_data, rundown_id, region_type, name, description, order_in_rundown, estimated_duration, actual_duration, is_collapsible, is_collapsed, allow_reorder, color_theme, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.role_permissions (role_id, permission_id, granted_at, granted_by) FROM stdin;
1	25	2025-08-13 12:59:32.624322+00	\N
2	14	2025-08-13 12:59:32.624322+00	\N
2	19	2025-08-13 12:59:32.624322+00	\N
2	11	2025-08-13 12:59:32.624322+00	\N
2	9	2025-08-13 12:59:32.624322+00	\N
2	3	2025-08-13 12:59:32.624322+00	\N
2	10	2025-08-13 12:59:32.624322+00	\N
2	7	2025-08-13 12:59:32.624322+00	\N
2	2	2025-08-13 12:59:32.624322+00	\N
2	18	2025-08-13 12:59:32.624322+00	\N
2	1	2025-08-13 12:59:32.624322+00	\N
2	16	2025-08-13 12:59:32.624322+00	\N
2	20	2025-08-13 12:59:32.624322+00	\N
2	13	2025-08-13 12:59:32.624322+00	\N
2	15	2025-08-13 12:59:32.624322+00	\N
2	6	2025-08-13 12:59:32.624322+00	\N
2	4	2025-08-13 12:59:32.624322+00	\N
2	23	2025-08-13 12:59:32.624322+00	\N
2	21	2025-08-13 12:59:32.624322+00	\N
2	12	2025-08-13 12:59:32.624322+00	\N
2	22	2025-08-13 12:59:32.624322+00	\N
2	24	2025-08-13 12:59:32.624322+00	\N
2	17	2025-08-13 12:59:32.624322+00	\N
3	11	2025-08-13 12:59:32.624322+00	\N
3	17	2025-08-13 12:59:32.624322+00	\N
3	13	2025-08-13 12:59:32.624322+00	\N
3	20	2025-08-13 12:59:32.624322+00	\N
3	19	2025-08-13 12:59:32.624322+00	\N
3	10	2025-08-13 12:59:32.624322+00	\N
3	21	2025-08-13 12:59:32.624322+00	\N
3	15	2025-08-13 12:59:32.624322+00	\N
3	16	2025-08-13 12:59:32.624322+00	\N
3	14	2025-08-13 12:59:32.624322+00	\N
3	18	2025-08-13 12:59:32.624322+00	\N
3	9	2025-08-13 12:59:32.624322+00	\N
4	19	2025-08-13 12:59:32.624322+00	\N
4	18	2025-08-13 12:59:32.624322+00	\N
4	21	2025-08-13 12:59:32.624322+00	\N
4	14	2025-08-13 12:59:32.624322+00	\N
4	15	2025-08-13 12:59:32.624322+00	\N
4	20	2025-08-13 12:59:32.624322+00	\N
5	10	2025-08-13 12:59:32.624322+00	\N
5	14	2025-08-13 12:59:32.624322+00	\N
5	19	2025-08-13 12:59:32.624322+00	\N
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.roles (id, name, slug, description, parent_role_id, level, is_system, is_active, color, organization_id, created_at, updated_at, created_by) FROM stdin;
1	Super Admin	super-admin	Full system administrator	\N	0	t	t	\N	\N	2025-08-13 12:59:32.624322+00	\N	system
2	Organization Admin	org-admin	Organization administrator	\N	1	t	t	\N	\N	2025-08-13 12:59:32.624322+00	\N	system
3	Content Manager	content-manager	Manages shows and episodes	\N	2	t	t	\N	\N	2025-08-13 12:59:32.624322+00	\N	system
4	Content Editor	content-editor	Edits content and rundowns	\N	3	t	t	\N	\N	2025-08-13 12:59:32.624322+00	\N	system
5	Viewer	viewer	Read-only access	\N	4	t	t	\N	\N	2025-08-13 12:59:32.624322+00	\N	system
\.


--
-- Data for Name: rundown_items; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.rundown_items (id, asset_id, rundown_id, segment_id, item_type, title, slug, order_in_rundown, duration, subtitle, description, airdate, guests, resources, tags, server_message, link, priority, message, status, created_at, updated_at, is_test_data, script_content, speaker_id) FROM stdin;
1	ASTMEEFD8AX520WY1	1	\N	advertisement	sponsor-message-1	sponsor-message-1	1	00:00:30	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	draft	2025-08-16 15:41:40.813318+00	\N	f	\N	\N
3	ASTMENN08JNRJDC0G	1	\N	advertisement	ad	ad	1	00:00:30	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	draft	2025-08-23 02:25:27.117073+00	\N	f	\N	\N
4	ASTMENNENQDGGNHMO	1	\N	advertisement	ad	ad	1	00:00:30	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	draft	2025-08-23 02:36:39.983838+00	\N	f	\N	\N
5	ASTMENNGGSESOGQAU	1	\N	advertisement	ad	ad	1	00:00:30	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	draft	2025-08-23 02:38:04.296152+00	\N	f	\N	\N
21	ASTMFMGRRWO0XMK4R	6	\N	segment	Block A - Charlie Kirk	charlie-kirk	80	00:25:00	None	# Charlie Kirk\n\n**Facts:**\n\nCharlie Kirk was the founder of Turning Point USA, a group dedicated to mobilizing the young conservative vote. Charlie was killed at 31 years old. He leaves behind his wife Erika, and two small children, at least one of whom watched her father's carotid artery explode from an assassin's bullet the morning of Wednesday, Sept 10, 2025. \n\nCharlie was speaking on the campus of Utah Valley University. The suspect in custody now is 22-year-old Tyler Robinson. We'll have more on Robinson below. Much more. \n\nThis clip is a good example of who Charlie Kirk was and how he operated. He was a consummate gentleman, not a provocateur, impossibly gracious. He invited young leftist students to come up to the microphone to debate, and he took the most vile abuse from them without ever returning it in kind. \n\nTake a look:\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: charlie-in-action]\n[Description: ]\n[MediaURL: ../assets/video/charlie-in-action.mp4]\n[Duration: 00:00:57:09]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nCharlie turned the other cheek just like so many Christians want everyone to do. He wasn't foul-mouthed, mean, provocative, outrageous, or any of the other adjectives applied to firebrand commentators, applied to me though I'm small potatoes. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-E16387628722]\n[Slug: charlie-family]\n[Description: ]\n[MediaURL: ../assets/graphics/charlie-family.png]\n<img src="../assets/graphics/charlie-family.png" width="200" />\n<!-- End Cue -->\n\nAnd he was murdered anyway. Here it is:\n\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: alternate-charlie-kirk-shooting]\n[Description: ]\n[MediaURL: ../assets/video/alternate-charlie-kirk-shooting.mp4]\n[Duration: Pending...]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nHere it is from the front:\n\n\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: charlie-kirk-shooting]\n[Description: ]\n[MediaURL: ../assets/video/charlie-kirk-shooting.mp4]\n[Duration: Pending...]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\n## What we know about the shooter\n\nEverything is provisional. The story has changed several times as I've watched in real time. This is what I think I know as of Saturday, September 13. Everything is subject to change. \n\nThe police have arrested 22-year-old Tyler Robinson. He apparently spent one semester in college and dropped out. He comes from a Republican family with a mother and father still married, and two brothers. His father is a countertop installer and his mother apparently a social worker. More on the family in a few minutes. \n\nRobinson appears to have gotten on a rooftop and shot Charlie from a few hundred yards. \n\nWe're just learning from Fox News that Tyler Robinson had a boyfriend who calls himself a trans woman. All claims so far point to Tyler being the lone leftist liberal in conservative family. It appears, so far, that he became radicalized by spending way too much time online. Also more on this in a few minutes. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-E16387628722]\n[Slug: tyler-mask]\n[Description: ]\n[MediaURL: ../assets/graphics/tyler-mask.png]\n<img src="../assets/graphics/tyler-mask.png" width="200" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-E16387628722]\n[Slug: tyler-bedroom]\n[Description: ]\n[MediaURL: ../assets/graphics/tyler-bedroom.png]\n<img src="../assets/graphics/tyler-bedroom.png" width="200" />\n<!-- End Cue -->\n\nFrom Fox News:\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-E16387628722]\n[Slug: exclusive-charlie-tweet]\n[Description: ]\n[MediaURL: ../assets/graphics/exclusive-charlie-tweet.png]\n<img src="../assets/graphics/exclusive-charlie-tweet.png" width="200" />\n<!-- End Cue -->\n\n{GFX/the last question}\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-E16387628722]\n[Slug: the-last-question]\n[Description: ]\n[MediaURL: ../assets/graphics/the-last-question.png]\n<img src="../assets/graphics/the-last-question.png" width="200" />\n<!-- End Cue -->\n\nHere's what Utah Governor Spencer Cox had to say after Tyler was caught. Pay attention to what Cox says about what Tyler engraved on the bullets. He wrote antifa slogans, and also what appears to be a reference to transgender/furry culture. You'll hear Cox refer to a family member who turned Tyler in to the police. That family member was Tyler's father Matt. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: ut-gov-announcement]\n[Description: ]\n[MediaURL: ../assets/video/ut-gov-announcement.mp4]\n[Duration: 00:02:43:19]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\n-"Notices bulges"-furry trans reference\n\n-As I said, it appears that Tyler's father Matt turned his son in after getting a family preacher to convince Tyler not to kill himself and to take accountability for his actions. \n\n-Everyone around the family so far has described them as conservative, religious, and that Tyler was the only leftist, and that he had gotten increasinbly radical over time. It's  not clear to me if the family were practicing mormons, or some other religion or denomination. I'm seeing conflicting reports. \n\n## Media reaction\n\nFor years on this show we've talked about the socially acceptable open glee the mainstream left takes in violence against conservatives. How it goes all the way to the top. How President Joe Biden stood in front of a blood red background and screamed at half the country and called them enemies and killers because they wouldn't take a fucking shot in their arm over a fucking cold virus. \n\nHere's a clip from last year after the first ass. attempt against pres Trump. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: disaffected-clip]\n[Description: ]\n[MediaURL: ../assets/video/disaffected-clip.mp4]\n[Duration: 00:00:31:10]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {"credit1":"Joshua Slocum"}]\n<!-- End Cue -->\n\nPeople around the country this week are learning that their brothers, sisters, mothers, fathers, friends, bosses, and teachers would see them dead. They know this because their loved ones are delighting in Charlie Kirk's murder, and these people had thoughts that aligned with Charlie. \n\nYes, that's right. Your own family many of you wants you dead, or would happily see you dead without lifting a finger to stop it. They might even helpfully point to you so the killer can find you. I put friends out of my life over this during the past five years becasue I think they would see me dead too. After all, I'm a moral contaminant. And so are you to your leftist family. \n\nWe need our noses rubbed in this shit until it is smeared up our nostrils and we can't pretend any longer that we don't have feces in our face. So let's go. \n\nHere's a video montage from Virginia's Lt. Gov, Winsome Sears, a conservative. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: winsome-sears-fascism]\n[Description: ]\n[MediaURL: ../assets/video/winsome-sears-fascism.mp4]\n[Duration: 00:02:24:01]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nPsychopathic moral reversals. The murderers are telling us we're the murderers. \n\nHere's MSNBC reacting to Kirk's murder. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: msnbc-trump-justify-charlie]\n[Description: ]\n[MediaURL: ../assets/video/msnbc-trump-justify-charlie.mp4]\n[Duration: 00:00:36:22]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nDid you catch her lie? \nShe said a DOGE employee was "allegedly attacked." \nThere's nothing alleged about it and she knows it. She's lying consciously. Here's what that attack looked like:\n\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: big-balls-attacked]\n[Description: ]\n[MediaURL: ../assets/video/big-balls-attacked.mp4]\n[Duration: 00:01:56:24]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nHere's more from MSNBC\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: msnbc-divisive-charlie]\n[Description: ]\n[MediaURL: ../assets/video/msnbc-divisive-charlie.mp4]\n[Duration: 00:01:17:19]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nAnd here's more from MSNBC\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: msnbc-unfortunate]\n[Description: ]\n[MediaURL: ../assets/video/msnbc-unfortunate.mp4]\n[Duration: 00:00:25:10]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\n-Charlie deserved it, see? You say awful things like I care about the Constitution, and so you get awful things. Including having your carotid artery shot out in front of your fucking children.\n\nHere's the US House of Representives refusing to keep silent for a one-minute prayer for Charlie:\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: house-dems-boo-kirk]\n[Description: ]\n[MediaURL: ../assets/video/house-dems-boo-kirk.mp4]\n[Duration: 00:00:55:22]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nLet's look at the reactions from the public. Do not lie to yourself and people around you saying "this is just a few loons on social media." No it's not. And the fact that these people are comfortable saying this in public is a REAL LIFE REAL WORLD EMERGENCY. \n\nThere will be no "you're just cherry picking extremists." If that's your line, I know who you side with and you are my enemy and I will keep you in line of sight and never turn my back on you. I suggest all of you adopt my stance. The shushers will get you killed. \n\nThere were thousands of these reactions online. What you're gonna see is just a tiny fraction. Thousands and thousands and thousands of these. \n\nHere's intensive care Cleveland clinic nurse Andrew Corbit/Stiltner:  \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-E16387628722]\n[Slug: andrew-corbit]\n[Description: ]\n[MediaURL: ../assets/graphics/andrew-corbit.png]\n<img src="../assets/graphics/andrew-corbit.png" width="200" />\n<!-- End Cue -->\n\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-E16387628722]\n[Slug: andrew-thread]\n[Description: ]\n[MediaURL: ../assets/graphics/andrew-thread.png]\n<img src="../assets/graphics/andrew-thread.png" width="200" />\n<!-- End Cue -->\n\n-There was no old him. That's who he's always been. \n\n-Fire him. Pull his nursing license. \n\nHere's Heather Harvey, staffer for Democrat Rep. Andre Carson of Illinois. On Instagram she calls herself the smartass staffer\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-E16387628722]\n[Slug: smart-ass-staffer]\n[Description: ]\n[MediaURL: ../assets/graphics/smart-ass-staffer.png]\n<img src="../assets/graphics/smart-ass-staffer.png" width="200" />\n<!-- End Cue -->\n\n-Fire her. Blacklist in all party politics. \n\nThe TeleTeeShirt company had a hot new product for a few hours until someone noticed their psychopathy:\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-E16387628722]\n[Slug: tele-teeshirt]\n[Description: ]\n[MediaURL: ../assets/graphics/tele-teeshirt.png]\n<img src="../assets/graphics/tele-teeshirt.png" width="200" />\n<!-- End Cue -->\n\nHere's another nurse. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: medical-worker-charlie]\n[Description: ]\n[MediaURL: ../assets/video/medical-worker-charlie.mp4]\n[Duration: 00:00:36:22]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nHere's Lisa Damato, a former contestant on America's Next Top Model:\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: lisa-damato-charlie]\n[Description: ]\n[MediaURL: ../assets/video/lisa-damato-charlie.mp4]\n[Duration: 00:00:21:26]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nCharlie knew what was coming to America. Here's what he tweeted on April 7. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-E16387628722]\n[Slug: assassination-culture]\n[Description: ]\n[MediaURL: ../assets/graphics/assassination-culture.png]\n<img src="../assets/graphics/assassination-culture.png" width="200" />\n<!-- End Cue -->\n\nLet's check in with the borderline personality set. All of these appear to have comorbid pyschopathy. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: nose-ring-girl-charlie]\n[Description: ]\n[MediaURL: ../assets/video/nose-ring-girl-charlie.mp4]\n[Duration: 00:01:07:15]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nHere's more. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: charlie-in-the-neck]\n[Description: ]\n[MediaURL: ../assets/video/charlie-in-the-neck.mp4]\n[Duration: 00:00:30:09]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nHere's a TikTok compilation. See if you can identify any patterns about these people:\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: tiktok-celebration]\n[Description: ]\n[MediaURL: ../assets/video/tiktok-celebration.mp4]\n[Duration: 00:00:38:02]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nHere's a commenter named Amanda Seales. She would like you to know that she just chillin' and having her snacks about it. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: amanda-seales-charlie]\n[Description: ]\n[MediaURL: ../assets/video/amanda-seales-charlie.mp4]\n[Duration: 00:02:41:05]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nHere's a delightful and sweet girl:\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: the-best-part-a]\n[Description: ]\n[MediaURL: ../assets/video/the-best-part-a.mp4]\n[Duration: 00:00:17:18]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->	\N	None	None	None	None	\N	None	\N	production	2025-09-16 11:22:50.764656+00	2025-10-03 18:04:27.410293+00	f	# Charlie Kirk\n\n**Facts:**\n\nCharlie Kirk was the founder of Turning Point USA, a group dedicated to mobilizing the young conservative vote. Charlie was killed at 31 years old. He leaves behind his wife Erika, and two small children, at least one of whom watched her father's carotid artery explode from an assassin's bullet the morning of Wednesday, Sept 10, 2025. \n\nCharlie was speaking on the campus of Utah Valley University. The suspect in custody now is 22-year-old Tyler Robinson. We'll have more on Robinson below. Much more. \n\nThis clip is a good example of who Charlie Kirk was and how he operated. He was a consummate gentleman, not a provocateur, impossibly gracious. He invited young leftist students to come up to the microphone to debate, and he took the most vile abuse from them without ever returning it in kind. \n\nTake a look:\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: charlie-in-action]\n[Description: ]\n[MediaURL: ../assets/video/charlie-in-action.mp4]\n[Duration: 00:00:57:09]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nCharlie turned the other cheek just like so many Christians want everyone to do. He wasn't foul-mouthed, mean, provocative, outrageous, or any of the other adjectives applied to firebrand commentators, applied to me though I'm small potatoes. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-E16387628722]\n[Slug: charlie-family]\n[Description: ]\n[MediaURL: ../assets/graphics/charlie-family.png]\n<img src="../assets/graphics/charlie-family.png" width="200" />\n<!-- End Cue -->\n\nAnd he was murdered anyway. Here it is:\n\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: alternate-charlie-kirk-shooting]\n[Description: ]\n[MediaURL: ../assets/video/alternate-charlie-kirk-shooting.mp4]\n[Duration: Pending...]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nHere it is from the front:\n\n\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: charlie-kirk-shooting]\n[Description: ]\n[MediaURL: ../assets/video/charlie-kirk-shooting.mp4]\n[Duration: Pending...]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\n## What we know about the shooter\n\nEverything is provisional. The story has changed several times as I've watched in real time. This is what I think I know as of Saturday, September 13. Everything is subject to change. \n\nThe police have arrested 22-year-old Tyler Robinson. He apparently spent one semester in college and dropped out. He comes from a Republican family with a mother and father still married, and two brothers. His father is a countertop installer and his mother apparently a social worker. More on the family in a few minutes. \n\nRobinson appears to have gotten on a rooftop and shot Charlie from a few hundred yards. \n\nWe're just learning from Fox News that Tyler Robinson had a boyfriend who calls himself a trans woman. All claims so far point to Tyler being the lone leftist liberal in conservative family. It appears, so far, that he became radicalized by spending way too much time online. Also more on this in a few minutes. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-E16387628722]\n[Slug: tyler-mask]\n[Description: ]\n[MediaURL: ../assets/graphics/tyler-mask.png]\n<img src="../assets/graphics/tyler-mask.png" width="200" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-E16387628722]\n[Slug: tyler-bedroom]\n[Description: ]\n[MediaURL: ../assets/graphics/tyler-bedroom.png]\n<img src="../assets/graphics/tyler-bedroom.png" width="200" />\n<!-- End Cue -->\n\nFrom Fox News:\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-E16387628722]\n[Slug: exclusive-charlie-tweet]\n[Description: ]\n[MediaURL: ../assets/graphics/exclusive-charlie-tweet.png]\n<img src="../assets/graphics/exclusive-charlie-tweet.png" width="200" />\n<!-- End Cue -->\n\n{GFX/the last question}\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-E16387628722]\n[Slug: the-last-question]\n[Description: ]\n[MediaURL: ../assets/graphics/the-last-question.png]\n<img src="../assets/graphics/the-last-question.png" width="200" />\n<!-- End Cue -->\n\nHere's what Utah Governor Spencer Cox had to say after Tyler was caught. Pay attention to what Cox says about what Tyler engraved on the bullets. He wrote antifa slogans, and also what appears to be a reference to transgender/furry culture. You'll hear Cox refer to a family member who turned Tyler in to the police. That family member was Tyler's father Matt. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: ut-gov-announcement]\n[Description: ]\n[MediaURL: ../assets/video/ut-gov-announcement.mp4]\n[Duration: 00:02:43:19]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\n-"Notices bulges"-furry trans reference\n\n-As I said, it appears that Tyler's father Matt turned his son in after getting a family preacher to convince Tyler not to kill himself and to take accountability for his actions. \n\n-Everyone around the family so far has described them as conservative, religious, and that Tyler was the only leftist, and that he had gotten increasinbly radical over time. It's  not clear to me if the family were practicing mormons, or some other religion or denomination. I'm seeing conflicting reports. \n\n## Media reaction\n\nFor years on this show we've talked about the socially acceptable open glee the mainstream left takes in violence against conservatives. How it goes all the way to the top. How President Joe Biden stood in front of a blood red background and screamed at half the country and called them enemies and killers because they wouldn't take a fucking shot in their arm over a fucking cold virus. \n\nHere's a clip from last year after the first ass. attempt against pres Trump. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: disaffected-clip]\n[Description: ]\n[MediaURL: ../assets/video/disaffected-clip.mp4]\n[Duration: 00:00:31:10]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {"credit1":"Joshua Slocum"}]\n<!-- End Cue -->\n\nPeople around the country this week are learning that their brothers, sisters, mothers, fathers, friends, bosses, and teachers would see them dead. They know this because their loved ones are delighting in Charlie Kirk's murder, and these people had thoughts that aligned with Charlie. \n\nYes, that's right. Your own family many of you wants you dead, or would happily see you dead without lifting a finger to stop it. They might even helpfully point to you so the killer can find you. I put friends out of my life over this during the past five years becasue I think they would see me dead too. After all, I'm a moral contaminant. And so are you to your leftist family. \n\nWe need our noses rubbed in this shit until it is smeared up our nostrils and we can't pretend any longer that we don't have feces in our face. So let's go. \n\nHere's a video montage from Virginia's Lt. Gov, Winsome Sears, a conservative. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: winsome-sears-fascism]\n[Description: ]\n[MediaURL: ../assets/video/winsome-sears-fascism.mp4]\n[Duration: 00:02:24:01]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nPsychopathic moral reversals. The murderers are telling us we're the murderers. \n\nHere's MSNBC reacting to Kirk's murder. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: msnbc-trump-justify-charlie]\n[Description: ]\n[MediaURL: ../assets/video/msnbc-trump-justify-charlie.mp4]\n[Duration: 00:00:36:22]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nDid you catch her lie? \nShe said a DOGE employee was "allegedly attacked." \nThere's nothing alleged about it and she knows it. She's lying consciously. Here's what that attack looked like:\n\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: big-balls-attacked]\n[Description: ]\n[MediaURL: ../assets/video/big-balls-attacked.mp4]\n[Duration: 00:01:56:24]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nHere's more from MSNBC\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: msnbc-divisive-charlie]\n[Description: ]\n[MediaURL: ../assets/video/msnbc-divisive-charlie.mp4]\n[Duration: 00:01:17:19]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nAnd here's more from MSNBC\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: msnbc-unfortunate]\n[Description: ]\n[MediaURL: ../assets/video/msnbc-unfortunate.mp4]\n[Duration: 00:00:25:10]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\n-Charlie deserved it, see? You say awful things like I care about the Constitution, and so you get awful things. Including having your carotid artery shot out in front of your fucking children.\n\nHere's the US House of Representives refusing to keep silent for a one-minute prayer for Charlie:\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: house-dems-boo-kirk]\n[Description: ]\n[MediaURL: ../assets/video/house-dems-boo-kirk.mp4]\n[Duration: 00:00:55:22]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nLet's look at the reactions from the public. Do not lie to yourself and people around you saying "this is just a few loons on social media." No it's not. And the fact that these people are comfortable saying this in public is a REAL LIFE REAL WORLD EMERGENCY. \n\nThere will be no "you're just cherry picking extremists." If that's your line, I know who you side with and you are my enemy and I will keep you in line of sight and never turn my back on you. I suggest all of you adopt my stance. The shushers will get you killed. \n\nThere were thousands of these reactions online. What you're gonna see is just a tiny fraction. Thousands and thousands and thousands of these. \n\nHere's intensive care Cleveland clinic nurse Andrew Corbit/Stiltner:  \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-E16387628722]\n[Slug: andrew-corbit]\n[Description: ]\n[MediaURL: ../assets/graphics/andrew-corbit.png]\n<img src="../assets/graphics/andrew-corbit.png" width="200" />\n<!-- End Cue -->\n\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-E16387628722]\n[Slug: andrew-thread]\n[Description: ]\n[MediaURL: ../assets/graphics/andrew-thread.png]\n<img src="../assets/graphics/andrew-thread.png" width="200" />\n<!-- End Cue -->\n\n-There was no old him. That's who he's always been. \n\n-Fire him. Pull his nursing license. \n\nHere's Heather Harvey, staffer for Democrat Rep. Andre Carson of Illinois. On Instagram she calls herself the smartass staffer\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-E16387628722]\n[Slug: smart-ass-staffer]\n[Description: ]\n[MediaURL: ../assets/graphics/smart-ass-staffer.png]\n<img src="../assets/graphics/smart-ass-staffer.png" width="200" />\n<!-- End Cue -->\n\n-Fire her. Blacklist in all party politics. \n\nThe TeleTeeShirt company had a hot new product for a few hours until someone noticed their psychopathy:\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-E16387628722]\n[Slug: tele-teeshirt]\n[Description: ]\n[MediaURL: ../assets/graphics/tele-teeshirt.png]\n<img src="../assets/graphics/tele-teeshirt.png" width="200" />\n<!-- End Cue -->\n\nHere's another nurse. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: medical-worker-charlie]\n[Description: ]\n[MediaURL: ../assets/video/medical-worker-charlie.mp4]\n[Duration: 00:00:36:22]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nHere's Lisa Damato, a former contestant on America's Next Top Model:\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: lisa-damato-charlie]\n[Description: ]\n[MediaURL: ../assets/video/lisa-damato-charlie.mp4]\n[Duration: 00:00:21:26]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nCharlie knew what was coming to America. Here's what he tweeted on April 7. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-E16387628722]\n[Slug: assassination-culture]\n[Description: ]\n[MediaURL: ../assets/graphics/assassination-culture.png]\n<img src="../assets/graphics/assassination-culture.png" width="200" />\n<!-- End Cue -->\n\nLet's check in with the borderline personality set. All of these appear to have comorbid pyschopathy. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: nose-ring-girl-charlie]\n[Description: ]\n[MediaURL: ../assets/video/nose-ring-girl-charlie.mp4]\n[Duration: 00:01:07:15]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nHere's more. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: charlie-in-the-neck]\n[Description: ]\n[MediaURL: ../assets/video/charlie-in-the-neck.mp4]\n[Duration: 00:00:30:09]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nHere's a TikTok compilation. See if you can identify any patterns about these people:\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: tiktok-celebration]\n[Description: ]\n[MediaURL: ../assets/video/tiktok-celebration.mp4]\n[Duration: 00:00:38:02]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nHere's a commenter named Amanda Seales. She would like you to know that she just chillin' and having her snacks about it. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: amanda-seales-charlie]\n[Description: ]\n[MediaURL: ../assets/video/amanda-seales-charlie.mp4]\n[Duration: 00:02:41:05]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nHere's a delightful and sweet girl:\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-79A4B334B1CB]\n[Slug: the-best-part-a]\n[Description: ]\n[MediaURL: ../assets/video/the-best-part-a.mp4]\n[Duration: 00:00:17:18]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->	\N
29	ASTMFMGRRX6OW4SYP	6	\N	segment	Block B - Iryna Zarutska	iryna-zarutska	100	00:18:00	None	# Block B - Iryna Zarutska\n\nThe murder of Iryna Zarutska was going to be the lead story on this episode until the assassination of Charlie Kirk. It's all part of the same horror. \n\nWe're lucky we even know that this poor girl was murdered. It happened on August 22, and it was only because somebody got ahold of the CCTV camera footage on the train that we know about it. The media sure wasn't going to go there willingly. \n\nWhy? Because an American black man with at least 14 arrests knifed a beautiful young blonde European white girl, and we don't have sympathy for beautiful young, European white people. \n\nWe only have sympathy for criminal psychopath blacks. That's the United STates of Fucking America in 2025. The blacks want the whites dead, and at least half the whites want themselves or other whites dead too. It's the sickest sexual perversion I've ever seen, and that's exactly what it is. Psychosexual masochism. White liberals, you're shot through with it. You're disgusting and dangerous. \n\nOn August 22, 2025, a 24-year-old woman named Iryna Zarutska clocked out of a job at a pizza parlor and rode the train home from work. She was an actual refugee from Ukraine who had only arrived in the US recently to escape the war. She's dead now. \n\nHere she is in a picture with her father from her obituary:\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-60042039024A]\n[Slug: iryna-zarutska]\n[Description: ]\n[MediaURL: ../assets/graphics/iryna-zarutska.png]\n<img src="../assets/graphics/iryna-zarutska.png" width="200" />\n<!-- End Cue -->\n\nThis is your warning to turn away. We're going to play the entire murder, and her death, on video. That's starting right now. \n\nI want you to listen to what her killer, DeCarlos Brown says as he walked away. \n\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-AD401C8015AA]\n[Slug: iryna-murder]\n[Description: ]\n[MediaURL: ../assets/video/iryna-murder.mp4]\n[Duration: 00:00:48:17]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\n-Did you hear it? \n\n-Got that white girl. Got that white girl. \n\n-You see Iryna realize that she has been fatally wounded. She puts her head and cries because she's knows she's dying. And she's dying alone with no one to hold her. \n\nThis is when she realized. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-60042039024A]\n[Slug: iryna-scared]\n[Description: ]\n[MediaURL: ../assets/graphics/iryna-scared.png]\n<img src="../assets/graphics/iryna-scared.png" width="200" />\n<!-- End Cue -->\n\nIt's not about race, says everyone on the left. Don't say it's about race. It can't be about race. Even though proportionally far more black people kill white people than white people kill black people. Uh uh, the fact that most murders are race on same race does not change that. Even accounting for that, black people kill whites at a far higher rate proportion to their population than whites kill blacks. \n\nBy at least an order of magnitude. \n\nCNN political personality Van Jones had this to say:\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-AD401C8015AA]\n[Slug: van-jones]\n[Description: ]\n[MediaURL: ../assets/video/van-jones.mp4]\n[Duration: 00:00:12:14]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\n-The way this man was hurting. \n\n-Hurt people hurt people. \n\n-Did Iryna hurt DeCarlos?\n\n-Got that white girl. Go that white girl. \n\nVan Jones you are a motherfucker. \n\nHere's what the organization Black Lives Matter posted on social media on learning about this race based murder. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-AD401C8015AA]\n[Slug: blm-iryna-murder]\n[Description: ]\n[MediaURL: ../assets/video/blm-iryna-murder.mp4]\n[Duration: 00:00:14:25]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nI don't know who this guy is, but he's one of hundreds, probably thousands posting sentiments just like this. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-AD401C8015AA]\n[Slug: liberation-in-blood]\n[Description: ]\n[MediaURL: ../assets/video/liberation-in-blood.mp4]\n[Duration: 00:00:25:11]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nWho is the murderer DeCarlos Brown? Just another black brotha who been done wrong and need second chance. \n\nFourteen second chances. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-60042039024A]\n[Slug: breaking-it-has-been]\n[Description: ]\n[MediaURL: ../assets/graphics/breaking-it-has-been.png]\n<img src="../assets/graphics/breaking-it-has-been.png" width="200" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-60042039024A]\n[Slug: decarlos-arrest]\n[Description: ]\n[MediaURL: ../assets/graphics/decarlos-arrest.png]\n<img src="../assets/graphics/decarlos-arrest.png" width="200" />\n<!-- End Cue -->\n\nWho kept releasing him? The latest was magistrate judge Teresa Stokes:\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-60042039024A]\n[Slug: teresa-stokes]\n[Description: ]\n[MediaURL: ../assets/graphics/teresa-stokes.png]\n<img src="../assets/graphics/teresa-stokes.png" width="200" />\n<!-- End Cue -->\n\nFrom Newsweek:\n\nhttps://www.newsweek.com/teresa-stokes-charlotte-judge-decarlos-brown-jr-2126808\n\n\n\n\n{FS Quote/records show that}\n"Records show that Brown has been arrested 14 times in over a decade and was diagnosed with schizophrenia.He has previously been convicted of felony larceny, robbery with a dangerous weapon and communicating threats, leading to a six-year prison sentence in 2015 for incidents dating to 2013 and 2014. He was released in 2020; then, months later, he was charged with assaulting his sister."  \n—Newsweek\n\n{FS Quote/  \nStokes is a magistrate judge for the Charlotte District in Mecklenburg County Court, North Carolina. She has also been linked to a charity that provides mental health and addiction support by social media users, though Newsweek was unable to verify these claims."  \n—Newsweek\n\n-I've seen several claims that judge Teresa Stokes is not even an attorney and never passed the bar exam. I can't confirm or deny this, but it wouldn't surprise me. And if North Carolina or any other state allows the appointment of non lawyers like this then we can expect more of this. \n\nAs fellow Vermont podcaster Styxenhammer said:\n\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-60042039024A]\n[Slug: styxhenhammer]\n[Description: ]\n[MediaURL: ../assets/graphics/styxhenhammer.png]\n<img src="../assets/graphics/styxhenhammer.png" width="200" />\n<!-- End Cue -->	\N	None	None	None	None	\N	None	\N	production	2025-09-16 11:22:50.781401+00	2025-10-03 18:04:27.411864+00	f	# Block B - Iryna Zarutska\n\nThe murder of Iryna Zarutska was going to be the lead story on this episode until the assassination of Charlie Kirk. It's all part of the same horror. \n\nWe're lucky we even know that this poor girl was murdered. It happened on August 22, and it was only because somebody got ahold of the CCTV camera footage on the train that we know about it. The media sure wasn't going to go there willingly. \n\nWhy? Because an American black man with at least 14 arrests knifed a beautiful young blonde European white girl, and we don't have sympathy for beautiful young, European white people. \n\nWe only have sympathy for criminal psychopath blacks. That's the United STates of Fucking America in 2025. The blacks want the whites dead, and at least half the whites want themselves or other whites dead too. It's the sickest sexual perversion I've ever seen, and that's exactly what it is. Psychosexual masochism. White liberals, you're shot through with it. You're disgusting and dangerous. \n\nOn August 22, 2025, a 24-year-old woman named Iryna Zarutska clocked out of a job at a pizza parlor and rode the train home from work. She was an actual refugee from Ukraine who had only arrived in the US recently to escape the war. She's dead now. \n\nHere she is in a picture with her father from her obituary:\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-60042039024A]\n[Slug: iryna-zarutska]\n[Description: ]\n[MediaURL: ../assets/graphics/iryna-zarutska.png]\n<img src="../assets/graphics/iryna-zarutska.png" width="200" />\n<!-- End Cue -->\n\nThis is your warning to turn away. We're going to play the entire murder, and her death, on video. That's starting right now. \n\nI want you to listen to what her killer, DeCarlos Brown says as he walked away. \n\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-AD401C8015AA]\n[Slug: iryna-murder]\n[Description: ]\n[MediaURL: ../assets/video/iryna-murder.mp4]\n[Duration: 00:00:48:17]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\n-Did you hear it? \n\n-Got that white girl. Got that white girl. \n\n-You see Iryna realize that she has been fatally wounded. She puts her head and cries because she's knows she's dying. And she's dying alone with no one to hold her. \n\nThis is when she realized. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-60042039024A]\n[Slug: iryna-scared]\n[Description: ]\n[MediaURL: ../assets/graphics/iryna-scared.png]\n<img src="../assets/graphics/iryna-scared.png" width="200" />\n<!-- End Cue -->\n\nIt's not about race, says everyone on the left. Don't say it's about race. It can't be about race. Even though proportionally far more black people kill white people than white people kill black people. Uh uh, the fact that most murders are race on same race does not change that. Even accounting for that, black people kill whites at a far higher rate proportion to their population than whites kill blacks. \n\nBy at least an order of magnitude. \n\nCNN political personality Van Jones had this to say:\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-AD401C8015AA]\n[Slug: van-jones]\n[Description: ]\n[MediaURL: ../assets/video/van-jones.mp4]\n[Duration: 00:00:12:14]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\n-The way this man was hurting. \n\n-Hurt people hurt people. \n\n-Did Iryna hurt DeCarlos?\n\n-Got that white girl. Go that white girl. \n\nVan Jones you are a motherfucker. \n\nHere's what the organization Black Lives Matter posted on social media on learning about this race based murder. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-AD401C8015AA]\n[Slug: blm-iryna-murder]\n[Description: ]\n[MediaURL: ../assets/video/blm-iryna-murder.mp4]\n[Duration: 00:00:14:25]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nI don't know who this guy is, but he's one of hundreds, probably thousands posting sentiments just like this. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: PROD-SOT-AD401C8015AA]\n[Slug: liberation-in-blood]\n[Description: ]\n[MediaURL: ../assets/video/liberation-in-blood.mp4]\n[Duration: 00:00:25:11]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nWho is the murderer DeCarlos Brown? Just another black brotha who been done wrong and need second chance. \n\nFourteen second chances. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-60042039024A]\n[Slug: breaking-it-has-been]\n[Description: ]\n[MediaURL: ../assets/graphics/breaking-it-has-been.png]\n<img src="../assets/graphics/breaking-it-has-been.png" width="200" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-60042039024A]\n[Slug: decarlos-arrest]\n[Description: ]\n[MediaURL: ../assets/graphics/decarlos-arrest.png]\n<img src="../assets/graphics/decarlos-arrest.png" width="200" />\n<!-- End Cue -->\n\nWho kept releasing him? The latest was magistrate judge Teresa Stokes:\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-60042039024A]\n[Slug: teresa-stokes]\n[Description: ]\n[MediaURL: ../assets/graphics/teresa-stokes.png]\n<img src="../assets/graphics/teresa-stokes.png" width="200" />\n<!-- End Cue -->\n\nFrom Newsweek:\n\nhttps://www.newsweek.com/teresa-stokes-charlotte-judge-decarlos-brown-jr-2126808\n\n\n\n\n{FS Quote/records show that}\n"Records show that Brown has been arrested 14 times in over a decade and was diagnosed with schizophrenia.He has previously been convicted of felony larceny, robbery with a dangerous weapon and communicating threats, leading to a six-year prison sentence in 2015 for incidents dating to 2013 and 2014. He was released in 2020; then, months later, he was charged with assaulting his sister."  \n—Newsweek\n\n{FS Quote/  \nStokes is a magistrate judge for the Charlotte District in Mecklenburg County Court, North Carolina. She has also been linked to a charity that provides mental health and addiction support by social media users, though Newsweek was unable to verify these claims."  \n—Newsweek\n\n-I've seen several claims that judge Teresa Stokes is not even an attorney and never passed the bar exam. I can't confirm or deny this, but it wouldn't surprise me. And if North Carolina or any other state allows the appointment of non lawyers like this then we can expect more of this. \n\nAs fellow Vermont podcaster Styxenhammer said:\n\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-60042039024A]\n[Slug: styxhenhammer]\n[Description: ]\n[MediaURL: ../assets/graphics/styxhenhammer.png]\n<img src="../assets/graphics/styxhenhammer.png" width="200" />\n<!-- End Cue -->	\N
9	SEGMF28JSPA3LJ9HU	3	\N	segment	Test Segment	test-segment	60	00:00:00		## Notes\n\n## Description\n\n## Script	\N				2025-09-02T07:37:18.094364: Generated server AssetID SEGMF28JSPA3LJ9HU via rundown item creation	\N		\N	draft	2025-09-16 11:15:55.189103+00	2025-09-16 11:40:41.270744+00	f	## Notes\n\n## Description\n\n## Script	\N
6	SEGMF28K7VQEMC4OW	3	\N	segment	Middle Segment	middle-segment	40	00:00:00		## Notes\n\n## Description\n\n## Script	\N				2025-09-02T07:37:37.766587: Generated server AssetID SEGMF28K7VQEMC4OW via rundown item creation	\N		\N	draft	2025-09-16 11:15:55.173805+00	2025-09-16 11:40:41.270744+00	f	## Notes\n\n## Description\n\n## Script	\N
197	SEGMG6GEK3DQ9R9O2	18	\N	segment	Test Segment	test-segment	0	00:00:00:00			\N		\N		\N	\N		\N	draft	2025-09-30 11:07:57.625646+00	2025-10-18 18:57:49.114961+00	f	<p class="josh"></p>	\N
130	ASTMFT51TF3GVSA2G	18	\N	tease	Untitled	cancel culture tease	0	00:00:00:00			\N		\N		\N	\N		\N	draft	2025-09-21 03:44:11.202212+00	2025-10-18 18:57:49.961532+00	f	Come back on the other side to indulge in some schadenfreude as we watch modern day\n<p class="josh"></p>	\N
133	ASTMFT5139ND2XSZF	18	\N	break	Break	break	0	00:00:00:00			\N		\N		\N	\N		\N	production	2025-09-21 03:44:11.204486+00	2025-10-18 18:58:07.026062+00	f	---\nid: 'ASTMFT5139ND2XSZF'\nslug: "break"\ntype: break\norder: 80\nduration: "00:00:00:00"\nstatus: production\ntitle: "Break"\n---\n<p class="josh"></p>	\N
131	ASTMFT4Z3IX239XGC	18	\N	break	Break	break	50	00:00:00:00			\N		\N		\N	\N		\N	production	2025-09-21 03:44:11.202775+00	2025-09-21 03:58:11.851067+00	f		\N
132	ASTMFT51VJ4LRT1AC	18	\N	tease	Untitled	family insane tease	70	00:00:00:00			\N		\N		\N	\N		\N	production	2025-09-21 03:44:11.203949+00	2025-09-21 03:58:11.85211+00	f	Come back after the break to talk about what I'm hearing from my coaching and consulting clients on this topic. Many of them are afraid of, or should be afraid, of the people who live in the same house they do. Also, we'll have little bit of fun to close the show out. Don't you need a laugh? I do.	\N
20	ASTMFJRXLJJFR9CD6	6	\N	break	Break	break	50	00:00:00		## Notes\n\n## Description\n\n## Script\n\n<!-- Begin Cue -->\n[Type: BREAK]\n[Slug: break]\n[AssetID: ASTMFJRXLJJFR9CD6]\n<!-- End Cue -->	\N				2025-09-14T14:11:59.695948: Generated server AssetID ASTMFJRXLJJFR9CD6 via rundown item creation	\N		\N	production	2025-09-16 11:22:50.755516+00	2025-10-03 18:04:40.735487+00	f	## Notes\n\n## Description\n\n## Script\n\n<!-- Begin Cue -->\n[Type: BREAK]\n[Slug: break]\n[AssetID: ASTMFJRXLJJFR9CD6]\n<!-- End Cue -->	\N
221	ASTMFJZF6Z67H8XAD	6	\N	segment	071 Tease	intro tease	0	00:03:21:00			\N		\N		\N	\N		\N	production	2025-10-03 18:04:40.456377+00	2025-10-16 02:38:37.247954+00	f	<p class="josh">This i a test.  this is the interpretation of all of the old markdown files.</p>\n\n<p class="josh">Tonight's show is heavy and graphic. We are not censoring video footage of murders; You're going to see Charlie Kirk murdered, and you're going to see Iryna Zarutska murdered.</p>\n\n<p class="josh">They did not "pass," as too many conservative millennials like to say. They were brutally murdered and blood gushed out of them so fast that they had only seconds of consciousness left. America needs to see the truth of what's happening. I want you to know what you're going to see if you stay with us.</p>\n\n<p class="josh">This episode is one I don't want to make but that we have to make. The murders of Ukrainian refugee Iryna Zarutska by a black man who boasted about getting the white girl, and the murder of a truly godly man named Charlie Kirk by a lunatic leftist with a transgender "partner" do constitute an actual turning point.</p>\n\n<p class="josh">It wasn't these brutal murders that demonstrate that turning point. It was the reaction of the left, the media, and much of the public that made this a turning point. The demonic gloating, the joy, the erotic frisson, the grave dancing in public–all of these are more sick-making than the murders themselves because they make the soul despair. We need to face this Satanic ugliness straight on and we're going to do it tonight.</p>\n\n<p class="josh">Many Americans realized this week for the first time who their friends, families, and coworkers really are. They should have realized it during the alleged pandemic. They should have realized it when their wives and husbands celebrated the assassination attempts on President Trump last year.</p>\n\n<p class="josh">But they didn't. They continued their denial until this week. Now they know, now maybe you know, that their own families would happily see them dead.</p>\n\n<p class="josh">Welcome to being a Democrat and a liberal in 2025. Yes. A liberal. No, I won't stop saying liberal. I won't qualify it. I won't say "leftist, not liberal.</p>\n\n<p class="josh">No, audience. No. This is liberalism. Pre-emptively: shut up if you're getting twisted about it. Shut up. Direct your anger at the devils around you, not at me. They're the ones who will see you dead. Not me.</p>\n\n<p class="josh">You go out and rebuild your reputation and rebuild the respectability aroudn the word liberal. It's not my job and you had better not try to make it my job.</p>\n\n<p class="josh">And yeah, we are going to talk about the shooter's parents. That includes his mother. We are going to identify patterns, speculate, and raise serious questions. That conversation is going to happen.</p>\n\n<p class="josh">I'm sick in my soul this week. This episode is harder than any I've done yet.</p>\n\n<p class="josh">I'm Joshua Slocum and this is Disaffected.  The show that ....</p>\n\n<p class="josh">When we come back after the break, its going to be dark.  Its going to be graphic.  Tonight, I'm not going to spare you.</p>\n\n<p class="josh">This has been your warning.</p>	\N
262	SEGMGMG13VKT7MHEU	26	\N	coldopen	Cold Open	show-cold-open	1	00:00:00:00			\N		\N		\N	\N		\N	draft	2025-10-11 15:41:48.89606+00	2025-10-18 18:57:41.274967+00	f	AssetID: SEGMGMG13VKT7MHEU\ntitle: Cold Open\ntype: coldopen\nslug: show-cold-open\nduration: "00:00:00:00"\nstatus: draft\norder: 1\ncreated_at: "2025-10-11T15:41:48.896060+00:00"\nupdated_at: "2025-10-15T05:58:19.339629+00:00"\n---\n\n<p class="josh"></p>"\n---\n\n<p class="josh"></p>	\N
33	ASTMFMGUNJ9DWHECM	9	\N	break	25 Break	25-break	25	00:05:00	None	<!-- Begin Cue -->\n[Type: Break]\n[AssetID: BREAK25001]\n[Slug: break]\n<!-- End Cue -->	\N	None	None	None	None	\N	None	\N	production	2025-09-16 11:25:05.066923+00	2025-09-16 11:40:41.244694+00	f	<!-- Begin Cue -->\n[Type: Break]\n[AssetID: BREAK25001]\n[Slug: break]\n<!-- End Cue -->	\N
38	SEGMEEJ56401DC7UN	9	\N	segment	Borderlines in the Wild	borderline wild	50	02:31	None	## Notes\n\n## Description\n\n## Script\n\nYou're about to see the most Karen borderline meltdown of them all. It happened in Portland, naturally. And let's go out of order so we make sure this woman is publicly identified. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJHWMROXL1L8]\n[Slug: pdx-real]\n[Description: ]\n[MediaURL: ../assets/graphics/pdx-real.png]\n<img src="../assets/graphics/pdx-real.png" width="200" />\n<!-- End Cue -->\n\nClassic borderline. "Clicks. That's all I am to you." Why won't you see me as a damsel in distress? \n\nWanna see the video?\n\n-This is borderline psychosis\n\n-She would have been in an asylum in any other era. \n\nHere's one from downtown Denver. This shit is happening in the real world. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: CUEMEEJHZTQUO2VE3]\n[Slug: karen-denver]\n[Description: ]\n[MediaURL: ../assets/video/karen-denver.mp4]\n[Duration: 00:01:39:23]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\n-She diagnoses Trump "Pedophilic Disorder" from the Diagnostic and Statistical Manual. You do understand that these women are psycho-sexually disturbed? That their triggered state at masculinity, and their allegations of rape and pedophilia, are a form of their own sexual fantasies? It's true.	2025-08-17 00:00:00	None	None	None	None	\N	None	\N	production	2025-09-16 11:25:05.073322+00	2025-09-16 11:40:41.244694+00	f	## Notes\n\n## Description\n\n## Script\n\nYou're about to see the most Karen borderline meltdown of them all. It happened in Portland, naturally. And let's go out of order so we make sure this woman is publicly identified. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJHWMROXL1L8]\n[Slug: pdx-real]\n[Description: ]\n[MediaURL: ../assets/graphics/pdx-real.png]\n<img src="../assets/graphics/pdx-real.png" width="200" />\n<!-- End Cue -->\n\nClassic borderline. "Clicks. That's all I am to you." Why won't you see me as a damsel in distress? \n\nWanna see the video?\n\n-This is borderline psychosis\n\n-She would have been in an asylum in any other era. \n\nHere's one from downtown Denver. This shit is happening in the real world. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: CUEMEEJHZTQUO2VE3]\n[Slug: karen-denver]\n[Description: ]\n[MediaURL: ../assets/video/karen-denver.mp4]\n[Duration: 00:01:39:23]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\n-She diagnoses Trump "Pedophilic Disorder" from the Diagnostic and Statistical Manual. You do understand that these women are psycho-sexually disturbed? That their triggered state at masculinity, and their allegations of rape and pedophilia, are a form of their own sexual fantasies? It's true.	\N
31	SEGMEEJ3TNWZ5IUEO	9	\N	segment	News Roundup and Updates	10-news-roundup-and-updates	10	06:27	None	## Notes\n\n## Description\n\n## Script\n\nWelcome to Disaffected. It's August 17, 2025 and this is the show where we talk about politics, culture, and relationships through a psychological lens. I'm Joshua Slocum. \n\nThe big focus tonight will be on the return of men and masculinity, and how feminists, women, and gays don't have to like it. We're going to look at the astonishing, but predictable, social media pile-on  that happened to none other than BillBoard Chris. Chris Elston\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEQS4B424DL1B]\n[Slug: chris-elston]\n[Description: ]\n[MediaURL: ../assets/graphics/chris-elston.png]\n<img src="../assets/graphics/chris-elston.png" width="200" />\n<!-- End Cue -->\n\nis someone you know as a Canadian father who travels the world to stop child gender mutilation. No single person man or woman has done as much or put his own safety on the line to stop this butchery than Chris. He's been assaulted countless times, and has had his arm broken by violent gender lunatics for wearing a sandwich board in public that decries the child abuse  we call "gender affirming care."\n\nAll hell broke loose online when he commented on the sissification of cheerleading in American football. Chris had the temerity to say that putting twinky gay men on cheerleading teams for NFL was, well, kind of faggy and off-putting. Suddenly, hundreds, maybe thousands of people--mainly women, but quite a few men--turned on him. They called him one of the reasons that children feel the need to transition. His homophobic, bigoted hate, they say, is why mommies are taking their little boys to get their peepees cut off. \n\nIt's a disgusting spectacle, and it's Cluster B to the core. And, it's not just some online fight on Twitter. It's the exposed edge of a conversation that has been waiting to happen for years, and we're going to have it tonight. The Western world has been so thoroughly feminized that women, gays, and suckered men move heaven and earth to teach boys to shake pom poms and live their best fabulous lives, and go apeshit berserk when men and fathers say, "Boys need to learn to be manly."\n\nWe're going to pick that scab right off and letting the bleeding begin. As the very kind of fey, artistiic sissy boy myself that these mother hens think they're protecting, you may be surprised to learn that I'm 100 percent on team Man Up, and foursquare behind men and fathers reasserting what it means to be a man. \n\nBut first, we have some updates on topics we've covered on the show in recent weeks. \n\nYou recall the video last week showing a black African on the London Underground train. He was standing there with his pants down showing his cock and balls off to everyone on the train. A couple of normal white English guys told him to cover it up or get off the train. \n\nNaturally, he chimped out and started screaming FUCK YOU FUCK YOU. Meanwhile, the normal men were saying, 'There's fookin kids about, mate." Those men took care of business. They beat some sense into him, and then they bodily through him off the train. As it should be. As a cop should have done. As no one would ever have had to do before our governments in the West deliberately brought in third world savages to destroy white Western culture. \n\nWell,  you know what's happened now, don't you? Don't you? \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJFS6N0Y6BVP]\n[Slug: vigilante-tube]\n[Description: ]\n[MediaURL: ../assets/graphics/vigilante-tube.png]\n<img src="../assets/graphics/vigilante-tube.png" width="800" />\n<!-- End Cue -->\n\nOriginally from The Independent:\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEF22TNG6F7ZS8]\n[Slug: a-group-of]\n[Description: ]\n[MediaURL: ../assets/graphics/a-group-of.png]\n<img src="../assets/graphics/a-group-of.png" width="800" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEF23DJ45GABLZ]\n[Slug: a-group-of-part]\n[Description: ]\n[MediaURL: ../assets/graphics/a-group-of-part.png]\n<img src="../assets/graphics/a-group-of-part.png" width="800" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEF23VI6WIQ8SW]\n[Slug: an-off-duty]\n[Description: ]\n[MediaURL: ../assets/graphics/an-off-duty.png]\n<img src="../assets/graphics/an-off-duty.png" width="800" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEF24QS9R6YDTF]\n[Slug: spokesperson]\n[Description: ]\n[MediaURL: ../assets/graphics/spokesperson.png]\n<img src="../assets/graphics/spokesperson.png" width="800" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEF2AE2W19MGZT]\n[Slug: the-clip]\n[Description: ]\n[MediaURL: ../assets/graphics/the-clip.png]\n<img src="../assets/graphics/the-clip.png" width="200" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: ADLIB]\n[AssetID: LOCAL-ADLIB-20250816-213201]\n[Slug: Josh talk]\n[Duration: 000100]\n<!-- End Cue -->\n\nAnd you remember how we told you about Holly, the middle-aged mom beaten almost to death by a black mob in Cincinnati at a music festival. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJG43IE9XE52]\n[Slug: holly-pictures]\n[Description: ]\n[MediaURL: ../assets/graphics/holly-pictures.png]\n<img src="../assets/graphics/holly-pictures.png" width="200" />\n<!-- End Cue -->\n\nThere are, naturally, more calls from Cincinnati's finest black leadership to. . . . prosecute the other victim.  A white man. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: CUEMEEJG6CVN16KFJ]\n[Slug: cincy-black-leaders]\n[Description: ]\n[MediaURL: ../assets/video/cincy-black-leaders.mp4]\n[Duration: 00:00:27:05]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nAs Walter remarked on Twitter:\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJG9AV3QQNDK]\n[Slug: walter-tweet]\n[Description: ]\n[MediaURL: ../assets/graphics/walter-tweet.png]\n<img src="../assets/graphics/walter-tweet.png" width="200" />\n<!-- End Cue -->\n\n-Riff a bit on waking up to the truth about race. \n\n-We're going to talk the truth about sexuality and sex roles, or "gender" if you will in the next block. \n\nEND OF BLOCK A	2025-08-17 00:00:00	None	None	None	None	\N	None	\N	production	2025-09-16 11:25:05.057383+00	2025-09-16 11:40:41.244694+00	f	## Notes\n\n## Description\n\n## Script\n\nWelcome to Disaffected. It's August 17, 2025 and this is the show where we talk about politics, culture, and relationships through a psychological lens. I'm Joshua Slocum. \n\nThe big focus tonight will be on the return of men and masculinity, and how feminists, women, and gays don't have to like it. We're going to look at the astonishing, but predictable, social media pile-on  that happened to none other than BillBoard Chris. Chris Elston\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEQS4B424DL1B]\n[Slug: chris-elston]\n[Description: ]\n[MediaURL: ../assets/graphics/chris-elston.png]\n<img src="../assets/graphics/chris-elston.png" width="200" />\n<!-- End Cue -->\n\nis someone you know as a Canadian father who travels the world to stop child gender mutilation. No single person man or woman has done as much or put his own safety on the line to stop this butchery than Chris. He's been assaulted countless times, and has had his arm broken by violent gender lunatics for wearing a sandwich board in public that decries the child abuse  we call "gender affirming care."\n\nAll hell broke loose online when he commented on the sissification of cheerleading in American football. Chris had the temerity to say that putting twinky gay men on cheerleading teams for NFL was, well, kind of faggy and off-putting. Suddenly, hundreds, maybe thousands of people--mainly women, but quite a few men--turned on him. They called him one of the reasons that children feel the need to transition. His homophobic, bigoted hate, they say, is why mommies are taking their little boys to get their peepees cut off. \n\nIt's a disgusting spectacle, and it's Cluster B to the core. And, it's not just some online fight on Twitter. It's the exposed edge of a conversation that has been waiting to happen for years, and we're going to have it tonight. The Western world has been so thoroughly feminized that women, gays, and suckered men move heaven and earth to teach boys to shake pom poms and live their best fabulous lives, and go apeshit berserk when men and fathers say, "Boys need to learn to be manly."\n\nWe're going to pick that scab right off and letting the bleeding begin. As the very kind of fey, artistiic sissy boy myself that these mother hens think they're protecting, you may be surprised to learn that I'm 100 percent on team Man Up, and foursquare behind men and fathers reasserting what it means to be a man. \n\nBut first, we have some updates on topics we've covered on the show in recent weeks. \n\nYou recall the video last week showing a black African on the London Underground train. He was standing there with his pants down showing his cock and balls off to everyone on the train. A couple of normal white English guys told him to cover it up or get off the train. \n\nNaturally, he chimped out and started screaming FUCK YOU FUCK YOU. Meanwhile, the normal men were saying, 'There's fookin kids about, mate." Those men took care of business. They beat some sense into him, and then they bodily through him off the train. As it should be. As a cop should have done. As no one would ever have had to do before our governments in the West deliberately brought in third world savages to destroy white Western culture. \n\nWell,  you know what's happened now, don't you? Don't you? \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJFS6N0Y6BVP]\n[Slug: vigilante-tube]\n[Description: ]\n[MediaURL: ../assets/graphics/vigilante-tube.png]\n<img src="../assets/graphics/vigilante-tube.png" width="800" />\n<!-- End Cue -->\n\nOriginally from The Independent:\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEF22TNG6F7ZS8]\n[Slug: a-group-of]\n[Description: ]\n[MediaURL: ../assets/graphics/a-group-of.png]\n<img src="../assets/graphics/a-group-of.png" width="800" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEF23DJ45GABLZ]\n[Slug: a-group-of-part]\n[Description: ]\n[MediaURL: ../assets/graphics/a-group-of-part.png]\n<img src="../assets/graphics/a-group-of-part.png" width="800" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEF23VI6WIQ8SW]\n[Slug: an-off-duty]\n[Description: ]\n[MediaURL: ../assets/graphics/an-off-duty.png]\n<img src="../assets/graphics/an-off-duty.png" width="800" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEF24QS9R6YDTF]\n[Slug: spokesperson]\n[Description: ]\n[MediaURL: ../assets/graphics/spokesperson.png]\n<img src="../assets/graphics/spokesperson.png" width="800" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEF2AE2W19MGZT]\n[Slug: the-clip]\n[Description: ]\n[MediaURL: ../assets/graphics/the-clip.png]\n<img src="../assets/graphics/the-clip.png" width="200" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: ADLIB]\n[AssetID: LOCAL-ADLIB-20250816-213201]\n[Slug: Josh talk]\n[Duration: 000100]\n<!-- End Cue -->\n\nAnd you remember how we told you about Holly, the middle-aged mom beaten almost to death by a black mob in Cincinnati at a music festival. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJG43IE9XE52]\n[Slug: holly-pictures]\n[Description: ]\n[MediaURL: ../assets/graphics/holly-pictures.png]\n<img src="../assets/graphics/holly-pictures.png" width="200" />\n<!-- End Cue -->\n\nThere are, naturally, more calls from Cincinnati's finest black leadership to. . . . prosecute the other victim.  A white man. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: CUEMEEJG6CVN16KFJ]\n[Slug: cincy-black-leaders]\n[Description: ]\n[MediaURL: ../assets/video/cincy-black-leaders.mp4]\n[Duration: 00:00:27:05]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nAs Walter remarked on Twitter:\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJG9AV3QQNDK]\n[Slug: walter-tweet]\n[Description: ]\n[MediaURL: ../assets/graphics/walter-tweet.png]\n<img src="../assets/graphics/walter-tweet.png" width="200" />\n<!-- End Cue -->\n\n-Riff a bit on waking up to the truth about race. \n\n-We're going to talk the truth about sexuality and sex roles, or "gender" if you will in the next block. \n\nEND OF BLOCK A	\N
34	SEGMEEJ44L61P9LZV	9	\N	segment	Man Up	Man Up	30	1081	None	## Notes\n\n## Description\n\n## Script\n\nSociety is finally starting to wake up to the trans delusion. The Trump administration is going after hospitals that maim children with what they call "gender affirming care." More than half the states have outlawed it. The Supreme Court upheld a Tennessee law banning it as an act of child abuse. \n\nFinally, we're able to say out loud that poisoning children with hormones isn't healthful. We're now allowed to say that it's evil and insane to cut the breasts off little girls and the scrotums off little boys. We're finally able to say it's ludicrous to let fetishistic men in dresses go into the women's bathroom or play on girls' sports teams. \n\nBut there's something we're still not allowed to say. The Gender Criticals won't allow it. The Terfs won't allow it. Because feminism won't allow it. And feminism doesn't  just include those women who explicitly identify this way. It includes almost all of society, because almost everyone has imbibed feminism at a core level. That's why we can have women claiming to live in a patriarchy when it's transparently obvious that we're living in a feminized gynocracy. \n\nDo you know what we're still not allowed to say? That masculinity is good. That boys can be and should be masculine. That's not allowed. That's "homophobic" because it says something not nice about effeminate boys. That's bigoted, because it says there's a "right way to be a boy or a girl." And that can only be bigoted. \n\nGirls can do anything. They can be President. An astronaut. A girl boss.Meanwhile, boys are drugged for ADHD because feminized school systems want them to sit quietly. Men are terrified to approach young women for fear of being called "creepy." Male suicide is many times higher than for women, and white men are a lot of that. But that doesn't matter because it's men, and men are bad, and if they're lonely, maybe they should like, go therapy. Maybe they should be more like women? And then when I find I'm not turned on by sissy men I'll tell them they don't live up to my standards? \n\nBut even hint that boys and young men should develop manly qualities and the feminists and your next door neighbors start shrieking. And then they turn on good men and start abusing him. Calling him the evil one who's making little boys feel like they have to transition. Because the demand for boys to be masculine is so overwhelmingly dominant that boys are falling off the ladder left and right? \n\nNo, it isn't. And hasn't been my entire life and I'm 50. The only things encouraged in boys are feminine things. Stop being angry. Be more empathetic. Talk about your feelings more, until that gives your girl the ick, then don't do that anymore. Do more chores around the house, but also be my knight in shining armor and bring home more money from your outside job. \n\nMen have been mocked, derided, and called toxic at the cultural level  for most of my life. And it's become clear how much feminists, and many women, really do dislike or outright hate boys and masculinity. \n\nThat became clear in the reaction online to Chris Elston. You know him as Billboard Chris, the guy who travels the world where a sandwich board sign to protest the medical transing of children. He's a married father, and he's put his life on the line, and been beaten up mulitple times to do this. \n\nWell, now the very TERFs that liked him are accusing him of being a force for evil. Of spreading attitudes that make young boys want to become girls. That's right, they're pulling an abusive, Cluster B reversal and it's sick-making. \n\nAnd it's all over this. The Minnesota Vikings Football team has two new male cheerleaders the squad. Their names simply must be Lance and Bryden. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJGLF9OYQXZC]\n[Slug: male-cheerleaders]\n[Description: ]\n[MediaURL: ../assets/graphics/male-cheerleaders.png]\n<img src="../assets/graphics/male-cheerleaders.png" width="200" />\n<!-- End Cue -->\n\n. In this video, he's bouncing around in what can only be described as girlish moves. Stay with me, don't get emotional, you don't know where I'm going yet. Just take a look. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: CUEMEEJGNHIAMNDQO]\n[Slug: dance-like-girl]\n[Description: ]\n[MediaURL: ../assets/video/dance-like-girl.mp4]\n[Duration: 00:00:21:13]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nBiologist Colin Wright put up a Twitter poll:\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJGPMGOLLC0T]\n[Slug: colin-wright-poll]\n[Description: ]\n[MediaURL: ../assets/graphics/colin-wright-poll.png]\n<img src="../assets/graphics/colin-wright-poll.png" width="200" />\n<!-- End Cue -->\n\n-A tendentiously put question full of buried assumptions. The biggest one is that OK to be means "everyone must approve and those who don't approve are bigots and their lack of approval means we're not letting boys be cheerleaders." I don't think Colin and the majority of people taking his position is even dimly aware of the smuggled assumptions they operate under. And they object mightilty when that' spointed out. \n\nHere's what Billboard Chris had to say:\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJGRSTM36X2K]\n[Slug: billboard-chris-tweet]\n[Description: ]\n[MediaURL: ../assets/graphics/billboard-chris-tweet.png]\n<img src="../assets/graphics/billboard-chris-tweet.png" width="200" />\n<!-- End Cue -->\n\n-All holy hell broke loose. Hundreds of people swarmed. Some of them are people I'm friendly with on Twitter. They accused him of bigotry, of being a gender essentialist, of "not letting boys express themselves," and being one of the major reasons why boys feel they need to transition. That's right. These people turned on Chris Elston and said HE is the reason why young boys want to get their dicks chopped off. It's revolting. \n\nYou know why? Because it's not allowed to tell boys to be masculine. That is "coded" as the kids say, as "homophobic abuse," and outmoded thinking. Meanwhile, no one, no man is allowed to say "boys need to man up." The very state of masculinity is itself considered poison. Why do you think women have been feminizing boys and men for decades in the school system? I want you to really see how normal male masculinity, and no other trait, is seen as so evil and obviously so, that people don't even hear themselves. \n\nThey suddenly don't see the Munchy moms, the personality disordered bitches who medicalize their own sons. Nope. That's not the reason boys transition cough Jazz Jennings, it's men like Chris. It's men like many others online who are football fans and who don't want to ogle a mincing faggot sticking his ass up in the air on the cheer team during gay time. Women and leftie men shocked and appalled! Haters! Troglodytes. \n\nDo you see how disfavored being  a man is? Do you see how much normal, normative boyhood and manhood is called unacceptable? Are you beginning to understand, just a little tiny bit, what my alleged "issue with women" is? \n\nLet's take a tour of the online responses. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJGUC9SV6YC8]\n[Slug: john-connor-tweet]\n[Description: ]\n[MediaURL: ../assets/graphics/john-connor-tweet.png]\n<img src="../assets/graphics/john-connor-tweet.png" width="200" />\n<!-- End Cue -->\n\nGay conservative Brad Polumbo whines. Notice throughout these the smuggled assumption. Liking or advocating for masculinity in boys is bigotry. Advocating for feminity is fine. Notice this double standard throughtout. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJGWBU9O8PJZ]\n[Slug: brad-polumbo]\n[Description: ]\n[MediaURL: ../assets/graphics/brad-polumbo.png]\n<img src="../assets/graphics/brad-polumbo.png" width="200" />\n<!-- End Cue -->\n\nDetransitioner Prisha Mosley, who proceeded to totally borderline out on me as well and accuse me of "harassing women":\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJGZ5BR5TNAN]\n[Slug: prisha-mosley]\n[Description: ]\n[MediaURL: ../assets/graphics/prisha-mosley.png]\n<img src="../assets/graphics/prisha-mosley.png" width="200" />\n<!-- End Cue -->\n\nNotice in this one the other: "Let them be feminine men." It's screamed, demanded. The implication is that these poor boys are prevented from being who they are because other men say they don't like their affect. Or their theatricality. The lie is that Chris saying anything is an act against these poor boys who have NO ability to be feminine without the left protecting them. Meanwhile in the real world there is ONLY space for feminized men. It's all a reversal. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJH18K27GCUJ]\n[Slug: what-youre-saying]\n[Description: ]\n[MediaURL: ../assets/graphics/what-youre-saying.png]\n<img src="../assets/graphics/what-youre-saying.png" width="200" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJH39UTHDQPZ]\n[Slug: when-you-start]\n[Description: ]\n[MediaURL: ../assets/graphics/when-you-start.png]\n<img src="../assets/graphics/when-you-start.png" width="200" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJH5L5EJ0QLB]\n[Slug: i-couldnt-disagree]\n[Description: ]\n[MediaURL: ../assets/graphics/i-couldnt-disagree.png]\n<img src="../assets/graphics/i-couldnt-disagree.png" width="200" />\n<!-- End Cue -->\n\nIt goes on and on. Notice what they're saying. They are denying that sex roles exist. What they call gender roles are just old fashioned sex roles. The gender criticals, the gays, the feminists, they really do think we can abolish sex role expectations. It's lunatic. No society on earth made up of humans does not have sex roles. What do you think "gender critical meant." Did you forget to take it at its word? They mean it. They think they can, and should, get rid of any expecations or associations of behavior with sex. All of them. \n\nIt will never happen, but this is why the left is insane. And not just the left. When it comes to seeing masculinity as suspect, the right is just as bad. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJH851KUTI9Z]\n[Slug: this-way-of-thinking]\n[Description: ]\n[MediaURL: ../assets/graphics/this-way-of-thinking.png]\n<img src="../assets/graphics/this-way-of-thinking.png" width="200" />\n<!-- End Cue -->\n\nDawn here is typical. She's pretending to be obtuse. "What does it mean to dance like a girl." Dawn you're lying. You're not asking a question. You're making a statement: You're a bad bigoted patriarch for noticing that there are feminine and masculine behaviors." \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJHAGOJO5MHZ]\n[Slug: why-not]\n[Description: ]\n[MediaURL: ../assets/graphics/why-not.png]\n<img src="../assets/graphics/why-not.png" width="200" />\n<!-- End Cue -->\n\n"Don't ruin your fight with this" "Lol" Shame on you. Shame on you awful people for throwing Chris' good work out, more than you've done, because you hate men. And you hate boys. And you hate everything that is natural to them. Meanwhile you crave us. You crave our masculinity. You desire it sexually. Women--sort your borderline selves out. \n\nHere's another feminist bitch with the typical female monitoring of Not a good look. Pretty weird. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJHCIJ9X84QX]\n[Slug: i-kept-seeing]\n[Description: ]\n[MediaURL: ../assets/graphics/i-kept-seeing.png]\n<img src="../assets/graphics/i-kept-seeing.png" width="200" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJHEY901HMCU]\n[Slug: when-you-were]\n[Description: ]\n[MediaURL: ../assets/graphics/when-you-were.png]\n<img src="../assets/graphics/when-you-were.png" width="200" />\n<!-- End Cue -->\n\nIt goes on like this endlessly. I'm sorry to say I saw some show viewers playing this nasty game too. \n\nI jumped in to defend Chris, and, naturally, was called the same sort of bigoted but also mentally ill male oppressor. I won't bore you with it, but it included the usual accusations of internalized homophobia, misogyny, and becoming the very thing I hated. I'm a monster, like all men, really. \n\nHatred of men, boys, and masculinity bubbles along underneath everything in this culture and I'm past the point of bearing it. One man, one father, advocates for manly and masculine behavior in boys. \n\nFury erupts. Decent people, some of whom are my Twitter "friends" go apeshit. They scold him. They accuse him of causing children to trans. They throw ever dirty feminist, manipulative trick at him. \n\nThen some of them turn it on me. \n\nAll of this because *a man dared to express that he doesn't approve of sissy behavior in boys*. He might even actually care that this kind of feminization does those boys no favors. \n\nBut no. That can't be spoken. All these women and feminists and homos get to shout all goddamned day long for decades about how we have to "make space" for your stupid antics, but one man says "no, masculinity," and you lose your shit. \n\nThere has been nothing but space--all of it, everywhere, all the time--for feminized boys. Gay boys and sissies are a goddamned protected class in this country. Regular boys? Masculine boys? Straight boys? Gay boys who don't mince? There is zero space for them culturally. And it's your fault, mothers, feminists, and absent, gelded fathers.\n\nThis topic exercises me; it’s pretty much a new frontier in the change of public discourse: that masculinity is almost universally “recognized” as a state of sin, a state of innate hostility and danger. Almost everyone believes this, even when they say and believe that they don’t believe it.\n\nThey do. The _merest_ mention of the ideas “boys ought not dance like girls on the Minnesota Vikings cheerleading squad” is met with shock and abuse. Accusations of “misogyny,” of “homophobia,” of “attitudes like yours are why these kids think they need to trans.” Men are not allowed, ever, under any circumstances, to ever object to sissying up boys. Why, that’s abusive. We have to make _even more space for sissy boys, encourage more sissiness and faggotry, because that means we reaaa-weeeee wuv them.”  \n  \n*Meanwhile society has space for no men who aren’t sissies. And this isn’t about gay or straight—none of us men who talk like men and insist on _being* men, however we may fail in the ways we do—we all get called toxic. Misogynist. Why trans kids happened.  \n  \nUngrateful. Abusive\n\nIt is loathsome, and it’s common. I’m seeing people online I like and respect and my eyes are goggling. \n\nAs a boy, I had no father. Mine left my mother before I was born.\n\nAt three years old, she hooked up with my stepfather, then married him. He was a violent abuser. He concussed me, beat me, beat my mother, and molested his own daughter, my sister.\n\nAgainst this backdrop was my abusive mother, the woman with borderline and narcissistic personality disorders. She vacillated between mocking and humiliating me for "being soft; no girl will ever want you, and you're going to turn out like every other piece of shit man like your father" and treating me like a golden prince, "You're so handsome all the girls will go for you."\n\nI didn't know if I was coming or going.\n\nHaving no father, I never learned to fight. I didn't learn how to defend myself. I didn't even learn how to walk like a man, talk like a man, or take responsibility for myself like a man.\n\nInstead, I learned to cry. To panic. To dissolve in tears of frustration, and then to scream to get my way. I learned to be a feminine borderline, like my mother.\n\nEvery normal, masculine man or boy I met I feared. I believed men were born innately evil and abusive (think how that affects a boy child's view of himself). When I did get pushed around or picked on for being a homo, I was terrified. And I exaggerated the bullying to a hysterical degree.\n\nBut most normal boys rejected me because, well, normal people can smell the freak on you (you may call it ‘trauma’ if that’s more palatable) and they could smell it on me. I had almost no friends until middle school when I suddenly “became funny” and found some popularity or acceptance for the first time in my life.\n\nI became a histrionic. An entertainer. I had a power no one else did. I couldn’t throw a football, but I could cast a spell on a room. Hey, it does me pretty well today to keep people entertained. But it’s definitively an adaptive behavior as a response to abuse. I would have been better off at least learning to throw the football, too.\n\nIf I'd known how to hold my own and throw the punches back, I would have been even better off.\n\nUntil my 40s, I thought I wasn't part of the male sex, not really. All straight men hated sissies like me, I thought, and would kill me if they could. It's deranged, but this is the mindset of so many guys like me.\n\nWhat I needed was a male role model. I needed to learn to be a man. That didn't need to mean I'd turn into a football jock. Society has always had a place for bookish, intellectual men--and that's a path I could have taken respectably. It didn't have to mean being a feminized, histrionic mess.\n\nBut I didn't have that. Millions of boys don't.\n\nAnd I removed myself from the society of men, not realizing that I was part of them. That most of them didn't hate me. That they, and I, all being men, could be friends and share men's business.\n\nAs gay rights became "the thing," society hug-boxed me. Women especially. I "leaned in" to being a victim, into seeking out maternal love and approval from women friends, into performing "gay best friend" for them.\n\nI turned into a stereoptypical pocket pansy.\n\nI’m not a “gay man” anymore. Not in any way that’s fundamental to who I am. Not in the way you inevitably hear when a guy describes himself that way. I am a man, and I am also a homosexual. Yeah, I’m shaped by my past and I’m definitely “gay” in that way. I like to put on camp humor. I’m a 20th century gay, and it’s fun. But I’m not a sissy, not anymore. And there is no dignity in sissyhood. That’s why it’s a popular BDSM fetish for God’s sake.\n\nDo you want this for your sons? For your neighbors' sons? For the boys you claim to care about?\n\nHave you ever thought about this?\n\nDon’t mistake me please; I’m not asking for your sympathy. I’m not wallowing in victimhood, or presenting myself to you as a victim. I’m trying to tell you a truth that pertains to many more gay men than me personally. I hope you’ll want to understand that point of view.\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJHIMKMC68FC]\n[Slug: if-it-was]\n[Description: ]\n[MediaURL: ../assets/graphics/if-it-was.png]\n<img src="../assets/graphics/if-it-was.png" width="200" />\n<!-- End Cue -->	2025-08-17 00:00:00	None	None	None	None	\N	None	\N	production	2025-09-16 11:25:05.066923+00	2025-09-16 11:40:41.244694+00	f	## Notes\n\n## Description\n\n## Script\n\nSociety is finally starting to wake up to the trans delusion. The Trump administration is going after hospitals that maim children with what they call "gender affirming care." More than half the states have outlawed it. The Supreme Court upheld a Tennessee law banning it as an act of child abuse. \n\nFinally, we're able to say out loud that poisoning children with hormones isn't healthful. We're now allowed to say that it's evil and insane to cut the breasts off little girls and the scrotums off little boys. We're finally able to say it's ludicrous to let fetishistic men in dresses go into the women's bathroom or play on girls' sports teams. \n\nBut there's something we're still not allowed to say. The Gender Criticals won't allow it. The Terfs won't allow it. Because feminism won't allow it. And feminism doesn't  just include those women who explicitly identify this way. It includes almost all of society, because almost everyone has imbibed feminism at a core level. That's why we can have women claiming to live in a patriarchy when it's transparently obvious that we're living in a feminized gynocracy. \n\nDo you know what we're still not allowed to say? That masculinity is good. That boys can be and should be masculine. That's not allowed. That's "homophobic" because it says something not nice about effeminate boys. That's bigoted, because it says there's a "right way to be a boy or a girl." And that can only be bigoted. \n\nGirls can do anything. They can be President. An astronaut. A girl boss.Meanwhile, boys are drugged for ADHD because feminized school systems want them to sit quietly. Men are terrified to approach young women for fear of being called "creepy." Male suicide is many times higher than for women, and white men are a lot of that. But that doesn't matter because it's men, and men are bad, and if they're lonely, maybe they should like, go therapy. Maybe they should be more like women? And then when I find I'm not turned on by sissy men I'll tell them they don't live up to my standards? \n\nBut even hint that boys and young men should develop manly qualities and the feminists and your next door neighbors start shrieking. And then they turn on good men and start abusing him. Calling him the evil one who's making little boys feel like they have to transition. Because the demand for boys to be masculine is so overwhelmingly dominant that boys are falling off the ladder left and right? \n\nNo, it isn't. And hasn't been my entire life and I'm 50. The only things encouraged in boys are feminine things. Stop being angry. Be more empathetic. Talk about your feelings more, until that gives your girl the ick, then don't do that anymore. Do more chores around the house, but also be my knight in shining armor and bring home more money from your outside job. \n\nMen have been mocked, derided, and called toxic at the cultural level  for most of my life. And it's become clear how much feminists, and many women, really do dislike or outright hate boys and masculinity. \n\nThat became clear in the reaction online to Chris Elston. You know him as Billboard Chris, the guy who travels the world where a sandwich board sign to protest the medical transing of children. He's a married father, and he's put his life on the line, and been beaten up mulitple times to do this. \n\nWell, now the very TERFs that liked him are accusing him of being a force for evil. Of spreading attitudes that make young boys want to become girls. That's right, they're pulling an abusive, Cluster B reversal and it's sick-making. \n\nAnd it's all over this. The Minnesota Vikings Football team has two new male cheerleaders the squad. Their names simply must be Lance and Bryden. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJGLF9OYQXZC]\n[Slug: male-cheerleaders]\n[Description: ]\n[MediaURL: ../assets/graphics/male-cheerleaders.png]\n<img src="../assets/graphics/male-cheerleaders.png" width="200" />\n<!-- End Cue -->\n\n. In this video, he's bouncing around in what can only be described as girlish moves. Stay with me, don't get emotional, you don't know where I'm going yet. Just take a look. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: CUEMEEJGNHIAMNDQO]\n[Slug: dance-like-girl]\n[Description: ]\n[MediaURL: ../assets/video/dance-like-girl.mp4]\n[Duration: 00:00:21:13]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nBiologist Colin Wright put up a Twitter poll:\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJGPMGOLLC0T]\n[Slug: colin-wright-poll]\n[Description: ]\n[MediaURL: ../assets/graphics/colin-wright-poll.png]\n<img src="../assets/graphics/colin-wright-poll.png" width="200" />\n<!-- End Cue -->\n\n-A tendentiously put question full of buried assumptions. The biggest one is that OK to be means "everyone must approve and those who don't approve are bigots and their lack of approval means we're not letting boys be cheerleaders." I don't think Colin and the majority of people taking his position is even dimly aware of the smuggled assumptions they operate under. And they object mightilty when that' spointed out. \n\nHere's what Billboard Chris had to say:\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJGRSTM36X2K]\n[Slug: billboard-chris-tweet]\n[Description: ]\n[MediaURL: ../assets/graphics/billboard-chris-tweet.png]\n<img src="../assets/graphics/billboard-chris-tweet.png" width="200" />\n<!-- End Cue -->\n\n-All holy hell broke loose. Hundreds of people swarmed. Some of them are people I'm friendly with on Twitter. They accused him of bigotry, of being a gender essentialist, of "not letting boys express themselves," and being one of the major reasons why boys feel they need to transition. That's right. These people turned on Chris Elston and said HE is the reason why young boys want to get their dicks chopped off. It's revolting. \n\nYou know why? Because it's not allowed to tell boys to be masculine. That is "coded" as the kids say, as "homophobic abuse," and outmoded thinking. Meanwhile, no one, no man is allowed to say "boys need to man up." The very state of masculinity is itself considered poison. Why do you think women have been feminizing boys and men for decades in the school system? I want you to really see how normal male masculinity, and no other trait, is seen as so evil and obviously so, that people don't even hear themselves. \n\nThey suddenly don't see the Munchy moms, the personality disordered bitches who medicalize their own sons. Nope. That's not the reason boys transition cough Jazz Jennings, it's men like Chris. It's men like many others online who are football fans and who don't want to ogle a mincing faggot sticking his ass up in the air on the cheer team during gay time. Women and leftie men shocked and appalled! Haters! Troglodytes. \n\nDo you see how disfavored being  a man is? Do you see how much normal, normative boyhood and manhood is called unacceptable? Are you beginning to understand, just a little tiny bit, what my alleged "issue with women" is? \n\nLet's take a tour of the online responses. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJGUC9SV6YC8]\n[Slug: john-connor-tweet]\n[Description: ]\n[MediaURL: ../assets/graphics/john-connor-tweet.png]\n<img src="../assets/graphics/john-connor-tweet.png" width="200" />\n<!-- End Cue -->\n\nGay conservative Brad Polumbo whines. Notice throughout these the smuggled assumption. Liking or advocating for masculinity in boys is bigotry. Advocating for feminity is fine. Notice this double standard throughtout. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJGWBU9O8PJZ]\n[Slug: brad-polumbo]\n[Description: ]\n[MediaURL: ../assets/graphics/brad-polumbo.png]\n<img src="../assets/graphics/brad-polumbo.png" width="200" />\n<!-- End Cue -->\n\nDetransitioner Prisha Mosley, who proceeded to totally borderline out on me as well and accuse me of "harassing women":\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJGZ5BR5TNAN]\n[Slug: prisha-mosley]\n[Description: ]\n[MediaURL: ../assets/graphics/prisha-mosley.png]\n<img src="../assets/graphics/prisha-mosley.png" width="200" />\n<!-- End Cue -->\n\nNotice in this one the other: "Let them be feminine men." It's screamed, demanded. The implication is that these poor boys are prevented from being who they are because other men say they don't like their affect. Or their theatricality. The lie is that Chris saying anything is an act against these poor boys who have NO ability to be feminine without the left protecting them. Meanwhile in the real world there is ONLY space for feminized men. It's all a reversal. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJH18K27GCUJ]\n[Slug: what-youre-saying]\n[Description: ]\n[MediaURL: ../assets/graphics/what-youre-saying.png]\n<img src="../assets/graphics/what-youre-saying.png" width="200" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJH39UTHDQPZ]\n[Slug: when-you-start]\n[Description: ]\n[MediaURL: ../assets/graphics/when-you-start.png]\n<img src="../assets/graphics/when-you-start.png" width="200" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJH5L5EJ0QLB]\n[Slug: i-couldnt-disagree]\n[Description: ]\n[MediaURL: ../assets/graphics/i-couldnt-disagree.png]\n<img src="../assets/graphics/i-couldnt-disagree.png" width="200" />\n<!-- End Cue -->\n\nIt goes on and on. Notice what they're saying. They are denying that sex roles exist. What they call gender roles are just old fashioned sex roles. The gender criticals, the gays, the feminists, they really do think we can abolish sex role expectations. It's lunatic. No society on earth made up of humans does not have sex roles. What do you think "gender critical meant." Did you forget to take it at its word? They mean it. They think they can, and should, get rid of any expecations or associations of behavior with sex. All of them. \n\nIt will never happen, but this is why the left is insane. And not just the left. When it comes to seeing masculinity as suspect, the right is just as bad. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJH851KUTI9Z]\n[Slug: this-way-of-thinking]\n[Description: ]\n[MediaURL: ../assets/graphics/this-way-of-thinking.png]\n<img src="../assets/graphics/this-way-of-thinking.png" width="200" />\n<!-- End Cue -->\n\nDawn here is typical. She's pretending to be obtuse. "What does it mean to dance like a girl." Dawn you're lying. You're not asking a question. You're making a statement: You're a bad bigoted patriarch for noticing that there are feminine and masculine behaviors." \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJHAGOJO5MHZ]\n[Slug: why-not]\n[Description: ]\n[MediaURL: ../assets/graphics/why-not.png]\n<img src="../assets/graphics/why-not.png" width="200" />\n<!-- End Cue -->\n\n"Don't ruin your fight with this" "Lol" Shame on you. Shame on you awful people for throwing Chris' good work out, more than you've done, because you hate men. And you hate boys. And you hate everything that is natural to them. Meanwhile you crave us. You crave our masculinity. You desire it sexually. Women--sort your borderline selves out. \n\nHere's another feminist bitch with the typical female monitoring of Not a good look. Pretty weird. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJHCIJ9X84QX]\n[Slug: i-kept-seeing]\n[Description: ]\n[MediaURL: ../assets/graphics/i-kept-seeing.png]\n<img src="../assets/graphics/i-kept-seeing.png" width="200" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJHEY901HMCU]\n[Slug: when-you-were]\n[Description: ]\n[MediaURL: ../assets/graphics/when-you-were.png]\n<img src="../assets/graphics/when-you-were.png" width="200" />\n<!-- End Cue -->\n\nIt goes on like this endlessly. I'm sorry to say I saw some show viewers playing this nasty game too. \n\nI jumped in to defend Chris, and, naturally, was called the same sort of bigoted but also mentally ill male oppressor. I won't bore you with it, but it included the usual accusations of internalized homophobia, misogyny, and becoming the very thing I hated. I'm a monster, like all men, really. \n\nHatred of men, boys, and masculinity bubbles along underneath everything in this culture and I'm past the point of bearing it. One man, one father, advocates for manly and masculine behavior in boys. \n\nFury erupts. Decent people, some of whom are my Twitter "friends" go apeshit. They scold him. They accuse him of causing children to trans. They throw ever dirty feminist, manipulative trick at him. \n\nThen some of them turn it on me. \n\nAll of this because *a man dared to express that he doesn't approve of sissy behavior in boys*. He might even actually care that this kind of feminization does those boys no favors. \n\nBut no. That can't be spoken. All these women and feminists and homos get to shout all goddamned day long for decades about how we have to "make space" for your stupid antics, but one man says "no, masculinity," and you lose your shit. \n\nThere has been nothing but space--all of it, everywhere, all the time--for feminized boys. Gay boys and sissies are a goddamned protected class in this country. Regular boys? Masculine boys? Straight boys? Gay boys who don't mince? There is zero space for them culturally. And it's your fault, mothers, feminists, and absent, gelded fathers.\n\nThis topic exercises me; it’s pretty much a new frontier in the change of public discourse: that masculinity is almost universally “recognized” as a state of sin, a state of innate hostility and danger. Almost everyone believes this, even when they say and believe that they don’t believe it.\n\nThey do. The _merest_ mention of the ideas “boys ought not dance like girls on the Minnesota Vikings cheerleading squad” is met with shock and abuse. Accusations of “misogyny,” of “homophobia,” of “attitudes like yours are why these kids think they need to trans.” Men are not allowed, ever, under any circumstances, to ever object to sissying up boys. Why, that’s abusive. We have to make _even more space for sissy boys, encourage more sissiness and faggotry, because that means we reaaa-weeeee wuv them.”  \n  \n*Meanwhile society has space for no men who aren’t sissies. And this isn’t about gay or straight—none of us men who talk like men and insist on _being* men, however we may fail in the ways we do—we all get called toxic. Misogynist. Why trans kids happened.  \n  \nUngrateful. Abusive\n\nIt is loathsome, and it’s common. I’m seeing people online I like and respect and my eyes are goggling. \n\nAs a boy, I had no father. Mine left my mother before I was born.\n\nAt three years old, she hooked up with my stepfather, then married him. He was a violent abuser. He concussed me, beat me, beat my mother, and molested his own daughter, my sister.\n\nAgainst this backdrop was my abusive mother, the woman with borderline and narcissistic personality disorders. She vacillated between mocking and humiliating me for "being soft; no girl will ever want you, and you're going to turn out like every other piece of shit man like your father" and treating me like a golden prince, "You're so handsome all the girls will go for you."\n\nI didn't know if I was coming or going.\n\nHaving no father, I never learned to fight. I didn't learn how to defend myself. I didn't even learn how to walk like a man, talk like a man, or take responsibility for myself like a man.\n\nInstead, I learned to cry. To panic. To dissolve in tears of frustration, and then to scream to get my way. I learned to be a feminine borderline, like my mother.\n\nEvery normal, masculine man or boy I met I feared. I believed men were born innately evil and abusive (think how that affects a boy child's view of himself). When I did get pushed around or picked on for being a homo, I was terrified. And I exaggerated the bullying to a hysterical degree.\n\nBut most normal boys rejected me because, well, normal people can smell the freak on you (you may call it ‘trauma’ if that’s more palatable) and they could smell it on me. I had almost no friends until middle school when I suddenly “became funny” and found some popularity or acceptance for the first time in my life.\n\nI became a histrionic. An entertainer. I had a power no one else did. I couldn’t throw a football, but I could cast a spell on a room. Hey, it does me pretty well today to keep people entertained. But it’s definitively an adaptive behavior as a response to abuse. I would have been better off at least learning to throw the football, too.\n\nIf I'd known how to hold my own and throw the punches back, I would have been even better off.\n\nUntil my 40s, I thought I wasn't part of the male sex, not really. All straight men hated sissies like me, I thought, and would kill me if they could. It's deranged, but this is the mindset of so many guys like me.\n\nWhat I needed was a male role model. I needed to learn to be a man. That didn't need to mean I'd turn into a football jock. Society has always had a place for bookish, intellectual men--and that's a path I could have taken respectably. It didn't have to mean being a feminized, histrionic mess.\n\nBut I didn't have that. Millions of boys don't.\n\nAnd I removed myself from the society of men, not realizing that I was part of them. That most of them didn't hate me. That they, and I, all being men, could be friends and share men's business.\n\nAs gay rights became "the thing," society hug-boxed me. Women especially. I "leaned in" to being a victim, into seeking out maternal love and approval from women friends, into performing "gay best friend" for them.\n\nI turned into a stereoptypical pocket pansy.\n\nI’m not a “gay man” anymore. Not in any way that’s fundamental to who I am. Not in the way you inevitably hear when a guy describes himself that way. I am a man, and I am also a homosexual. Yeah, I’m shaped by my past and I’m definitely “gay” in that way. I like to put on camp humor. I’m a 20th century gay, and it’s fun. But I’m not a sissy, not anymore. And there is no dignity in sissyhood. That’s why it’s a popular BDSM fetish for God’s sake.\n\nDo you want this for your sons? For your neighbors' sons? For the boys you claim to care about?\n\nHave you ever thought about this?\n\nDon’t mistake me please; I’m not asking for your sympathy. I’m not wallowing in victimhood, or presenting myself to you as a victim. I’m trying to tell you a truth that pertains to many more gay men than me personally. I hope you’ll want to understand that point of view.\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJHIMKMC68FC]\n[Slug: if-it-was]\n[Description: ]\n[MediaURL: ../assets/graphics/if-it-was.png]\n<img src="../assets/graphics/if-it-was.png" width="200" />\n<!-- End Cue -->	\N
35	SEGMEEOBAPUJXSG4D	9	\N	advertisement	Disaffected.com One-time Dono	40-support-disaffected.com	40	00:01:00	None	<!-- Begin Cue -->\n[Type: ADLIB]\n[AssetID: CUEMEENDH3XSJ7GMN]\n[Slug: Support Disaffected.com]\n[Duration: 00:01:00 ]\n<!-- End Cue -->\n\n[^1]:	\N	None	None	None	None	\N	medium	\N	production	2025-09-16 11:25:05.066923+00	2025-09-16 11:40:41.244694+00	f	<!-- Begin Cue -->\n[Type: ADLIB]\n[AssetID: CUEMEENDH3XSJ7GMN]\n[Slug: Support Disaffected.com]\n[Duration: 00:01:00 ]\n<!-- End Cue -->\n\n[^1]:	\N
198	SEGMG6GH8ZH3E23PK	18	\N	segment	Test Segment 2	test-segment-2	45	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	draft	2025-09-30 11:10:03.197741+00	2025-09-30 11:10:03.197741+00	f	\N	\N
265	SEGMGMG20FY8HNVGG	26	\N	tease	Top Stories Tonight	Top Stories Tonight	20	00:00:00:00			\N		\N		\N	\N		\N	draft	2025-10-11 20:04:19.116356+00	2025-10-18 18:57:41.272876+00	f	<p class="josh"></p>	\N
223	SEGMGB5XLLKWVML4O	4	\N	interview	Interview	interview	70	00:00:00:00			\N		\N		\N	\N		\N	draft	2025-10-03 18:13:41.144477+00	2025-10-03 18:18:37.217175+00	f	---\nid: 'SEGMGB5XLLKWVML4O'\nslug: "interview"\ntype: interview\norder: 70\nindex: 70\nduration: "00:00:00:00"\nstatus: draft\ntitle: "Interview"\n---\n<p class="josh"></p>	\N
23	ASTMFJSG4BT913KEO	6	\N	break	Break	break	70	00:00:00		## Notes\n\n## Description\n\n## Script\n\n<!-- Begin Cue -->\n[Type: BREAK]\n[Slug: break]\n[AssetID: ASTMFJSG4BT913KEO]\n<!-- End Cue -->	\N				2025-09-14T14:26:23.849066: Generated server AssetID ASTMFJSG4BT913KEO via rundown item creation	\N		\N	production	2025-09-16 11:22:50.764656+00	2025-10-03 18:04:27.409259+00	f	## Notes\n\n## Description\n\n## Script\n\n<!-- Begin Cue -->\n[Type: BREAK]\n[Slug: break]\n[AssetID: ASTMFJSG4BT913KEO]\n<!-- End Cue -->	\N
22	ASTMFJSIFMFRY2KJB	6	\N	segment	041 Tease	050-tease-041-tease	30	00:00:00		## Notes\n\n## Description\n\n## Script\n\nWhen we come back we're going to go even further through the looking glass.\n\nWe're going to take an uncomfortably close look at the relationship between the assassin - and his mother.  \n\nPut you predictions on a postcard.. \n\nwe'll be right back.	\N				2025-09-14T14:28:11.799145: Generated server AssetID ASTMFJSIFMFRY2KJB via rundown item creation	\N		\N	production	2025-09-16 11:22:50.764656+00	2025-10-03 18:04:40.73385+00	f	## Notes\n\n## Description\n\n## Script\n\nWhen we come back we're going to go even further through the looking glass.\n\nWe're going to take an uncomfortably close look at the relationship between the assassin - and his mother.  \n\nPut you predictions on a postcard.. \n\nwe'll be right back.	\N
39	SEGMEEJ5H1D9I4K1D	9	\N	segment	Potpourri Du Moquerie	60-potpourri-du-moquerie	60	00:12	None	## Notes\n\n## Description\n\n## Script\n\nRetards\n\nLet's go back to a public service announcement from 1980. Hey Gen Z---get your anxiety fidget toys. The olds are gonna say bad things? \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: CUEMEEPQ1XNB587ME]\n[Slug: retarded-neighbors]\n[Description: ]\n[MediaURL: ../assets/video/retarded-neighbors.mp4]\n[Duration: 00:00:20:17]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJJ87VW7XCBR]\n[Slug: cookie-dough]\n[Description: ]\n[MediaURL: ../assets/graphics/cookie-dough.png]\n<img src="../assets/graphics/cookie-dough.png" width="200" />\n<!-- End Cue -->\n\nThat's the show-goodnight!	2025-08-17 00:00:00	None	None	None	None	\N	None	\N	production	2025-09-16 11:25:05.073322+00	2025-09-16 11:40:41.244694+00	f	## Notes\n\n## Description\n\n## Script\n\nRetards\n\nLet's go back to a public service announcement from 1980. Hey Gen Z---get your anxiety fidget toys. The olds are gonna say bad things? \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: CUEMEEPQ1XNB587ME]\n[Slug: retarded-neighbors]\n[Description: ]\n[MediaURL: ../assets/video/retarded-neighbors.mp4]\n[Duration: 00:00:20:17]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: CUEMEEJJ87VW7XCBR]\n[Slug: cookie-dough]\n[Description: ]\n[MediaURL: ../assets/graphics/cookie-dough.png]\n<img src="../assets/graphics/cookie-dough.png" width="200" />\n<!-- End Cue -->\n\nThat's the show-goodnight!	\N
37	ASTMFMGUNJI53Q3M9	9	\N	break	45 Break	45-break	45	00:05:00	None	<!-- Begin Cue -->\n[Type: Break]\n[AssetID: BREAK45001]\n[Slug: break]\n<!-- End Cue -->	\N	None	None	None	None	\N	None	\N	production	2025-09-16 11:25:05.073322+00	2025-09-16 11:40:41.244694+00	f	<!-- Begin Cue -->\n[Type: Break]\n[AssetID: BREAK45001]\n[Slug: break]\n<!-- End Cue -->	\N
36	SEGMEENCPXQ375N35	9	\N	segment	Slocum Consulting	41-slocum-consulting	41	01:00	None	<!-- Begin Cue -->\n[Type: ADLIB]\n[AssetID: CUEMEEND27OHTCFXG]\n[Slug: Support Disaffected.com]\n[Duration: 00:01:00 ]\n<!-- End Cue -->	\N	None	None	None	None	\N	None	\N	production	2025-09-16 11:25:05.066923+00	2025-09-16 11:40:41.244694+00	f	<!-- Begin Cue -->\n[Type: ADLIB]\n[AssetID: CUEMEEND27OHTCFXG]\n[Slug: Support Disaffected.com]\n[Duration: 00:01:00 ]\n<!-- End Cue -->	\N
32	SEGMEEJ3YD0OKZM7D	9	\N	advertisement	20 Biltong	20-biltong	20	00:30	None	<!-- Begin Cue -->\n[Type: ADLIB]\n[AssetID: CUEMEENDM8FGBUPV8]\n[Slug: biltong adlib]\n[Duration: 00:00:30 ]\n<!-- End Cue -->	\N	None	None	None	None	\N	None	\N	production	2025-09-16 11:25:05.057383+00	2025-09-16 11:40:41.244694+00	f	<!-- Begin Cue -->\n[Type: ADLIB]\n[AssetID: CUEMEENDM8FGBUPV8]\n[Slug: biltong adlib]\n[Duration: 00:00:30 ]\n<!-- End Cue -->	\N
13	BRKM8N4L5R7TZV9D	4	\N	break	Support Break	support-promo	60	00:03:00	Support and consulting promos	## Notes\nMid-show break featuring support promos and advertisements.\n\n## Description\nBreak segment featuring Biltong promotion and Slocum Consulting advertisement.\n\n## Script\n**BILTONG WITHIN BLOCK TO TAKE US OUT TO BREAK**\n\n**BREAK**\n—Support Us\n—Slocum Consulting\n\n[Break content from original script lines 154-160]	2025-09-07 00:00:00		Biltong promo, Slocum Consulting promo	break, promo, support, consulting, biltong	Generated for episode 0239 segmentation	\N	medium	\N	draft	2025-09-16 11:15:55.200852+00	2025-10-03 18:18:37.216307+00	f	---\nid: 'SEGMF8N3K4Q6SYU8C'\nslug: "princess-and-pea"\ntype: segment\norder: 40\nindex: 40\nduration: "00:12:00"\nstatus: draft\ntitle: "The Princess and the Pea"\n---\n## Notes\nPsychological exploration of fairy tale themes and their relevance to childhood development and modern identity formation.\n\n## Description\nAnalysis of The Princess and the Pea fairy tale as a metaphor for sensitivity, authenticity, and childhood development patterns.\n\n## Script\n**Media Elements Referenced:**\n- {GFX/align} → align.png\n- {GFX/princess-pea-illustration} → princess pea illustration}.png\n\n**Script Content:**\nThe Princess and the Pea is a fascinating fairy tale that reveals deep psychological truths about sensitivity, authenticity, and the nature of true identity. The story tells us that a real princess can feel a single pea through twenty mattresses and twenty feather beds.\n\nThis hypersensitivity becomes the test of authenticity - only someone of true nobility could be so acutely aware of discomfort that others would never notice.\n\n[Full segment content from original script lines 94-153]\n<p class="josh"></p>	\N
266	SEGMGMPEQS59I0AT0	26	\N	segment	Segment	Jane Goodall Death	10	00:06:08:00			\N		\N		\N	\N		\N	draft	2025-10-11 20:04:21.653346+00	2025-10-18 18:57:41.270856+00	f	<p class="josh"></p>	\N
24	ASTMFMGRRWVUYHVKA	6	\N	segment	Mommy - Pattern Recognition	mommy	40	00:15:00	None	# Mommy - Pattern Recognition\n\nNow we have to talk about the part no one wants to talk about, and that will get me accused of hating women, jumping to conclusions, and being a hysterical misogynist. To those read to make those accusations, I'll pray that you see the light before it's too late for you and yours. You don't have to like this, and you don't have to like me. But I'm recognizing something real, my pattern spotting is very good, and I have lived this. You scorn me and you only hurt you and yours. Those of us who can see this, and who tell you, are not your enemies. We're not hateful. We're telling the truth as an act of love. \n\nA longtime show viewer and supporter rounded these up. She's a good woman, and she too grew up in a Cluster B household.\n\nAmber Jones Robinson is shooter suspect Tyler Robinson's mother. She's a social worker. You've heard that the family is intact and conservative. For many that means they think they know it was a good family. They've already decided that. And they're upset that people like me are going to probe a little deeper. Being upset about this is only hurting them and their. It's not making me stop saying it. I will never stop saying it. \n\nThis is speculation; that's all it can be. I do not claim to have first person insight into this family. But I don't need to. There are patterns here to recognize. They exist in the real world, it's not Josh Slocum imaginging them for personal reasons. \n\nAnd yes, it is not appropriate to ask these questions and point out these patterns, it is absolutely necessary. Oh I know. A lot of people want to stop at "it's SSRIs." They want to stop at "he was radicallized online." They want to stop at "it was the guns." \n\nNo. We're gonna look at the pattern. And the pattern appears be to a mother who comports herself just like a mother with borderline personality disorder. An emotionally enmeshed, performative, uncomfortably close to her sons mother. \n\nLet's take a look at years of Facebook postings by mother Amber Jones Robinson. Even if you hate that I'm doing this, try to let your eyes show you what you're able to see when your emotional disinclination isn't stopping you from seeing it. \n\nThe friend of the show who rounded these posts up gos by Nua Peasant:\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: tylers-mom-fb]\n[Description: ]\n[MediaURL: ../assets/graphics/tylers-mom-fb.png]\n<img src="../assets/graphics/tylers-mom-fb.png" width="200" />\n<!-- End Cue -->\n\nCan you handle this? Can you commit to trying it on without reacting against it reflexively? Let's try. \n\nHere's a post from 12 years ago when shooter suspect Tyler Robinson was just a boy. It's about how he's got all the computers he wants now so he doesn't have to interact with the family. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: almost-forgot-tyler]\n[Description: ]\n[MediaURL: ../assets/graphics/almost-forgot-tyler.png]\n<img src="../assets/graphics/almost-forgot-tyler.png" width="200" />\n<!-- End Cue -->\n\n"He was radicalized online!"\n\nOK. How did that happen? How was it faciliated? By whom?\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: posting-tylers-scores]\n[Description: ]\n[MediaURL: ../assets/graphics/posting-tylers-scores.png]\n<img src="../assets/graphics/posting-tylers-scores.png" width="200" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: man-child-of-mine]\n[Description: ]\n[MediaURL: ../assets/graphics/man-child-of-mine.png]\n<img src="../assets/graphics/man-child-of-mine.png" width="200" />\n<!-- End Cue -->\n\n-Date. Stay close to momma. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: two-posts-so-far]\n[Description: ]\n[MediaURL: ../assets/graphics/two-posts-so-far.png]\n<img src="../assets/graphics/two-posts-so-far.png" width="200" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: back-to-school-date]\n[Description: ]\n[MediaURL: ../assets/graphics/back-to-school-date.png]\n<img src="../assets/graphics/back-to-school-date.png" width="200" />\n<!-- End Cue -->\n\nSo she dates both her sons. And she jokes about murdering them. \n\nHere's another date, this time with Tyler:\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: again-this-is]\n[Description: ]\n[MediaURL: ../assets/graphics/again-this-is.png]\n<img src="../assets/graphics/again-this-is.png" width="200" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: back-to-school]\n[Description: ]\n[MediaURL: ../assets/graphics/back-to-school.png]\n<img src="../assets/graphics/back-to-school.png" width="200" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: you-may-think]\n[Description: ]\n[MediaURL: ../assets/graphics/you-may-think.png]\n<img src="../assets/graphics/you-may-think.png" width="200" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: since-austin-is]\n[Description: ]\n[MediaURL: ../assets/graphics/since-austin-is.png]\n<img src="../assets/graphics/since-austin-is.png" width="200" />\n<!-- End Cue -->\n\nAnother murder joke:\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: another-murder-joke]\n[Description: ]\n[MediaURL: ../assets/graphics/another-murder-joke.png]\n<img src="../assets/graphics/another-murder-joke.png" width="200" />\n<!-- End Cue -->\n\nMommy is so close to her little boys. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: grad-picture]\n[Description: ]\n[MediaURL: ../assets/graphics/grad-picture.png]\n<img src="../assets/graphics/grad-picture.png" width="200" />\n<!-- End Cue -->\n\n-I know. You've decided I've gone off the rails and i'm just making normal maternal love sound prurient. Are you sure? \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: LOCAL-GFX-20250914-164813]\n[Slug: tit-jut]\n[Description: ]\n[MediaURL: ../assets/graphics/tit-jut.png]\n<img src="../assets/graphics/tit-jut.png" width="200" />\n<!-- End Cue -->\n\nAmber's a hot mommy. I know you see this. \n\nI've talked about emotional incest between mothers and sons many times. I've told you about how my mother would coo at me for being so handsome, so brilliant, how all the girls were gonna want me. Do you know what else was going on that no one could see? Walking around naked when I was too old to see it? In adolescene, making "hilarious jokes" about how she refused to wear a bra in public, along with flapping her boob and laughing hysterically? Or how about swishing her skirt because she was having a hot flash, and making sure I knew she wasn't wearing panties. \n\nBut that's just my mom though. I'm crazy, and she's uniquely crazy, and I'm just projecting. Nothing to see here. What pattern?\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: happy-birthday-to]\n[Description: ]\n[MediaURL: ../assets/graphics/happy-birthday-to.png]\n<img src="../assets/graphics/happy-birthday-to.png" width="200" />\n<!-- End Cue -->\n\nAre you sure that there's nothing to see, here? In the car at age 45 to 50, with her son Tyler, wearing prostitute false eyelashes and making duck face? \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: amber-jones-duck-face]\n[Description: ]\n[MediaURL: ../assets/graphics/amber-jones-duck-face.png]\n<img src="../assets/graphics/amber-jones-duck-face.png" width="200" />\n<!-- End Cue -->\n\nHot mom. Cool mom. Babe mom. \n\nDo I know any of this for sure? Nope. But I'm seeing something, and I think I recognize it. And everyone else does, too. \n\nSound off in the comments. Tell me what you see and what you don't see. \n\nThis is the hardest show I've done yet, and it's not going to get easier in the second half, I'm afraid. \n\nBut that's enough about this topic for all of us, for today. All week I've had a Bible passage in my head. I now understand what it meant for the first time. People have asked how anyone could kill a man so good, so righteous, so kind, so loving, as Charlie. That's an ill-posed question. They killed because was good. \n\n"If the world hates you, keep in mind that it hated me first."\n\nJohn 15:18\n\nTHIS NEEDS THE CUT SCENE FROM THE EXORCIST ABOUT MAKING US DESPAIR\n\nSEE OURSELVES AS ANIMALS AND UGLY AND REJECT THE POSSIBILITY THAT GOD COULD LOVE US	\N	None	None	None	None	\N	None	\N	production	2025-09-16 11:22:50.771113+00	2025-10-03 18:04:40.734788+00	f	# Mommy - Pattern Recognition\n\nNow we have to talk about the part no one wants to talk about, and that will get me accused of hating women, jumping to conclusions, and being a hysterical misogynist. To those read to make those accusations, I'll pray that you see the light before it's too late for you and yours. You don't have to like this, and you don't have to like me. But I'm recognizing something real, my pattern spotting is very good, and I have lived this. You scorn me and you only hurt you and yours. Those of us who can see this, and who tell you, are not your enemies. We're not hateful. We're telling the truth as an act of love. \n\nA longtime show viewer and supporter rounded these up. She's a good woman, and she too grew up in a Cluster B household.\n\nAmber Jones Robinson is shooter suspect Tyler Robinson's mother. She's a social worker. You've heard that the family is intact and conservative. For many that means they think they know it was a good family. They've already decided that. And they're upset that people like me are going to probe a little deeper. Being upset about this is only hurting them and their. It's not making me stop saying it. I will never stop saying it. \n\nThis is speculation; that's all it can be. I do not claim to have first person insight into this family. But I don't need to. There are patterns here to recognize. They exist in the real world, it's not Josh Slocum imaginging them for personal reasons. \n\nAnd yes, it is not appropriate to ask these questions and point out these patterns, it is absolutely necessary. Oh I know. A lot of people want to stop at "it's SSRIs." They want to stop at "he was radicallized online." They want to stop at "it was the guns." \n\nNo. We're gonna look at the pattern. And the pattern appears be to a mother who comports herself just like a mother with borderline personality disorder. An emotionally enmeshed, performative, uncomfortably close to her sons mother. \n\nLet's take a look at years of Facebook postings by mother Amber Jones Robinson. Even if you hate that I'm doing this, try to let your eyes show you what you're able to see when your emotional disinclination isn't stopping you from seeing it. \n\nThe friend of the show who rounded these posts up gos by Nua Peasant:\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: tylers-mom-fb]\n[Description: ]\n[MediaURL: ../assets/graphics/tylers-mom-fb.png]\n<img src="../assets/graphics/tylers-mom-fb.png" width="200" />\n<!-- End Cue -->\n\nCan you handle this? Can you commit to trying it on without reacting against it reflexively? Let's try. \n\nHere's a post from 12 years ago when shooter suspect Tyler Robinson was just a boy. It's about how he's got all the computers he wants now so he doesn't have to interact with the family. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: almost-forgot-tyler]\n[Description: ]\n[MediaURL: ../assets/graphics/almost-forgot-tyler.png]\n<img src="../assets/graphics/almost-forgot-tyler.png" width="200" />\n<!-- End Cue -->\n\n"He was radicalized online!"\n\nOK. How did that happen? How was it faciliated? By whom?\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: posting-tylers-scores]\n[Description: ]\n[MediaURL: ../assets/graphics/posting-tylers-scores.png]\n<img src="../assets/graphics/posting-tylers-scores.png" width="200" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: man-child-of-mine]\n[Description: ]\n[MediaURL: ../assets/graphics/man-child-of-mine.png]\n<img src="../assets/graphics/man-child-of-mine.png" width="200" />\n<!-- End Cue -->\n\n-Date. Stay close to momma. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: two-posts-so-far]\n[Description: ]\n[MediaURL: ../assets/graphics/two-posts-so-far.png]\n<img src="../assets/graphics/two-posts-so-far.png" width="200" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: back-to-school-date]\n[Description: ]\n[MediaURL: ../assets/graphics/back-to-school-date.png]\n<img src="../assets/graphics/back-to-school-date.png" width="200" />\n<!-- End Cue -->\n\nSo she dates both her sons. And she jokes about murdering them. \n\nHere's another date, this time with Tyler:\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: again-this-is]\n[Description: ]\n[MediaURL: ../assets/graphics/again-this-is.png]\n<img src="../assets/graphics/again-this-is.png" width="200" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: back-to-school]\n[Description: ]\n[MediaURL: ../assets/graphics/back-to-school.png]\n<img src="../assets/graphics/back-to-school.png" width="200" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: you-may-think]\n[Description: ]\n[MediaURL: ../assets/graphics/you-may-think.png]\n<img src="../assets/graphics/you-may-think.png" width="200" />\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: since-austin-is]\n[Description: ]\n[MediaURL: ../assets/graphics/since-austin-is.png]\n<img src="../assets/graphics/since-austin-is.png" width="200" />\n<!-- End Cue -->\n\nAnother murder joke:\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: another-murder-joke]\n[Description: ]\n[MediaURL: ../assets/graphics/another-murder-joke.png]\n<img src="../assets/graphics/another-murder-joke.png" width="200" />\n<!-- End Cue -->\n\nMommy is so close to her little boys. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: grad-picture]\n[Description: ]\n[MediaURL: ../assets/graphics/grad-picture.png]\n<img src="../assets/graphics/grad-picture.png" width="200" />\n<!-- End Cue -->\n\n-I know. You've decided I've gone off the rails and i'm just making normal maternal love sound prurient. Are you sure? \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: LOCAL-GFX-20250914-164813]\n[Slug: tit-jut]\n[Description: ]\n[MediaURL: ../assets/graphics/tit-jut.png]\n<img src="../assets/graphics/tit-jut.png" width="200" />\n<!-- End Cue -->\n\nAmber's a hot mommy. I know you see this. \n\nI've talked about emotional incest between mothers and sons many times. I've told you about how my mother would coo at me for being so handsome, so brilliant, how all the girls were gonna want me. Do you know what else was going on that no one could see? Walking around naked when I was too old to see it? In adolescene, making "hilarious jokes" about how she refused to wear a bra in public, along with flapping her boob and laughing hysterically? Or how about swishing her skirt because she was having a hot flash, and making sure I knew she wasn't wearing panties. \n\nBut that's just my mom though. I'm crazy, and she's uniquely crazy, and I'm just projecting. Nothing to see here. What pattern?\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: happy-birthday-to]\n[Description: ]\n[MediaURL: ../assets/graphics/happy-birthday-to.png]\n<img src="../assets/graphics/happy-birthday-to.png" width="200" />\n<!-- End Cue -->\n\nAre you sure that there's nothing to see, here? In the car at age 45 to 50, with her son Tyler, wearing prostitute false eyelashes and making duck face? \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: PROD-GFX-01F1EC28ADC0]\n[Slug: amber-jones-duck-face]\n[Description: ]\n[MediaURL: ../assets/graphics/amber-jones-duck-face.png]\n<img src="../assets/graphics/amber-jones-duck-face.png" width="200" />\n<!-- End Cue -->\n\nHot mom. Cool mom. Babe mom. \n\nDo I know any of this for sure? Nope. But I'm seeing something, and I think I recognize it. And everyone else does, too. \n\nSound off in the comments. Tell me what you see and what you don't see. \n\nThis is the hardest show I've done yet, and it's not going to get easier in the second half, I'm afraid. \n\nBut that's enough about this topic for all of us, for today. All week I've had a Bible passage in my head. I now understand what it meant for the first time. People have asked how anyone could kill a man so good, so righteous, so kind, so loving, as Charlie. That's an ill-posed question. They killed because was good. \n\n"If the world hates you, keep in mind that it hated me first."\n\nJohn 15:18\n\nTHIS NEEDS THE CUT SCENE FROM THE EXORCIST ABOUT MAKING US DESPAIR\n\nSEE OURSELVES AS ANIMALS AND UGLY AND REJECT THE POSSIBILITY THAT GOD COULD LOVE US	\N
26	ASTMFJXNEKU7DJLZP	6	\N	segment	090 Tease Tease	090-tease-tease	60	00:00:00		## Notes\n\n## Description\n\n## Script\n\nAfter the break we're going to talk about the murder of Iryna Zarustka by a black man on a North Carolina train who walked away bragging that he got that white girl.	\N				2025-09-14T16:52:01.806148: Generated server AssetID ASTMFJXNEKU7DJLZP via rundown item creation	\N		\N	production	2025-09-16 11:22:50.771113+00	2025-10-03 18:04:27.408573+00	f	## Notes\n\n## Description\n\n## Script\n\nAfter the break we're going to talk about the murder of Iryna Zarustka by a black man on a North Carolina train who walked away bragging that he got that white girl.	\N
27	ASTMFK0RNJH2GH0RW	6	\N	break	Break	break	20	00:00:00		## Notes\n\n## Description\n\n## Script\n\n<!-- Begin Cue -->\n[Type: BREAK]\n[Slug: break]\n[AssetID: ASTMFK0RNJH2GH0RW]\n<!-- End Cue -->	\N				2025-09-14T18:19:18.893072: Generated server AssetID ASTMFK0RNJH2GH0RW via rundown item creation	\N		\N	production	2025-09-16 11:22:50.771113+00	2025-10-03 18:04:40.73315+00	f	## Notes\n\n## Description\n\n## Script\n\n<!-- Begin Cue -->\n[Type: BREAK]\n[Slug: break]\n[AssetID: ASTMFK0RNJH2GH0RW]\n<!-- End Cue -->	\N
28	ASTMFMGRRX2989JL4	6	\N	break	Support Break	support	90	00:02:00	None	# Break - Support\n\n**BREAK**\n\n[Support messaging and transition elements]	\N	None	None	None	None	\N	None	\N	production	2025-09-16 11:22:50.777421+00	2025-10-03 18:04:27.410973+00	f	# Break - Support\n\n**BREAK**\n\n[Support messaging and transition elements]	\N
227	SEGMGC47WOLCSZTML	23	\N	tease	Untitled	Guest Jade	0	00:00:00:00			\N		\N		\N	\N		\N	draft	2025-10-04 10:13:29.013403+00	2025-10-19 08:30:22.95157+00	f	---\nid: 'SEGMGC47WOLCSZTML'\nslug: "Guest Jade"\ntype: tease\norder: 1\nduration: "00:00:00:00"\nstatus: draft\ntitle: "Untitled"\n---\n<p class="josh">\n</p>	\N
10	COPMF8N1H7K3QWX4Z	4	\N	coldopen	Cold Open	show-intro	10	00:02:30	Welcome to Disaffected	## Notes\nOpening segment introducing show and main topics for the episode.\n\n## Description  \nWelcome to Disaffected introduction, teaser for upcoming content including Best Buy rant reference.\n\n## Script\nWelcome to Disaffected, it's September 7, 2025. This is the show that talks about politics, culture, and relationships through a psychological lens. I'm Joshua Slocum\n\nIf you didn't catch the special bonus extra rant this week, be sure to go back on Rumble or Youtube and find it. If you like my grocery store stories, you'll love/hate my Best Buy rant. It's got everything, retarded Gen Z's with man boobs, zombie broads weaving around parking lots, and more.	2025-09-07 00:00:00			intro, welcome, topics	Generated for episode 0239 segmentation	\N	high	\N	draft	2025-09-16 11:15:55.200852+00	2025-10-03 18:18:37.211825+00	f	---\nid: 'COPMF8N1H7K3QWX4Z'\nslug: "show-intro"\ntype: coldopen\norder: 1\nduration: "00:02:30"\nstatus: draft\ntitle: "Cold Open"\n---\n## Notes\nOpening segment introducing show and main topics for the episode.\n\n## Description  \nWelcome to Disaffected introduction, teaser for upcoming content including Best Buy rant reference.\n\n## Script\nWelcome to Disaffected, it's September 7, 2025. This is the show that talks about politics, culture, and relationships through a psychological lens. I'm Joshua Slocum\n\nIf you didn't catch the special bonus extra rant this week, be sure to go back on Rumble or Youtube and find it. If you like my grocery store stories, you'll love/hate my Best Buy rant. It's got everything, retarded Gen Z's with man boobs, zombie broads weaving around parking lots, and more.\n<p class="josh"></p>	\N
12	SEGMF8N3K4Q6SYU8C	4	\N	segment	The Princess and the Pea	princess-and-pea	50	00:12:00	Fairy tale psychology analysis	## Notes\nPsychological exploration of fairy tale themes and their relevance to childhood development and modern identity formation.\n\n## Description\nAnalysis of The Princess and the Pea fairy tale as a metaphor for sensitivity, authenticity, and childhood development patterns.\n\n## Script\n**Media Elements Referenced:**\n- {GFX/align} → align.png\n- {GFX/princess-pea-illustration} → princess pea illustration}.png\n\n**Script Content:**\nThe Princess and the Pea is a fascinating fairy tale that reveals deep psychological truths about sensitivity, authenticity, and the nature of true identity. The story tells us that a real princess can feel a single pea through twenty mattresses and twenty feather beds.\n\nThis hypersensitivity becomes the test of authenticity - only someone of true nobility could be so acutely aware of discomfort that others would never notice.\n\n[Full segment content from original script lines 94-153]	2025-09-07 00:00:00		Hans Christian Andersen works, developmental psychology	fairy tales, psychology, childhood, development, sensitivity	Generated for episode 0239 segmentation	\N	medium	\N	draft	2025-09-16 11:15:55.200852+00	2025-10-03 18:18:37.215391+00	f	## Notes\nPsychological exploration of fairy tale themes and their relevance to childhood development and modern identity formation.\n\n## Description\nAnalysis of The Princess and the Pea fairy tale as a metaphor for sensitivity, authenticity, and childhood development patterns.\n\n## Script\n**Media Elements Referenced:**\n- {GFX/align} → align.png\n- {GFX/princess-pea-illustration} → princess pea illustration}.png\n\n**Script Content:**\nThe Princess and the Pea is a fascinating fairy tale that reveals deep psychological truths about sensitivity, authenticity, and the nature of true identity. The story tells us that a real princess can feel a single pea through twenty mattresses and twenty feather beds.\n\nThis hypersensitivity becomes the test of authenticity - only someone of true nobility could be so acutely aware of discomfort that others would never notice.\n\n[Full segment content from original script lines 94-153]	\N
142	SEGMG0U5I5F1CVZBM	19	\N	reader	Reader	reader	0	00:00:00:00			\N		\N		\N	\N		\N	draft	2025-09-26 12:46:12.771181+00	2025-10-18 18:57:37.005919+00	f	---\nid: 'SEGMG0U5I5F1CVZBM'\nslug: "reader"\ntype: reader\norder: 1\nduration: "00:00:00:00"\nstatus: draft\ntitle: "Reader"\n---\n<p class="josh"></p>	\N
126	SEGMFT39C7Q8V9TWE	18	\N	segment	all manson girls	we're all manson girl	30	00:06:39			2025-09-21 00:00:00		\N		\N	\N	normal	\N	production	2025-09-21 03:43:06.658199+00	2025-09-21 03:58:11.850097+00	f	## Notes\n\n## Description\n\n## Script\n\nOn September 10, 22-year-old Tyler Robinson allegedly shot Charlie Kirk dead on a college campus in Utah. The bullet hit his carotid artery and his neck exploded in front of thousands at an event while his family was watching, and he was dead before he hit the grass. \n\nLast week we told you what we knew about Robinson and his family, including a series of Facebook posts from his mother, Amber, which strongly suggest an emotionally incestuous borderline personality stance toward her son. \n\nYou've watched the mainstream leftist media try to blame this murder on right wingers. You've watched them lie directly to the camera and claim they have no idea what his motive was, even though they have heard the same information from law enforcement that we've heard. Tyler Robinson had a boyfriend who's a "furry", an adult who wears full sized sexualized animal costumes. He went full hard antifa leftist over several years despite his family's conservatism. He engraved antifa and trans/furry slogans on the bullets he used, including the one that killed Charlie. \n\nThe media's psychopathy-actual psychopathy–was obvious this week when they just flatly pretended they didn't know this so they could reverse the blame and put it on people like us. You watched thousands of people celebrate his murder, and you noticed the overwhelming proportion of young women who were obviously erotically and emotionally climaxing over this murder.\n\nNow you know that we live in a nation of Manson Girls, except America thinks cult loyalty to brutal killers is now normal and cute, quite a different reaction from what the Manson Girls of 1970 provoked in the public. \n\nWell, you've tried all the rest, so now let's sample the best. In a minute we're going to listen to an NBC news reporter talk about the shooter's relationship with his troonatic boyfriend in a tone usually reserved for a reivew of a romance novel. \n\nBut we have to set it up first by looking at the text message exchanges between shooter Robinson and his  boyfriend. . .Lance Twiggs. Yes. When I first heard the name I wondered if he was related to David Pumpkins. \n\nIt's not confirmed, but it also appears that many more trans and trans sympathetic associates of the shooter had advance knowledge of the shooting judging by online chat messages between them. Again, not confirmed, but it's being investigated and it would be no surprise. \n\nThis week we've seen text messages between the alleged killer, Robinson, and his boyfriend Lance Twiggs. These messages happened on Discord, which is an online chat platform used by videogamers and others. Our show has a Discord chat server. If you remember old school chat rooms like IRC, AOL, and the like, it's like that with more features. \n\nMy friend Holly wrote a Substack article diving deeper into these messages and you should read Better Bent than Blind if you're interested. \n\nHere are some of the exchanges. You'll notice strange, stilted, almost "fake historical dialogue" quality to how Tyler Robinson addresses his boyfriend. Holly sees this as a holdover from Robinson's religious upbringing; that he's talking to his boyfriend the way Mormon boys are taught to talk to women (he's treating Lance as a lady, because Lance is trans, whatever that means). She also thinks the exchanges suggest the boyfriend didn't know about the shooting ahead of time. \n\nI see it differently. This just doesn't read as genuine to me. It looks like a setup, pre-arranged messages that they agreed to make to each other to get the boyfriend out of trouble. To make it seem like Lance Twiggs, the boyfriend, had nothign to do with it. \n\nWe don't know the truth, but maybe we'll find out. \n\nHere's Tyler Robinson:\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: ASTMFT39C85NHP49A]\n[Slug: GFX/10 tyler-robinson]\n[Description: ]\n[MediaURL: ../assets/graphics/10-tyler-robinson.png]\n<img src="../assets/graphics/tyler-robinson.png" width="200" />\n<!-- End Cue -->\n\nHere's his boyfriend Lance Twiggs. Remember, Lance is "trans," so he's a lady, but he's also a furry, which means he's a sexual non-human animal. \n\n  <!-- Begin Cue -->\n[Type: GFX]\n[AssetID: ASTMFT39C8C7NK3Y9]\n[Slug: GFX/20 lance-twiggs]\n[Description: ]\n[MediaURL: ../assets/graphics/20-lance-twiggs.png]\n<img src="../assets/graphics/lance-twiggs.png" width="200" />\n<!-- End Cue -->\n\nHere's lance being a doggy. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: ASTMFT39C8J9XHMST]\n[Slug: GFX/30 lance-doggy]\n[Description: ]\n[MediaURL: ../assets/graphics/30-lance-doggy.png]\n<img src="../assets/graphics/lance-doggy.png" width="200" />\n<!-- End Cue -->\n  \nAnd here are some of the text exhanges on Discord. \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: ASTMFT39C8QEPNBQH]\n[Slug: GFX/40 keyboard-note]\n[Description: ]\n[MediaURL: ../assets/graphics/40-keyboard-note.png]\n<img src="../assets/graphics/keyboard-note.png" width="200" />\n<!-- End Cue -->\n\nTyler apparently left Lance a paper note under the keyboard. What kind of dialogue is this? \n\n"I am still OK, my love."\n\n"I had hoped to keep this secret until I died of old age. I am sorry to involve you."\n\nIt reminds me of dialogue from a parody of 50s B scifi movies called the Lost Skeleton of Cadavra. In that movie, space aliens try to pass themselves off as earthlings. The main alien says things like, "I am a normal earth man, I assure you."\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: ASTMFT39C8XYANWUO]\n[Slug: GFX/50 why-did-i]\n[Description: ]\n[MediaURL: ../assets/graphics/50-why-did-i.png]\n<img src="../assets/graphics/why-did-i.png" width="200" />\n<!-- End Cue -->\n\nIt goes on like that. Check out Holly's article for more. \n\nIt doesn't pass my sniff test. This looks like ex-post-facto storytelling. \n\nBut it passes the mainstream media's sniff test. For NBC reporter Matt Gutman, it smelled like the sweetest English roses. \n\n{SOT/matt abc touching shooter}\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: ASTMFT39C942OE6ZU]\n[Slug: SOT/60 abc-touching-shooter]\n[Description: ]\n[MediaURL: ../assets/video/60-abc-touching-shooter.mp4]\n[Duration: 00:00:52]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\n-First of all, Robinson never said "I want to protect you, my love." That's Matt himself confabulating and confessing his own fantasy. \n\n-Touching? Touching cloth maybe. \n\n-An intimate portrait? Is he watching the Patty Duke Story on Lifetime, Television for Women and Homosexuals?\n\nMatt keeps going. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: ASTMFT39C9BIHDDA2]\n[Slug: SOT/70 touching-intimate-portrait]\n[Description: ]\n[MediaURL: ../assets/video/70-touching-intimate-portrait.mp4]\n[Duration: 00:01:50]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\n-Oh, a duality? A portrait of a very human person, a very human experience. \n\nWashed up former talk show host Montel Williams also finds the alleged shooter very, very touching and sympathetic. Naturally, he's on that idiot Abbie Philip's CNN show. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: ASTMFT39C9XCYUL42]\n[Slug: SOT/80 montel-williams]\n[Description: ]\n[MediaURL: ../assets/video/80-montel-williams.mp4]\n[Duration: 00:00:48]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nMontel doesn't think he was motivated politically, despite knowing that he killed conservative Charlie Kirk and said why in text chat. \n\nSee? It's a love story. He was motivated by the power of love. He had to protect his love. See? It's beautiful. He did it all for the glory of love. \n\nThis is psychopathy. Mass pscyhopathy. Don't get used to this. Don't just accommodate it the way you've taken in stride everything else that's gone nuts in the past 10 years. This is a national emergency. \n\nLet's go back to about 1970 and talk about the Manson Family. Those of you too young to remember this or remember it in popular culture, here's what happened. Charles Manson was a psychopathic hippie who formed a commune cult for the purposes of murder. A certain type of young woman flocked to him, a type of young woman we see every single day now. \n\nI'll read a summary from Wikipedia:\n\n"The Manson Family (known among its members as the Family) was a commune, gang and cult led by criminal Charles Manson that was active in California in the late 1960s and early 1970s.[1][2][3] At its peak the group consisted of approximately 100 followers who lived an unconventional lifestyle, frequently using psychoactive drugs, including amphetamine and hallucinogens such as LSD.[1][4] Most were young women from middle-class backgrounds, many of whom were attracted by hippie counterculture and communal living, and then radicalized by Manson's teachings.[1][5] The group murdered at least nine people, and may have killed as many as twenty-four.[1][6]\n\nManson had been institutionalized or incarcerated for more than half of his life by the time he was released from prison in 1967. He began attracting acolytes in the San Francisco Bay Area. They gradually moved to a run-down movie ranch, called the Spahn Ranch, in Los Angeles County.[7] According to group member Susan Atkins, members of the Family became convinced that Manson was a manifestation of Jesus Christ,[1] and believed in his prophecies concerning an imminent, apocalyptic race war.[1][8][9]\n\nIn 1969, Manson Family members Atkins, Charles Denton "Tex" Watson and Patricia Krenwinkel entered the home of actress Sharon Tate and murdered her and four others. Linda Kasabian was also present but did not take part. The following night, members of the Family murdered supermarket executive Leno LaBianca and his wife Rosemary at their home in Los Angeles. Members also committed a number of assaults, petty crimes, theft and street vandalism, including an assassination attempt on U.S. President Gerald Ford in 1975 by Family member Lynette "Squeaky" Fromme."\n\nThis story was the biggest headline in the nation for months, years. I was born 4 years after it took place, but Charles Manson and the Manson Girls were still talked about constantly among adults and in culture. Everyone normal, almost everyone, was shocked by these people and couldn't believe they were real. \n\nHow times have changed. More on that in a minute. \n\nHere are some of the Manson girls holding a vigil for Charlie outside his trial in Los Angeles in 1970.\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: ASTMFT39CANMRT24I]\n[Slug: GFX/90 manson-girls-kneel]\n[Description: ]\n[MediaURL: ../assets/graphics/90-manson-girls-kneel.png]\n<img src="../assets/graphics/manson-girls-kneel.png" width="200" />\n<!-- End Cue -->\n  \nHere they are singing on their way into the court room.\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: ASTMFT39CBDW0BE1X]\n[Slug: SOT/100 manson-girls-singing]\n[Description: ]\n[MediaURL: ../assets/video/100-manson-girls-singing.mp4]\n[Duration: 00:00:24]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nHere's Charlie himself on why the girls loved him so much. See if you have a better understanding after this. \n\n{SOT/manson speaks}\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: ASTMFT39CC3XVAFFE]\n[Slug: SOT/110 manson-speaks]\n[Description: ]\n[MediaURL: ../assets/video/110-manson-speaks.mp4]\n[Duration: 00:00:14]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ...and i play and i sing]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nRemember Luigi Mangione? \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: ASTMFT39CCTV6A883]\n[Slug: GFX/120 luigi-mangione]\n[Description: ]\n[MediaURL: ../assets/graphics/120-luigi-mangione.png]\n<img src="../assets/graphics/luigi-mangione.png" width="200" />\n<!-- End Cue -->\n\nIt was only a few months ago. Young Luigi, hot criminal, allegedly executed United Healthcare CEO Brian Thompson with a gun on December 4, 2024. Countless young people celebrated the death of a nasty capitalist pig who denied people healthcare. \n\nBut it was more than that. You saw young women in the midst of sexual and religious ecstsasy fan girling over this killer. Yes, it's sexual. Yes, they're turned on by violent men. Yes, it makes them tingle. You're seeing what you think you're seeing. \n\nThe difference between 1970 and today is that it was socially unacceptable to openly sympathize with and get hot for brutal psychopathic kilers. Today it's normal. \n\nFrom Axios:\n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: ASTMFT39CDJ8I2TAZ]\n[Slug: GFX/130 by-the-numbers]\n[Description: ]\n[MediaURL: ../assets/graphics/130-by-the-numbers.png]\n<img src="../assets/graphics/by-the-numbers.png" width="200" />\n<!-- End Cue -->\n\nHere's a Mangione Girl for you:\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: ASTMFT39CE8FBYXHA]\n[Slug: SOT/140 married-luigi-mangioni]\n[Description: ]\n[MediaURL: ../assets/video/140-married-luigi-mangioni.mp4]\n[Duration: 00:01:28]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nI think this next is from the same event, which was a gathering outside the court room to hear what charges would stick against Mangione and which would go. The court threw out the terrorism charges. This was the crowd on hearing that news:\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: ASTMFT39CELCZPRZT]\n[Slug: SOT/150 cheer-for-luigi]\n[Description: ]\n[MediaURL: ../assets/video/150-cheer-for-luigi.mp4]\n[Duration: 00:01:03]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\n-Murder for profit is terrorism\n-Capitalist pigs, die lol lmao\n\nWe're all Manson boys and girls now. Aren't we. \n\nCome back on the other side to indulge in some schadenfreude as we watch modern day Charlie's girls lose their jobs because they celebrated a bloody murder on social media.	\N
127	SEGMFT39CEVMP5WD9	18	\N	segment	Cancel Culture	cancel culture	60	00:03:12			2025-09-21 00:00:00		\N		\N	\N	normal	\N	production	2025-09-21 03:43:06.658199+00	2025-09-21 03:58:11.851645+00	f	## Notes\n\n## Description\n\n## Script\nYou've seen them fucking around. Now let's see them find out. \n\nThis nurse is no longer a nurse. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: ASTMFT39CF6PENLRD]\n[Slug: SOT/160 nurse-fired]\n[Description: ]\n[MediaURL: ../assets/video/160-nurse-fired.mp4]\n[Duration: 00:00:33]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nGood. Yes. Good. Moral. Right. It needed to happen. Do you want a bloodthirsty psychopathic nurse who celebrates murdering a father and husand taking care of your mother? Your duaghter? \n\n<!-- Begin Cue -->\n[Type: GFX]\n[AssetID: ASTMFT39CFDJ3EFG3]\n[Slug: GFX/170 weird-how-people]\n[Description: ]\n[MediaURL: ../assets/graphics/170-weird-how-people.png]\n<img src="../assets/graphics/weird-how-people.png" width="200" />\n<!-- End Cue -->\n\nThis young woman\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: ASTMFT39CFJMPTI97]\n[Slug: SOT/180 fuck-fired-charlie]\n[Description: ]\n[MediaURL: ../assets/video/180-fuck-fired-charlie.mp4]\n[Duration: 00:01:05:03]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\n-Do I go home and goon? Yes, she said, do I go home and masturbate? \n\n-I don't care what you're supposed to do. I don't care if you do anything. \n\n-This is Gen Z. This is the lack of parenting. This is what happens. Chronological adutls who are literally retarded children. \n\nI haven't seen any consequences yet, but I hope these girls get some for destroying a memorial to Charlie Kirk on their college campus and putting out a video of them looking cute and hot doing it. \n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: ASTMFT39CFQ6LJEJJ]\n[Slug: SOT/190 girls-destroy-memorial]\n[Description: ]\n[MediaURL: ../assets/video/190-girls-destroy-memorial.mp4]\n[Duration: 00:02:39]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\n-"Love your neighbor"\n\n-"I'm not gonna love a man who doesn't even. . ."\n\n"I am not judging."\n\n"We're not the ones"\n\nPsychologist and author Rob Henderson has a fascinating article on Substack discussing the imbalance in how liberals and conservatives see each other. Here's the spoiler: liberals really do hate and fear and dehumanize conservatives, while conservatives don't know or pretend they don't know how much the left actually hates them. The left doesn't disagree with us, they viscerally hate us. \n\nFrom Henderson's Substack:\n\n<!-- Begin Cue -->\n[Type: FSQ]\n[AssetID: fsq_1758417263807_a 2023 stu]\n[Slug: a 2023 study]\n[Quote: \\"A 2023 study from psychologists Christopher D Petsko and Nour S Kteily uncovered something troubling about how Americans see one another. Conservatives tend to view liberals as \\'immature\\' irresponsible, gullible and irrational. Liberals, in turn, tend to see conservatives as \\'savage\\' aggressive, cold-hearted and barbaric.\\"]\n[Align: left]\n[Part: 1x1]\n[WordCount: 45]\n[Attribution: Rob Henderson]\n[Duration: 00:23]\n<!-- End Cue -->\n\n-You see the reversal, right? The actually savage people think we conservatives are the irrational savages. \n\n<!-- Begin Cue -->\n[Type: FSQ]\n[AssetID: fsq_1758417347183_the resear]\n[Slug: the researchers also]\n[Quote: \\"The researchers also found something even more revealing: liberals overestimate how dehumanised they are by conservatives (they think conservatives view them even more negatively than they do). But conservatives underestimate how dehumanised they are by liberals (they think liberals view them more positively than they actually do).\\"]\n[Align: left]\n[Part: 1x1]\n[WordCount: 47]\n[Attribution: Rob Henderson]\n[Duration: 00:24]\n<!-- End Cue -->\n\n-Do you understand now that you're not dealing with morally normal people? Do you understand that I haven't been exaggerating when I say these people, including some of your family, would see you dead? \n\nA number of people on the right are now bellyaching about how the right is just "doing cancel culture" getting these people fired. It's moral insanity to view it that way, and it's suicidal. \n\n"Cancel culture" isn't a thing. Not the way you use it, conservatives. Our side has this badly wrong. \n\n"Cancel culture" is a new word for what we all used to call "social pressure to enforce pro-social behavior and to punish anti-social behavior."\n\nThat's a normal part of human society. It's hardwired. You approve of it, because all human societies, forever, everywhere, operate on *rules*. \n\nWhen you criticize performers who get naked in front of children, or when you boycott stores that cater to LGBTQ and do it to entice kids, you're doing what you scream is "cancel culture" when leftists do it. \n\nWhat you're doing--protesting and boycotting with the aim of using social pressure, not the government, to change behavior--is normal. It's in bounds. \n\nYou know this. \n\nWhat we call "cancel culture" is the left's MIS-USE of this pressure. They've inverted it. \n\nInstead of targeting antisocial behavior, they target pro-social behavior.\n\nInstead of debating, they use social reputation destruction to stop people from being able to disagree and keep their jobs.\n\nBut somehow, you've gotten all twisted up. Somehow, you've allowed yourself to be convinced that normal social pressure against BAD behavior is the same kind of sin as social pressure against GOOD behavior. \n\nDo you see the problem you've backed into? \n\nLet's use the gun analogy. If you treated gun discourse the  same way you're treating this conversation, you would say this:\n\n"NO ONE should EVER have guns. That's death culture. It's not OK when OUR SIDE does it. It's not OK to defend your life with a gun, because a bad guy used his gun to hurt your mother. Therefore, if you use a gun to protect your mother, you're JUST AS BAD and you're practicing DEATH CULTURE.\n\nTherefore, no one should have a gun."\n\nTLDR; you're mistaking the tool for the operator's misuse.\n\nYou have to actually make judgments about right and wrong. \n\nThat's what you're afraid of. That's why you do this. \n\nYou don't want the responsibility. But it is your duty. \n\nJudge.\n\nI want to close this segment out with a letter I got from a viewer. Yes, I said "letter," even though I came by email. I won't name this gentleman, but I do thank him for writing and for being part of the audience. \n\n{FS Quote/greetings mr. slocum}\n\n<!-- Begin Cue -->\n[Type: FSQ]\n[AssetID: fsq_1758417424535_greetings ]\n[Slug: greetings mr. slocum]\n[Quote: Greetings Mr. Slocum,\\n\\nI\\'m a middle-aged heterosexual white man living in California. I had no love for Charlie Kirk, but I wouldn\\'t call myself a Leftist and consider my affiliation \\'politically homeless\\'. The way I found out about Charlie Kirk\\'s assassination was a friend of mine celebrating it on Twitter. He said it was \\'a good thing actually\\' and that \\'we should make this a holiday\\'.\\n]\n[Align: left]\n[Part: 1x1]\n[WordCount: 66]\n[Attribution: viewer letter]\n[Duration: 00:33]\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: FSQ]\n[AssetID: fsq_1758417567627_i have alw]\n[Slug: i have always known]\n[Quote: \\"I\\'ve always known he was far left and was content to stay away from politics, just hang out and play games. This is crossing an unacceptable moral line. This is a hate cult and I cannot associate with these ghouls.\\n\\n\\nWhen will they lynch me? If I die in a car accident, will my death be celebrated too?\\"]\n[Align: left]\n[Part: 1x1]\n[WordCount: 58]\n[Attribution: viewer letter]\n[Duration: 00:29]\n<!-- End Cue -->\n\n<!-- Begin Cue -->\n[Type: FSQ]\n[AssetID: fsq_1758417621953_this frien]\n[Slug: this friend once]\n[Quote: \\"This friend once told me he believes in cutting off relationships with people as a social consequence for wrongthink. He\\'s going to get exactly what he wished for and swallow his own medicine.\\n\\nThese people must be socially ostrasized. If you employ them, fire them. If you work for woke, quit. Demand they vacate your place of business.\\n\\nWe must be willing to sacrifice being comfortable. I had to sacrifice this friendship and have gone No Contact.\\"\\n\\n]\n[Align: left]\n[Part: 1x1]\n[WordCount: 77]\n[Attribution: viewer letter]\n[Duration: 00:39]\n<!-- End Cue -->\n\nSir, hats off. You are living in reality, and you don't need me. \n\nCome back after the break to talk about what I'm hearing from my coaching and consulting clients on this topic. Many of them are afraid of, or should be afraid, of the people who live in the same house they do. Also, we'll have little bit of fun to close the show out. Don't you need a laugh? I do.	\N
128	SEGMFT39CFXRU8V4P	18	\N	segment	Your Family is Insane	family insane	90	00:00:00			2025-09-21 00:00:00		\N		\N	\N	normal	\N	production	2025-09-21 03:43:06.658199+00	2025-09-21 03:58:11.853198+00	f	## Notes\n\n## Description\n\n## Script\nYour husband is insane. Your mother is insane. Your sister is insane. Your son is insane. That’s what I’ve said to an increasing number of my coaching/consulting clients. That is not something I say lightly, and I don’t ever say it unless I believe I have good reason to say so based on the specific’s of my client’s circumstances as the client relates them to me (understanding that I don’t have direct knowledge).\n\n\nYou hear me on my show “diagnosing” people all over the place, I know. I do “diagnose” public figures with personality pathology all the time. It’s obvious. We can see their moves and detect patterns.\n\n\n\n\nThat’s not the case when I’m dealing with clients one on one, when my only information about them or their family member comes from that client. I can only go on what they tell me. And, yes, when I’m picking up that my client is also behaving badly/unwisely, I point to the client’s behavior as well. But I am limited in what I can know with confidence from a one-hour conversation with a stranger.\n\n\nIf I were to actually diagnose a person, it would take many more steps. Because I’m not a licensed or degreed mental health pro, I don’t have the medico-legal power to make a diagnosis. When I say above that I “diagnose” celebrities, I’m using the colloquial sense of the word “diagnose.” Because I’m not, actually, “diagnosing” Madonna. I haven’t assessed her in person, and I don’t have the power to make entries in her medical record that inform her course of treatment. That’s why it’s not actual “diagnosis.”\n\n\nDegreed or not, I would be qualified (in my own judgment) to make a real differential diagnosis of a specific personality/trauma disorder. I have the knowledge and the experience. But it could only come after developing a therapeutic relationship over time, one where I could talk with and probe a person in many different ways.\n\n\nIn short, I could pretty rapidly come to “This is likely a Cluster B disorder” in my mind, but I would not commit to it, nor would I say “which one” until I had the time to test my assessment against reality through conversation with the client. And after eliminating other environmental, trauma history, and other influences that might make a person appear to have a disorder that they don’t actually have.\n\n\nI can’t do any of this with the unseen family members of my clients. But I don’t need to delve this deeply to know that many of my clients have family members who are either or a combination of:\n\n\nSeverely situationally traumatized by a world full of evil leftists that they don’t want to be true, so they’re in temporary psychosis to make it “not true” that they’re living in crazy world.\n\n\nFully Cluster B disordered, and have been for decades, but you, client, didn’t see it when you weren’t the target of his ire and disgust. Now you are, since you’ve admitted that you don’t believe Trump or Charlie Kirk should be murdered.\n\n\nDependent, changeable, fickle people who adopt the most strident opinions of the people around them who hold the most power. Weak character, can’t be trusted, has no thoughts of her own.\n\n\nIn a state of cult-induced psychosis: genuine, thorough-going disconnection from reality.\n\n\nHow can I make these assessments, even provisionally, when I haven’t even met these people? Here are the statements and behaviors that clients have reported to me. These are composites; they do not reflect any specific person or situation. But they’re all real. Assuming my clients are telling the truth, what would you think? None of these are one-off statements. They’re all part of a long, sometimes years-long pattern, of similar statements.\n\n\n“I’m glad Charlie Kirk is dead so his children won’t suffer growing up with him for a father.”-told to a client by his father\n\n\n“No one is actually poisoning children or mutilating their genitals. You’re insane, and you’re in a cult. The ‘gender critical’ people you hang around with are psychopaths.”-told to a wife by her husband.\n\n\n“It’s only a few children, a tiny, vanishing number, who are really trans and they need the surgery. You’re insane and full of hate to claim that there are more than a few. Also, no one is doing this to any children yes, the same person often makes these contradictory statements-I see it often.”\n\n\n“Charlie Kirk said that black women shouldn’t have the right to vote, and he said that his political opponents should be executed in public. You’re insane and a psychopath to feel any empathy for him or his family.”-said to a brother by his sister.\n\n\nThis is just a sampling of the things that the family members of my clients are telling them. Any one of these statements, by themselves, suggests disconnection from reality, and suggests membership in a cult. Yes, a literal cult. As culty as The Moonies. Not “cult-like,” an actual ACME, simon-pure cult.\n\n\nGiven the history of these behaviors and statements from some client family members, it’s quite clear that mom/dad/hubby/sister really is a psychopath themselves, and always has been. At least three returning clients have faced the music recently and admitted that it’s true that their loved one has always had a personality disorder, and they can’t deny it or find a workaround any longer after hearing their bloodthirsty rage.\n\n\nI hate this. It’s horrible. My clients are facing deep grief and sorrow, and uncertainty about what the rest of their lives is going to look like.\n\n\nBut what’s most important is that they’re facing the truth, and they’re able to repeat the truth back to me. Yes, my husband is clinically insane. Yes, my wife has a borderline-narcissist personality disorder and she always has, and this is not going to get better. Yes, my father would see me dead.\n\n\nIt’s a horror. Yes. But it is true.	\N
268	SEGMGRKYN0Z2XMHYZ	26	\N	promo	Promo		40	00:00:00:00			\N		\N		\N	\N		\N	draft	2025-10-15 05:58:42.707686+00	2025-10-18 18:57:42.714862+00	f	<p class="josh"></p>	\N
125	ASTMFSR6T43X378M1	18	\N	tease	Intro Tease	Intro Tease	0	00:00:00:00			2025-09-21 00:00:00		\N		\N	\N	normal	\N	production	2025-09-21 03:43:06.658199+00	2025-10-18 18:57:46.772905+00	f	## Notes\n\n## Description\n\n## Script\n\nTonight we're going to catch up on the aftermath of the Charlie Kirk assassination. People are getting fired for their bloodthirsty social media death orgasms, and they're some pissed.\n\nAnd the media is turning the shooter's relationship with his troon boyfriend into a romance, describing 22-year-old Tyler Robinson's text messages to his animal-costume-wearing boyfriend as "touching." A real Romeo and Furriet story. \n\nAnd you've heard of the woke right, the idea that conservatives have just as many bad lunatics as the left and it's bad bad bad if conservatives use the left's medicine against it. We're going to look at the cuck right, the conservatives afraid to defend their own interests against leftist banshees. \n\nIt's September 21, 2025, and this is Disaffected, the show that talks about politics, culture, and relationships through a psychological lens. I'm Joshua Slocum and put your seatbelt on we're goin'.\n<p class="josh"></p>	\N
129	SEGMFT39CG6TYWMQB	18	\N	segment	Potpourri du Moquerie	Potpourri du Moquerie	100	00:03:07			2025-09-21 00:00:00		\N		\N	\N	normal	\N	production	2025-09-21 03:43:06.658199+00	2025-09-21 03:58:11.853726+00	f	## Notes\n\n## Description\n\n## Script\n\nThank God we are back!\n\n\nOur first entry comes from a very funny man named Terrence K. Williams, who I call cousin Terrence because he sells pancake mix under the name Cousin T's, and I want this man for my family. He doesn't say anything in this video reaction, but he pulls some good faces. \n\n\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: ASTMFT39CGFV9VMRR]\n[Slug: SOT/200 meow-girl]\n[Description: ]\n[MediaURL: ../assets/video/200-meow-girl.mp4]\n[Duration: 00:01:29]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\n-I need help wiping. \n\n\n-Kitten time. \n\n\n\n\n-I actually want to take care of this girl and be her father and save her. She doesn't have to stay this way. Something tells me she's smart as hell and creative and just needs some guidance. \n\n\nDo you remember Mad TV, and the character Stewart, the overgrown naughty manchild? Well this gentleman would like to say to you "Look what I can do."\n\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: ASTMFT39CGMD4TDX4]\n[Slug: SOT/210 look-what-i-can]\n[Description: ]\n[MediaURL: ../assets/video/210-look-what-i-can.mp4]\n[Duration: 00:00:28]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nFor the next report we turn to our sister network Univision\n\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: ASTMFT39CGSWS1B57]\n[Slug: SOT/220 mom-got-deported]\n[Description: ]\n[MediaURL: ../assets/video/220-mom-got-deported.mp4]\n[Duration: 00:00:43]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->\n\nMiguel, I prescribe Miss Clairol Frivolous fawn toner with 10 volume peroxide. Call me back when you've got the brass out of that bleached head. \n\n\nFinally, a lesson from the President in how to talk to bitches. Remember the show a few weeks ago where we watched the cop cam videos with George? How the chicks kept telling the cops that, no, they weren't under arrest, and no, they weren't being taken into custody? Listen to this doxy mouth off in the Oval Office. \n\n\n\n\n<!-- Begin Cue -->\n[Type: SOT]\n[AssetID: ASTMFT39CGZUYJYDF]\n[Slug: SOT/230 trump-to-bitches]\n[Description: ]\n[MediaURL: ../assets/video/230-trump-to-bitches.mp4]\n[Duration: 00:00:27]\n[TrimStart: 00:00:00]\n[TrimEnd: 00:00:00]\n[Transcription: ]\n[ThumbnailURL: ]\n[Credits: {}]\n<!-- End Cue -->	\N
226	SEGMGC47MFBBM2VHS	23	\N	coldopen	Cold Open	show-cold-open	0	00:00:45:00			\N		\N		\N	\N		\N	draft	2025-10-04 10:13:15.719007+00	2025-10-07 07:10:47.113069+00	f	<p class="josh"></p>	\N
228	SEGMGC4B1MI0UU7J2	23	\N	segment	Segment	Zohran Mamdani	0	00:00:00:00			\N		\N		\N	\N		\N	draft	2025-10-04 10:15:55.386377+00	2025-10-07 07:10:47.743393+00	f	<p class="josh"></p>	\N
11	SEGMF8N2J9P5RXT7B	4	\N	segment	Trans Shooter Update	trans-shooter-update	20	00:15:00	Robert Westman case analysis	## Notes\nDeep dive into the Robert "Robin" Westman school shooting case, examining family dynamics and parental responsibility.\n\n## Description\nAnalysis of the Minneapolis Annunciation Catholic School shooting, focusing on family dynamics, parental responsibility, and the role of gender transition in the case.\n\n## Script\n**Media Elements Referenced:**\n- {GFX/robert-westman-and-mom} → robert westman and mom.png\n- {GFX/robert-and-mary-grace} → robert and mary grace.png  \n- {SOT/mary-grace-instagram} → mary grace instagram.mp4\n- {FS quote/mary grace did not} → See quotes_0239.json\n- {GFX/aunt-lyn} → aunt lyn.png\n- {GFX/mainstream-media} → mainstream media.png\n- {GFX/jaimee-michell} → jaimee michell.png\n- {GFX/janedoeuknow} → janedoeuknow.png\n- {GFX/mkdanaher} → mkdanaher.png\n\n**Script Content:** \nLast week we talked about the shooting at Annunciation Catholic School in Minneapolis. A 22 year old man named Robert "Robin" Westman killed two kids and put 17 other people in the hospital on August 27, 2025.\n\nWe talked about how the right wants to blame SSRI antidepressants, and how the left wants to blame guns. Now we're going to talk about how so many people absolutely, positively, never, under no circumstances, want to blame mommy.\n\n[Full segment content from original script lines 17-93]	2025-09-07 00:00:00		Robert Westman case files, Andy Ngo reporting	trans, shooting, family, responsibility, Minneapolis	Generated for episode 0239 segmentation	\N	high	\N	draft	2025-09-16 11:15:55.200852+00	2025-10-03 18:18:37.212762+00	f	---\nid: 'SEGMF8N3K4Q6SYU8C'\nslug: "princess-and-pea"\ntype: segment\norder: 40\nindex: 40\nduration: "00:12:00"\nstatus: draft\ntitle: "The Princess and the Pea"\n---\n## Notes\nPsychological exploration of fairy tale themes and their relevance to childhood development and modern identity formation.\n\n## Description\nAnalysis of The Princess and the Pea fairy tale as a metaphor for sensitivity, authenticity, and childhood development patterns.\n\n## Script\n**Media Elements Referenced:**\n- {GFX/align} → align.png\n- {GFX/princess-pea-illustration} → princess pea illustration}.png\n\n**Script Content:**\nThe Princess and the Pea is a fascinating fairy tale that reveals deep psychological truths about sensitivity, authenticity, and the nature of true identity. The story tells us that a real princess can feel a single pea through twenty mattresses and twenty feather beds.\n\nThis hypersensitivity becomes the test of authenticity - only someone of true nobility could be so acutely aware of discomfort that others would never notice.\n\n[Full segment content from original script lines 94-153]\n<p class="josh"></p>	\N
14	SEGMF8N5M6S8UWA0E	4	\N	segment	Beatrix Potter Fantasy	beatrix-potter	40	00:08:00	Childrens literature analysis	## Notes\nCultural commentary on children's literature and its role in identity formation and fantasy development.\n\n## Description\nAnalysis of Beatrix Potter's work and its cultural significance in childhood development and identity formation.\n\n## Script  \n**Media Elements Referenced:**\n- {GFX/toads} → 1 toads.png\n- {SOT/frog-song} → frog song.mp4\n\n**Script Content:**\nMoving into our Beatrix Potter fantasy segment, we explore how children's literature shapes identity and provides frameworks for understanding the world.\n\nThe anthropomorphic characters in Potter's work - Peter Rabbit, Jemima Puddle-Duck, Mrs. Tiggy-Winkle - offer children models for behavior, consequence, and moral development.\n\n[Full segment content from original script lines 163-178]	2025-09-07 00:00:00		Beatrix Potter works, children literature analysis	beatrix potter, children, literature, fantasy, identity	Generated for episode 0239 segmentation	\N	medium	\N	draft	2025-09-16 11:15:55.200852+00	2025-10-03 18:18:37.214501+00	f	## Notes\nCultural commentary on children's literature and its role in identity formation and fantasy development.\n\n## Description\nAnalysis of Beatrix Potter's work and its cultural significance in childhood development and identity formation.\n\n## Script  \n**Media Elements Referenced:**\n- {GFX/toads} → 1 toads.png\n- {SOT/frog-song} → frog song.mp4\n\n**Script Content:**\nMoving into our Beatrix Potter fantasy segment, we explore how children's literature shapes identity and provides frameworks for understanding the world.\n\nThe anthropomorphic characters in Potter's work - Peter Rabbit, Jemima Puddle-Duck, Mrs. Tiggy-Winkle - offer children models for behavior, consequence, and moral development.\n\n[Full segment content from original script lines 163-178]	\N
15	SEGMF8N6N7T9VXB1F	4	\N	segment	Dress You Up in Ornamentation	dress-you-up	80	00:08:00	Madonna and pop culture analysis	## Notes\nPop culture analysis focusing on Madonna's music and its cultural impact on identity and self-expression.\n\n## Description\nExtended analysis of Madonna's music, particularly focusing on themes of identity, ornamentation, and cultural impact.\n\n## Script\n**Media Elements Referenced:**\n- {SOT/bach-minuet-major} → bach minuet major.mp4\n- {SOT/bach-minuet-minor} → bach minuet minor.mp4\n- {SOT/album-pink-cadillac} → album pink cadillace.mp4\n- {SOT/radio-pink-cadillac} → radio pink cadillac.mp4\n- {SOT/two-of-hearts-stacey} → two of hearts stacey.mp4\n- {SOT/radio-like-a-prayer} → radio like a prayer.mp4\n- {SOT/dress-you-up} → dress you up.mp4\n\n**Script Content:**\nOur final segment explores Madonna's cultural impact and the psychology of ornamentation in popular music. The concept of "dressing up" extends beyond clothing into identity construction and performance.\n\nMadonna's "Dress You Up" represents the ultimate expression of artifice as authenticity - the idea that we become real through performance and decoration.\n\n[Full segment content from original script lines 179-end]	2025-09-07 00:00:00		Madonna discography, pop culture analysis	madonna, pop culture, music, identity, ornamentation	Generated for episode 0239 segmentation	\N	medium	\N	draft	2025-09-16 11:15:55.200852+00	2025-10-03 18:18:37.218074+00	f	## Notes\nPop culture analysis focusing on Madonna's music and its cultural impact on identity and self-expression.\n\n## Description\nExtended analysis of Madonna's music, particularly focusing on themes of identity, ornamentation, and cultural impact.\n\n## Script\n**Media Elements Referenced:**\n- {SOT/bach-minuet-major} → bach minuet major.mp4\n- {SOT/bach-minuet-minor} → bach minuet minor.mp4\n- {SOT/album-pink-cadillac} → album pink cadillace.mp4\n- {SOT/radio-pink-cadillac} → radio pink cadillac.mp4\n- {SOT/two-of-hearts-stacey} → two of hearts stacey.mp4\n- {SOT/radio-like-a-prayer} → radio like a prayer.mp4\n- {SOT/dress-you-up} → dress you up.mp4\n\n**Script Content:**\nOur final segment explores Madonna's cultural impact and the psychology of ornamentation in popular music. The concept of "dressing up" extends beyond clothing into identity construction and performance.\n\nMadonna's "Dress You Up" represents the ultimate expression of artifice as authenticity - the idea that we become real through performance and decoration.\n\n[Full segment content from original script lines 179-end]	\N
\.


--
-- Data for Name: rundown_items_legacy; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.rundown_items_legacy (id, episode_id, asset_id, slug, type, "order", title, description, duration, priority, status, script_content, notes, resources, guests, tags, created_at, updated_at, file_path, is_test_data) FROM stdin;
\.


--
-- Data for Name: rundowns; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.rundowns (id, asset_id, episode_id, name, description, order_in_episode, estimated_duration, status, created_at, updated_at) FROM stdin;
1	RUND8AX520WY1	1	Default Rundown	Auto-created rundown for standalone items	0	\N	draft	2025-08-16 15:41:40.813318+00	\N
3	ASTMFMGIV8BZF5SF8	6	Main Rundown	Rundown for Episode 238 - Keri Smith	1	\N	draft	2025-09-16 11:15:55.173805+00	\N
4	ASTMFMGIV960OJRIF	7	Main Rundown	Rundown for The Princess and the Pea	1	\N	draft	2025-09-16 11:15:55.200852+00	\N
6	ASTMFMGRRWF7TC15C	8	Main Rundown	Rundown for The Turning Point	1	\N	draft	2025-09-16 11:22:50.755516+00	\N
9	ASTMFMGUNIY1T7V0J	3	Main Rundown	Rundown for Episode 236	1	\N	draft	2025-09-16 11:25:05.057383+00	\N
18	RUN21	21	Main Rundown	Main rundown for episode 0241	0	\N	draft	2025-09-21 03:43:06.658199+00	\N
19	RUNMG07Q6WBURPDRT	22	Episode 0242 Rundown	\N	0	\N	draft	2025-09-26 02:18:26.795048+00	\N
23	RUNMGC47MFBBM2VHS	25	Episode 0243 Rundown	\N	0	\N	draft	2025-10-04 10:13:15.719007+00	\N
26	RUNMGMG13VKT7MHEU	28	Episode 0244 Rundown	\N	0	\N	draft	2025-10-11 15:41:48.89606+00	\N
\.


--
-- Data for Name: scripts; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.scripts (id, asset_id, segment_id, role, content, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: seasons; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.seasons (id, asset_id, show_id, name, number, slug, created_at, updated_at) FROM stdin;
1	SSNA0DTJNAYVN	2	Default Season	1	default-season	2025-08-16 15:39:10.681475+00	\N
\.


--
-- Data for Name: segments; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.segments (id, asset_id, episode_id, rundown_type, title, slug, "order", description, tags, thumbnail_url, estimated_duration, actual_duration, in_point, out_point, markers, publishable, published_platforms, created_at, updated_at) FROM stdin;
1	SEGMEEFAFL4C5RT2B	1	SEGMENT	test-segment	test-segment	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-16 15:39:30.287115+00	\N
2	SEGMEEJ3TNWZ5IUEO	\N	SEGMENT	news updates	news updates	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-16 17:26:20.40291+00	\N
3	SEGMEEJ3YD0OKZM7D	\N	SEGMENT	Biltong	Biltong	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-16 17:26:26.494607+00	\N
4	SEGMEEJ44L61P9LZV	\N	SEGMENT	man up	man up	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-16 17:26:34.564141+00	\N
5	SEGMEEJ4JNYVA02T4	\N	SEGMENT	Support our work	Support our work	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-16 17:26:54.105248+00	\N
6	SEGMEEJ56401DC7UN	\N	SEGMENT	borderline wild	borderline wild	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-16 17:27:23.194399+00	\N
7	SEGMEEJ5H1D9I4K1D	\N	SEGMENT	potpourri	potpourri	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-16 17:27:37.354315+00	\N
8	SEGMEENCPXQ375N35	\N	SEGMENT	slocum consulting	slocum consulting	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-16 19:25:14.024959+00	\N
9	SEGMEEOBAPUJXSG4D	\N	SEGMENT	type: promo	type: promo	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-16 19:52:07.17273+00	\N
10	SEGMEEUGQPOVKPL0G	\N	SEGMENT	Untitled Segment	segment-POVKPL0G	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-16 22:44:18.880865+00	\N
11	SEGMENI0G7NHDS95Y	\N	SEGMENT	segment	segment	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-23 00:05:38.973465+00	\N
12	SEGMENJX099GXB5YW	\N	SEGMENT	segment	segment	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-23 00:58:57.551934+00	\N
13	SEGMENN1KTT4WZ9IA	\N	SEGMENT	segment	segment	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-23 02:26:29.691196+00	\N
14	SEGMENNHZMNHN1OLZ	\N	SEGMENT	segment	segment	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-23 02:39:15.369005+00	\N
15	SEGMENNWG7MZFJ7T4	\N	SEGMENT	segment	segment	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-23 02:50:30.044715+00	\N
16	SEGMENO45GP697XFT	\N	SEGMENT	female narcissism	female narcissism	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-23 02:56:29.363266+00	\N
17	SEGMENO4J9M1S526M	\N	SEGMENT	segment	segment	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-23 02:56:47.25253+00	\N
18	SEGMEOFKUYOZE0Y76	\N	SEGMENT	type: coldopen	type: coldopen	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-23 15:45:18.537693+00	\N
19	SEGMEOIYLBRXWRRFC	\N	SEGMENT	segment	segment	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-23 17:19:58.082835+00	\N
20	SEGMEOIZJ66BP0L2S	\N	SEGMENT	type: segment	type: segment	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-23 17:20:41.944314+00	\N
21	SEGMEOJ3IIYIR5I9H	\N	SEGMENT	60 Cracker Barrel	60 Cracker Barrel	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-23 17:23:47.733068+00	\N
22	SEGMEOJ449DRJ4QTV	\N	SEGMENT	taylor swift	taylor swift	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-23 17:24:15.891226+00	\N
23	SEGMEOJ4VJG38C2GD	\N	SEGMENT	segment	segment	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-23 17:24:51.252033+00	\N
24	SEGMEOJ57H90X3NHF	\N	SEGMENT	type: segment	type: segment	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-23 17:25:06.727869+00	\N
25	SEGMEOJK6D4V67EAJ	\N	SEGMENT	Slocum Consulting	Slocum Consulting	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-23 17:36:45.122117+00	\N
26	SEGMEOOMWQVHLKPE7	\N	SEGMENT	Untitled Segment	segment-QVHLKPE7	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-23 19:58:50.705234+00	\N
27	SEGMEXLBQBFLD4KQB	\N	SEGMENT	type: coldopen	type: coldopen	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-08-30 01:36:05.889581+00	\N
28	SEGMFT39C7Q8V9TWE	\N	SEGMENT	we're all manson girl	we're all manson girl	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-09-21 02:38:58.843562+00	\N
29	SEGMFT39CEVMP5WD9	\N	SEGMENT	cancel culture	cancel culture	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-09-21 02:38:59.099385+00	\N
30	SEGMFT39CFXRU8V4P	\N	SEGMENT	family insane	family insane	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-09-21 02:38:59.135337+00	\N
31	SEGMFT39CG6TYWMQB	\N	SEGMENT	Potpourri du Moquerie	Potpourri du Moquerie	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-09-21 02:38:59.145026+00	\N
36	SEGMG2KVSDL9HUS78	22	SEGMENT	this-weeks-news-a	this-weeks-news-a	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-09-27 18:02:15.279026+00	\N
37	SEGMG2KVVKRJ8HDCU	22	SEGMENT	forgiveness-and-erika-kirk-b	forgiveness-and-erika-kirk-b	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-09-27 18:02:19.423428+00	\N
38	SEGMG2LYDS65PWXQP	22	SEGMENT	daughters-tale-part-ii	daughters-tale-part-ii	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-09-27 18:32:15.946766+00	\N
39	SEGMG2LYH4QI36OI8	22	SEGMENT	support-us	support-us	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-09-27 18:32:20.285161+00	\N
40	SEGMG2LYK9O94ADTY	22	SEGMENT	slocum-consulting	slocum-consulting	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-09-27 18:32:24.351839+00	\N
41	SEGMG2LYNNLI3QNKQ	22	SEGMENT	harrison-koehli-conversation	harrison-koehli-conversation	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-09-27 18:32:28.739894+00	\N
42	SEGMG6F5RUOT8UBY2	\N	SEGMENT	test-segment	test-segment	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-09-30 10:33:08.165307+00	\N
43	SEGMG6G2WEO27B0E4	\N	SEGMENT	untitled-tease	untitled-tease	1	\N	[]	\N	180	\N	\N	\N	[]	t	{}	2025-09-30 10:58:53.714087+00	\N
45	SEGMG6GH8ZH3E23PK	21	SEGMENT	Test Segment 2	test-segment-2	45	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2025-09-30 11:10:03.197741+00	2025-09-30 11:10:03.197741+00
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.settings (id, key, value, category, user_id, description, created_at, updated_at) FROM stdin;
12	show_item_numbers	true	rundown	\N	Rundown setting: show_item_numbers	2025-09-02 10:58:48.617548+00	2025-10-09 15:32:41.034284+00
3	enumerate_rundown_markdown_files	true	rundown	\N	Enumerate Rundown Item markdown files with order number	2025-09-02 07:53:41.981982+00	2025-10-09 15:32:41.034284+00
4	auto_number_rundown_items	true	rundown	\N	Auto-number rundown items	2025-09-02 07:53:41.981982+00	2025-10-09 15:32:41.034284+00
5	default_segment_duration	"00:05:00"	rundown	\N	Rundown setting: default_segment_duration	2025-09-02 10:58:48.617548+00	2025-10-09 15:32:41.034284+00
6	enable_timecode	true	rundown	\N	Rundown setting: enable_timecode	2025-09-02 10:58:48.617548+00	2025-10-09 15:32:41.034284+00
7	timecode_format	"HH:MM:SS"	rundown	\N	Rundown setting: timecode_format	2025-09-02 10:58:48.617548+00	2025-10-09 15:32:41.034284+00
8	show_cumulative_time	true	rundown	\N	Rundown setting: show_cumulative_time	2025-09-02 10:58:48.617548+00	2025-10-09 15:32:41.034284+00
9	enable_drag_drop	true	rundown	\N	Rundown setting: enable_drag_drop	2025-09-02 10:58:48.617548+00	2025-10-09 15:32:41.034284+00
10	auto_calculate_duration	true	rundown	\N	Rundown setting: auto_calculate_duration	2025-09-02 10:58:48.617548+00	2025-10-09 15:32:41.034284+00
11	warn_on_delete	true	rundown	\N	Rundown setting: warn_on_delete	2025-09-02 10:58:48.617548+00	2025-10-09 15:32:41.034284+00
2	theme_settings_default	{"theme": "dark"}	theme	\N	Theme settings for 'default' profile	2025-08-13 14:36:40.12776+00	2025-10-09 15:32:41.034284+00
20	llm_routing	{"key": "llm_routing", "value": {"key": "llm_routing", "value": {"key": "llm_routing", "value": {"key": "llm_routing", "value": {"prompts": [{"name": "Quote Splitter", "enabled": true, "category": "formatting", "template": "Split this quote into segments of maximum {maxWords} words each. Maintain natural sentence boundaries and preserve meaning. If this submission is not wrapped in quotes, assume it should be and correct for any nested quotes inside the overall quote:\\n\\n\\"{quote}\\"\\n\\nReturn ONLY a JSON array of strings.", "maxTokens": 500, "temperature": 0.3, "preferredService": "auto"}, {"name": "Slug Generator", "enabled": true, "category": "formatting", "template": "Generate a short, SEO-friendly slug (5-8 words max) for this text. Use lowercase, hyphens, no special characters:\\n\\n\\"{title}\\"\\n\\nReturn ONLY the slug.", "maxTokens": 50, "temperature": 0.5, "preferredService": "auto"}, {"name": "Script Summarizer", "enabled": true, "category": "summarization", "template": "Summarize this script segment in 2-3 sentences:\\n\\n{script}\\n\\nFocus on key points and main message.", "maxTokens": 200, "temperature": 0.7, "preferredService": "auto"}, {"name": "Segment Generator (Tease)", "enabled": true, "category": "development", "template": "RUNDOWN ITEM TYPE DEFINITIONS:\\n- Cold Open: Opening hook before any intro/music. Grabs attention instantly with compelling question, shocking statement, or intriguing scenario. Sets episode tone. No explanations - just hook. 30-90 seconds.\\n- Tease: Preview of upcoming segments to keep listeners engaged. Builds curiosity without spoiling details. References specific upcoming topics. Brief and energetic. Appears before breaks or at show start.\\n- Segment: Main content blocks. In-depth discussion, analysis, interviews, storytelling. Educational yet engaging. Conversational tone. 5-15 minutes.\\n- Ad: Commercial advertisement with sponsor name, product description, benefits, pricing, clear call-to-action.\\n- Promo: Promotional content for the show, network shows, events, or membership offers.\\n\\nYOU ARE WRITING: TEASE\\n\\nWrite a {duration}-minute podcast tease/preview for a true crime podcast that examines manipulation tactics and abuse dynamics common to Cluster B personality disorders (narcissistic, borderline, antisocial, histrionic).\\n\\nThis tease should hook listeners and preview what's coming up in the show.{upcomingSegments}\\n\\nWrite {paragraphs} short, punchy paragraphs that build anticipation.\\n\\nStyle requirements:\\n- Create urgency and intrigue\\n- Tease topics without spoiling details\\n- Use vivid, compelling language\\n- Build curiosity about upcoming segments\\n- Keep it brief and energetic\\n\\nCRITICAL FORMATTING:\\n- Separate each paragraph with TWO newlines (blank line between paragraphs)\\n- Format: Plain paragraph text, ready to paste into script\\n- No titles, no metadata, just the tease content\\n\\nDO NOT include any introductory text like \\"Here is the tease\\" - start IMMEDIATELY with the first paragraph of actual content.\\n\\nGenerate the tease now:", "maxTokens": 1000, "temperature": 0.8, "preferredService": "ollama"}, {"name": "Segment Generator (Cold Open)", "enabled": true, "category": "development", "template": "RUNDOWN ITEM TYPE DEFINITIONS:\\n- Cold Open: Opening hook before any intro/music. Grabs attention instantly with compelling question, shocking statement, or intriguing scenario. Sets episode tone. No explanations - just hook. 30-90 seconds.\\n- Tease: Preview of upcoming segments to keep listeners engaged. Builds curiosity without spoiling details. References specific upcoming topics. Brief and energetic. Appears before breaks or at show start.\\n- Segment: Main content blocks. In-depth discussion, analysis, interviews, storytelling. Educational yet engaging. Conversational tone. 5-15 minutes.\\n- Ad: Commercial advertisement with sponsor name, product description, benefits, pricing, clear call-to-action.\\n- Promo: Promotional content for the show, network shows, events, or membership offers.\\n\\nYOU ARE WRITING: COLD OPEN\\n\\nWrite a {duration}-minute cold open for a true crime podcast that examines manipulation tactics and abuse dynamics common to Cluster B personality disorders (narcissistic, borderline, antisocial, histrionic).\\n\\nA cold open should immediately grab attention with a compelling hook - a powerful question, shocking statement, or intriguing scenario.\\n\\nWrite {paragraphs} paragraphs.\\n\\nStyle requirements:\\n- Start with maximum impact - hook listeners instantly\\n- Create immediate tension or curiosity\\n- Use vivid, cinematic language\\n- Set the tone for the episode\\n- Don't explain everything - leave them wanting more\\n\\nCRITICAL FORMATTING:\\n- Separate each paragraph with TWO newlines (blank line between paragraphs)\\n- Format: Plain paragraph text, ready to paste into script\\n- No titles, no metadata, just the cold open content\\n\\nDO NOT include any introductory text - start IMMEDIATELY with the hook.\\n\\nGenerate the cold open now:", "maxTokens": 1500, "temperature": 0.8, "preferredService": "ollama"}, {"name": "Segment Generator (Standard)", "enabled": true, "category": "development", "template": "RUNDOWN ITEM TYPE DEFINITIONS:\\n- Cold Open: Opening hook before any intro/music. Grabs attention instantly with compelling question, shocking statement, or intriguing scenario. Sets episode tone. No explanations - just hook. 30-90 seconds.\\n- Tease: Preview of upcoming segments to keep listeners engaged. Builds curiosity without spoiling details. References specific upcoming topics. Brief and energetic. Appears before breaks or at show start.\\n- Segment: Main content blocks. In-depth discussion, analysis, interviews, storytelling. Educational yet engaging. Conversational tone. 5-15 minutes.\\n- Ad: Commercial advertisement with sponsor name, product description, benefits, pricing, clear call-to-action.\\n- Promo: Promotional content for the show, network shows, events, or membership offers.\\n\\nYOU ARE WRITING: SEGMENT\\n\\nWrite a {duration}-minute podcast segment for a true crime podcast that examines manipulation tactics and abuse dynamics common to Cluster B personality disorders (narcissistic, borderline, antisocial, histrionic).\\n\\nWrite {paragraphs} paragraphs.\\n\\nStyle requirements:\\n- Speak directly to podcast listeners in conversational, engaging tone\\n- Use real psychological concepts but fictional case examples\\n- Include specific manipulation tactics (gaslighting, love-bombing, triangulation, DARVO, hoovering)\\n- Reference clinical patterns while remaining accessible\\n- Maintain journalistic credibility and empathy for victims\\n- DO NOT use real names or identify real cases\\n\\nCRITICAL FORMATTING:\\n- Separate each paragraph with TWO newlines (blank line between paragraphs)\\n- Example format:\\n  First paragraph text here.\\n\\n  Second paragraph text here.\\n\\n  Third paragraph text here.\\n\\nFormat: Plain paragraph text, ready to paste into script. No titles, no metadata, just the segment content with blank lines between paragraphs.\\n\\nDO NOT include any introductory text like \\"Here is the podcast segment\\" or \\"Here you go\\" - start IMMEDIATELY with the first paragraph of actual content.\\n\\nGenerate the segment now:", "maxTokens": 2000, "temperature": 0.8, "preferredService": "ollama"}], "routing": {"factChecking": "auto", "peopleSearch": "auto", "socialSearch": "auto", "fallbackOrder": ["ollama", "openai", "anthropic", "gemini", "grok"], "scriptSummary": "auto", "enableFallback": true, "quoteSplitting": "auto", "slugGeneration": "auto", "tweetComposing": "auto", "titleGeneration": "auto", "contentExpansion": "grok:grok-4-latest", "entityExtraction": "auto"}}, "category": "generation"}, "prompts": [{"name": "Quote Splitter", "enabled": true, "category": "formatting", "template": "Split this quote into segments of maximum {maxWords} words each. Maintain natural sentence boundaries and preserve meaning:\\n\\n\\"{quote}\\"\\n\\nReturn ONLY a JSON array of strings.", "maxTokens": 500, "temperature": 0.3, "preferredService": "auto"}, {"name": "Slug Generator", "enabled": true, "category": "formatting", "template": "Generate a short, SEO-friendly slug (5-8 words max) for this text. Use lowercase, hyphens, no special characters:\\n\\n\\"{title}\\"\\n\\nReturn ONLY the slug.", "maxTokens": 50, "temperature": 0.5, "preferredService": "auto"}, {"name": "Script Summarizer", "enabled": true, "category": "summarization", "template": "Summarize this script segment in 2-3 sentences:\\n\\n{script}\\n\\nFocus on key points and main message.", "maxTokens": 200, "temperature": 0.7, "preferredService": "auto"}, {"name": "Segment Generator (Tease)", "enabled": true, "category": "development", "template": "RUNDOWN ITEM TYPE DEFINITIONS:\\n- Cold Open: Opening hook before any intro/music. Grabs attention instantly with compelling question, shocking statement, or intriguing scenario. Sets episode tone. No explanations - just hook. 30-90 seconds.\\n- Tease: Preview of upcoming segments to keep listeners engaged. Builds curiosity without spoiling details. References specific upcoming topics. Brief and energetic. Appears before breaks or at show start.\\n- Segment: Main content blocks. In-depth discussion, analysis, interviews, storytelling. Educational yet engaging. Conversational tone. 5-15 minutes.\\n- Ad: Commercial advertisement with sponsor name, product description, benefits, pricing, clear call-to-action.\\n- Promo: Promotional content for the show, network shows, events, or membership offers.\\n\\nYOU ARE WRITING: TEASE\\n\\nWrite a {duration}-minute podcast tease/preview for a true crime podcast that examines manipulation tactics and abuse dynamics common to Cluster B personality disorders (narcissistic, borderline, antisocial, histrionic).\\n\\nThis tease should hook listeners and preview what's coming up in the show.{upcomingSegments}\\n\\nWrite {paragraphs} short, punchy paragraphs that build anticipation.\\n\\nStyle requirements:\\n- Create urgency and intrigue\\n- Tease topics without spoiling details\\n- Use vivid, compelling language\\n- Build curiosity about upcoming segments\\n- Keep it brief and energetic\\n\\nCRITICAL FORMATTING:\\n- Separate each paragraph with TWO newlines (blank line between paragraphs)\\n- Format: Plain paragraph text, ready to paste into script\\n- No titles, no metadata, just the tease content\\n\\nDO NOT include any introductory text like \\"Here is the tease\\" - start IMMEDIATELY with the first paragraph of actual content.\\n\\nGenerate the tease now:", "maxTokens": 1000, "temperature": 0.8, "preferredService": "ollama"}, {"name": "Segment Generator (Cold Open)", "enabled": true, "category": "development", "template": "RUNDOWN ITEM TYPE DEFINITIONS:\\n- Cold Open: Opening hook before any intro/music. Grabs attention with a poetic high-level convenance of what the show is about.  Usually dissonant and a bit uncomfortable.  Almost always ends on a punchy question.  Always reads between 43 and 45 seconds.\\n- Tease: Preview of upcoming segments to keep listeners engaged. Builds curiosity without spoiling details. References specific upcoming topics. Brief and energetic. Appears before breaks or at show start.\\n- Segment: Main content blocks. In-depth discussion, analysis, interviews, storytelling. Educational yet engaging. Conversational tone. 5-15 minutes.\\n- Ad: Commercial advertisement with sponsor name, product description, benefits, pricing, clear call-to-action.\\n- Promo: Promotional content for the show, network shows, events, or membership offers.\\n\\nYOU ARE WRITING: COLD OPEN\\n\\nWrite a {duration}-second cold open for a dark and disordered late-night podcast that examines manipulation tactics and abuse dynamics common to Cluster B personality disorders (narcissistic, borderline, antisocial, histrionic).\\n\\nA cold open should immediately grab attention with a compelling hook - a powerful question, shocking statement, or intriguing scenario.  Its almost, if not, poetic.\\n\\nWrite {paragraphs} paragraphs.\\n\\nStyle requirements:\\n- Start with maximum impact - hook listeners instantly\\n- Create immediate tension or curiosity\\n- Use vivid, cinematic language\\n- Set the tone for the episode\\n- Don't explain everything - leave them wanting more\\n\\nCRITICAL FORMATTING:\\n- Separate each paragraph with TWO newlines (blank line between paragraphs)\\n- Format: Plain paragraph text, ready to paste into script\\n- No titles, no metadata, just the cold open content\\n\\nDO NOT include any introductory text - start IMMEDIATELY with the text to the cold open.\\n\\nGenerate the cold open now:", "maxTokens": 1500, "temperature": 1.1, "preferredService": "ollama"}, {"name": "Segment Generator (Standard)", "enabled": true, "category": "development", "template": "RUNDOWN ITEM TYPE DEFINITIONS:\\n- Cold Open: Opening hook before any intro/music. Grabs attention instantly with compelling question, shocking statement, or intriguing scenario. Sets episode tone. No explanations - just hook. 30-90 seconds.\\n- Tease: Preview of upcoming segments to keep listeners engaged. Builds curiosity without spoiling details. References specific upcoming topics. Brief and energetic. Appears before breaks or at show start.\\n- Segment: Main content blocks. In-depth discussion, analysis, interviews, storytelling. Educational yet engaging. Conversational tone. 5-15 minutes.\\n- Ad: Commercial advertisement with sponsor name, product description, benefits, pricing, clear call-to-action.\\n- Promo: Promotional content for the show, network shows, events, or membership offers.\\n\\nYOU ARE WRITING: SEGMENT\\n\\nWrite a {duration}-minute podcast segment for a true crime podcast that examines manipulation tactics and abuse dynamics common to Cluster B personality disorders (narcissistic, borderline, antisocial, histrionic).\\n\\nWrite {paragraphs} paragraphs.\\n\\nStyle requirements:\\n- Speak directly to podcast listeners in conversational, engaging tone\\n- Use real psychological concepts but fictional case examples\\n- Include specific manipulation tactics (gaslighting, love-bombing, triangulation, DARVO, hoovering)\\n- Reference clinical patterns while remaining accessible\\n- Maintain journalistic credibility and empathy for victims\\n- DO NOT use real names or identify real cases\\n\\nCRITICAL FORMATTING:\\n- Separate each paragraph with TWO newlines (blank line between paragraphs)\\n- Example format:\\n  First paragraph text here.\\n\\n  Second paragraph text here.\\n\\n  Third paragraph text here.\\n\\nFormat: Plain paragraph text, ready to paste into script. No titles, no metadata, just the segment content with blank lines between paragraphs.\\n\\nDO NOT include any introductory text like \\"Here is the podcast segment\\" or \\"Here you go\\" - start IMMEDIATELY with the first paragraph of actual content.\\n\\nGenerate the segment now:", "maxTokens": 2000, "temperature": 0.8, "preferredService": "ollama"}], "category": "generation"}, "prompts": [{"name": "Quote Splitter", "enabled": true, "category": "formatting", "template": "Split this quote into segments of maximum {maxWords} words each. Maintain natural sentence boundaries and preserve meaning:\\n\\n\\"{quote}\\"\\n\\nReturn ONLY a JSON array of strings.", "maxTokens": 500, "temperature": 0.3, "preferredService": "auto"}, {"name": "Slug Generator", "enabled": true, "category": "formatting", "template": "Generate a short, SEO-friendly slug (5-8 words max) for this text. Use lowercase, hyphens, no special characters:\\n\\n\\"{title}\\"\\n\\nReturn ONLY the slug.", "maxTokens": 50, "temperature": 0.5, "preferredService": "auto"}, {"name": "Script Summarizer", "enabled": true, "category": "summarization", "template": "Summarize this script segment in 2-3 sentences:\\n\\n{script}\\n\\nFocus on key points and main message.", "maxTokens": 200, "temperature": 0.7, "preferredService": "auto"}, {"name": "Segment Generator (Tease)", "enabled": true, "category": "development", "template": "RUNDOWN ITEM TYPE DEFINITIONS:\\n- Cold Open: Opening hook before any intro/music. Grabs attention instantly with compelling question, shocking statement, or intriguing scenario. Sets episode tone. No explanations - just hook. 30-90 seconds.\\n- Tease: Preview of upcoming segments to keep listeners engaged. Builds curiosity without spoiling details. References specific upcoming topics. Brief and energetic. Appears before breaks or at show start.\\n- Segment: Main content blocks. In-depth discussion, analysis, interviews, storytelling. Educational yet engaging. Conversational tone. 5-15 minutes.\\n- Ad: Commercial advertisement with sponsor name, product description, benefits, pricing, clear call-to-action.\\n- Promo: Promotional content for the show, network shows, events, or membership offers.\\n\\nYOU ARE WRITING: TEASE\\n\\nWrite a {duration}-minute podcast tease/preview for a true crime podcast that examines manipulation tactics and abuse dynamics common to Cluster B personality disorders (narcissistic, borderline, antisocial, histrionic).\\n\\nThis tease should hook listeners and preview what's coming up in the show.{upcomingSegments}\\n\\nWrite {paragraphs} short, punchy paragraphs that build anticipation.\\n\\nStyle requirements:\\n- Create urgency and intrigue\\n- Tease topics without spoiling details\\n- Use vivid, compelling language\\n- Build curiosity about upcoming segments\\n- Keep it brief and energetic\\n\\nCRITICAL FORMATTING:\\n- Separate each paragraph with TWO newlines (blank line between paragraphs)\\n- Format: Plain paragraph text, ready to paste into script\\n- No titles, no metadata, just the tease content\\n\\nDO NOT include any introductory text like \\"Here is the tease\\" - start IMMEDIATELY with the first paragraph of actual content.\\n\\nGenerate the tease now:", "maxTokens": 1000, "temperature": 0.8, "preferredService": "ollama"}, {"name": "Segment Generator (Cold Open)", "enabled": true, "category": "development", "template": "YOU ARE WRITING: COLD OPEN\\n\\nCOLD OPEN DEFINITION:\\nA cold open is the voice, music, and graphics display for the show.  Its a hard-hitting hook that grabs the viewers attention instantly with compelling questions, shocking statements, or intriguing scenarios. Sets episode tone.  It is meant to leave the viewer a little uncomfortable by making them answer questions in their own mind that make them question what they believed to be true.  Its 43-46 seconds long.\\n\\n\\nWrite a 45-second long cold open monologue assuming a speaker reading at 165 words per minute.  You are writing the cold open for a tv show about the truly dark and discorded that examines manipulation tactics and abuse dynamics common to Cluster B personality disorders (narcissistic, borderline, antisocial, histrionic).  \\n\\nA cold open should immediately grab attention with a compelling hook - a powerful question, shocking statement, or intriguing scenario.\\n\\nWrite as many or as few paragraphs as needed to comfortably make the read 45-seconds.\\n\\nDo not include any parentheticals or labels.  Do not return speaker names or anything other than the text to the cold open. \\n\\nReturn only the text to the cold open.\\n\\nStyle requirements:\\n- Start with maximum impact - hook listeners instantly\\n- Create immediate tension or curiosity\\n- Use vivid, cinematic language\\n- Set the tone for the episode\\n- Don't explain everything - leave them wanting more\\n\\nCRITICAL FORMATTING:\\n- Separate each paragraph with TWO newlines (blank line between paragraphs)\\n- Format: Plain paragraph text, ready to paste into script\\n- No titles, no metadata, just the cold open content\\n\\nDO NOT include any introductory text - start IMMEDIATELY with the hook.\\n\\nGenerate the cold open now:", "maxTokens": 1500, "temperature": 0.8, "preferredService": "ollama"}, {"name": "Segment Generator (Standard)", "enabled": true, "category": "development", "template": "RUNDOWN ITEM TYPE DEFINITIONS:\\n- Cold Open: Opening hook before any intro/music. Grabs attention instantly with compelling question, shocking statement, or intriguing scenario. Sets episode tone. No explanations - just hook. 30-90 seconds.\\n- Tease: Preview of upcoming segments to keep listeners engaged. Builds curiosity without spoiling details. References specific upcoming topics. Brief and energetic. Appears before breaks or at show start.\\n- Segment: Main content blocks. In-depth discussion, analysis, interviews, storytelling. Educational yet engaging. Conversational tone. 5-15 minutes.\\n- Ad: Commercial advertisement with sponsor name, product description, benefits, pricing, clear call-to-action.\\n- Promo: Promotional content for the show, network shows, events, or membership offers.\\n\\nYOU ARE WRITING: SEGMENT\\n\\nWrite a {duration}-minute podcast segment for a true crime podcast that examines manipulation tactics and abuse dynamics common to Cluster B personality disorders (narcissistic, borderline, antisocial, histrionic).\\n\\nWrite {paragraphs} paragraphs.\\n\\nStyle requirements:\\n- Speak directly to podcast listeners in conversational, engaging tone\\n- Use real psychological concepts but fictional case examples\\n- Include specific manipulation tactics (gaslighting, love-bombing, triangulation, DARVO, hoovering)\\n- Reference clinical patterns while remaining accessible\\n- Maintain journalistic credibility and empathy for victims\\n- DO NOT use real names or identify real cases\\n\\nCRITICAL FORMATTING:\\n- Separate each paragraph with TWO newlines (blank line between paragraphs)\\n- Example format:\\n  First paragraph text here.\\n\\n  Second paragraph text here.\\n\\n  Third paragraph text here.\\n\\nFormat: Plain paragraph text, ready to paste into script. No titles, no metadata, just the segment content with blank lines between paragraphs.\\n\\nDO NOT include any introductory text like \\"Here is the podcast segment\\" or \\"Here you go\\" - start IMMEDIATELY with the first paragraph of actual content.\\n\\nGenerate the segment now:", "maxTokens": 2000, "temperature": 0.8, "preferredService": "ollama"}], "category": "generation"}, "routing": {"fallbackOrder": ["ollama", "openai"], "enableFallback": true}, "category": "generation"}	llm	\N	LLM routing and prompt template configuration	2025-10-08 05:45:05.234229+00	2025-10-09 15:32:41.034284+00
101	template_library_path	"/mnt/sync/disaffected/templates"	generation	\N	\N	2025-10-08 19:56:41.330621+00	2025-10-09 15:32:41.034284+00
102	media_assets_path	"/mnt/sync/disaffected/media assets"	generation	\N	\N	2025-10-08 19:56:41.330621+00	2025-10-09 15:32:41.034284+00
50	fsq_background_video	"/assets/preview-background.mp4"	generation	\N	\N	2025-10-08 18:38:31.052024+00	2025-10-09 15:32:41.034284+00
75	fsq_min_second_screen	150	generation	\N	\N	2025-10-08 18:54:51.394754+00	2025-10-09 15:32:41.034284+00
76	fsq_split_strategy	"smart"	generation	\N	\N	2025-10-08 18:54:51.394754+00	2025-10-09 15:32:41.034284+00
77	fsq_balance_threshold_percent	30	generation	\N	\N	2025-10-08 18:54:51.394754+00	2025-10-09 15:32:41.034284+00
78	fsq_prefer_sentence_boundaries	true	generation	\N	\N	2025-10-08 18:54:51.394754+00	2025-10-09 15:32:41.034284+00
79	fsq_allow_mid_sentence_split	false	generation	\N	\N	2025-10-08 18:54:51.394754+00	2025-10-09 15:32:41.034284+00
80	fsq_overflow_handling	"multi_segment"	generation	\N	\N	2025-10-08 18:54:51.394754+00	2025-10-09 15:32:41.034284+00
51	fsq_max_lines	5	generation	\N	\N	2025-10-08 18:38:31.052024+00	2025-10-09 15:32:41.034284+00
52	fsq_chars_per_line	50	generation	\N	\N	2025-10-08 18:38:31.052024+00	2025-10-09 15:32:41.034284+00
44	episodes_folder	null	media_paths	\N	\N	2025-10-08 18:38:31.052024+00	2025-10-09 15:32:41.034284+00
45	media_assets	null	media_paths	\N	\N	2025-10-08 18:38:31.052024+00	2025-10-09 15:32:41.034284+00
46	uploads	null	media_paths	\N	\N	2025-10-08 18:38:31.052024+00	2025-10-09 15:32:41.034284+00
43	show_root	"/home"	media_paths	\N	\N	2025-10-08 18:38:31.052024+00	2025-10-09 15:32:41.034284+00
47	process	null	media_paths	\N	\N	2025-10-08 18:38:31.052024+00	2025-10-09 15:32:41.034284+00
48	archive_enabled	false	media_paths	\N	\N	2025-10-08 18:38:31.052024+00	2025-10-09 15:32:41.034284+00
49	archive_type	"s3"	media_paths	\N	\N	2025-10-08 18:38:31.052024+00	2025-10-09 15:32:41.034284+00
146	fsq_default_alignment	"left"	generation	\N	\N	2025-10-08 19:57:48.113984+00	2025-10-09 15:32:41.034284+00
147	fsq_default_font	"sans-serif"	generation	\N	\N	2025-10-08 19:57:48.113984+00	2025-10-09 15:32:41.034284+00
148	fsq_default_font_size	18	generation	\N	\N	2025-10-08 19:57:48.113984+00	2025-10-09 15:32:41.034284+00
149	fsq_include_attribution_by_default	true	generation	\N	\N	2025-10-08 19:57:48.113984+00	2025-10-09 15:32:41.034284+00
13	theme_colors_default	{"segment": "light-blue-darken-4", "ad": "cyan-darken-2", "promo": "cyan-lighten-2", "cta": "cyan-lighten-4", "live": "green-lighten-2", "tease": "teal-lighten-2", "tag": "indigo-lighten-1", "break": "blue-grey-darken-3", "block": "grey", "block-a": "blue", "block-b": "green", "block-c": "purple", "block-d": "red", "block-e": "orange", "block-f": "cyan", "block-g": "pink", "block-h": "yellow", "trans": "secondary", "pkg": "purple-lighten-1", "vo": "teal-lighten-1", "sot": "deep-orange-darken-1", "interview": "lime", "music": "orange", "reader": "indigo-darken-4", "gfx": "cyan", "fsq": "indigo-lighten-1", "nat": "light-green-darken-2", "img": "purple-lighten-1", "Selection-interface": "yellow-lighten-1", "selection": "yellow-lighten-1", "Hover-interface": "yellow-lighten-3", "hover": "yellow-lighten-3", "Highlight-interface": "yellow-lighten-4", "highlight": "yellow-lighten-4", "Dropline-interface": "deep-purple-darken-4", "dropline": "deep-purple-darken-4", "DragLight-interface": "deep-purple-lighten-4", "draglight": "deep-purple-lighten-4", "LocatorFlash-interface": "deep-orange-lighten-1", "locatorflash": "deep-orange-lighten-1", "Draft-script": "blue-grey", "draft": "blue-grey", "Approved-script": "light-green", "approved": "light-green", "Production-script": "blue", "production": "blue", "Promotion-script": "purple", "promotion": "purple", "Completed-script": "deep-orange-darken-4", "completed": "deep-orange-darken-4"}	colors	\N	Theme color configuration for 'default' profile	2025-09-26 02:45:24.68042+00	2025-10-09 15:32:41.034284+00
\.


--
-- Data for Name: shows; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.shows (id, asset_id, organization_id, name, description, created_at, updated_at, settings, is_test_data) FROM stdin;
1	SHOWQAVRZJ9TUV5	1	Disaffected	dcdfs	2025-08-10 07:58:55.555599+00	2025-08-10 08:57:27.932954+00	{}	f
2	SHWA0DTJNAYVN	7	Default Show	\N	2025-08-16 15:39:10.681475+00	\N	{}	f
\.


--
-- Data for Name: sot_processing_jobs; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.sot_processing_jobs (id, temp_job_id, episode, slug, asset_id, current_phase, status, job_type, clips_data, error_message, retry_count, celery_task_id, working_directory, final_video_path, final_audio_path, final_thumbnail_path, created_at, updated_at) FROM stdin;
1	sot_20251011_192209_b82da28a	0244	Goodall Death Video	ASTMGMNYNLPK9P5GZ	phase1	processing	full_process	\N	\N	0	cb9c51eb-c130-4198-9003-5329383471f6	/shared_media/preproc/working/sot_20251011_192209_b82da28a	\N	\N	\N	2025-10-11 19:22:09.288005+00	2025-10-11 19:23:51.44834+00
2	sot_20251011_193422_76b8b998	0244	Goodall Death video	ASTMGMODWVIK0HGBP	phase1	processing	full_process	\N	\N	0	5c47e1c9-a400-4f3a-aac0-7a016aa50a02	/shared_media/preproc/working/sot_20251011_193422_76b8b998	\N	\N	\N	2025-10-11 19:34:22.562516+00	2025-10-11 19:35:43.314185+00
3	sot_20251011_200502_48271d6f	0244	Goodall Death Video	ASTMGMPKFVORV5Z46	phase1	processing	full_process	\N	\N	0	a36f2196-2125-46c4-b13b-38709174a786	/shared_media/preproc/working/sot_20251011_200502_48271d6f	\N	\N	\N	2025-10-11 20:05:02.271785+00	2025-10-11 20:08:47.506913+00
\.


--
-- Data for Name: speakers; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.speakers (id, name, slug, wpm, wpm_min, wpm_max, role, voice_type, language, accent, xtts_speaker_name, voice_sample_path, is_active, is_test_data, organization_id, show_id, created_at, updated_at, user_id) FROM stdin;
1	Josh	josh	165	140	190	host	\N	en	\N	\N	\N	t	f	1	\N	2025-10-07 06:28:55.215041+00	2025-10-07 06:28:55.215041+00	\N
2	Kevin	kevin	180	155	205	host	\N	en	\N	\N	\N	t	f	1	\N	2025-10-07 06:28:55.215041+00	2025-10-07 06:28:55.215041+00	\N
3	Guest Speaker	guest	150	130	170	guest	\N	en	\N	\N	\N	t	t	1	\N	2025-10-07 06:28:55.215041+00	2025-10-07 06:28:55.215041+00	\N
4	Kevin	kevin-voice	237	201.45	250	user	\N	en	\N	\N	/shared_media/voice_samples/user_1/sample_20251016_052221.wav	t	f	\N	\N	2025-10-16 05:22:21.350623+00	\N	1
\.


--
-- Data for Name: twitter_oauth_tokens; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.twitter_oauth_tokens (id, user_id, access_token, refresh_token, token_type, expires_at, scope, twitter_user_id, twitter_username, twitter_name, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_groups; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.user_groups (user_id, group_id, joined_at, added_by) FROM stdin;
\.


--
-- Data for Name: user_permission_overrides; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.user_permission_overrides (id, user_id, permission_id, is_granted, resource_type, resource_id, granted_at, granted_by, expires_at, reason) FROM stdin;
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.user_roles (user_id, role_id, assigned_at, assigned_by, expires_at) FROM stdin;
1	1	2025-08-13 13:00:27.045792+00	rbac-test	\N
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.user_sessions (id, session_token, username, ip_address, user_agent, created_at, expires_at, last_activity, is_active) FROM stdin;
\.


--
-- Data for Name: user_todos; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.user_todos (id, content, description, priority, status, created_by, created_at, updated_at, completed_at) FROM stdin;
2	Status Levels:  Review current status levels and suggest modified final format that compliments more appropriately the workflow of our show production.	\N	normal	pending	\N	2025-10-15 03:46:36.152959+00	\N	\N
3	Consolidation tool: Build a tool to manually consolidate episode directories in Syncthing with those in Google Drive.\nd	\N	high	pending	\N	2025-10-15 04:05:34.861762+00	2025-10-15 04:05:44.118529+00	\N
4	Remove the Scratch section from the content editor.  And make it available at its dedicated location under brainstorm.	\N	normal	pending	\N	2025-10-15 05:09:47.000526+00	\N	\N
5	Todo List Function:  Implement function to have llm take these todo items, and summarize them into a topic header and then preface the item with that topic header like "Scratch Functionality: {and then the users note}"\n	\N	normal	pending	\N	2025-10-15 05:13:18.87356+00	\N	\N
6	Dummy Content Generation Broken:   From within the content-editor , pressing  [ctl] + [shift] + [alt] + {any number} should generate that number of paragraphs for test content.  But it is failing to generate. needs fixed.	\N	normal	pending	\N	2025-10-15 06:01:28.389436+00	\N	\N
7	Status Indicator:  The status indicator in the top right is missing some items.  I know we just added the google drive api.  Please make sure  the status bar has a light for "goog" that shows green when google is available and working. 	\N	high	pending	\N	2025-10-15 11:09:39.951092+00	\N	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.users (id, username, hashed_password, access_level, first_name, last_name, email, phone, profile_picture, is_active, is_verified, created_at, updated_at, last_login, preferences, organization_id, is_test_data) FROM stdin;
5	josh	$2b$12$tm2Djjahq1PNo/NYzwEwJuS95xHhTXzIFPaK.V99GyeFr0iVQ92GK	user	Josh	Slocum	josh@disaffected.com			t	f	2025-10-03 15:45:00.976577+00	2025-10-11 01:18:03.485386+00	2025-10-11 01:18:03.485691+00	{}	\N	f
4	dev	$2b$12$M/Qqu/5pOMDQ24z7gD/zUO56eeKGFyzCCUX5FhcnilmDG8ABP33Wu	admin	Dev	User	dev@showbuild.local	555-0003		t	f	2025-08-12 07:40:26.818795+00	2025-08-30 14:11:14.613529+00	2025-08-30 14:11:14.613952+00	{}	\N	f
3	admin	$2b$12$xKH50ySM.LRZClMB1WS1Du9AP6/fMlOCGd6QpgZ1lhjBb31/V243O	admin	Admin	User	admin@example.com	\N	\N	t	t	2025-08-12 04:40:21.216425+00	2025-10-07 07:29:20.400214+00	2025-10-07 07:29:20.400573+00	{}	\N	f
1	kevin	$2b$12$nngsUrbIrotnUxoNVeh1l.Lbn5Zz8Mk0OxJn0CrAnWoY1lmI4iAKS	admin	Kevin					t	f	2025-08-10 06:09:35.210082+00	2025-10-19 17:19:42.154757+00	2025-10-19 17:19:42.154957+00	{}	1	f
\.


--
-- Data for Name: whiteboard_items; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.whiteboard_items (id, whiteboard_id, item_type, x_position, y_position, text_content, url, notes, image_data, caption, width, z_index, created_at, updated_at, preview_title, preview_description, preview_image, preview_domain, preview_favicon, social_metadata, title, asset_id, parent_item_id, is_child, video_url, audio_url, thumbnail_url, html_content, code_content, code_language, markdown_content, file_url, mime_type, file_size, collapsed) FROM stdin;
8	1	link	327	137.5	\N	https://x.com/realMaalouf/status/1979369186020212825	\N	\N	\N	500	1000	2025-10-18 09:10:26.369207+00	\N	\N	\N	\N	x.com	https://abs.twimg.com/favicons/twitter.3.ico	{"likes": 638, "quotes": 32, "replies": 184, "entities": {"urls": [{"end": 159, "url": "https://t.co/6zoTRwvAR0", "start": 136, "media_key": "13_1978783044900454400", "display_url": "pic.x.com/6zoTRwvAR0", "expanded_url": "https://x.com/clowndownunder/status/1978783553023300086/video/1"}], "annotations": [{"end": 41, "type": "Place", "start": 33, "probability": 0.9807, "normalized_text": "Australia"}]}, "platform": "x", "retweets": 141, "tweet_id": "1979369186020212825", "author_bio": "\\ud83d\\udea8Breaking News | \\u2694\\ufe0fHistory \\ud83d\\uddfa\\ufe0fGeopolitics", "media_urls": ["https://pbs.twimg.com/amplify_video_thumb/1978783044900454400/img/EwJwQ2_vlpfMzLaO.jpg"], "tweet_text": "A trans man converts to Islam in Australia.\\n\\nThe imam performing the conversion is unaware that he\\u2019s trans.\\n\\nHow will this story end?\\n\\n https://t.co/6zoTRwvAR0", "author_name": "Dr. Maalouf \\u200f", "author_avatar": "https://pbs.twimg.com/profile_images/1771658176200318976/zppeMEGD_normal.jpg", "author_handle": "realMaalouf", "published_time": "2025-10-18T02:09:23.000Z", "conversation_id": "1979369186020212825", "author_followers": 365376, "author_following": 1310}	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
45	3	link	821	79.5	\N	https://x.com/KamalaHarris/status/1979392929388204241	\N	\N	\N	500	1000	2025-10-19 18:04:24.971007+00	\N	\N	\N	\N	x.com	https://abs.twimg.com/favicons/twitter.3.ico	{"likes": 33365, "quotes": 679, "replies": 8550, "entities": {"urls": [{"end": 171, "url": "https://t.co/tAXlyqoamq", "start": 148, "media_key": "13_1979392384929579008", "display_url": "pic.x.com/tAXlyqoamq", "expanded_url": "https://x.com/KamalaHarris/status/1979392929388204241/video/1"}]}, "platform": "x", "retweets": 5482, "tweet_id": "1979392929388204241", "author_bio": "Always fighting for the people. Wife, Momala, Auntie. She/her. 107 Days available now.", "media_urls": ["https://pbs.twimg.com/media/G3g3OEwakAAnrie.jpg"], "tweet_text": "In our country, the power is with the people. Tomorrow, October 18, I encourage you to join your neighbors in peaceful protest at a No Kings event. https://t.co/tAXlyqoamq", "author_name": "Kamala Harris", "author_avatar": "https://pbs.twimg.com/profile_images/1592241313700782081/T2pTYU8d_normal.jpg", "author_handle": "KamalaHarris", "published_time": "2025-10-18T03:43:44.000Z", "conversation_id": "1979392929388204241", "author_followers": 20839436, "author_following": 704}	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f
\.


--
-- Data for Name: whiteboard_node_links; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.whiteboard_node_links (id, whiteboard_id, source_item_id, target_item_id, relationship_type, label, color, created_at) FROM stdin;
\.


--
-- Data for Name: whiteboards; Type: TABLE DATA; Schema: public; Owner: showbuild
--

COPY public.whiteboards (id, episode_number, workspace_id, name, created_by, created_at, updated_at) FROM stdin;
1	0244	\N	\N	\N	2025-10-16 03:39:56.965182+00	\N
2	\N	fetch-link-preview	\N	\N	2025-10-16 05:10:29.374546+00	\N
3	0245	\N	\N	\N	2025-10-18 02:17:58.365296+00	\N
4	0246	\N	\N	\N	2025-10-19 18:00:59.337146+00	\N
\.


--
-- Name: api_configs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.api_configs_id_seq', 382, true);


--
-- Name: api_keys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.api_keys_id_seq', 14, true);


--
-- Name: asset_id_pending_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.asset_id_pending_messages_id_seq', 1, false);


--
-- Name: asset_id_registry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.asset_id_registry_id_seq', 645, true);


--
-- Name: asset_id_relationships_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.asset_id_relationships_id_seq', 154, true);


--
-- Name: asset_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.asset_links_id_seq', 116, true);


--
-- Name: asset_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.asset_messages_id_seq', 4, true);


--
-- Name: asset_pool_files_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.asset_pool_files_id_seq', 1, false);


--
-- Name: asset_tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.asset_tags_id_seq', 1, false);


--
-- Name: assets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.assets_id_seq', 1, false);


--
-- Name: blueprint_nodes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.blueprint_nodes_id_seq', 101, true);


--
-- Name: blueprint_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.blueprint_templates_id_seq', 6, true);


--
-- Name: blueprints_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.blueprints_id_seq', 1, true);


--
-- Name: breaks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.breaks_id_seq', 1, false);


--
-- Name: cue_blocks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.cue_blocks_id_seq', 1, false);


--
-- Name: cues_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.cues_id_seq', 99, true);


--
-- Name: elements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.elements_id_seq', 1, false);


--
-- Name: episode_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.episode_templates_id_seq', 12, true);


--
-- Name: episodes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.episodes_id_seq', 33, true);


--
-- Name: extracted_quotes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.extracted_quotes_id_seq', 7, true);


--
-- Name: groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.groups_id_seq', 3, true);


--
-- Name: link_preview_cache_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.link_preview_cache_id_seq', 21, true);


--
-- Name: organizations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.organizations_id_seq', 7, true);


--
-- Name: permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.permissions_id_seq', 25, true);


--
-- Name: processing_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.processing_jobs_id_seq', 1, false);


--
-- Name: rbac_audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.rbac_audit_log_id_seq', 1, true);


--
-- Name: regions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.regions_id_seq', 1, false);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.roles_id_seq', 5, true);


--
-- Name: rundown_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.rundown_items_id_seq', 371, true);


--
-- Name: rundown_items_legacy_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.rundown_items_legacy_id_seq', 1, false);


--
-- Name: rundowns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.rundowns_id_seq', 28, true);


--
-- Name: scratchpad_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.scratchpad_items_id_seq', 45, true);


--
-- Name: scratchpads_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.scratchpads_id_seq', 4, true);


--
-- Name: scripts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.scripts_id_seq', 1, false);


--
-- Name: seasons_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.seasons_id_seq', 1, true);


--
-- Name: segments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.segments_id_seq', 45, true);


--
-- Name: settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.settings_id_seq', 450, true);


--
-- Name: shows_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.shows_id_seq', 2, true);


--
-- Name: sot_processing_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.sot_processing_jobs_id_seq', 3, true);


--
-- Name: speakers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.speakers_id_seq', 4, true);


--
-- Name: twitter_oauth_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.twitter_oauth_tokens_id_seq', 1, false);


--
-- Name: user_permission_overrides_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.user_permission_overrides_id_seq', 1, false);


--
-- Name: user_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.user_sessions_id_seq', 1, false);


--
-- Name: user_todos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.user_todos_id_seq', 7, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.users_id_seq', 5, true);


--
-- Name: whiteboard_node_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: showbuild
--

SELECT pg_catalog.setval('public.whiteboard_node_links_id_seq', 1, false);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: api_configs api_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.api_configs
    ADD CONSTRAINT api_configs_pkey PRIMARY KEY (id);


--
-- Name: api_configs api_configs_workflow_category_service_config_key_key; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.api_configs
    ADD CONSTRAINT api_configs_workflow_category_service_config_key_key UNIQUE (workflow, category, service, config_key);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: asset_id_pending_messages asset_id_pending_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.asset_id_pending_messages
    ADD CONSTRAINT asset_id_pending_messages_pkey PRIMARY KEY (id);


--
-- Name: asset_id_registry asset_id_registry_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.asset_id_registry
    ADD CONSTRAINT asset_id_registry_pkey PRIMARY KEY (id);


--
-- Name: asset_id_relationships asset_id_relationships_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.asset_id_relationships
    ADD CONSTRAINT asset_id_relationships_pkey PRIMARY KEY (id);


--
-- Name: asset_links asset_links_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.asset_links
    ADD CONSTRAINT asset_links_pkey PRIMARY KEY (id);


--
-- Name: asset_messages asset_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.asset_messages
    ADD CONSTRAINT asset_messages_pkey PRIMARY KEY (id);


--
-- Name: asset_pool_files asset_pool_files_asset_id_key; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.asset_pool_files
    ADD CONSTRAINT asset_pool_files_asset_id_key UNIQUE (asset_id);


--
-- Name: asset_pool_files asset_pool_files_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.asset_pool_files
    ADD CONSTRAINT asset_pool_files_pkey PRIMARY KEY (id);


--
-- Name: asset_tags asset_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.asset_tags
    ADD CONSTRAINT asset_tags_pkey PRIMARY KEY (id);


--
-- Name: assets assets_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT assets_pkey PRIMARY KEY (id);


--
-- Name: blueprint_nodes blueprint_nodes_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.blueprint_nodes
    ADD CONSTRAINT blueprint_nodes_pkey PRIMARY KEY (id);


--
-- Name: blueprint_templates blueprint_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.blueprint_templates
    ADD CONSTRAINT blueprint_templates_pkey PRIMARY KEY (id);


--
-- Name: blueprints blueprints_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.blueprints
    ADD CONSTRAINT blueprints_pkey PRIMARY KEY (id);


--
-- Name: breaks breaks_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.breaks
    ADD CONSTRAINT breaks_pkey PRIMARY KEY (id);


--
-- Name: cue_blocks cue_blocks_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.cue_blocks
    ADD CONSTRAINT cue_blocks_pkey PRIMARY KEY (id);


--
-- Name: cues cues_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.cues
    ADD CONSTRAINT cues_pkey PRIMARY KEY (id);


--
-- Name: elements elements_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.elements
    ADD CONSTRAINT elements_pkey PRIMARY KEY (id);


--
-- Name: episode_templates episode_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.episode_templates
    ADD CONSTRAINT episode_templates_pkey PRIMARY KEY (id);


--
-- Name: episodes episodes_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.episodes
    ADD CONSTRAINT episodes_pkey PRIMARY KEY (id);


--
-- Name: extracted_quotes extracted_quotes_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.extracted_quotes
    ADD CONSTRAINT extracted_quotes_pkey PRIMARY KEY (id);


--
-- Name: group_roles group_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.group_roles
    ADD CONSTRAINT group_roles_pkey PRIMARY KEY (group_id, role_id);


--
-- Name: groups groups_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_pkey PRIMARY KEY (id);


--
-- Name: link_preview_cache link_preview_cache_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.link_preview_cache
    ADD CONSTRAINT link_preview_cache_pkey PRIMARY KEY (id);


--
-- Name: llm_notifications llm_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.llm_notifications
    ADD CONSTRAINT llm_notifications_pkey PRIMARY KEY (id);


--
-- Name: llm_operations llm_operations_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.llm_operations
    ADD CONSTRAINT llm_operations_pkey PRIMARY KEY (id);


--
-- Name: organizations organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: processing_jobs processing_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.processing_jobs
    ADD CONSTRAINT processing_jobs_pkey PRIMARY KEY (id);


--
-- Name: prompt_overrides prompt_overrides_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.prompt_overrides
    ADD CONSTRAINT prompt_overrides_pkey PRIMARY KEY (id);


--
-- Name: rbac_audit_log rbac_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.rbac_audit_log
    ADD CONSTRAINT rbac_audit_log_pkey PRIMARY KEY (id);


--
-- Name: regions regions_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.regions
    ADD CONSTRAINT regions_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (role_id, permission_id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: rundown_items_legacy rundown_items_legacy_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.rundown_items_legacy
    ADD CONSTRAINT rundown_items_legacy_pkey PRIMARY KEY (id);


--
-- Name: rundown_items rundown_items_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.rundown_items
    ADD CONSTRAINT rundown_items_pkey PRIMARY KEY (id);


--
-- Name: rundowns rundowns_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.rundowns
    ADD CONSTRAINT rundowns_pkey PRIMARY KEY (id);


--
-- Name: whiteboard_items scratchpad_items_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.whiteboard_items
    ADD CONSTRAINT scratchpad_items_pkey PRIMARY KEY (id);


--
-- Name: whiteboards scratchpads_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.whiteboards
    ADD CONSTRAINT scratchpads_pkey PRIMARY KEY (id);


--
-- Name: scripts scripts_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.scripts
    ADD CONSTRAINT scripts_pkey PRIMARY KEY (id);


--
-- Name: seasons seasons_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.seasons
    ADD CONSTRAINT seasons_pkey PRIMARY KEY (id);


--
-- Name: segments segments_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.segments
    ADD CONSTRAINT segments_pkey PRIMARY KEY (id);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (id);


--
-- Name: shows shows_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.shows
    ADD CONSTRAINT shows_pkey PRIMARY KEY (id);


--
-- Name: sot_processing_jobs sot_processing_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.sot_processing_jobs
    ADD CONSTRAINT sot_processing_jobs_pkey PRIMARY KEY (id);


--
-- Name: speakers speakers_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.speakers
    ADD CONSTRAINT speakers_pkey PRIMARY KEY (id);


--
-- Name: speakers speakers_slug_key; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.speakers
    ADD CONSTRAINT speakers_slug_key UNIQUE (slug);


--
-- Name: twitter_oauth_tokens twitter_oauth_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.twitter_oauth_tokens
    ADD CONSTRAINT twitter_oauth_tokens_pkey PRIMARY KEY (id);


--
-- Name: user_groups user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.user_groups
    ADD CONSTRAINT user_groups_pkey PRIMARY KEY (user_id, group_id);


--
-- Name: user_permission_overrides user_permission_overrides_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.user_permission_overrides
    ADD CONSTRAINT user_permission_overrides_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (user_id, role_id);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- Name: user_todos user_todos_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.user_todos
    ADD CONSTRAINT user_todos_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: whiteboard_node_links whiteboard_node_links_pkey; Type: CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.whiteboard_node_links
    ADD CONSTRAINT whiteboard_node_links_pkey PRIMARY KEY (id);


--
-- Name: idx_asset_pool_asset_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX idx_asset_pool_asset_id ON public.asset_pool_files USING btree (asset_id);


--
-- Name: idx_asset_pool_source; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX idx_asset_pool_source ON public.asset_pool_files USING btree (source);


--
-- Name: idx_asset_tags_asset_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX idx_asset_tags_asset_id ON public.asset_tags USING btree (asset_id);


--
-- Name: idx_asset_tags_tag; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX idx_asset_tags_tag ON public.asset_tags USING btree (tag);


--
-- Name: idx_link_preview_url_hash; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX idx_link_preview_url_hash ON public.link_preview_cache USING btree (url_hash);


--
-- Name: idx_llm_notifications_user_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX idx_llm_notifications_user_id ON public.llm_notifications USING btree (user_id);


--
-- Name: idx_llm_operations_user_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX idx_llm_operations_user_id ON public.llm_operations USING btree (user_id);


--
-- Name: idx_node_links_source; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX idx_node_links_source ON public.whiteboard_node_links USING btree (source_item_id);


--
-- Name: idx_node_links_target; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX idx_node_links_target ON public.whiteboard_node_links USING btree (target_item_id);


--
-- Name: idx_prompt_overrides_category_operation; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE UNIQUE INDEX idx_prompt_overrides_category_operation ON public.prompt_overrides USING btree (category, operation_key);


--
-- Name: idx_prompt_overrides_enabled; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX idx_prompt_overrides_enabled ON public.prompt_overrides USING btree (is_enabled);


--
-- Name: ix_api_keys_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_api_keys_id ON public.api_keys USING btree (id);


--
-- Name: ix_api_keys_key_hash; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE UNIQUE INDEX ix_api_keys_key_hash ON public.api_keys USING btree (key_hash);


--
-- Name: ix_api_keys_key_prefix; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_api_keys_key_prefix ON public.api_keys USING btree (key_prefix);


--
-- Name: ix_asset_id_pending_messages_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_asset_id_pending_messages_id ON public.asset_id_pending_messages USING btree (id);


--
-- Name: ix_asset_id_pending_messages_pending_asset_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_asset_id_pending_messages_pending_asset_id ON public.asset_id_pending_messages USING btree (pending_asset_id);


--
-- Name: ix_asset_id_registry_asset_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE UNIQUE INDEX ix_asset_id_registry_asset_id ON public.asset_id_registry USING btree (asset_id);


--
-- Name: ix_asset_id_registry_entity_type; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_asset_id_registry_entity_type ON public.asset_id_registry USING btree (entity_type);


--
-- Name: ix_asset_id_registry_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_asset_id_registry_id ON public.asset_id_registry USING btree (id);


--
-- Name: ix_asset_id_relationships_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_asset_id_relationships_id ON public.asset_id_relationships USING btree (id);


--
-- Name: ix_asset_id_relationships_relationship_type; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_asset_id_relationships_relationship_type ON public.asset_id_relationships USING btree (relationship_type);


--
-- Name: ix_asset_id_relationships_source_asset_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_asset_id_relationships_source_asset_id ON public.asset_id_relationships USING btree (source_asset_id);


--
-- Name: ix_asset_id_relationships_target_asset_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_asset_id_relationships_target_asset_id ON public.asset_id_relationships USING btree (target_asset_id);


--
-- Name: ix_asset_links_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_asset_links_id ON public.asset_links USING btree (id);


--
-- Name: ix_asset_links_source_asset_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_asset_links_source_asset_id ON public.asset_links USING btree (source_asset_id);


--
-- Name: ix_asset_links_target_asset_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_asset_links_target_asset_id ON public.asset_links USING btree (target_asset_id);


--
-- Name: ix_asset_messages_asset_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_asset_messages_asset_id ON public.asset_messages USING btree (asset_id);


--
-- Name: ix_asset_messages_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_asset_messages_id ON public.asset_messages USING btree (id);


--
-- Name: ix_assets_asset_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_assets_asset_id ON public.assets USING btree (asset_id);


--
-- Name: ix_assets_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_assets_id ON public.assets USING btree (id);


--
-- Name: ix_assets_slug; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_assets_slug ON public.assets USING btree (slug);


--
-- Name: ix_blueprint_nodes_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_blueprint_nodes_id ON public.blueprint_nodes USING btree (id);


--
-- Name: ix_blueprint_templates_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_blueprint_templates_id ON public.blueprint_templates USING btree (id);


--
-- Name: ix_blueprint_templates_name; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE UNIQUE INDEX ix_blueprint_templates_name ON public.blueprint_templates USING btree (name);


--
-- Name: ix_blueprint_templates_parent_template_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_blueprint_templates_parent_template_id ON public.blueprint_templates USING btree (parent_template_id);


--
-- Name: ix_blueprint_templates_template_type; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_blueprint_templates_template_type ON public.blueprint_templates USING btree (template_type);


--
-- Name: ix_blueprints_episode_number; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE UNIQUE INDEX ix_blueprints_episode_number ON public.blueprints USING btree (episode_number);


--
-- Name: ix_blueprints_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_blueprints_id ON public.blueprints USING btree (id);


--
-- Name: ix_blueprints_status; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_blueprints_status ON public.blueprints USING btree (status);


--
-- Name: ix_breaks_asset_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE UNIQUE INDEX ix_breaks_asset_id ON public.breaks USING btree (asset_id);


--
-- Name: ix_breaks_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_breaks_id ON public.breaks USING btree (id);


--
-- Name: ix_cue_blocks_asset_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_cue_blocks_asset_id ON public.cue_blocks USING btree (asset_id);


--
-- Name: ix_cue_blocks_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_cue_blocks_id ON public.cue_blocks USING btree (id);


--
-- Name: ix_cue_blocks_slug; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_cue_blocks_slug ON public.cue_blocks USING btree (slug);


--
-- Name: ix_cues_asset_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE UNIQUE INDEX ix_cues_asset_id ON public.cues USING btree (asset_id);


--
-- Name: ix_cues_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_cues_id ON public.cues USING btree (id);


--
-- Name: ix_elements_asset_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE UNIQUE INDEX ix_elements_asset_id ON public.elements USING btree (asset_id);


--
-- Name: ix_elements_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_elements_id ON public.elements USING btree (id);


--
-- Name: ix_episode_templates_episode_number; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE UNIQUE INDEX ix_episode_templates_episode_number ON public.episode_templates USING btree (episode_number);


--
-- Name: ix_episode_templates_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_episode_templates_id ON public.episode_templates USING btree (id);


--
-- Name: ix_episode_templates_status; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_episode_templates_status ON public.episode_templates USING btree (status);


--
-- Name: ix_episodes_asset_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE UNIQUE INDEX ix_episodes_asset_id ON public.episodes USING btree (asset_id);


--
-- Name: ix_episodes_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_episodes_id ON public.episodes USING btree (id);


--
-- Name: ix_extracted_quotes_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_extracted_quotes_id ON public.extracted_quotes USING btree (id);


--
-- Name: ix_extracted_quotes_quote_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_extracted_quotes_quote_id ON public.extracted_quotes USING btree (quote_id);


--
-- Name: ix_extracted_quotes_slug; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_extracted_quotes_slug ON public.extracted_quotes USING btree (slug);


--
-- Name: ix_groups_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_groups_id ON public.groups USING btree (id);


--
-- Name: ix_groups_name; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_groups_name ON public.groups USING btree (name);


--
-- Name: ix_groups_organization_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_groups_organization_id ON public.groups USING btree (organization_id);


--
-- Name: ix_groups_slug; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_groups_slug ON public.groups USING btree (slug);


--
-- Name: ix_link_preview_cache_url_hash; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE UNIQUE INDEX ix_link_preview_cache_url_hash ON public.link_preview_cache USING btree (url_hash);


--
-- Name: ix_organizations_asset_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE UNIQUE INDEX ix_organizations_asset_id ON public.organizations USING btree (asset_id);


--
-- Name: ix_organizations_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_organizations_id ON public.organizations USING btree (id);


--
-- Name: ix_permissions_action; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_permissions_action ON public.permissions USING btree (action);


--
-- Name: ix_permissions_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_permissions_id ON public.permissions USING btree (id);


--
-- Name: ix_permissions_name; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE UNIQUE INDEX ix_permissions_name ON public.permissions USING btree (name);


--
-- Name: ix_permissions_resource; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_permissions_resource ON public.permissions USING btree (resource);


--
-- Name: ix_processing_jobs_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_processing_jobs_id ON public.processing_jobs USING btree (id);


--
-- Name: ix_processing_jobs_job_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_processing_jobs_job_id ON public.processing_jobs USING btree (job_id);


--
-- Name: ix_rbac_audit_log_action; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_rbac_audit_log_action ON public.rbac_audit_log USING btree (action);


--
-- Name: ix_rbac_audit_log_created_at; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_rbac_audit_log_created_at ON public.rbac_audit_log USING btree (created_at);


--
-- Name: ix_rbac_audit_log_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_rbac_audit_log_id ON public.rbac_audit_log USING btree (id);


--
-- Name: ix_regions_asset_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE UNIQUE INDEX ix_regions_asset_id ON public.regions USING btree (asset_id);


--
-- Name: ix_regions_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_regions_id ON public.regions USING btree (id);


--
-- Name: ix_roles_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_roles_id ON public.roles USING btree (id);


--
-- Name: ix_roles_name; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE UNIQUE INDEX ix_roles_name ON public.roles USING btree (name);


--
-- Name: ix_roles_slug; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE UNIQUE INDEX ix_roles_slug ON public.roles USING btree (slug);


--
-- Name: ix_rundown_items_asset_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE UNIQUE INDEX ix_rundown_items_asset_id ON public.rundown_items USING btree (asset_id);


--
-- Name: ix_rundown_items_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_rundown_items_id ON public.rundown_items USING btree (id);


--
-- Name: ix_rundown_items_legacy_asset_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_rundown_items_legacy_asset_id ON public.rundown_items_legacy USING btree (asset_id);


--
-- Name: ix_rundown_items_legacy_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_rundown_items_legacy_id ON public.rundown_items_legacy USING btree (id);


--
-- Name: ix_rundown_items_legacy_slug; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_rundown_items_legacy_slug ON public.rundown_items_legacy USING btree (slug);


--
-- Name: ix_rundowns_asset_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE UNIQUE INDEX ix_rundowns_asset_id ON public.rundowns USING btree (asset_id);


--
-- Name: ix_rundowns_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_rundowns_id ON public.rundowns USING btree (id);


--
-- Name: ix_scratchpads_episode_number; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_scratchpads_episode_number ON public.whiteboards USING btree (episode_number);


--
-- Name: ix_scratchpads_workspace_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_scratchpads_workspace_id ON public.whiteboards USING btree (workspace_id);


--
-- Name: ix_scripts_asset_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE UNIQUE INDEX ix_scripts_asset_id ON public.scripts USING btree (asset_id);


--
-- Name: ix_scripts_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_scripts_id ON public.scripts USING btree (id);


--
-- Name: ix_seasons_asset_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE UNIQUE INDEX ix_seasons_asset_id ON public.seasons USING btree (asset_id);


--
-- Name: ix_seasons_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_seasons_id ON public.seasons USING btree (id);


--
-- Name: ix_segments_asset_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE UNIQUE INDEX ix_segments_asset_id ON public.segments USING btree (asset_id);


--
-- Name: ix_segments_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_segments_id ON public.segments USING btree (id);


--
-- Name: ix_segments_slug; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_segments_slug ON public.segments USING btree (slug);


--
-- Name: ix_settings_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_settings_id ON public.settings USING btree (id);


--
-- Name: ix_settings_key; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE UNIQUE INDEX ix_settings_key ON public.settings USING btree (key);


--
-- Name: ix_shows_asset_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE UNIQUE INDEX ix_shows_asset_id ON public.shows USING btree (asset_id);


--
-- Name: ix_shows_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_shows_id ON public.shows USING btree (id);


--
-- Name: ix_sot_processing_jobs_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_sot_processing_jobs_id ON public.sot_processing_jobs USING btree (id);


--
-- Name: ix_sot_processing_jobs_temp_job_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE UNIQUE INDEX ix_sot_processing_jobs_temp_job_id ON public.sot_processing_jobs USING btree (temp_job_id);


--
-- Name: ix_speakers_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_speakers_id ON public.speakers USING btree (id);


--
-- Name: ix_speakers_name; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_speakers_name ON public.speakers USING btree (name);


--
-- Name: ix_speakers_slug; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE UNIQUE INDEX ix_speakers_slug ON public.speakers USING btree (slug);


--
-- Name: ix_speakers_user_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_speakers_user_id ON public.speakers USING btree (user_id);


--
-- Name: ix_twitter_oauth_tokens_user_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_twitter_oauth_tokens_user_id ON public.twitter_oauth_tokens USING btree (user_id);


--
-- Name: ix_user_permission_overrides_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_user_permission_overrides_id ON public.user_permission_overrides USING btree (id);


--
-- Name: ix_user_permission_overrides_permission_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_user_permission_overrides_permission_id ON public.user_permission_overrides USING btree (permission_id);


--
-- Name: ix_user_permission_overrides_user_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_user_permission_overrides_user_id ON public.user_permission_overrides USING btree (user_id);


--
-- Name: ix_user_sessions_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_user_sessions_id ON public.user_sessions USING btree (id);


--
-- Name: ix_user_sessions_session_token; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE UNIQUE INDEX ix_user_sessions_session_token ON public.user_sessions USING btree (session_token);


--
-- Name: ix_user_sessions_username; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_user_sessions_username ON public.user_sessions USING btree (username);


--
-- Name: ix_user_todos_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_user_todos_id ON public.user_todos USING btree (id);


--
-- Name: ix_users_id; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE INDEX ix_users_id ON public.users USING btree (id);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: showbuild
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: asset_pool_files asset_pool_files_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.asset_pool_files
    ADD CONSTRAINT asset_pool_files_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES public.asset_id_registry(asset_id) ON DELETE CASCADE;


--
-- Name: asset_tags asset_tags_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.asset_tags
    ADD CONSTRAINT asset_tags_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES public.asset_id_registry(asset_id) ON DELETE CASCADE;


--
-- Name: blueprint_nodes blueprint_nodes_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.blueprint_nodes
    ADD CONSTRAINT blueprint_nodes_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.blueprint_nodes(id) ON DELETE CASCADE;


--
-- Name: blueprint_nodes blueprint_nodes_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.blueprint_nodes
    ADD CONSTRAINT blueprint_nodes_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.blueprint_templates(id) ON DELETE CASCADE;


--
-- Name: blueprints blueprints_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.blueprints
    ADD CONSTRAINT blueprints_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: blueprints blueprints_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.blueprints
    ADD CONSTRAINT blueprints_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE SET NULL;


--
-- Name: blueprints blueprints_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.blueprints
    ADD CONSTRAINT blueprints_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.blueprint_templates(id) ON DELETE SET NULL;


--
-- Name: breaks breaks_episode_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.breaks
    ADD CONSTRAINT breaks_episode_id_fkey FOREIGN KEY (episode_id) REFERENCES public.episodes(id);


--
-- Name: cue_blocks cue_blocks_rundown_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.cue_blocks
    ADD CONSTRAINT cue_blocks_rundown_item_id_fkey FOREIGN KEY (rundown_item_id) REFERENCES public.rundown_items_legacy(id);


--
-- Name: cues cues_element_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.cues
    ADD CONSTRAINT cues_element_id_fkey FOREIGN KEY (element_id) REFERENCES public.elements(id);


--
-- Name: elements elements_segment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.elements
    ADD CONSTRAINT elements_segment_id_fkey FOREIGN KEY (segment_id) REFERENCES public.segments(id);


--
-- Name: episode_templates episode_templates_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.episode_templates
    ADD CONSTRAINT episode_templates_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: episode_templates episode_templates_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.episode_templates
    ADD CONSTRAINT episode_templates_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE SET NULL;


--
-- Name: episode_templates episode_templates_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.episode_templates
    ADD CONSTRAINT episode_templates_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.blueprint_templates(id) ON DELETE SET NULL;


--
-- Name: episodes episodes_season_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.episodes
    ADD CONSTRAINT episodes_season_id_fkey FOREIGN KEY (season_id) REFERENCES public.seasons(id);


--
-- Name: blueprint_templates fk_blueprint_templates_parent; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.blueprint_templates
    ADD CONSTRAINT fk_blueprint_templates_parent FOREIGN KEY (parent_template_id) REFERENCES public.blueprint_templates(id) ON DELETE SET NULL;


--
-- Name: users fk_users_organization; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fk_users_organization FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: whiteboard_items fk_whiteboard_items_asset_id; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.whiteboard_items
    ADD CONSTRAINT fk_whiteboard_items_asset_id FOREIGN KEY (asset_id) REFERENCES public.asset_id_registry(asset_id) ON DELETE SET NULL;


--
-- Name: whiteboard_items fk_whiteboard_items_parent_item_id; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.whiteboard_items
    ADD CONSTRAINT fk_whiteboard_items_parent_item_id FOREIGN KEY (parent_item_id) REFERENCES public.whiteboard_items(id) ON DELETE CASCADE;


--
-- Name: group_roles group_roles_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.group_roles
    ADD CONSTRAINT group_roles_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id);


--
-- Name: group_roles group_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.group_roles
    ADD CONSTRAINT group_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id);


--
-- Name: groups groups_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: llm_notifications llm_notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.llm_notifications
    ADD CONSTRAINT llm_notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: llm_operations llm_operations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.llm_operations
    ADD CONSTRAINT llm_operations_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: rbac_audit_log rbac_audit_log_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.rbac_audit_log
    ADD CONSTRAINT rbac_audit_log_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: regions regions_rundown_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.regions
    ADD CONSTRAINT regions_rundown_id_fkey FOREIGN KEY (rundown_id) REFERENCES public.rundowns(id);


--
-- Name: role_permissions role_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES public.permissions(id);


--
-- Name: role_permissions role_permissions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id);


--
-- Name: roles roles_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: roles roles_parent_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_parent_role_id_fkey FOREIGN KEY (parent_role_id) REFERENCES public.roles(id);


--
-- Name: rundown_items rundown_items_rundown_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.rundown_items
    ADD CONSTRAINT rundown_items_rundown_id_fkey FOREIGN KEY (rundown_id) REFERENCES public.rundowns(id);


--
-- Name: rundown_items rundown_items_segment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.rundown_items
    ADD CONSTRAINT rundown_items_segment_id_fkey FOREIGN KEY (segment_id) REFERENCES public.segments(id);


--
-- Name: rundown_items rundown_items_speaker_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.rundown_items
    ADD CONSTRAINT rundown_items_speaker_id_fkey FOREIGN KEY (speaker_id) REFERENCES public.speakers(id);


--
-- Name: rundowns rundowns_episode_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.rundowns
    ADD CONSTRAINT rundowns_episode_id_fkey FOREIGN KEY (episode_id) REFERENCES public.episodes(id);


--
-- Name: whiteboard_items scratchpad_items_scratchpad_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.whiteboard_items
    ADD CONSTRAINT scratchpad_items_scratchpad_id_fkey FOREIGN KEY (whiteboard_id) REFERENCES public.whiteboards(id) ON DELETE CASCADE;


--
-- Name: whiteboards scratchpads_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.whiteboards
    ADD CONSTRAINT scratchpads_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: scripts scripts_segment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.scripts
    ADD CONSTRAINT scripts_segment_id_fkey FOREIGN KEY (segment_id) REFERENCES public.segments(id);


--
-- Name: seasons seasons_show_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.seasons
    ADD CONSTRAINT seasons_show_id_fkey FOREIGN KEY (show_id) REFERENCES public.shows(id);


--
-- Name: segments segments_episode_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.segments
    ADD CONSTRAINT segments_episode_id_fkey FOREIGN KEY (episode_id) REFERENCES public.episodes(id);


--
-- Name: settings settings_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: shows shows_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.shows
    ADD CONSTRAINT shows_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: speakers speakers_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.speakers
    ADD CONSTRAINT speakers_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: speakers speakers_show_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.speakers
    ADD CONSTRAINT speakers_show_id_fkey FOREIGN KEY (show_id) REFERENCES public.shows(id);


--
-- Name: speakers speakers_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.speakers
    ADD CONSTRAINT speakers_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: twitter_oauth_tokens twitter_oauth_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.twitter_oauth_tokens
    ADD CONSTRAINT twitter_oauth_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_groups user_groups_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.user_groups
    ADD CONSTRAINT user_groups_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id);


--
-- Name: user_groups user_groups_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.user_groups
    ADD CONSTRAINT user_groups_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: user_permission_overrides user_permission_overrides_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.user_permission_overrides
    ADD CONSTRAINT user_permission_overrides_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES public.permissions(id);


--
-- Name: user_permission_overrides user_permission_overrides_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.user_permission_overrides
    ADD CONSTRAINT user_permission_overrides_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: user_roles user_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id);


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: whiteboard_node_links whiteboard_node_links_source_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.whiteboard_node_links
    ADD CONSTRAINT whiteboard_node_links_source_item_id_fkey FOREIGN KEY (source_item_id) REFERENCES public.whiteboard_items(id) ON DELETE CASCADE;


--
-- Name: whiteboard_node_links whiteboard_node_links_target_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.whiteboard_node_links
    ADD CONSTRAINT whiteboard_node_links_target_item_id_fkey FOREIGN KEY (target_item_id) REFERENCES public.whiteboard_items(id) ON DELETE CASCADE;


--
-- Name: whiteboard_node_links whiteboard_node_links_whiteboard_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: showbuild
--

ALTER TABLE ONLY public.whiteboard_node_links
    ADD CONSTRAINT whiteboard_node_links_whiteboard_id_fkey FOREIGN KEY (whiteboard_id) REFERENCES public.whiteboards(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict IcLrdC3Vutvfkk7pvhxzK8VD6y7V66rBtwjXEEmLDirMkM8wIxLBDJzxscsQtJc

